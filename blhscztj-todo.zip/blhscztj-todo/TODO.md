# blhscztj 剩余任务（接续版）

- 仓库：`13510954098/blhscztj`，分支 `main`
- 本包整理时 main 的最新提交：`350e101 Delete fetch_jcnode.py`
- 本包内容：
  - `TODO.md`：本说明
  - `files/.gitignore`：要放到仓库根目录的完整 `.gitignore`

> **重要：之前交接包（blhscztj-handoff）的代码改动已经全部在 main 上了，不要再应用 `changes.patch`。** 那些改动是：晚间只测活、`geoip.metadb` 去重、`fetch_jcnode.py` 移入 `scripts/`、清理未使用代码。对应提交为 be5b470、9257d10、08be968、350e101。

---

## 已完成（只用于核对，不要重做）

| 项目 | 状态 |
|---|---|
| `update.yml`、`schedule_gate.py`、`mihomo_alive_check.py`、`normalize_country_groups.py`、`scripts/fetch_jcnode.py`、`tests/test_pipeline.py`、`tests/test_schedule_gate.py` | ✅ 已在 main 上，内容与交接包一致 |
| 删除根目录的 `fetch_jcnode.py` | ✅ 已完成（350e101） |
| 精确定时器 | ✅ 11:00:00 准点唤醒，11:00:10 调起 "Update JCNode subscription"（`workflow_dispatch`） |

---

## 任务 1：更新 `.gitignore`

main 上现在的 `.gitignore` 只有两行（`__pycache__/`、`*.py[cod]`）。要改成 `files/.gitignore` 的内容：

```gitignore
__pycache__/
*.py[cod]
# mihomo -t 在各校验目录生成的 GeoIP 副本；只保留 sub/geoip.metadb
sub/merged/geoip.metadb
sub/alive/geoip.metadb
```

```bash
git checkout main && git pull
cp files/.gitignore .gitignore
git add .gitignore
git commit -m "chore: gitignore 各校验目录生成的 geoip.metadb 副本"
git push            # 改动很小，可以直接推 main；习惯走 PR 也可以
```

- 这只是防止以后误提交，工作流本身已经会在提交前删掉这两个副本。
- **不要**把 `sub/geoip.metadb` 加进 `.gitignore`，它必须保留在仓库里。

---

## 任务 2：仓库清理

需要 `gh` CLI，并对仓库有 admin 或 write 权限。

```bash
export GH_REPO=13510954098/blhscztj
```

### 待清理清单（以本包整理时的状态为准）

| # | 内容 | 处理 |
|---|---|---|
| 1 | 工作流 "TEMP fetch gofile"（`tmp-fetch-gofile.yml`，ID `380956165`），8 条运行记录 | 停用，再删除全部运行记录 |
| 2 | 工作流 "TEMP fetch handoff"（`tmp-fetch-handoff.yml`，ID `380977832`），1 条以上运行记录 | 同上 |
| 3 | 以后如果又有名字以 `TEMP ` 开头的工作流 | 同上（下面的命令按名字前缀匹配，会一并处理） |
| 4 | 工作流 "Tests" 的 2 条失败记录（该工作流文件早已不存在） | 删除记录 |
| 5 | "Update JCNode subscription" 历史上已结束的 failure/cancelled 记录（约 8 条） | 删除记录 |
| 6 | Actions 产物（artifacts），约 14 个、213MB | 保留最新 2 个，其余删除 |
| 7 | 仓库设置 "Automatically delete head branches" | 开启（`delete_branch_on_merge=true`） |
| 8 | 分支 `arena/01a10be5-blhscztj`、`arena/a1d23447-blhscztj`（以及任何其他 `arena/*` 分支） | 删除。**必须最后做**，见下面的说明 |

### 命令

```bash
# 1-3. 停用所有名字以 "TEMP " 开头的工作流，并删除它们的全部运行记录
for wf in $(gh api "repos/$GH_REPO/actions/workflows" --paginate \
              --jq '.workflows[] | select(.name | startswith("TEMP ")) | .id'); do
  gh api -X PUT "repos/$GH_REPO/actions/workflows/$wf/disable" || true
  gh api "repos/$GH_REPO/actions/workflows/$wf/runs" --paginate --jq '.workflow_runs[].id' \
    | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/runs/{}"
  echo "cleaned workflow $wf"
done

# 4-5. 删除 "Tests" 的全部记录，以及 Update 工作流已结束的 failure/cancelled 记录
gh api "repos/$GH_REPO/actions/runs" --paginate \
  --jq '.workflow_runs[]
        | select(.status == "completed")
        | select(.name == "Tests"
                 or (.name == "Update JCNode subscription"
                     and (.conclusion == "failure" or .conclusion == "cancelled")))
        | .id' \
  | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/runs/{}"

# 6. 删除旧产物，保留最新 2 个
gh api "repos/$GH_REPO/actions/artifacts?per_page=100" \
  --jq '.artifacts | sort_by(.created_at) | reverse | .[2:][] | .id' \
  | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/artifacts/{}"

# 7. 开启"合并后自动删除分支"
gh api -X PATCH "repos/$GH_REPO" -F delete_branch_on_merge=true --jq .delete_branch_on_merge   # 期望 true
```

### 第 8 项：删除 `arena/*` 分支（最后做）

- 如果你自己正在用某个 `arena/*` 分支，比如当前 PR 的源分支，**要等那个 PR 合并或关闭之后再删**。
- 第 7 项开启后，以后 PR 合并时分支会自动删除。

```bash
CURRENT=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")
for b in $(gh api "repos/$GH_REPO/branches" --paginate --jq '.[].name | select(startswith("arena/"))'); do
  if [ "$b" = "$CURRENT" ]; then echo "skip current branch $b"; continue; fi
  gh api -X DELETE "repos/$GH_REPO/git/refs/heads/$b" && echo "deleted branch $b"
done
```

### 清理后的检查

```bash
gh api "repos/$GH_REPO/branches" --jq '[.[].name]'
#   期望 ["main"]（如果你自己的分支还在用，允许多出这一个）
gh api "repos/$GH_REPO/actions/workflows" --jq '[.workflows[] | "\(.name):\(.state)"]'
#   期望 "Precise timer:active"、"Update JCNode subscription:active"
#   TEMP 工作流如果还在列表里，状态必须是 disabled_manually；运行记录删光后通常会自动消失
gh api "repos/$GH_REPO/actions/runs?per_page=100" \
  --jq '[.workflow_runs[] | select(.name=="Tests" or (.name|startswith("TEMP ")))] | length'   # 期望 0
gh api "repos/$GH_REPO/actions/artifacts" --jq .total_count               # 期望 ≤ 2（新运行会再产生）
gh api "repos/$GH_REPO" --jq .delete_branch_on_merge                      # 期望 true
```

---

## 任务 3：今天的运行验收（只观察，不修改）

| 时间点 | 检查 | 期望 |
|---|---|---|
| 11:00 那次更新跑完后（大约 11:30–11:45） | "Update JCNode subscription" 的运行 38106966998 | 结论为 success；提交标题为 `chore(sub): 去重合并 JCNode 订阅 2026-10-11 …`；`.schedule/success.json` 里的 `slot` 为 `2026-10-11/11:00` |
| 同上 | 存活订阅 | `sub/alive/meta.json` 的 `generated_at` 为 10-11；当天订阅 `sub/clash.yaml` 中的部分节点出现在 `sub/alive/clash.yaml` 里 |
| 第一次由新版工作流跑出的提交（最晚是 21:00 那次） | `geoip.metadb` 去重 | `sub/merged/geoip.metadb`、`sub/alive/geoip.metadb` 已从仓库删除；`sub/geoip.metadb` 仍在 |
| 21:00 | 定时器调起更新 | 在 21:00 后几分钟内出现一条 `workflow_dispatch` 运行 |
| 21:00 那次运行 | gate 的 Step Summary | `mode: alive`（前提是 11:00 那次成功）。抓取、修复、保存、合并、路径修复这 5 步为 skipped；提交标题为 `chore(alive): 晚间复测存活节点 2026-10-11 …` |

说明：11:00 那次运行启动时，新代码还没上传，所以它跑的是旧版工作流，不会出现 `mode` 输出，也不会删除 `geoip.metadb` 副本。这是正常的。

### 如果验收不通过

- **11:00 那次失败了**：定时器会每隔 ≥30 分钟自动重试，每个时段最多 4 次。不需要手动处理，记录失败步骤的日志即可。
- **21:00 后 10 分钟内没出现更新运行**：检查 "Precise timer" 是否还有一条正在运行或排队。都没有就说明任务链断了，手动运行一次 "Precise timer"（`workflow_dispatch`，参数都留空）即可恢复。
- **21:00 显示 `mode: full`**：先确认 `.schedule/success.json` 是不是 `2026-10-11/11:00`。不是的话，说明 11:00 那次没有成功发布，`full` 是正确的。

---

## 不要做的事

- 不要应用旧交接包里的 `changes.patch`，改动已经在 main 上了。
- 不要删除或取消正在运行、排队的 "Precise timer" / "Update JCNode subscription" 记录。
- 不要手动改动 `sub/`、`history/`、`.schedule/` 里的数据。
- 不要删除 `sub/geoip.metadb`。
- 不要裁剪综合订阅（`sub/merged`）里的节点。
- 不要修改 `timer.yml`，也不要改 `schedule_gate.py` 里 `plan()` 的参数。
- 不要改写 git 历史（filter-repo、force push）。
