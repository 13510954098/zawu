#!/usr/bin/env python3
# 本地静态服务器：python3 serve.py  然后访问 http://localhost:8000
import http.server, socketserver, os, sys
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = dict(http.server.SimpleHTTPRequestHandler.extensions_map)
    extensions_map.update({".js": "application/javascript", ".mjs": "application/javascript",
        ".json": "application/json", ".css": "text/css", ".wasm": "application/wasm",
        ".svg": "image/svg+xml", ".webp": "image/webp", ".avif": "image/avif", ".woff2": "font/woff2"})
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()
class TS(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
with TS(("0.0.0.0", PORT), H) as httpd:
    print("Serving at http://localhost:%d" % PORT)
    httpd.serve_forever()