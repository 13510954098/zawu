# 网站克隆导出包

由「网站克隆器 & 动态记录器 v1.0.0」导出 · 2026-10-25T06:27:36.263Z
原始地址: https://arena.ai/agent/01a171bb-995f-735c-ba8e-7b317161d16a

## 目录结构

    index.html            重写后的页面（资源已本地化，双击可打开）
    assets/               克隆的静态资源 (css/js/img/fonts/media/frames)
    recording.js/json     动态记录数据（网络/DOM/事件/控制台/错误/WebSocket）
    recording/responses/  录制期间捕获的响应体文件
    recording/dom/        DOM 快照
    replay.html           记录回放查看器（打开它可浏览整段动态记录）
    serve.py              本地静态服务器（可选）

## 本地调试

1. 简单方式：直接用浏览器打开 index.html（file:// 协议）。
2. 推荐方式（页面行为更接近线上）:

       python3 serve.py 8000
       # 或: python3 -m http.server 8000

   然后访问 http://localhost:8000/
3. 打开 replay.html 查看动态记录：网络请求（含响应体）、用户操作轨迹、DOM 变更、控制台与报错，按时间线还原 bug 现场。

## 调试建议

- 网络面板中每条请求的「响应体」可直接下载对照，排查数据问题。
- 「事件」页是用户操作回放（点击/输入/滚动），可据此复现步骤。
- 「DOM 变更」配合 recording/dom/ 快照可定位界面状态问题。
- 若本地打开缺资源，多为跨域资源未授权下载，见 recording 中的 error 或控制台。

## 重要说明

- 本包仅用于你有权测试/调试的网站，请勿用于未授权复制或分发他人站点内容。
- 跨域 iframe（不同域名）内容无法克隆，保留原 URL，本地打开需联网。
- 需要登录态/动态接口的页面，本地静态克隆无法复现真实后端行为，请配合录制数据排查。
