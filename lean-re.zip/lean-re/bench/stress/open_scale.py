"""Stress 1: index very large binaries in a fresh process each; report time, peak RSS, functions, output size.

Every child runs under RLIMIT_AS (STRESS_MEM_MB, default 1600): an uncapped run on a 2 GB machine swapped the
whole box to a standstill on libLLVM before the columnar index existed.

python bench/stress/open_scale.py CACHE_DIR BINARY...
"""
import json, os, subprocess, sys, time

CHILD = r'''
import json, os, resource, sys, time
lim = int(sys.argv[2]) << 20
resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
from lean_re.engine import Engine
from lean_re.budget import est_tokens
p = sys.argv[1]; E = Engine(); t = time.time()
try:
    out = E.run("open", p, 1200); st = "ok"
except Exception as e:
    out = f"{type(e).__name__}: {e}"; st = "err"
n = next(iter(E.targets.values()), None)
print(json.dumps({"st": st, "secs": round(time.time() - t, 1), "peak_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024,
                  "funcs": len(getattr(n, "fn_size", {}) or {}), "out_tok": est_tokens(out), "head": out[:90]}))
'''

def run(path, cache, timeout=900):
    env = dict(os.environ, LRE_CACHE=cache)
    t = time.time()
    try:
        r = subprocess.run([sys.executable, "-c", CHILD, path, os.environ.get("STRESS_MEM_MB", "1600")], capture_output=True, text=True, timeout=timeout, env=env)
        line = (r.stdout.strip().splitlines() or ["{}"])[-1]
        d = json.loads(line) if line.startswith("{") else {"st": "crash", "err": (r.stderr or "")[-300:]}
    except subprocess.TimeoutExpired:
        d = {"st": "timeout"}
    d["wall"] = round(time.time() - t, 1)
    return d

if __name__ == "__main__":
    cache = sys.argv[1]
    for p in sys.argv[2:]:
        size = os.path.getsize(p) / 1e6
        cold = run(p, cache); warm = run(p, cache)
        print(json.dumps({"file": os.path.basename(p), "MB": round(size, 1), "cold": cold, "warm": warm}), flush=True)
