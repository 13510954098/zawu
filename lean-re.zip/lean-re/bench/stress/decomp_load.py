"""Stress 3: many decompiles in one session (persistent worker). Random functions weighted toward real
code (size >= 32 B). Reports latency percentiles, failures by reason, worker RSS growth.

python bench/stress/decomp_load.py BINARY N [angr|ghidra] [SEED]
"""
import json, os, random, re, statistics, sys, time

from lean_re import decomp
from lean_re.budget import est_tokens
from lean_re.engine import Engine


def rss(pid):
    try:
        return int(open(f"/proc/{pid}/status").read().split("VmRSS:")[1].split()[0]) // 1024
    except Exception:
        return 0


def main():
    path, n = sys.argv[1], int(sys.argv[2])
    backend = sys.argv[3] if len(sys.argv) > 3 else "angr"
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    E = Engine()
    E.run("open", path)
    nat = next(iter(E.targets.values()))
    pool = sorted(a for a, s in nat.fn_size.items() if s >= 32)
    if seed < 0:                                # worst case: the largest functions first
        pool.sort(key=lambda a: -nat.fn_size[a])
    else:
        random.Random(seed).shuffle(pool)
    lat, fails, toks, rss_trace = [], {}, [], []
    t0 = time.time()
    for i, f in enumerate(pool[:n]):
        t = time.time()
        out = E.run("show", path, 1500, ident=f"f:{f:x}", view=f"decomp:{backend}")
        while "retry later" in out or "still analyzing" in out:      # Ghidra first-open import+analysis
            time.sleep(5)
            out = E.run("show", path, 1500, ident=f"f:{f:x}", view=f"decomp:{backend}")
        dt = time.time() - t
        if i == 0 and backend == "ghidra":
            print(f"  first request incl. import+analysis: {dt:.0f}s", flush=True)
            dt = None
        toks.append(est_tokens(out))
        if "decompile failed" in out or out.startswith("error:"):
            reason = re.sub(r"0x[0-9a-f]+|\d+", "N", out.split(":", 3)[-1].strip())[:70]
            fails[reason] = fails.get(reason, 0) + 1
        elif dt is not None:
            lat.append(dt)
        w = decomp._WORKERS.get(backend)
        if w and w.proc:
            rss_trace.append(rss(w.proc.pid))
        if (i + 1) % 10 == 0 or seed < 0:
            print(f"  {i + 1}/{n}  size {nat.fn_size[f]}  {(dt or 0):.1f}s  {out.splitlines()[1][:70] if seed < 0 else ''}  elapsed {time.time() - t0:.0f}s  worker {rss_trace[-1] if rss_trace else 0} MB",
                  flush=True)
    lat.sort()
    q = lambda p: round(lat[min(len(lat) - 1, int(p * len(lat)))], 2) if lat else None
    print(json.dumps({"binary": os.path.basename(path), "backend": backend, "n": n, "ok": len(lat),
                      "fail": sum(fails.values()), "fail_reasons": fails, "p50": q(0.5), "p90": q(0.9),
                      "p99": q(0.99), "max": round(lat[-1], 2) if lat else None,
                      "mean": round(statistics.mean(lat), 2) if lat else None,
                      "max_tokens": max(toks), "worker_rss_first_last_max": [rss_trace[0], rss_trace[-1], max(rss_trace)]
                      if rss_trace else None, "total_s": round(time.time() - t0),
                      "recycles": getattr(decomp._WORKERS.get(backend), "recycles", 0)}))


if __name__ == "__main__":
    main()
