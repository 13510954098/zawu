"""Stress 2: malformed inputs. Every case runs in its own process with an address-space cap and a wall
clock limit; we classify how lean-re reacts. Acceptable: ok / graceful "error: ...". Not acceptable:
crash (signal), hang (timeout), escaped exception, output over budget.

python bench/stress/fuzz.py OUTDIR [--only SUBSTR]
"""
import io, json, os, random, re, struct, subprocess, sys, time, zipfile

FX = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures")
APK = os.environ.get("LRE_TEST_APKS", os.path.expanduser("~/fixtures_dl"))
MEM_MB = int(os.environ.get("FUZZ_MEM_MB", "1024"))
WALL = int(os.environ.get("FUZZ_WALL", "60"))
BUDGET = 400

CHILD = r'''
import json, re, resource, sys, time
lim = int(sys.argv[2]) << 20
resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
from lean_re.engine import Engine
from lean_re.budget import est_tokens
E, p, B = Engine(), sys.argv[1], int(sys.argv[3])
ID = re.compile(r"\b((?:f|s|c|m):(?!<)[0-9A-Za-z_$./;>-]+|file:(?!.*<)[^\s]+|ipc:[^\s]+)")
res, ident = [], None
def call(op, **kw):
    global ident
    t = time.time()
    out = E.run(op, p, B, 0, **kw)
    if ident is None:
        m = ID.search(out.split("\n", 1)[-1])
        ident = m.group(1).rstrip(",;)") if m else None
    res.append({"op": op, "err": out.startswith("error:"), "tok": est_tokens(out), "secs": round(time.time() - t, 2),
                "msg": out[:120] if out.startswith("error:") else ""})
outs = []
_run = E.run
def _rec(*a, **k):
    o = _run(*a, **k); outs.append(o); return o
E.run = _rec
call("open"); call("list"); call("find", query="a")
if ident:
    call("show", ident=ident); call("xrefs", ident=ident)
if p.endswith(".asar"):                       # touch every file the archive exposes
    for fid in sorted(set(re.findall(r"file:[^\s,]+", "\n".join(outs))))[:30]:
        call("show", ident=fid)
print("@@" + json.dumps(res))
if any("CANARY-7f3a" in o for o in outs):
    print("@@LEAK")
'''


def mutate_flip(data, n, seed, lo=0, hi=None):
    r = random.Random(seed)
    b = bytearray(data)
    hi = hi or len(b)
    for _ in range(n):
        i = r.randrange(lo, min(hi, len(b)))
        b[i] = r.randrange(256)
    return bytes(b)


def gen(out):
    os.makedirs(out, exist_ok=True)
    cases = []

    def put(name, data):
        p = os.path.join(out, name)
        with open(p, "wb") as f:
            f.write(data)
        cases.append(p)

    natives = ["pack_x64_stripped", "pack_a64_stripped", "pack_win.exe", "macho_x64.so", "macho_a64.so"]
    for nm in natives:
        d = open(os.path.join(FX, nm), "rb").read()
        base = nm.replace(".", "_")
        for cut in (0, 4, 16, 64, 300, 2000, len(d) // 4, len(d) // 2, len(d) - 1):
            put(f"{base}.trunc{cut}", d[:cut])
        for seed in range(4):
            put(f"{base}.hdrflip{seed}", mutate_flip(d, 24, seed, 0, 512))
            put(f"{base}.flip{seed}", mutate_flip(d, 400, 100 + seed))
    # targeted header corruption
    elf = bytearray(open(os.path.join(FX, "pack_x64_stripped"), "rb").read())
    for nm, off, fmt, val in [("shoff_eof", 0x28, "<Q", len(elf) - 8), ("shoff_huge", 0x28, "<Q", 1 << 62),
                              ("shnum_max", 0x3C, "<H", 0xFFFF), ("phnum_max", 0x38, "<H", 0xFFFF),
                              ("phoff_huge", 0x20, "<Q", 1 << 40), ("entry_wild", 0x18, "<Q", 0xFFFFFFFFFFFF0000)]:
        e = bytearray(elf)
        struct.pack_into(fmt, e, off, val)
        put(f"elf.{nm}", bytes(e))
    pe = bytearray(open(os.path.join(FX, "pack_win.exe"), "rb").read())
    for nm, val in [("lfanew_eof", len(pe) - 2), ("lfanew_neg", 0xFFFFFFF0), ("lfanew_zero", 0)]:
        e = bytearray(pe)
        struct.pack_into("<I", e, 0x3C, val)
        put(f"pe.{nm}", bytes(e))
    mo = bytearray(open(os.path.join(FX, "macho_x64.so"), "rb").read())
    for nm, off, val in [("ncmds_huge", 16, 0xFFFFFFF), ("sizeofcmds_huge", 20, 0xFFFFFFF0)]:
        e = bytearray(mo)
        struct.pack_into("<I", e, off, val)
        put(f"macho.{nm}", bytes(e))
    # magic + garbage
    r = random.Random(5)
    for magic, nm in [(b"\x7fELF\x02\x01\x01", "elf"), (b"MZ", "pe"), (b"\xcf\xfa\xed\xfe", "macho"),
                      (b"\xca\xfe\xba\xbe\x00\x00\x00\x40", "fat"), (b"PK\x03\x04", "zip")]:
        put(f"garbage.{nm}", magic + bytes(r.randrange(256) for _ in range(5000)))
    put("garbage.noext", bytes(r.randrange(256) for _ in range(20000)))
    put("empty.bin", b"")
    # asar
    # garbled (non-UTF-8) section names, as packers produce
    for nm in ("pack_x64_stripped", "pack_win.exe"):
        src = os.path.join(FX, nm)
        if os.path.exists(src):
            d = bytearray(open(src, "rb").read())
            for sec in (b".comment", b".rdata", b".data"):
                i = d.find(sec + b"\0")
                if i > 0:
                    d[i + 1:i + 3] = b"\xc3\x28"
            put(f"{nm}.badnames", bytes(d))
    def asar(header_obj=None, raw_header=None, blob=b"", size_override=None):
        h = raw_header if raw_header is not None else json.dumps(header_obj).encode()
        pad = (4 - len(h) % 4) % 4
        pickle = struct.pack("<II", 4 + len(h) + pad if size_override is None else size_override, len(h)) + h + b"\0" * pad
        return struct.pack("<II", 4, len(pickle)) + pickle + blob
    put("a_hdrlen_huge.asar", struct.pack("<II", 4, 0xFFFFFFF0) + b"{}")
    put("a_badjson.asar", asar(raw_header=b'{"files": {"a.js": {"size": 3, "offset": "0"'))
    put("a_offset_eof.asar", asar({"files": {"main.js": {"size": 100000, "offset": "999999999"}}}, blob=b"x" * 10))
    put("a_neg.asar", asar({"files": {"main.js": {"size": -5, "offset": "-100"}}}, blob=b"abc"))
    put("a_traversal.asar", asar({"files": {"../../../../etc/passwd": {"size": 3, "offset": "0"},
                                            "main.js": {"size": 3, "offset": "0"}}}, blob=b"abc"))
    # unpacked-entry traversal: a canary next to the archive must never be read
    open(os.path.join(out, "CANARY_SECRET.txt"), "w").write("CANARY-7f3a top secret\n")
    unp = os.path.join(out, "a_unp.asar.unpacked")
    os.makedirs(unp, exist_ok=True)
    open(os.path.join(unp, "ok.js"), "w").write("ipcRenderer.invoke('safe:one')\n")
    if not os.path.lexists(os.path.join(unp, "link.js")):
        os.symlink(os.path.join("..", "CANARY_SECRET.txt"), os.path.join(unp, "link.js"))
    put("a_unp.asar", asar({"files": {
        "../CANARY_SECRET.txt": {"size": 23, "unpacked": True},
        "..": {"files": {"CANARY_SECRET.txt": {"size": 23, "unpacked": True}}},
        "link.js": {"size": 23, "unpacked": True},
        "ok.js": {"size": 31, "unpacked": True},
        "main.js": {"size": 3, "offset": "0"}}}, blob=b"abc"))
    deep = {}
    cur = deep
    for _ in range(5000):
        cur["files"] = {"d": {}}
        cur = cur["files"]["d"]
    put("a_deep.asar", asar(raw_header=("{\"files\":{\"d\":" * 5000 + "{}" + "}}" * 5000).encode()))
    put("a_manyfiles.asar", asar({"files": {f"f{i}.js": {"size": 1, "offset": "0"} for i in range(200000)}}, blob=b"a"))
    put("a_truncated.asar", open(os.path.join(FX, "app.asar"), "rb").read()[:5000])
    # js dirs
    d = os.path.join(out, "js_hugeline")
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "package.json"), "w").write('{"main": "main.js"}')
    open(os.path.join(d, "main.js"), "w").write("var a=1;" * 2_500_000 + "ipcMain.handle('x:y',()=>1);")
    cases.append(d)
    d = os.path.join(out, "js_binary")
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "package.json"), "w").write('{"main": "main.js"}')
    open(os.path.join(d, "main.js"), "wb").write(bytes(r.randrange(256) for _ in range(300000)))
    cases.append(d)
    d = os.path.join(out, "js_symloop")
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "package.json"), "w").write('{"main": "main.js"}')
    open(os.path.join(d, "main.js"), "w").write("ipcRenderer.invoke('a:b')")
    if not os.path.lexists(os.path.join(d, "loop")):
        os.symlink(".", os.path.join(d, "loop"))
    cases.append(d)
    d = os.path.join(out, "js_badpkg")
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "package.json"), "w").write('{"main": ')
    open(os.path.join(d, "x.js"), "w").write("require('electron')")
    cases.append(d)
    # apk
    apk_path = os.path.join(APK, "de.markusfisch.android.binaryeye.apk")
    if os.path.exists(apk_path):
        a = open(apk_path, "rb").read()
        for cut in (100, len(a) // 2, len(a) - 30):
            put(f"apk_trunc{cut}.apk", a[:cut])
        for seed in range(3):
            put(f"apk_cdflip{seed}.apk", mutate_flip(a, 60, 300 + seed, len(a) - 4000))
        zin = zipfile.ZipFile(apk_path)
        dex = zin.read("classes.dex")
        for nm, mut in [("dex_flip", lambda x: mutate_flip(x, 2000, 9)),
                        ("dex_strids_huge", lambda x: x[:56] + struct.pack("<I", 0x7FFFFFFF) + x[60:]),
                        ("dex_trunc", lambda x: x[: len(x) // 3]),
                        ("dex_garbage", lambda x: b"dex\n035\0" + bytes(r.randrange(256) for _ in range(100000)))]:
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as z:
                for info in zin.infolist():
                    z.writestr(info.filename, mut(dex) if info.filename == "classes.dex" else zin.read(info.filename))
            put(f"apk_{nm}.apk", buf.getvalue())
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("AndroidManifest.xml", b"\x03\x00\x08\x00" + bytes(r.randrange(256) for _ in range(3000)))
        put("apk_badmanifest.apk", buf.getvalue())
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:   # 1 GB of zeros -> ~1 MB compressed
            with z.open("classes.dex", "w") as f:
                chunk = b"\0" * (1 << 20)
                for _ in range(1024):
                    f.write(chunk)
        put("apk_zipbomb.apk", buf.getvalue())
        # bomb behind a *valid* manifest, so the DEX path is actually reached
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for info in zin.infolist():
                if info.filename == "classes.dex":
                    with z.open("classes.dex", "w") as f:
                        for _ in range(1024):
                            f.write(chunk)
                else:
                    z.writestr(info.filename, zin.read(info.filename))
        put("apk_bomb_realmanifest.apk", buf.getvalue())
        # intact DEX, tampered checksum only (anti-analysis trick)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            for info in zin.infolist():
                d = zin.read(info.filename)
                if info.filename == "classes.dex":
                    d = d[:8] + b"\xde\xad\xbe\xef" + d[12:]
                z.writestr(info.filename, d)
        put("apk_dex_badsum.apk", buf.getvalue())
    return cases


def run_case(p):
    t = time.time()
    try:
        r = subprocess.run([sys.executable, "-c", CHILD, p, str(MEM_MB), str(BUDGET)], capture_output=True, text=True,
                           timeout=WALL, errors="replace")
    except subprocess.TimeoutExpired:
        return {"case": os.path.basename(p), "verdict": "HANG", "secs": WALL}
    secs = round(time.time() - t, 1)
    m = re.search(r"^@@(.*)$", r.stdout, re.M)
    if r.returncode < 0:
        return {"case": os.path.basename(p), "verdict": f"CRASH(signal {-r.returncode})", "secs": secs,
                "tail": r.stderr[-300:]}
    if not m:
        return {"case": os.path.basename(p), "verdict": "ESCAPED", "secs": secs, "tail": r.stderr[-400:]}
    ops = json.loads(m.group(1))
    if "@@LEAK" in r.stdout:
        return {"case": os.path.basename(p), "verdict": "LEAK(read outside archive)", "secs": secs}
    over = [o for o in ops if o["tok"] > BUDGET]
    verdict = "OVER_BUDGET" if over else ("graceful-error" if ops[0]["err"] else "ok")
    slow = max(o["secs"] for o in ops)
    return {"case": os.path.basename(p), "verdict": verdict, "secs": secs, "slowest_op": slow,
            "ops": len(ops), "errors": [o["msg"] for o in ops if o["err"]][:2], "max_tok": max(o["tok"] for o in ops)}


if __name__ == "__main__":
    out = sys.argv[1]
    only = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else ""
    cases = [c for c in gen(out) if only in c]
    print(f"{len(cases)} cases, mem cap {MEM_MB} MB, wall {WALL}s", flush=True)
    for c in cases:
        print(json.dumps(run_case(c)), flush=True)
