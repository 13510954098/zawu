"""Stress 3: budget property test. Thousands of random calls (random target/op/id/budget/cursor, plus
adversarial arguments); every response must satisfy tokens <= effective budget, and following cursors must
enumerate each result exactly once.

python bench/stress/budget_prop.py [N] [SEED]
"""
import os, random, re, sys, time

from lean_re.budget import MAX_BUDGET, effective_budget, est_tokens
from lean_re.engine import Engine

FX = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures")
APK = os.environ.get("LRE_TEST_APKS", os.path.expanduser("~/fixtures_dl"))
TARGETS = [os.path.join(FX, n) for n in ("pack_x64", "pack_a64_stripped", "pack_win.exe", "macho_x64.so",
                                         "macho_a64.so", "app.asar", "electron_app")]
TARGETS += [os.path.join(APK, n) for n in ("de.markusfisch.android.binaryeye.apk",) if os.path.exists(os.path.join(APK, n))]
ID = re.compile(r"\b((?:f|s|c|m):[0-9A-Za-z_$./;<>()\[-]+|file:[^\s,]+|ipc:[^\s,]+)")
LISTS = ["functions", "imports", "exports", "strings", "sections", "files", "ipc", "classes", "packages",
         "components", "permissions", "urls", "libs", "", "bogus"]
QUERIES = ["a", "e", "main", "http", "crypt", "ipc", ".", "x" * 100_000, "(", "\x00", "ä中文", "*", ""]


def eff(b):
    # documented policy: 0/None -> default 1200; clamp to [200, 8000]
    return effective_budget(b)


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    rnd = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 7)
    E = Engine()
    ids = {t: set() for t in TARGETS}
    viol, errs, cnt = [], 0, 0
    t0 = time.time()

    def call(op, t, b, cur=0, **kw):
        nonlocal errs, cnt
        out = E.run(op, t, b, cur, **kw)
        cnt += 1
        tok = est_tokens(out)
        if tok > eff(b):
            viol.append((op, os.path.basename(t), b, cur, {k: (v[:30] if isinstance(v, str) else v) for k, v in kw.items()},
                         tok, out[:90].replace("\n", " | ")))
        if out.startswith("error:"):
            errs += 1
        for m in ID.findall(out):
            if len(ids[t]) < 400:
                ids[t].add(m.rstrip(",;)"))
        return out

    for t in TARGETS:                       # seed id pools
        call("open", t, 2000)
        for w in LISTS[:8]:
            call("list", t, 3000, what=w)
    for i in range(n):
        t = rnd.choice(TARGETS)
        b = rnd.choice([1, 50, 199, 200, 201, 300, 517, 1200, 4000, 8000, 10**9, -5, 0])
        cur = rnd.choice([0, 0, 0, 1, 7, 100, 10**7, -3])
        op = rnd.choice(["open", "list", "find", "show", "show", "xrefs", "xrefs"])
        pool = sorted(ids[t]) or ["f:0"]
        if op == "open":
            call(op, t, b, cur)
        elif op == "list":
            call(op, t, b, cur, what=rnd.choice(LISTS), filter=rnd.choice(["", "a", "[", ".*"]))
        elif op == "find":
            call(op, t, b, cur, query=rnd.choice(QUERIES), regex=rnd.random() < 0.3,
                 kind=rnd.choice(["any", "any", "function", "string", "class", "method", "zzz"]))
        elif op == "show":
            ident = rnd.choice(pool + ["f:ffffffffffffffff", "f:-1", "m:" + "A" * 5000, "file:../../etc/passwd", "zz"])
            call(op, t, b, cur, ident=ident, view=rnd.choice(["auto", "asm", "summary", "bogus"]))
        else:
            ident = rnd.choice(pool + ["s:nonexistent", "f:0"])
            call(op, t, b, cur, ident=ident, direction=rnd.choice(["to", "from", "both", "sideways"]))
        if (i + 1) % 500 == 0:
            print(f"  {i + 1}/{n}  violations {len(viol)}  {time.time() - t0:.0f}s", flush=True)

    # cursor walk: every list row exactly once
    walk_bad = []
    for t in TARGETS:
        for w in ("functions", "strings", "files", "classes"):
            full = E.run("list", t, 10**9, 0, what=w)
            if full.startswith("error") or "no results" in full:
                continue
            seen, cur, pages = [], 0, 0
            while True:
                out = E.run("list", t, 200, cur, what=w)
                rows = out.split("\n")[1:]
                m = re.match(r"\[\+(\d+) more lines · cursor=(\d+)\]", rows[-1]) if rows else None
                if m:
                    rows = rows[:-1]
                seen += rows
                pages += 1
                if not m or pages > 100000:
                    break
                cur = int(m.group(2))
            # reference: concatenation of a huge-budget walk the same way
            ref, cur = [], 0
            while True:
                out = E.run("list", t, MAX_BUDGET, cur, what=w)
                rows = out.split("\n")[1:]
                m = re.match(r"\[\+(\d+) more lines · cursor=(\d+)\]", rows[-1]) if rows else None
                ref += rows[:-1] if m else rows
                if not m:
                    break
                cur = int(m.group(2))
            if [r.split("…")[0][:60] for r in seen] != [r.split("…")[0][:60] for r in ref]:
                walk_bad.append((os.path.basename(t), w, len(seen), len(ref)))
    print(f"calls {cnt}  errors {errs}  budget violations {len(viol)}  cursor-walk mismatches {len(walk_bad)}"
          f"  {time.time() - t0:.0f}s")
    by = {}
    for v in viol:
        by.setdefault((v[0], v[4].get("what") or v[4].get("view") or ""), []).append(v)
    for k, vs in sorted(by.items(), key=lambda kv: -len(kv[1]))[:12]:
        v = max(vs, key=lambda v: v[5] - eff(v[2]))
        print(f"  {len(vs):4d}× {k}: worst tok {v[5]} vs budget {eff(v[2])}  e.g. {v[1]} cur={v[3]} {v[6]}")
    for w in walk_bad:
        print("  walk mismatch", w)


if __name__ == "__main__":
    main()
