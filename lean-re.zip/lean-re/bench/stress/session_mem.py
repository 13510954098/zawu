"""Stress 4: long-lived session memory. Runs in a child capped with RLIMIT_AS.

A) open many distinct binaries in one Engine (an MCP server lives for hours) -> RSS must plateau
B) thousands of random calls on a fixed working set -> RSS slope after warm-up must be ~0

python bench/stress/session_mem.py [A|B|AB] [N_FILES] [N_CALLS]
"""
import glob, gc, os, random, resource, sys, time

CAP_MB = int(os.environ.get("SESSION_CAP_MB", "1500"))
resource.setrlimit(resource.RLIMIT_AS, (CAP_MB << 20, CAP_MB << 20))

from lean_re.engine import Engine  # noqa: E402

FX = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures")


def rss():
    return int(open("/proc/self/status").read().split("VmRSS:")[1].split()[0]) // 1024


def pick_libs(n):
    libs = []
    for p in sorted(glob.glob("/usr/lib/x86_64-linux-gnu/*.so*")):
        if os.path.islink(p) or not os.path.isfile(p):
            continue
        sz = os.path.getsize(p)
        if 300_000 <= sz <= 4_000_000:
            libs.append(p)
    random.Random(3).shuffle(libs)
    return libs[:n]


def phase_a(n):
    E = Engine()
    trace = []
    t0 = time.time()
    for i, p in enumerate(pick_libs(n)):
        out = E.run("open", p, 300)
        E.run("find", p, 300, query="init")
        gc.collect()
        trace.append(rss())
        if (i + 1) % 5 == 0:
            print(f"  A {i + 1}/{n} files  rss {trace[-1]} MB  live targets {len(E.targets)} evictions {getattr(E, 'evictions', 0)}  "
                  f"{time.time() - t0:.0f}s  {'ERR ' + out[:60] if out.startswith('error') else ''}", flush=True)
    return trace


def phase_b(n):
    E = Engine()
    tg = [os.path.join(FX, x) for x in ("pack_x64", "pack_win.exe", "macho_a64.so", "app.asar")]
    tg.append("/usr/lib/x86_64-linux-gnu/libcrypto.so.3")
    apk = os.path.expanduser("~/fixtures_dl/de.markusfisch.android.binaryeye.apk")
    if os.path.exists(apk):
        tg.append(apk)
    rnd = random.Random(5)
    ids = {}
    for t in tg:
        out = E.run("list", t, 4000, what="functions") + E.run("list", t, 4000, what="classes") \
            + E.run("list", t, 4000, what="files")
        ids[t] = [w for w in out.split() if w[:2] in ("f:", "c:", "m:") or w.startswith("file:")][:300] or ["f:0"]
    trace = []
    t0 = time.time()
    for i in range(n):
        t = rnd.choice(tg)
        op = rnd.choice(["show", "xrefs", "find", "list"])
        if op == "find":
            E.run(op, t, 600, query=rnd.choice(["a", "init", "http", "error", "key"]))
        elif op == "list":
            E.run(op, t, 600, rnd.choice([0, 50, 500]), what=rnd.choice(["functions", "strings", "classes", "files"]))
        else:
            E.run(op, t, 600, ident=rnd.choice(ids[t]))
        if (i + 1) % 250 == 0:
            gc.collect()
            trace.append(rss())
            print(f"  B {i + 1}/{n} calls  rss {trace[-1]} MB  {time.time() - t0:.0f}s", flush=True)
    return trace


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "AB"
    nf = int(sys.argv[2]) if len(sys.argv) > 2 else 40
    nc = int(sys.argv[3]) if len(sys.argv) > 3 else 5000
    if "A" in mode:
        a = phase_a(nf)
        print(f"A: rss after 1 file {a[0]} MB, after {len(a)} files {a[-1]} MB, max {max(a)} MB")
    if "B" in mode:
        b = phase_b(nc)
        half = b[len(b) // 4:]
        print(f"B: rss first {b[0]} MB, last {b[-1]} MB, max {max(b)} MB, growth after warm-up "
              f"{half[-1] - half[0]} MB over {len(half) * 250} calls")
