"""Deterministic token-cost benchmark: lean-re vs a plain-shell workflow.

Not an LLM eval. For each question we run the tool calls an agent would make on
each path and measure (a) tokens of output the agent must read and (b) whether
the facts needed for the answer appear literally in that output.
Run from repo root: python bench/bench.py
"""
import os, subprocess, sys
sys.path.insert(0, "src")
from lean_re.budget import est_tokens
from lean_re.engine import Engine

FX = "tests/fixtures"
E = Engine()


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, errors="replace").stdout


def lre(op, target, **kw):
    return E.run(op, target, 4000, 0, **kw)


def find_tool(name):
    """PATH, then $LRE_A64_OBJDUMP, then a user-level extraction (apt-get download + dpkg-deb -x)."""
    import shutil
    hit = shutil.which(name) or (os.environ.get("LRE_A64_OBJDUMP") if "aarch64" in name else None)
    if not hit:
        root = os.path.expanduser("~/.cache/tools/binutils-a64/usr")
        cand = f"{root}/bin/{name}"     # the .deb ships its own libopcodes-*-arm64.so next to it
        hit = f"LD_LIBRARY_PATH={root}/lib/x86_64-linux-gnu {cand}" if os.path.exists(cand) else None
    return hit


def native_q(binary, objdump):
    tool = find_tool(objdump)
    def lean():
        f = lre("find", binary, query="bad record")
        fid = [l for l in f.splitlines() if "length" in l][0].split("← ")[1].split()[0]
        return [f, lre("show", binary, ident=fid)]

    def shell():
        if tool is None:
            raise FileNotFoundError(objdump)
        objdump_ = tool
        return [sh(f"strings -a -t x {binary} | grep -i record"),
                sh(f"{objdump_} -d -M intel --no-show-raw-insn -j .text {binary}" if "aarch64" not in objdump
                   else f"{objdump_} -d --no-show-raw-insn -j .text {binary}")]
    return lean, shell


def js_q(app):
    def lean():
        return [lre("xrefs", app, ident="ipc:notes:search")]

    def shell():
        return [sh(f"grep -rn 'notes:search' {app}"), sh(f"grep -rn 'search' {app}/assets")]
    return lean, shell


QUESTIONS = [
    ("x64 stripped: which record tags/lengths are accepted?", *native_q(f"{FX}/pack_x64_stripped", "objdump"),
     ["0xa1", "0xa2", "0x1000", "bad record length"]),
    ("arm64 stripped: same question", *native_q(f"{FX}/pack_a64_stripped", "aarch64-linux-gnu-objdump"),
     ["0xa1", "0xa2", "0x1000", "bad record length"]),
    ("Electron: trace notes:search renderer→preload→main", *js_q(f"{FX}/electron_app"),
     ["ipcMain.handle('notes:search'", "r.invoke('notes:search'", "t.search("]),
]

if __name__ == "__main__":
    rows = ["| question | path | output tokens | facts present |", "|---|---|---:|---|"]
    for q, lean, shell, facts in QUESTIONS:
        for name, fn in (("lean-re", lean), ("shell", shell)):
            try:
                out = "\n".join(fn())
            except FileNotFoundError as e:
                rows.append(f"| {q} | {name} | n/a | n/a ({e} not installed) |")
                continue
            got = [f for f in facts if f in out]
            rows.append(f"| {q} | {name} | {est_tokens(out):,} | {len(got)}/{len(facts)} |")
    print("\n".join(rows))
