"""Agent-in-the-loop evaluation (GitTested-style): 3 conditions × N tasks × R repeats.

  python bench/agent_eval/run.py --agent claude --repeats 3
  python bench/agent_eval/run.py --agent codex
  python bench/agent_eval/run.py --agent oracle      # pipeline self-test, no LLM

Conditions: shell (lean-re MCP not registered), lean-re (told to use it), free (registered, no hint).
Scores = checklist facts matched (regex, case-insensitive) in the final answer. Token usage is
taken from the agent CLI's JSON output when available. Results -> bench/agent_eval/results.jsonl
"""
import argparse, json, os, re, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
APKS = os.environ.get("LRE_TEST_APKS", "/home/user/fixtures_dl")
MCP_CFG = {"mcpServers": {"lean-re": {"command": "lean-re-mcp", "args": []}}}

PROMPT = {
    "shell": "You have no source code. Use ordinary command-line tools only (objdump, strings, rg, unzip...). ",
    "lean-re": "You have no source code. Use the lean-re MCP tools (re_open, re_find, re_show, re_xrefs, re_list). ",
    "free": "You have no source code. Use whatever tools you find most effective. ",
}


def target_path(t):
    return os.path.join(APKS, t[4:]) if t.startswith("APK:") else os.path.join(ROOT, t)


def score(task, answer):
    got = [f for f in task["facts"] if re.search(f, answer, re.I)]
    return len(got), len(task["facts"])


def run_claude(cond, prompt, workdir):
    cmd = ["claude", "-p", prompt, "--output-format", "json", "--permission-mode", "bypassPermissions"]
    if cond != "shell":
        cfg = os.path.join(workdir, ".mcp-eval.json")
        json.dump(MCP_CFG, open(cfg, "w"))
        cmd += ["--mcp-config", cfg, "--strict-mcp-config"]
    else:
        cmd += ["--strict-mcp-config"]
    out = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True, timeout=900).stdout
    j = json.loads(out)
    u = j.get("usage", {}) or {}
    toks = sum(u.get(k, 0) or 0 for k in ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"))
    return j.get("result", ""), toks, j.get("total_cost_usd")


def run_codex(cond, prompt, workdir):
    cmd = ["codex", "exec", "--skip-git-repo-check", "--json", prompt]
    if cond != "shell":
        cmd[2:2] = ["-c", 'mcp_servers.lean-re.command="lean-re-mcp"']
    out = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True, timeout=900).stdout
    answer, toks = "", 0
    for line in out.splitlines():
        try:
            ev = json.loads(line)
        except ValueError:
            continue
        msg = ev.get("item", {}) if isinstance(ev.get("item"), dict) else {}
        if msg.get("type") == "agent_message":
            answer = msg.get("text", answer)
        u = ev.get("usage") or {}
        toks += (u.get("input_tokens", 0) or 0) + (u.get("output_tokens", 0) or 0)
    return answer, toks, None


def run_oracle(cond, prompt, workdir, task=None):
    """Self-test: answers built from lean-re's own output, proves scoring/plumbing work end to end."""
    sys.path.insert(0, os.path.join(ROOT, "src"))
    from lean_re.engine import Engine
    E, t = Engine(), target_path(task["target"])
    if task.get("negative"):
        return "The program does not perform any network upload; no socket or HTTPS code is present.", 0, None
    parts = [E.run("open", t, 3000)]
    for q in ("record", "magic", "search", "save", "UPDATE_REPOS"):
        parts.append(E.run("find", t, 3000, query=q))
    for ident in ("main", "f:13b0", "ipc:notes:search", "ipc:notes:save"):
        parts.append(E.run("show" if not ident.startswith("ipc") else "xrefs", t, 3000, ident=ident))
    return "\n".join(parts), 0, None


AGENTS = {"claude": run_claude, "codex": run_codex, "oracle": run_oracle}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--agent", default="oracle", choices=AGENTS)
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--conditions", default="shell,lean-re,free")
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    tasks = json.load(open(os.path.join(os.path.dirname(__file__), "tasks.json")))
    if a.only:
        tasks = [t for t in tasks if re.search(a.only, t["id"])]
    res_path = os.path.join(os.path.dirname(__file__), f"results-{a.agent}.jsonl")
    summary = {}
    with open(res_path, "w") as out:
        for task in tasks:
            tp = target_path(task["target"])
            if not os.path.exists(tp):
                print(f"skip {task['id']}: {tp} missing")
                continue
            for cond in a.conditions.split(","):
                for r in range(a.repeats):
                    prompt = PROMPT[cond] + f"Target: {tp}\nQuestion: {task['question']}\nAnswer concisely with evidence."
                    t0 = time.time()
                    fn = AGENTS[a.agent]
                    ans, toks, cost = fn(cond, prompt, ROOT, task) if a.agent == "oracle" else fn(cond, prompt, ROOT)
                    s, n = score(task, ans)
                    row = dict(task=task["id"], cond=cond, rep=r, score=s, max=n, tokens=toks, cost=cost,
                               seconds=round(time.time() - t0, 1))
                    out.write(json.dumps(row) + "\n")
                    agg = summary.setdefault(cond, [0, 0, []])
                    agg[0] += s; agg[1] += n; agg[2].append(toks)
                    print(f"{task['id']:<20} {cond:<8} {s}/{n} tokens={toks}")
    print("\ncondition  facts      median tokens")
    for cond, (s, n, toks) in summary.items():
        toks = sorted(toks)
        print(f"{cond:<10} {s}/{n:<8} {toks[len(toks)//2] if toks else 0}")
    print(f"rows -> {res_path}")


if __name__ == "__main__":
    main()
