"""Regressions from the stress campaign (bench/stress/*): hostile inputs, budget guarantees, memory bounds."""
import json, os, random, struct, zipfile

import pytest

from conftest import apk, fx
from lean_re.budget import est_tokens, paginate
from lean_re.engine import Engine


def _asar(header, blob=b""):
    h = json.dumps(header).encode()
    pad = (4 - len(h) % 4) % 4
    pickle = struct.pack("<II", 4 + len(h) + pad, len(h)) + h + b"\0" * pad
    return struct.pack("<II", 4, len(pickle)) + pickle + blob


# ---- asar: path traversal through "unpacked" entries ------------------------------------------------------
def test_asar_unpacked_traversal_and_symlink_never_leak(tmp_path):
    (tmp_path / "SECRET.txt").write_text("CANARY-7f3a\n")
    unp = tmp_path / "app.asar.unpacked"
    unp.mkdir()
    (unp / "ok.js").write_text("ipcRenderer.invoke('safe:one')\n")
    os.symlink(os.path.join("..", "SECRET.txt"), unp / "link.js")
    p = tmp_path / "app.asar"
    p.write_bytes(_asar({"files": {
        "../SECRET.txt": {"size": 12, "unpacked": True},
        "..": {"files": {"SECRET.txt": {"size": 12, "unpacked": True}}},
        "link.js": {"size": 12, "unpacked": True},
        "ok.js": {"size": 31, "unpacked": True},
        "main.js": {"size": 3, "offset": "0"}}}, b"abc"))
    E = Engine()
    outs = [E.run("open", str(p), 2000), E.run("list", str(p), 4000, what="files"),
            E.run("find", str(p), 4000, query="CANARY"), E.run("show", str(p), 2000, ident="file:link.js"),
            E.run("list", str(p), 2000, what="ipc")]
    assert not any("CANARY" in o for o in outs[:2] + outs[3:])
    assert "safe:one" in outs[4]                     # the rest of the app still works
    assert "skipped" in outs[0]


@pytest.mark.parametrize("name,data,msg", [
    ("short", b"\x04\0\0\0", "not an asar"),
    ("huge", struct.pack("<IIII", 4, 0xFFFFFFF0, 0xFFFFFFF0, 0xFFFFFFF0) + b"{}", "corrupt asar"),
    ("deep", None, "nested too deeply"),
])
def test_asar_corrupt_headers_have_clear_errors(tmp_path, name, data, msg):
    if data is None:
        data = _asar({}).replace(b"{}", b"")         # placeholder; build raw deep JSON below
        raw = b'{"files":{"d":' * 20000 + b"{}" + b"}}" * 20000
        pad = (4 - len(raw) % 4) % 4
        pickle = struct.pack("<II", 4 + len(raw) + pad, len(raw)) + raw + b"\0" * pad
        data = struct.pack("<II", 4, len(pickle)) + pickle
    p = tmp_path / f"{name}.asar"
    p.write_bytes(data)
    out = Engine().run("open", str(p), 400)
    assert "RecursionError" not in out
    assert (out.startswith("error:") and msg in out) or (name == "deep" and "skipped" in out)


def test_asar_negative_offsets_rejected(tmp_path):
    p = tmp_path / "neg.asar"
    p.write_bytes(_asar({"files": {"main.js": {"size": -5, "offset": "-100"}}}, b"abc"))
    out = Engine().run("show", str(p), 400, ident="file:main.js")
    assert "outside the archive" in out


# ---- native: garbled section/symbol names -----------------------------------------------------------------
def test_native_non_utf8_section_names(tmp_path):
    d = bytearray(open(fx("pack_x64_stripped"), "rb").read())
    i = d.find(b".comment\0")
    d[i + 1:i + 3] = b"\xc3\x28"
    p = tmp_path / "garbled"
    p.write_bytes(bytes(d))
    E = Engine()
    assert "main" in E.run("open", str(p), 600)
    assert "\\xc3" in E.run("list", str(p), 2000, what="sections")


def test_lite_windows_equal_single_sweep():
    from lean_re.native import Native
    path = fx("pack_x64")
    n = Native(path, open(path, "rb").read())
    va, _, _, code, _ = max((s for s in n.sections if s[4]), key=lambda s: len(s[3]))
    assert len(code) > 200
    full = list(n.cs.disasm_lite(code, va))
    for chunk in (17, 64, 1000):
        n.SWEEP_CHUNK = chunk
        assert list(n._lite(code, va)) == full, chunk


def test_refs_negative_and_wrapped_targets():
    from lean_re.native import _Refs
    r = _Refs()
    r.add(-0x40, 0x1000, "call")
    r.add((1 << 64) - 8, 0x1004, "jmp")               # wraps to -8
    r.add(1 << 70, 0x1008, "call")                    # unrepresentable: dropped, no OverflowError
    r.add(0x2000, 0x100c, "call")
    r.add(0x2000, 0x1010, "jmp")
    assert r.get(-0x40) == [(0x1000, "call")]
    assert r[(1 << 64) - 8] == [(0x1004, "jmp")]
    assert r.get(1 << 70) == ()
    assert r[0x2000] == [(0x100c, "call"), (0x1010, "jmp")]   # insertion order kept per target
    import pickle
    assert pickle.loads(pickle.dumps(r))[0x2000] == r[0x2000]


# ---- budget: hard guarantee -------------------------------------------------------------------------------
def test_paginate_never_exceeds_budget_and_cursor_walk_is_complete():
    rnd = random.Random(1)
    lines = ["x" * rnd.choice([1, 10, 80, 300, 5000, 200000]) for _ in range(400)]
    for budget in (1, 199, 200, 333, 1200, 8000, 10 ** 9):
        eff = max(200, min(budget, 8000))
        out = paginate(lines, 0, budget, header="h" * 100000)
        assert est_tokens(out) <= eff
    seen, cur = 0, 0
    while True:
        out = paginate(lines, cur, 300).split("\n")
        assert est_tokens("\n".join(out)) <= 300
        more = out[-1].startswith("[+")
        seen += len(out) - 1 - (1 if more else 0) + 1     # rows on this page (+1 for the absent header)
        if not more:
            break
        cur = int(out[-1].split("cursor=")[1].rstrip("]"))
    assert cur <= len(lines)


def test_errors_are_budgeted():
    out = Engine().run("show", fx("pack_x64"), 200, ident="m:" + "A" * 50000)
    assert out.startswith("error:") and est_tokens(out) <= 200


# ---- session memory: LRU working set with stable handles --------------------------------------------------
def test_engine_lru_eviction_keeps_handles_valid():
    E = Engine(max_live=2)
    a, b, c = fx("pack_x64"), fx("pack_win.exe"), fx("macho_x64.so")
    for p in (a, b, c):
        E.run("open", p, 300)
    assert len(E.live) == 2 and E.evictions == 1 and "t1" not in E.live
    out = E.run("list", "t1", 400, what="functions")   # transparently reloaded
    assert out.startswith("[t1]") and "f:" in out
    assert E.run("open", a, 300).startswith("[t1]")     # same path -> same handle


# ---- apk: tampered checksum, zip bomb, unreadable manifest -------------------------------------------------
def _rezip(src, dst, mutate):
    zin = zipfile.ZipFile(src)
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for info in zin.infolist():
            mutate(z, info.filename, zin.read(info.filename))


def test_apk_tampered_dex_checksum_is_repaired(tmp_path):
    src = apk("de.markusfisch.android.binaryeye.apk")
    dst = tmp_path / "badsum.apk"
    _rezip(src, dst, lambda z, n, d: z.writestr(n, d[:8] + b"\xde\xad\xbe\xef" + d[12:] if n == "classes.dex" else d))
    out = Engine().run("list", str(dst), 600, what="classes")
    assert "repaired" in out and "c:L" in out


def test_apk_dex_zip_bomb_refused(tmp_path):
    src = apk("de.markusfisch.android.binaryeye.apk")
    dst = tmp_path / "bomb.apk"

    def mut(z, n, d):
        if n != "classes.dex":
            return z.writestr(n, d)
        with z.open("classes.dex", "w") as f:
            for _ in range(300):
                f.write(b"\0" * (1 << 20))
    _rezip(src, dst, mut)
    out = Engine().run("list", str(dst), 600, what="classes")
    assert "refused" in out


def test_apk_unreadable_manifest_degrades(tmp_path):
    p = tmp_path / "m.apk"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("AndroidManifest.xml", b"\x03\x00\x08\x00" + bytes(random.Random(2).randrange(256) for _ in range(2000)))
    out = Engine().run("open", str(p), 600)
    assert not out.startswith("error:") and "unreadable" in out


# ---- ghidra: default cache path (~/.cache/...) was rejected by ProjectLocator --------------------------------
def test_ghidra_projects_dir_avoids_dot_elements(tmp_path, monkeypatch):
    from lean_re.decomp import _ghidra_ok_path, ghidra_projects_dir
    assert not _ghidra_ok_path("/home/u/.cache/lean-re/ghidra")
    assert not _ghidra_ok_path("relative/ghidra")
    assert _ghidra_ok_path("/var/tmp/lean-re-1/ghidra")
    monkeypatch.delenv("LRE_GHIDRA_PROJECTS", raising=False)
    monkeypatch.setenv("LRE_CACHE", str(tmp_path / ".cache" / "lean-re"))
    d = ghidra_projects_dir()
    assert _ghidra_ok_path(d) and os.path.isdir(d)
    ok = tmp_path / "plain"
    monkeypatch.setenv("LRE_CACHE", str(ok))
    if _ghidra_ok_path(str(ok)):
        assert ghidra_projects_dir() == str(ok / "ghidra")
