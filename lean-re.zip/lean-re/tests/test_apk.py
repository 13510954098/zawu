import time
from conftest import apk
from lean_re.apk import Apk
from lean_re import batch


def test_manifest_fast_and_exported():
    t = time.time()
    a = Apk(apk("org.fdroid.basic.apk"))
    s = "\n".join(a.overview())
    assert time.time() - t < 5
    assert "org.fdroid.basic" in s and "exported activity org.fdroid.MainActivity" in s


def test_string_xref_decompile_and_cache():
    p = apk("org.fdroid.basic.apk")
    a = Apk(p)
    hits = a.find("org.fdroid.action.UPDATE_REPOS", kind="string")
    assert any("UpdateRepoActivity;->onCreate" in h for h in hits)
    m = [l.split()[0] for l in a.show("c:Lorg/fdroid/MainActivity;") if "->onCreate(" in l][0]
    src = "\n".join(a.show(m))
    assert "onCreate" in src and "decompile failed" not in src
    t = time.time()
    Apk(p).xref_index()                       # second load comes from cache
    assert time.time() - t < 3


def test_batch(tmp_path):
    out = tmp_path / "t.jsonl"
    lines = batch.run([apk("org.fdroid.basic.apk"), apk("de.markusfisch.android.binaryeye.apk")], str(out), 2)
    assert len(out.read_text().splitlines()) == 2
    assert any("de.markusfisch.android.binaryeye" in l for l in lines)
