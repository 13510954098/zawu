"""0.6.0: fixes for the limitations left after the stress campaign — memory of huge binaries (columnar call
graph, mmap section views, LIEF released), variadic call arguments, huge-function decompile routing."""
import os

import pytest

from conftest import fx
from lean_re.engine import Engine
from lean_re.native import Native, fmt_args, fmt_func


# ---- variadic arguments -----------------------------------------------------------------------------------
@pytest.mark.parametrize("fmt,scan,kinds", [
    ("records=%d hash=%08x\\n", False, ["i", "i"]),
    ("%5.2f %%s %*d %s", False, ["f", "i", "i", "i"]),
    ("%2$s %1$d", False, ["i", "i"]),
    ("%m %lu %Lf %lf", False, ["i", "f", "f"]),
    ("%d %f %[a-z]", True, ["i", "i", "i"]),           # scanf: every conversion is a pointer
    ("no conversions %%", False, []),
])
def test_fmt_args(fmt, scan, kinds):
    assert fmt_args(fmt, scan) == kinds


def test_fmt_func_names():
    assert fmt_func("fprintf") == 1 and fmt_func("__printf_chk") == 1 and fmt_func("_printf") == 0
    assert fmt_func("f:140001480 fprintf") == 1          # statically linked, lean-re display name
    assert fmt_func("printf.constprop.0") is None          # GCC clone: ABI may differ
    assert fmt_func("vfprintf") is None                    # va_list, not variadic


def _calls(path, fname):
    E = Engine()
    _h, n = E.get(path)
    f = next(a for a in n.fn_starts if n.fname(a).split()[-1] == fname)
    return {c[1].split()[-1]: c[2] for c in n.dossier(f)["calls"] if c[1]}, n, f


def test_varargs_sysv_x64():
    calls, _n, _f = _calls(fx("pack_x64"), "main")
    assert calls["printf"] == ['"records=%d hash=%08x\\n"', "<rsi>", "<rdx>"]


def test_varargs_aarch64_linux():
    calls, _n, _f = _calls(fx("pack_a64_stripped"), "main")
    assert calls["printf"][1:] == ["<x1>", "<x2>"]


def test_varargs_win64_positional_and_stack():
    calls, _n, _f = _calls(fx("pack_win.exe"), "_matherr")
    # fmt in rdx (slot 1): %s %s -> r8 r9, then %g %g %g on the stack after the 32-byte shadow space
    assert calls["fprintf"][2:] == ["<r8>", "<r9>", "<stack+0x20>", "<stack+0x28>", "<stack+0x30>"]


def test_varargs_in_show_output():
    out = Engine().run("show", fx("pack_x64"), 800, ident="read_record")
    assert 'fprintf(&stderr, "bad record length %u\\n", <rdx>)' in out


# ---- columnar call graph -----------------------------------------------------------------------------------
@pytest.mark.parametrize("name", ["pack_x64", "pack_win.exe", "macho_a64.so"])
def test_graph_consistency(name):
    p = fx(name)
    n = Native(p)
    for f in n.fn_starts:
        for k in n.callees.get(f, ()):
            assert f in n.callers[k]
            sites = n.graph.sites(k, f)
            assert sites and all(n.func_of(s) == f for s in sites)
        assert n.callees.count(f) == len(n.callees.get(f, ()))
    assert n.callers.get(("imp", "no_such_import")) == ()
    assert 0xdeadbeef not in n.callers


# ---- memory: no private copy of the file, LIEF released ----------------------------------------------------
def test_sections_are_zero_copy_and_lief_released():
    p = fx("pack_x64")
    n = Native(p)
    assert not hasattr(n, "b") and not hasattr(n, "data")
    assert n.size == os.path.getsize(p)
    views = [s[3] for s in n.sections if s[3]]
    assert views and any(isinstance(v, memoryview) for v in views)
    va, _sz, _nm, content, _ex = next(s for s in n.sections if s[4] and s[3])
    assert isinstance(n.read(va, 16), bytes) and n.read(va, 16) == bytes(content[:16])


def test_engine_does_not_read_whole_file(monkeypatch):
    import builtins
    real = builtins.open
    seen = []

    def spy(path, mode="r", *a, **k):
        f = real(path, mode, *a, **k)
        if "b" in mode and str(path).endswith("pack_x64"):
            orig = f.read
            f.read = lambda n=-1: (seen.append(n), orig(n))[1]
        return f
    monkeypatch.setattr(builtins, "open", spy)
    Engine().run("open", fx("pack_x64"), 300)
    assert -1 not in seen                                  # only the 4-byte magic sniff, never read()-all


# ---- huge-function routing -----------------------------------------------------------------------------------
def test_huge_function_routing_notes(monkeypatch):
    from lean_re import decomp
    n = Native(fx("pack_x64"))
    f = next(a for a in n.fn_starts if "read_record" in n.fname(a))
    monkeypatch.setenv("LRE_HUGE_FN", "16")
    seen = []
    monkeypatch.setattr(decomp, "backends", lambda prefer=None: ["ghidra", "angr"])
    monkeypatch.setattr(n, "_decomp_live", lambda b, f, fallback=False, huge=False: (seen.append((b, huge)), "x")[1])
    n.cache_key = None
    out = n._decomp(f)
    assert seen == [("ghidra", True)]                      # angr is not tried for huge functions
    assert "using Ghidra only" in " ".join(out)
