import os, subprocess, sys
import pytest

HERE = os.path.dirname(__file__)
FIX = os.path.join(HERE, "fixtures")
APKS = os.environ.get("LRE_TEST_APKS", "/home/user/fixtures_dl")


@pytest.fixture(scope="session", autouse=True)
def build_fixtures(tmp_path_factory):
    os.environ["LRE_CACHE"] = str(tmp_path_factory.mktemp("cache"))
    if not os.path.exists(os.path.join(FIX, "app.asar")):
        subprocess.check_call([sys.executable, os.path.join(FIX, "make_electron.py")])
    yield


def fx(name):
    p = os.path.join(FIX, name)
    if not os.path.exists(p):
        pytest.skip(f"fixture {name} missing (see tests/fixtures/build.sh)")
    return p


def apk(name):
    p = os.path.join(APKS, name)
    if not os.path.exists(p):
        pytest.skip(f"APK {name} not available (set LRE_TEST_APKS)")
    return p
