#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
static uint32_t rotl(uint32_t x, int r) { return (x << r) | (x >> (32 - r)); }
uint32_t pack_hash(const uint8_t *p, size_t n, uint32_t seed) {
    uint32_t h = seed ^ (uint32_t)n * 0x9E3779B1u;
    for (size_t i = 0; i + 4 <= n; i += 4) {
        uint32_t k; memcpy(&k, p + i, 4);
        k *= 0xCC9E2D51u; k = rotl(k, 15); k *= 0x1B873593u;
        h ^= k; h = rotl(h, 13) * 5 + 0xE6546B64u;
    }
    return h;
}
int read_record(FILE *f, uint8_t *buf, size_t cap) {
    int tag = fgetc(f);
    if (tag == EOF) return -1;
    if (tag != 0xA1 && tag != 0xA2) { fprintf(stderr, "bad record tag %02x\n", tag); return -2; }
    uint32_t len = 0;
    if (fread(&len, 1, 4, f) != 4) return -3;
    if (len == 0 || len > 0x1000 || len > cap) { fprintf(stderr, "bad record length %u\n", len); return -4; }
    if (fread(buf, 1, len, f) != len) return -5;
    return (int)len;
}
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s <file.gtp>\n", argv[0]); return 2; }
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("open"); return 1; }
    char magic[4];
    if (fread(magic, 1, 4, f) != 4 || memcmp(magic, "GTP1", 4)) { puts("bad magic"); return 1; }
    uint8_t buf[0x1000]; int n, count = 0; uint32_t h = 0;
    while ((n = read_record(f, buf, sizeof buf)) > 0) { h = pack_hash(buf, n, h); count++; }
    printf("records=%d hash=%08x\n", count, h);
    return n == -1 ? 0 : 1;
}
