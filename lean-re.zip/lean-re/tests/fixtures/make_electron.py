"""Build a small Electron-style app fixture (dir + .asar) for tests."""
import json, os, struct, sys

MAIN = """const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const store = require('./store');
const CH = require('./channels');
function createWindow() {
  const win = new BrowserWindow({ width: 900, height: 600,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false } });
  win.loadFile('index.html');
  return win;
}
ipcMain.handle('notes:search', async (event, query) => {
  const q = String(query).toLowerCase().normalize('NFKD');
  return store.all().filter(n => n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q)).slice(0, 50);
});
ipcMain.handle(CH.SAVE, async (e, note) => { store.add(note); return true; });
ipcMain.on('log:info', (e, msg) => console.log(msg));
ipcMain.on('open-link', (e, url) => { if (/^https:\\/\\//.test(url)) shell.openExternal(url); });
app.whenReady().then(() => { const w = createWindow(); w.webContents.send('app:ready', { v: 1 }); });
"""
STORE = """const fs = require('fs');
let notes = [];
module.exports = { all: () => notes, add: (n) => notes.push(n) };
"""
PRELOAD = """const { contextBridge, ipcRenderer: r } = require('electron');
const CH = require('./channels');
contextBridge.exposeInMainWorld('api', {
  search: (q) => r.invoke('notes:search', q),
  openLink: (u) => r.send('open-link', u),
  save: (n) => r.invoke(CH.SAVE, n),
  log: (level, msg) => r.send('log:' + level, msg),
  raw: (chan, data) => r.send(chan, data),
  onReady: (cb) => r.on('app:ready', (_e, info) => cb(info)),
  version: process.versions.electron
});
"""
FILLER = "".join(f"function q{i}(a,b){{return a*{i}+b^{i*7}}}" for i in range(900))
RENDERER = ("(()=>{" + FILLER + "const t=window.api;let n=document.getElementById('q');"
            "n.addEventListener('input',async e=>{const r=await t.search(e.target.value);render(r)});"
            "function render(r){document.getElementById('out').innerHTML=r.map(x=>'<li>'+x.title).join('')}"
            "fetch('https://api.example.org/v2/sync?token=1').then(x=>x.json());" + FILLER + "})();")
FILES = {"package.json": json.dumps({"name": "notes-demo", "version": "1.4.2", "main": "main.js",
                                     "devDependencies": {"electron": "^38.0.0"}}),
         "main.js": MAIN, "channels.js": "module.exports = { SAVE: 'notes:save', VERSION: 3 };\n", "store.js": STORE, "preload.js": PRELOAD,
         "assets/renderer.bundle.js": RENDERER, "index.html": "<script src='assets/renderer.bundle.js'></script>"}


def write_asar(files, out):
    tree, blob, off = {"files": {}}, b"", 0
    for p, s in files.items():
        data = s.encode()
        node = tree
        parts = p.split("/")
        for d in parts[:-1]:
            node = node["files"].setdefault(d, {"files": {}})
        node["files"][parts[-1]] = {"size": len(data), "offset": str(off)}
        blob += data
        off += len(data)
    h = json.dumps(tree).encode()
    pad = (4 - len(h) % 4) % 4
    pickle = struct.pack("<II", 4 + len(h) + pad, len(h)) + h + b"\0" * pad
    with open(out, "wb") as f:
        f.write(struct.pack("<II", 4, len(pickle)) + pickle + blob)


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(root, "electron_app")
    for p, s in FILES.items():
        os.makedirs(os.path.dirname(os.path.join(d, p)), exist_ok=True)
        open(os.path.join(d, p), "w").write(s)
    write_asar(FILES, os.path.join(root, "app.asar"))
    print("ok", d)
