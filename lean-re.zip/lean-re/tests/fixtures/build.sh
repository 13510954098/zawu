#!/bin/sh
# Rebuild native fixtures (gcc, aarch64-linux-gnu-gcc, x86_64-w64-mingw32-gcc).
set -e
cd "$(dirname "$0")"
gcc -O2 -o pack_x64 src/pack.c
cp pack_x64 pack_x64_stripped && strip pack_x64_stripped
aarch64-linux-gnu-gcc -O2 -o pack_a64_stripped src/pack.c && aarch64-linux-gnu-strip pack_a64_stripped || true
x86_64-w64-mingw32-gcc -O2 -o pack_win.exe src/pack.c || true
python3 make_electron.py
