module.exports = { SAVE: 'notes:save', VERSION: 3 };
