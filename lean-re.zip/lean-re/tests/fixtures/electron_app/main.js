const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const store = require('./store');
const CH = require('./channels');
function createWindow() {
  const win = new BrowserWindow({ width: 900, height: 600,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: false } });
  win.loadFile('index.html');
  return win;
}
ipcMain.handle('notes:search', async (event, query) => {
  const q = String(query).toLowerCase().normalize('NFKD');
  return store.all().filter(n => n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q)).slice(0, 50);
});
ipcMain.handle(CH.SAVE, async (e, note) => { store.add(note); return true; });
ipcMain.on('log:info', (e, msg) => console.log(msg));
ipcMain.on('open-link', (e, url) => { if (/^https:\/\//.test(url)) shell.openExternal(url); });
app.whenReady().then(() => { const w = createWindow(); w.webContents.send('app:ready', { v: 1 }); });
