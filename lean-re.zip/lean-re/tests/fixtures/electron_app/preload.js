const { contextBridge, ipcRenderer: r } = require('electron');
const CH = require('./channels');
contextBridge.exposeInMainWorld('api', {
  search: (q) => r.invoke('notes:search', q),
  openLink: (u) => r.send('open-link', u),
  save: (n) => r.invoke(CH.SAVE, n),
  log: (level, msg) => r.send('log:' + level, msg),
  raw: (chan, data) => r.send(chan, data),
  onReady: (cb) => r.on('app:ready', (_e, info) => cb(info)),
  version: process.versions.electron
});
