const fs = require('fs');
let notes = [];
module.exports = { all: () => notes, add: (n) => notes.push(n) };
