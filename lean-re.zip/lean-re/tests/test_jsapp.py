import pytest
from conftest import fx
from lean_re.jsapp import JsApp


@pytest.fixture(params=["app.asar", "electron_app"])
def app(request):
    return JsApp(fx(request.param))


def test_overview(app):
    s = "\n".join(app.overview())
    assert "notes:search" in s and "open-link" in s and "app:ready" in s
    assert "window.api = {search, openLink, save, log, raw, onReady, version}" in s
    assert "sandbox:false" in s and "shell.openExternal" in s


def test_ipc_trace_end_to_end(app):
    s = "\n".join(app.xrefs("ipc:notes:search"))
    assert "handle" in s and "main.js:11" in s
    assert "invoke" in s and "preload.js" in s
    assert "renderer window.api.search()" in s and "renderer.bundle.js" in s


def test_minified_hits_are_windows_not_lines(app):
    hits = app.find("api.example.org")
    assert hits and all(len(h) < 260 for h in hits)       # bundle line is ~70 KB


def test_show_minified_location(app):
    loc = app.find("t.search")[0].split()[0]
    out = app.show(loc)
    assert any(l.startswith("▶") and "search" in l for l in out)
    assert len(out) < 200


def test_import_graph(app):
    assert any("main.js" in l for l in app.xrefs("file:store.js"))


def test_dynamic_channels_resolved(app):
    s = "\n".join(app.xrefs("ipc:notes:save"))
    assert s.count("[via CH.SAVE]") == 2 and "handle" in s and "invoke" in s


def test_concat_channel_matches_pattern(app):
    s = "\n".join(app.xrefs("ipc:log:info"))
    assert "main.js" in s and "preload.js" in s
    assert "ipc:log: " not in "\n".join(app.list("ipc")) + " "    # no bogus literal 'log:'


def test_unresolvable_dynamic_is_reported(app):
    assert "+1 dynamic" in "\n".join(app.overview())
