"""Check lean-re's AArch64 flag-helper mapping against angr's own concrete VEX semantics."""
import random

import pytest

angr = pytest.importorskip("angr")
from angr import claripy  # noqa: E402
from angr.engines.vex.claripy import ccall as C  # noqa: E402

from lean_re.a64_ccall import _OPS, _SIGNED, _UNSIGNED  # noqa: E402

_S = claripy.Solver()


def _v(x):
    x = x[0] if isinstance(x, tuple) else x
    try:
        return x.concrete_value & 1
    except Exception:
        return _S.eval(x, 1)[0] & 1


def _a64(cond, op, d1, d2, d3=0):
    B = lambda v: claripy.BVV(v, 64)
    return _v(C.arm64g_calculate_condition(None, B((cond << 4) | op), B(d1), B(d2), B(d3)))


def _pick(w):
    m = (1 << w) - 1
    return random.choice([0, 1, m, m >> 1, (m >> 1) + 1, random.getrandbits(w), random.getrandbits(8)])


def test_32bit_ops_match_arm_semantics():
    """ARM64 *32 ops on zero-extended deps == ARM helper with the mapped cc_op (what the rewriter reuses)."""
    random.seed(1)
    for op64, (op32, w) in _OPS.items():
        if w != 32 or op32 == C.ARMG_CC_OP_COPY:
            continue
        for cond in range(14):
            for _ in range(150):
                d1, d2 = _pick(32), _pick(32)
                d3 = random.getrandbits(1) if op32 in (C.ARMG_CC_OP_ADC, C.ARMG_CC_OP_SBB) else 0
                if op32 == C.ARMG_CC_OP_LOGIC:
                    d2 = d3 = 0
                B = lambda v: claripy.BVV(v, 32)
                ref = _v(C.armg_calculate_condition(None, B((cond << 4) | op32), B(d1), B(d2), B(d3)))
                assert _a64(cond, op64, d1, d2, d3) == ref, (op64, cond, d1, d2, d3)


@pytest.mark.parametrize("w,add,sub", [(32, C.ARM64G_CC_OP_ADD32, C.ARM64G_CC_OP_SUB32),
                                       (64, C.ARM64G_CC_OP_ADD64, C.ARM64G_CC_OP_SUB64)])
def test_cmn_const_becomes_cmp_negated(w, add, sub):
    """The rewriter turns `cmn x, #c` into `cmp x, #-c` only where that is exact."""
    random.seed(2)
    m = (1 << w) - 1
    for cond in range(14):
        for _ in range(150):
            d1, c = _pick(w), _pick(w)
            allowed = cond in (C.ARMCondEQ, C.ARMCondNE) or (cond in _UNSIGNED and c) or \
                (cond in _SIGNED and c != 1 << (w - 1))
            if allowed:
                assert _a64(cond, add, d1, c) == _a64(cond, sub, d1, (-c) & m), (w, cond, d1, c)
