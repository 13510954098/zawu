import pytest
from conftest import fx
from lean_re.engine import Engine
from lean_re.native import Native


def load(name):
    p = fx(name)
    return Native(p, open(p, "rb").read())


@pytest.mark.parametrize("name", ["pack_x64_stripped", "pack_a64_stripped", "pack_win.exe"])
def test_main_and_imports(name):
    n = load(name)
    assert "main" in n.names.values()
    assert any("fread" in i for i in n.imports)


@pytest.mark.parametrize("name", ["pack_x64_stripped", "pack_a64_stripped", "pack_win.exe"])
def test_string_xref_finds_validator(name):
    n = load(name)
    hits = n.find("bad record length")
    assert hits and "no direct code ref" not in hits[0]
    fid = hits[0].split("← ")[1].split()[0]
    text = "\n".join(n.show(fid))
    # validation rules recovered without a decompiler
    assert "range check" in text and "0x1000" in text
    assert "0xa1" in text and "0xa2" in text


@pytest.mark.parametrize("name", ["pack_x64_stripped", "pack_a64_stripped"])
def test_call_args_and_constants(name):
    n = load(name)
    s = "\n".join(n.show("main"))
    assert 'puts("bad magic")' in s
    assert "fopen(?, \"rb\")" in s
    assert "MurmurHash3 c1" in s and "xxHash32 PRIME1" in s


def test_magic_ascii_and_loops():
    n = load("pack_x64_stripped")
    s = "\n".join(n.show("main"))
    assert "ascii 'GTP1'" in s
    rec = "\n".join(n.show(n.find("bad record tag")[0].split("← ")[1].split()[0]))
    assert "loops=0" in rec          # back-jump to shared epilogue is not a loop


def test_asm_view_annotated():
    n = load("pack_x64_stripped")
    asm = "\n".join(n.show("main", view="asm"))
    assert "call puts" in asm and '"bad magic"' in asm


def test_engine_budget_and_cursor():
    e = Engine()
    p = fx("pack_x64_stripped")
    out = e.run("list", p, budget=200, what="strings")
    assert "cursor=" in out and len(out) < 1200
    nxt = int(out.rsplit("cursor=", 1)[1].rstrip("]"))
    out2 = e.run("list", p, budget=200, cursor=nxt, what="strings")
    assert out2 != out


def test_errors_are_short():
    e = Engine()
    assert e.run("show", fx("pack_x64_stripped"), ident="f:zzz").startswith("error:")
    assert e.run("open", "/nonexistent").startswith("error:")


@pytest.mark.parametrize("name", ["macho_x64.so", "macho_a64.so"])
def test_macho_stubs_and_pointer_tables(name):
    # real Apple-toolchain binaries (MarkupSafe _speedups, BSD-3) for x86_64 and arm64
    n = load(name)
    assert n.fmt == "Mach-O"
    s = "\n".join(n.show("escape_unicode"))
    assert "PyUnicode_New(?, 0x10ffff)" in s and "memcpy(" in s
    assert '"_escape_inner"' in s            # found through the method table pointer
    assert "PyInit__speedups" in n.names.values()


def test_native_index_cache(tmp_path, monkeypatch):
    monkeypatch.setenv("LRE_CACHE", str(tmp_path))
    p = fx("pack_x64_stripped")
    a = Native(p, open(p, "rb").read())
    b = Native(p, open(p, "rb").read())
    assert not a.from_cache and b.from_cache
    assert a.show("main") == b.show("main")


def test_a64_magic_from_movk_pair():
    s = "\n".join(load("pack_a64_stripped").show("main"))
    assert "ascii 'GTP1'" in s


# ---- pseudo-C (angr backend; optional dependency) ----
from lean_re import decomp as _dec

needs_angr = pytest.mark.skipif(not _dec.available(), reason="angr not installed (pip install 'lean-re[decomp]')")


needs_ghidra = pytest.mark.skipif(not _dec.ghidra_available(),
                                  reason="Ghidra backend needs GHIDRA_INSTALL_DIR, JDK 21 and pyghidra")


@pytest.fixture
def ghidra_room():
    """Ghidra's JVM wants ~1 GB; on small CI boxes free the angr worker first."""
    _dec.shutdown("angr")
    yield


def _c(name, ident, tmp_path, monkeypatch, view="decomp:angr"):
    monkeypatch.setenv("LRE_CACHE", str(tmp_path))
    p = fx(name)
    return "\n".join(Native(p, open(p, "rb").read()).show(ident, view=view))


@needs_angr
def test_decomp_x64_main(tmp_path, monkeypatch):
    s = _c("pack_x64_stripped", "main", tmp_path, monkeypatch)
    assert "fopen" in s and "ascii 'GTP1'" in s and "MurmurHash3" in s
    assert "sub_" not in s                          # renamed to lean-re ids


@needs_angr
def test_decomp_pe_error_codes(tmp_path, monkeypatch):
    s = _c("pack_win.exe", "read_record", tmp_path, monkeypatch)
    assert "-3" in s and "-5" in s


@needs_angr
def test_decomp_macho_bundle(tmp_path, monkeypatch):
    s = _c("macho_a64.so", "escape_unicode", tmp_path, monkeypatch)
    assert "_escape_unicode(" in s and "decompile failed" not in s


@needs_angr
def test_decomp_cached(tmp_path, monkeypatch):
    a = _c("pack_a64_stripped", "f:bf0", tmp_path, monkeypatch)
    b = _c("pack_a64_stripped", "f:bf0", tmp_path, monkeypatch)
    assert a == b and "fread" in a


def test_decomp_without_backend_degrades(tmp_path, monkeypatch):
    monkeypatch.setattr(_dec, "available", lambda: False)
    monkeypatch.setattr(_dec, "ghidra_available", lambda: False)
    s = _c("pack_x64_stripped", "main", tmp_path, monkeypatch, view="decomp")
    assert "pip install 'lean-re[decomp]'" in s


import re as _re


@needs_angr
def test_decomp_import_prototypes_keep_args(tmp_path, monkeypatch):
    # region-only CFGs never reach angr's SimProcedure hooks; lean-re supplies libc prototypes
    s = _c("pack_x64_stripped", "f:13b0", tmp_path, monkeypatch)
    assert len(_re.findall(r"fread\([^(),]+, 1, [^(),]+, [^(),]+\)", s)) == 2
    assert _re.search(r"fgetc\(\w+\)", s)


@needs_angr
def test_decomp_a64_flag_helpers_rewritten(tmp_path, monkeypatch):
    s = _c("pack_a64_stripped", "f:bf0", tmp_path, monkeypatch)
    assert "arm64g_" not in s                      # AArch64 ccall rewriter (angr has none)
    assert "0xffffffff /* -1 */" in s              # cmn w0, #1  ->  == -1 (EOF)
    assert len(_re.findall(r"fread\([^(),&]+, 1, [^(),]+, [^(),]+\)", s)) == 1


LIBCRYPTO = "/usr/lib/x86_64-linux-gnu/libcrypto.so.3"


@needs_angr
@pytest.mark.skipif(not __import__("os").path.exists(LIBCRYPTO), reason="system libcrypto not present")
def test_decomp_tail_call_to_import(tmp_path, monkeypatch):
    monkeypatch.setenv("LRE_CACHE", str(tmp_path))
    n = Native(LIBCRYPTO, open(LIBCRYPTO, "rb").read())
    s = "\n".join(n.show("EVP_EncryptInit_ex", view="decomp:angr"))
    assert _re.search(r"EVP_EncryptInit_ex\((long long a\d, ){4}long long a4\)", s)
    assert "return EVP_CipherInit_ex(a0, a1, a2, a3, a4, 1);" in s


@needs_ghidra
def test_decomp_ghidra_backend(tmp_path, monkeypatch, ghidra_room):
    monkeypatch.setenv("LRE_GHIDRA_WAIT", "600")
    s = _c("pack_x64_stripped", "f:13b0", tmp_path, monkeypatch, view="decomp:ghidra")
    assert "(ghidra;" in s and "f_13b0(" in s and "FUN_" not in s   # Ghidra names mapped to lean-re ids
    assert "/* -3 */" in s and "fread(" in s


@needs_ghidra
def test_decomp_ghidra_pe_high_va(tmp_path, monkeypatch, ghidra_room):
    monkeypatch.setenv("LRE_GHIDRA_WAIT", "600")
    s = _c("pack_win.exe", "read_record", tmp_path, monkeypatch, view="decomp:ghidra")
    assert "read_record(" in s and "/* -5 */" in s
