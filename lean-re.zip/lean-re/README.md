# lean-re

**给 AI 编程智能体用的、省 token 的静态逆向工具。** 支持原生二进制（ELF / PE / Mach-O，x86-64 / x86 / arm64）、Electron/JS 应用（目录或 `.asar`）和 Android APK。提供 6 个 MCP 工具和一个同构的 CLI，所有输出都有 token 预算并支持分页。

这个项目是针对公开评测里 [REA](https://github.com/morluto/rea) 暴露出的问题重新设计的。它不是 REA 的 fork，代码从零写起。

## 为什么要重做：REA 的问题和对应改法

| 评测发现的问题 | 来源 | lean-re 的做法 |
|---|---|---|
| 强制使用 REA 时得分 73/75，低于纯 shell 的 74/75，token 却是 2.5 倍 | GitTested | 每次调用都有**输出预算**（默认 1200 token），超出部分用 `cursor` 分页；默认返回**函数档案**而不是整段反汇编 |
| 往智能体的工具列表里塞了 139 个工具 | GitTested | 只有 **6 个工具**，整份 schema 约 1,000 token |
| 只是外部反编译器的"胶水层"，本身没有分析能力 | 多篇评测、HN | **内置分析**：调用点参数恢复、字符串/指针表交叉引用、比较立即数和**范围检查惯用法**识别（`lea r,[x-0xa1]; cmp r,1; ja` → `x ∈ [0xa1,0xa2]`）、魔数/加密表识别、基于 CFG 可达性的循环检测、剥离符号二进制的 `main` 定位。**不依赖** Ghidra、IDA 或 Hopper |
| 一个 22 MB 的 asar 生成了 692 MB 的文档，一次工具调用返回不了 | GitTested | 不生成整体报告。按文件惰性建索引，命中结果只返回**命中点附近的窗口**，不返回整行压缩代码；`show` 对压缩代码只**局部美化**命中位置附近 |
| Android 依赖 jadx 预处理，动辄几十分钟，无法批量 | HN | manifest 约 0.1 秒；DEX 表按需解析；invoke 和 const-string 的 xref 索引**只建一次**（16 MB DEX 约 11 秒）并缓存到磁盘，再次打开约 0.4 秒；单个方法用 androguard DAD **按需反编译**；`re_batch` **多进程**批量分诊 |
| "比直接让 Claude 去装 Ghidra 强在哪？" | HN | 见下面的基准对比。对于很小的程序，工具说明里会直接告诉智能体：objdump/rg 可能就够了 |

## 基准（`python bench/bench.py`）

这是确定性的 token 成本对比，不是 LLM 评测。同一个问题，统计智能体在两条路径上需要阅读的输出 token 数，以及关键事实是否按字面出现在输出里。

| 问题 | 路径 | 输出 token | 关键事实 |
|---|---|---:|---|
| x64 剥离符号：接受哪些 record tag 和长度？ | **lean-re** | **190** | **4/4** |
| | shell（strings + objdump） | 2,433 | 3/4 |
| arm64 剥离符号：同一问题 | **lean-re** | **188** | **4/4** |
| | shell | 2,256 | 3/4 |
| Electron：追踪 `notes:search` 渲染进程 → preload → 主进程 | **lean-re** | **187** | **3/3** |
| | shell（grep） | 19,444 | 3/3 |

arm64 的 shell 路径需要 `aarch64-linux-gnu-objdump`。脚本会依次在 PATH、`$LRE_A64_OBJDUMP` 和 `~/.cache/tools/binutils-a64` 中查找；没有 root 时可以用 `apt-get download binutils-aarch64-linux-gnu && dpkg-deb -x *.deb ~/.cache/tools/binutils-a64` 装到用户目录。找不到时该行输出 `n/a`，不会再像以前那样给出失真的数字。

纯 shell 路径缺的那条事实是 `0xa2`。它在汇编里不会以字面量出现，需要模型自己从 `lea edx,[rax-0xa1]; cmp edx,1; ja` 推出来，而 lean-re 直接给出了 `rax ∈ [0xa1, 0xa2]`。

**局限，如实说明：**
- 测试样本是我自己写的小程序，代表性有限。
- 二进制越大、压缩代码越长，token 差距越大，但这还没有在真实的智能体任务上做过端到端评测。`bench/` 里的脚本可以作为跑真实评测的起点。

## 安装

```bash
pip install -e .            # Python ≥ 3.10；依赖 capstone、lief、androguard、jsbeautifier、mcp
pip install -e '.[decomp]'  # 可选：伪 C 反编译（angr，纯 pip 安装，不需要 Ghidra/JDK）
pip install -e '.[ghidra]'  # 可选：Ghidra 后端（另需 Ghidra 12 + JDK 21，设置 GHIDRA_INSTALL_DIR / JAVA_HOME）
lre open ./some_binary
```

Ghidra 后端不需要 root，全部装在用户目录即可（本仓库就是这样测试的）：

```bash
T=~/.cache/tools && mkdir -p $T && cd $T
curl -LO https://github.com/adoptium/temurin21-binaries/releases/download/jdk-21.0.12.1%2B1/OpenJDK21U-jdk_x64_linux_hotspot_21.0.12.1_1.tar.gz
curl -LO https://github.com/NationalSecurityAgency/ghidra/releases/download/Ghidra_12.1.4_build/ghidra_12.1.4_PUBLIC_20260921.zip
tar xzf OpenJDK21U-*.tar.gz && unzip -q ghidra_12.1.4_*.zip
pip install --no-index -f ghidra_12.1.4_PUBLIC/Ghidra/Features/PyGhidra/pypkg/dist pyghidra
export GHIDRA_INSTALL_DIR=$T/ghidra_12.1.4_PUBLIC JAVA_HOME=$T/jdk-21.0.12.1+1
```

注册为 MCP 服务器（以 Claude Code 为例）：

```bash
claude mcp add lean-re -- lean-re-mcp
```

其他客户端的配置方式相同：`command: lean-re-mcp`，传输方式为 stdio。

## 6 个工具

| 工具 | 作用 |
|---|---|
| `re_open(path)` | 自动识别类型，返回句柄（如 `t1`）和 ≤900 token 的概览 |
| `re_find(target, query, kind)` | 统一搜索：字符串、符号、导入、常量、代码、IPC、类、方法 |
| `re_show(target, id, view)` | 原生函数档案（默认）、带注解的汇编（`view=asm`）或伪 C（`view=decomp`）；APK 类大纲、单方法反编译或 `view=smali`；JS 文件大纲或指定位置的源码窗口 |
| `re_xrefs(target, id, direction)` | 调用者/使用者（`to`）或被调用者/引用的字符串（`from`），包括函数指针表；`ipc:<chan>` 一次给出整条 IPC 链路（含常量和拼接的通道名） |
| `re_list(target, what, filter)` | 函数、导入、字符串、节；文件、IPC、URL、依赖、风险点；组件、权限、包、类 |
| `re_batch(paths)` | 并行分诊多个 APK 或二进制，完整结果写入 JSONL，只返回紧凑表格 |

任意结果里的 id（`f:401136`、`s:2010`、`file:main.js:12`、`ipc:chan`、`c:Lpkg/Cls;`、`m:Lpkg/Cls;->m()V`）都可以直接传给 `show` 或 `xrefs`。`target` 既可以是路径，也可以是已打开的句柄。

## 示例：剥离符号的 x86-64 二进制

```
$ lre find pack_x64_stripped "bad record"
s:2004 "bad record tag %02x\n" ← f:13b0
s:2019 "bad record length %u\n" ← f:13b0

$ lre show pack_x64_stripped f:13b0
f:13b0  size=238 insns=64 blocks=6 cond-branches=6 loops=0
callers: f:1100 main
calls:
  13c1 fgetc()
  13f4 fread()
  1450 fprintf(&stderr, "bad record length %u\n", <rdx>)
  1492 fprintf(&stderr, "bad record tag %02x\n", <rdx>)
compares→branch: 13c6 eax, -1 →je · 13d1 edx, 1  [range check rax ∈ [0xa1, 0xa2] else reject-branch] →ja ·
  13f9 rax, 4 →jne · 1406 eax, 0xfff  [range check rdx ∈ [0x1, 0x1000] else reject-branch] →ja
```

## 示例：Electron IPC 一次追到底

```
$ lre xrefs app.asar ipc:notes:search
ipc:notes:search — 2 uses (handlers first)
  handle   main.js:10:0     …ipcMain.handle('notes:search', async (event, query) => {…
  invoke   preload.js:3:17  …search: (q) => r.invoke('notes:search', q),…
  renderer window.api.search() dist/renderer.bundle.js:1:34831  …const r=await t.search(e.target.value)…
```

## 伪 C 反编译（`view=decomp`）

默认视图仍然是紧凑的函数档案，因为它最省 token。需要看控制流细节时，再对单个函数要伪 C。后端有两个，可以通过 `view=decomp:angr` / `view=decomp:ghidra` 或环境变量 `LRE_DECOMP_BACKEND` 指定：

| 后端 | 安装 | 首次打开 | 之后每个函数 | 质量 |
|---|---|---|---|---|
| **angr**（默认可用） | `pip install -e '.[decomp]'` | 只分析目标函数所在区域：fixture 约 3 秒，libcrypto 约 5–7 秒 | 约 1 秒 | 够用；输出头部提示对照汇编核实 |
| **Ghidra**（可选） | Ghidra 12 + JDK 21 + `pip install pyghidra`，设置 `GHIDRA_INSTALL_DIR` 和 `JAVA_HOME` | 整个程序导入并自动分析一次，存入缓存目录；fixture 约 14 秒，libcrypto（6.4 MB）**156 秒、内存峰值 722 MB**；之后新进程打开约 8 秒 | **0.0–0.2 秒** | 更好：有类型库，例如 `EVP_EncryptInit_ex(EVP_CIPHER_CTX *ctx, …)` |

**auto 模式**（默认）：装了 Ghidra 就优先用 Ghidra，没装就用 angr。Ghidra 首次分析一个大二进制时，最多只等 5 秒（`LRE_GHIDRA_AUTO_WAIT`），超时就**由 angr 先回答**，输出里附 `// note: ghidra: …analyzing…`，Ghidra 则继续在后台分析，完成后的请求自动切到 Ghidra。智能体不会因为等分析被卡几分钟。显式指定 `decomp:ghidra` 时会一直等到分析完成（`LRE_GHIDRA_WAIT`，默认 300 秒）。

```
$ lre show /usr/lib/x86_64-linux-gnu/libcrypto.so.3 EVP_EncryptInit_ex --view decomp:angr
// f:241ad0 EVP_EncryptInit_ex  pseudo-C (angr; names/consts mapped to lean-re ids; verify against view=asm)
// tail-jumps to import EVP_CipherInit_ex: no prototype known; argument count inferred from register setup, check view=asm
long long EVP_EncryptInit_ex(long long a0, long long a1, long long a2, long long a3, long long a4)
{
    return EVP_CipherInit_ex(a0, a1, a2, a3, a4, 1);  /* tail call */
}
```

lean-re 在 angr 之上补了几处它原本的不足：

- **导入函数原型**：只恢复局部 CFG 时，angr 走不到 SimProcedure 挂钩，PLT 被调函数没有原型，参数全丢（`strlen()`、`fread(a1, 1)`）。现在先查 angr 自带的 libc/msvcrt/win32 原型库；查不到的，用 lean-re 在调用点恢复出的参数个数生成原型，按 `PrototypeSource.SIGNATURES` 登记，避免被 angr 的猜测覆盖。结果是 `fread(a1, 1, v4, a0)`、`strlen(a0)`，参数类型也能推出来（`FILE *a0`）。
- **尾调用**：尾跳目标会一起交给 angr。跳到导入函数时，用尾跳前写入的参数寄存器推出参数个数（写了 `r9d=1`，说明至少 6 个参数），没被改动的参数寄存器就是本函数的透传参数。angr 误标的 `/* do not return */` 改写成 `return …; /* tail call */`。
- **AArch64 标志位重写器**：angr 只给 x86、AMD64 和 32 位 ARM 写了 ccall 重写器，arm64 输出里会留下 `arm64g_calculate_condition(1, ch & 0xffffffff, 1, 0)`。`lean_re/a64_ccall.py` 把 ARM64 的 cc_op 映射到 ARM 的精确规则上，按真实位宽（32/64 位）处理，于是这一句变成 `ch == 0xffffffff /* -1 */`，也就是 `fgetc` 返回 EOF。实测见下表。
- **Mach-O bundle**（MH_BUNDLE，angr 的加载器不接受）：把头部类型改成 dylib，用临时副本反编译。

两种后端共用的部分：

- **独立的常驻子进程**（`python -m lean_re.decomp angr|ghidra`，JSON 行协议）。angr 超时就杀掉；Ghidra 首次分析慢时保留进程，返回“忙”。angr worker 有内存保护：RSS 超过 `LRE_DECOMP_MEM_MB`（默认 1200）的 60% 时在两次请求之间回收，超过 100% 时由看门狗中止当前请求。angr 同一个函数、或 Ghidra 同一个二进制让 worker 死两次后，本会话不再重试，并提示调整 `LRE_DECOMP_MEM_MB` 或 `LRE_GHIDRA_MAXMEM`（默认 768m）。
- **后处理统一**：
  - `sub_XXXX`、`FUN_XXXX` 改写成 lean-re 的名字或 `f_<addr>`（Ghidra 的 PIE 基址 0x100000 按 LIEF 读出的链接基址确定性换算回来），`LAB_`/`LABEL_0x` 改写成 `L_<addr>`，`DAT_` 同样换算地址，可以直接拿去 `re_xrefs`；
  - 常量加注释，例如 `827348039 /* 0x31505447 ascii 'GTP1' */`，以及 MurmurHash3/xxHash 常量、在 `return`/比较/赋值上下文中的负错误码（`0xfffffffd /* -3 */`）。
- **结果按“二进制 × 后端 × 函数”缓存**：重复请求不到 0.1 秒。Ghidra 项目也存在缓存目录里，跨会话复用。

AArch64 重写器实测（PyYAML 的 aarch64 `_yaml.so`，2.6 MB，随机抽取 20 个函数，只用 angr）：

| | 成功反编译 | 残留的 `arm64g_*` helper 调用 |
|---|---|---|
| 不带重写器 | 19 | 92 |
| 带重写器 | 19 | **0** |

映射的正确性用 angr 自己的 VEX helper 具体语义做了等价验证（`tests/test_a64_ccall.py`）：32 位操作逐一对照 ARM helper，`cmn x,#c → cmp x,#-c` 的改写只在精确成立的条件下进行。

## 实测数据

- **libcrypto.so.3**（6.4 MB，剥离符号）：首次建索引 3.6 秒，缓存命中后 0.9 秒；找到 13,242 个函数，识别出 AES S-box、SHA-256 K 表和 ChaCha 常量。
- **Mach-O**（Apple 工具链编译的真实 x86_64 和 arm64 bundle，取自 MarkupSafe wheel）：stub 能解析成导入名；通过 rebase/chained-fixup 指针找到注册表里的函数（`escape_unicode` 存放在 `"_escape_inner"` 旁边）。
- **F-Droid 客户端 APK**（2 个 DEX，11k 个类）：打开 0.13 秒，xref 索引 11 秒（缓存后 0.4 秒），单方法反编译不到 1 秒。
- **测试**：`pytest` 共 63 项，配齐 Ghidra 时 56 秒跑完。其中反编译相关 13 项（angr 8、Ghidra 2、AArch64 重写器语义验证 3），压力测试回归 15 项（`tests/test_hardening.py`），覆盖 x64、arm64、PE、Mach-O x64/arm64、asar 和目录形式的 JS 应用，以及 2 个真实 APK。

## 压力测试（`bench/stress/`）

机器：2 核、约 2 GB 内存。所有脚本都在子进程里跑，并设置内存上限（`RLIMIT_AS` 或 RSS 看门狗）。早期一次不设上限的 libLLVM 运行曾让整台机器卡死。

**规模**（`open_scale.py`）：

| 二进制 | 函数数 | 0.4.0 | 0.5.0 冷启动 | 0.5.0 缓存命中 |
|---|---:|---|---|---|
| libcrypto.so.3（6.4 MB） | 13,242 | 峰值 402 MB | 2.9 s，峰值 189 MB | — |
| libz3.so.4（28 MB） | 88,387 | 1.2 GB 上限下 `CS_ERR_MEM` | 16.6 s，320 MB | 0.5 s |
| libLLVM.so.19.1（130 MB） | 118,060 | 2 GB 机器卡死 | 43.5 s，峰值 887 MB | 2.4 s，833 MB |

0.6.0 又降了一轮常驻内存（同一台机器）：

| 二进制 | 0.5.0 | 0.6.0 |
|---|---|---|
| libcrypto.so.3 | 峰值 189 MB | 峰值 161–173 MB |
| libLLVM.so.19.1 冷启动 | 43.5 s，峰值 887 MB | 41.9 s，常驻 488 MB，峰值 821 MB |
| libLLVM.so.19.1 缓存命中 | 2.4 s，常驻 833 MB | 2.3 s，常驻 438 MB（匿名内存 343 MB），峰值 614 MB |

做法：不再把整个文件读进 `bytes`，节内容改为文件 mmap 上的零拷贝 `memoryview`；建好索引后释放 LIEF 的解析对象（它对 130 MB 的库要占约 300 MB）；调用图改为 numpy 列式（CSR）结构，`callers`/`callees` 用二分查找代替 dict-of-list，`re_xrefs` 在 8,694 个调用者的函数上也只要 0.33 s。cache 格式升到 v4。改动前后对 7 个目标的 544 个工具输出逐字比对，除 printf 类调用行新增了参数之外完全一致；libcrypto 的 13,425 条调用关系 0 差异。

原因有两个：capstone 的 `disasm_lite` 会为整段代码一次性分配 `cs_insn`（20 MB 代码约需 1.2 GB），现在改成 64 KB 窗口逐段扫描；xref 表从“dict + list + tuple”（约 100 B/条）改成 numpy 列式存储（16 B/条）。这两处改动后，五个 fixture 和 libcrypto 的索引指纹逐项一致。

**畸形输入**（`fuzz.py`）：共 132 个样本，覆盖原生格式的截断、翻转字节和头字段篡改；asar 的超大头、坏 JSON、负偏移、2 万层嵌套、20 万文件、路径穿越；JS 目录的 20 MB 单行、软链接环；APK 的截断、中央目录损坏、DEX 损坏或篡改、两种 zip 炸弹。每个样本在独立进程中运行，限 1 GB 内存、60 秒。结果为 **0 崩溃、0 卡死、0 异常逃逸、0 文件泄漏、0 超预算**。修复了这些问题：

- **安全**：asar 中标记为 `unpacked` 的条目可以用 `../` 或 `.unpacked` 里的软链接读到归档外的任意文件（例如 `~/.ssh`），再交给 LLM。现在会拒绝不安全的条目名，并对路径做 realpath 校验，保证不越出 `.unpacked` 目录。
- 非 UTF-8 的节名或符号名（加壳样本常见）会导致原生文件根本打不开。
- APK 的 Manifest 损坏或混淆时整个 APK 打不开，现在会降级，继续分析 DEX。单个坏 DEX 也会导致整个 APK 失败，现在只跳过这个 DEX。DEX 头校验和被篡改（一种反分析手段）时会自动修复并提示。解压后大于 256 MB 的 DEX 会被拒绝，以防 zip 炸弹；解压时也有读取上限。
- asar 遇到负的 size 时会读完整个文件；深层嵌套会抛 `RecursionError`；其余损坏情况只给出看不懂的 `struct.error`。现在一律给出说明原因的 `AsarError`，单个坏条目只跳过这个条目，不会拖垮整个应用。

**预算硬保证**（`budget_prop.py`）：用随机的目标、操作、ID、预算（1 到 10⁹，以及负数和 0）和游标，加上 10 万字符的查询、5000 字符的 ID 等对抗参数，共 20,072 次调用，**0 次超预算**；按游标翻页 0 处遗漏或重复。修复前可能超预算的地方有：错误消息、回显查询的页眉、单行超长的压缩 JS，以及未计入预算的游标行。现在页眉会裁剪，当前页的首行放不下就截断，游标行预留空间，最后再用 `fit()` 兜底。预算策略：0 或不传时取默认值 1200，其余值限制在 [200, 8000]。

**长会话内存**（`session_mem.py`）：
- 打开的目标改为 LRU 工作集（`LRE_MAX_TARGETS=8`、`LRE_SOFT_MB=1024`）。句柄在整个会话内保持有效，被淘汰的目标下次使用时透明重载：libcrypto 0.2 s，libz3 0.5 s（冷启动 16.4 s）。
- 依次打开 40 个不同的库：0.4.0 线性涨到 381 MB；现在稳定在约 170 MB。
- 固定工作集上 5000 次随机调用：RSS 一直是 464 MB，没有逐调用的泄漏。

**批量反编译**（`decomp_load.py`，libcrypto）：

| | 随机 40 个函数 | 最大的 8 个函数 |
|---|---|---|
| angr | 40/40，p50 0.89 s，p90 1.59 s，最慢 4.2 s | 8/8，最慢 49 s |
| Ghidra（首次分析 152 s，728 MB） | 39/39，p50 0.01 s，最慢 0.05 s | 0.5.0：6/8；**0.6.0：8/8**，两个 330 KB 的函数各 70–106 s |

- 0.6.0 对超大函数（> `LRE_HUGE_FN`，默认 64 KB）的处理：
  - 只交给 Ghidra，不走 angr，并在输出中注明；
  - 输出缓冲上限提到 512 MB（`LRE_GHIDRA_MAX_PAYLOAD_MB`）；
  - 超时按函数大小放宽（约 1 秒/KB）；
  - 处理完后回收 Ghidra worker。原因：一个 330 KB 的函数会让 JVM 堆和原生反编译进程合计接近 1 GB，第二个大函数接着跑时原生进程会死掉（报 `Stream closed`），2 GB 的机器随即开始换页。
  - 原生反编译进程中途死亡时，自动新建 `DecompInterface` 再重试一次。
  - 结果约 8 万行，照常按 token 预算分页。
- angr worker 的内存只增不减（8 个大函数后达到 602 MB）。现在有两层保护：RSS 超过 `LRE_DECOMP_MEM_MB`（默认 1200）的 60% 时，在两次请求之间主动回收；超过 100% 时，看门狗中止当前请求，返回清楚的错误，下一个请求自动用新 worker。死亡计数改为按函数统计，不再按二进制：以前在两个大函数上各死一次，就会把整个文件的反编译全部禁掉。
- angr 会在 `/tmp` 留下 LMDB 文件，而 `/tmp` 是 tmpfs，会占内存。现在每个 worker 使用私有的 `TMPDIR`，worker 被杀后整个删除。
- **Ghidra 在默认配置下完全不可用**：默认缓存路径 `~/.cache/lean-re` 含有以点号开头的 `.cache`，被 Ghidra 的 `ProjectLocator` 拒绝。测试和基准都用临时目录，所以一直没发现。现在 Ghidra 项目放到一个合法目录：优先用 `LRE_GHIDRA_PROJECTS`，否则依次尝试缓存目录、macOS 的 `~/Library/Caches`、Windows 的 `%LOCALAPPDATA%`、Linux 的 `/var/tmp/lean-re-<uid>`。

## 智能体端到端评测（`bench/agent_eval/`）

评测方法对齐 GitTested：

- 7 道题，每题有 5 条事先根据源码写好的事实清单，另含 1 道"功能不存在"的反向题；
- 三种条件：`shell`（不注册 MCP）、`lean-re`（明确要求使用）、`free`（注册了但不提示）；
- 记录每次的得分、token 用量和耗时。

```bash
python bench/agent_eval/run.py --agent claude --repeats 3   # 需要已安装 Claude Code CLI
python bench/agent_eval/run.py --agent codex                # 需要 Codex CLI
python bench/agent_eval/run.py --agent oracle               # 无 LLM 的流程自检
```

**目前只跑过 oracle 自检**，即把工具的原始输出直接当作答案，结果是 30/31。缺的那条是"长度为 0 会被拒绝"，需要从 `[1, 0x1000]` 推理得出。**真实 LLM 的结果还需要在装有智能体 CLI 的环境里跑。**

## 已知局限

- **原生分析是线性扫描加启发式**：间接调用和跳转表无法解析时会在 `unknowns:` 里注明，不会去猜。伪 C 的质量取决于后端：
  - angr 不如 Ghidra（变量多、类型粗）；
  - Ghidra 首次打开大二进制要分钟级的分析和约 0.7 GB 内存；
  - 数万条指令的手写汇编函数（例如 OpenSSL 用 perlasm 生成的 AVX-512 AES-GCM，单个约 330 KB）：只走 Ghidra，每个要 1–2 分钟和约 1 GB 内存，没装 Ghidra 时会让你改用 `view=asm`；
  - angr 在 Win64 上偶尔会给 printf 类调用多认一个参数（例如 `fprintf(f, "...%u\n", v0, v4)`）。

  所以输出头部总是注明“对照 view=asm 核实”。
- **可变参数**：摘要视图会根据字面量格式串，按 ABI 把参数放到对应的寄存器或栈槽上（SysV、AArch64 Linux、Win64、Apple arm64），例如 `printf("records=%d hash=%08x\n", <rsi>, <rdx>)`。格式串不是字面量时不展开。`<rdx>` 表示“在这个寄存器里”，值本身要看 `view=asm` 或 `view=decomp`。
- **规模**：libLLVM 这种 130 MB 的库，缓存命中后常驻约 440 MB，冷启动峰值约 820 MB。2 GB 的机器可以开着它，再做别的事。
- **JS 分析基于正则和词法**，不做完整 AST：
  - 通道常量（`CH.SAVE`）只有在全应用范围内唯一时才会解析；
  - 前缀拼接（`'log:' + x`）按模式 `log:*` 匹配；
  - 其余动态通道名只计数，不解析。
- **只做静态分析**：不运行目标程序。请只分析你有权分析的软件。

## 开发

```bash
pip install -e '.[dev]' && tests/fixtures/build.sh && pytest -q
python bench/bench.py
```

APK 测试需要真实的 APK，用 `LRE_TEST_APKS=<目录>` 指定 APK 所在目录，否则会自动跳过。

MIT License.
