"""Token budgeting and paging.

Every response is a list of short lines. The engine renders as many lines as fit
in the caller's token budget and appends a cursor for the rest. Nothing is ever
returned unbounded, which fixes the "692 MB document in one tool call" problem.
"""
DEFAULT_BUDGET = 1200
MAX_BUDGET = 8000


def est_tokens(s: str) -> int:
    # ~3.6 chars/token for code-ish text; conservative.
    return (len(s) * 10 + 35) // 36


def clip(s: str, n: int = 160) -> str:
    s = s.replace("\n", "\\n").replace("\r", "")
    return s if len(s) <= n else s[: n - 1] + "…"


def fit(s: str, budget: int) -> str:
    """Hard guarantee: truncate s so est_tokens(s) <= budget."""
    if est_tokens(s) <= budget:
        return s
    keep = max(0, (budget * 36 - 35) // 10 - 1)
    return s[:keep] + "…"


def effective_budget(budget) -> int:
    try:
        b = int(budget or DEFAULT_BUDGET)
    except (TypeError, ValueError):
        b = DEFAULT_BUDGET
    return max(200, min(b, MAX_BUDGET))


TRAILER_RESERVE = 14     # "[+NNNNNNN more lines · cursor=NNNNNNN]"


def paginate(lines, cursor=0, budget=DEFAULT_BUDGET, header=None):
    budget = effective_budget(budget)
    out, used = [], 0
    if header:
        header = clip(header, budget)            # echoing a 100k-char query must not blow the budget
        out.append(header)
        used += est_tokens(header) + 1
    try:
        cursor = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        cursor = 0
    i = cursor
    n = len(lines)
    while i < n:
        room = budget - used - (TRAILER_RESERVE if i + 1 < n else 0)
        line = lines[i]
        t = est_tokens(line) + 1
        if t > room:
            if i > cursor:
                break
            line = fit(line, max(1, room - 1))   # a single giant line (minified JS, long decomp) is truncated
            t = est_tokens(line) + 1
        out.append(line)
        used += t
        i += 1
    if i < n:
        out.append(f"[+{n - i} more lines · cursor={i}]")
    elif cursor >= n and n:
        out.append(f"[cursor {cursor} is past the end: {n} lines]")
    return fit("\n".join(out), budget)
