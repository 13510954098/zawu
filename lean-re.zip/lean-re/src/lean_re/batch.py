"""Parallel batch triage: many APKs / binaries -> JSONL + compact table.

Manifest/header-level facts only (no DEX decode, no disassembly of every
function), so 100 APKs cost seconds-to-minutes instead of hours.
"""
import glob
import json
import os
import re
import struct
import time
import zipfile
from concurrent.futures import ProcessPoolExecutor

SECRETS = {"google_api_key": re.compile(rb"AIza[0-9A-Za-z_\-]{35}"),
           "aws_access_key": re.compile(rb"AKIA[0-9A-Z]{16}"),
           "private_key": re.compile(rb"-----BEGIN (?:RSA |EC )?PRIVATE KEY-----")}


def triage_apk(path):
    from .apk import DANGEROUS, manifest_facts
    from androguard.core.apk import APK
    a = APK(path)
    z = zipfile.ZipFile(path)
    comps, flags = manifest_facts(a)
    dex = [n for n in z.namelist() if re.fullmatch(r"classes\d*\.dex", n)]
    ncls, hits = 0, {}
    for n in dex:
        raw = z.read(n)
        ncls += struct.unpack_from("<I", raw, 0x60)[0]   # class_defs_size from DEX header
        for k, rx in SECRETS.items():
            c = len(rx.findall(raw))
            if c:
                hits[k] = hits.get(k, 0) + c
    perms = a.get_permissions() or []
    exp = [c for c in comps if c["exported"]]
    return dict(path=path, kind="apk", package=a.get_package(), version=a.get_androidversion_name(),
                min_sdk=a.get_min_sdk_version(), target_sdk=a.get_target_sdk_version(), dex=len(dex), classes=ncls,
                permissions=len(perms), dangerous=[p.split(".")[-1] for p in perms if p.split(".")[-1] in DANGEROUS],
                exported=len(exp), exported_unprotected=[c["name"] for c in exp if not c["perm"]],
                flags=flags, native_libs=sorted({n.split("/")[-1] for n in z.namelist() if n.endswith(".so")}),
                secret_patterns=hits)


def triage_native(path):
    from .native import Native
    n = Native(path, open(path, "rb").read())
    sus = [i for i in n.imports if re.search(r"ptrace|mprotect|dlopen|VirtualProtect|CreateRemoteThread|"
                                               r"WriteProcessMemory|system$|execve|popen|LoadLibrary", i)]
    return dict(path=path, kind="native", format=n.fmt, arch=n.arch, functions=len(n.fn_starts),
                named=sum(1 for f in n.fn_starts if f in n.names), imports=len(n.imports),
                notable_imports=sus[:12], strings=len(n.strings))


def triage(path):
    t = time.time()
    try:
        with open(path, "rb") as f:
            head = f.read(4)
        r = triage_apk(path) if head[:2] == b"PK" else triage_native(path)
    except Exception as e:
        r = dict(path=path, kind="error", error=f"{type(e).__name__}: {e}"[:200])
    r["seconds"] = round(time.time() - t, 2)
    return r


def expand(paths):
    out = []
    for p in paths:
        if os.path.isdir(p):
            out += sorted(os.path.join(d, f) for d, _, fs in os.walk(p) for f in fs
                          if f.endswith((".apk", ".so", ".exe", ".dll", ".elf", ".bin")) or "." not in f)
        else:
            out += sorted(glob.glob(p)) or [p]
    return out


def run(paths, out=None, workers=None):
    files = expand(paths)
    out = out or os.path.join(os.getcwd(), f"triage-{int(time.time())}.jsonl")
    rows = []
    with ProcessPoolExecutor(max_workers=workers or max(1, (os.cpu_count() or 2))) as ex, open(out, "w") as f:
        for r in ex.map(triage, files):
            f.write(json.dumps(r) + "\n")
            rows.append(r)
    lines = [f"triaged {len(rows)} files → {out}"]
    for r in rows:
        if r["kind"] == "apk":
            lines.append(f"{r['package']} v{r['version']} sdk{r['min_sdk']}-{r['target_sdk']} cls={r['classes']} "
                         f"exp={r['exported']}/{len(r['exported_unprotected'])}unprot dang={','.join(r['dangerous'][:5])}"
                         + (f" secrets={r['secret_patterns']}" if r["secret_patterns"] else "") + f" ({r['seconds']}s)")
        elif r["kind"] == "native":
            lines.append(f"{os.path.basename(r['path'])} {r['format']} {r['arch']} fn={r['functions']} "
                         f"imports={r['imports']} notable={','.join(r['notable_imports'])} ({r['seconds']}s)")
        else:
            lines.append(f"{os.path.basename(r['path'])} ERROR {r['error']}")
    return lines
