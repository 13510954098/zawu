"""Tiny on-disk cache: pickled+zlib analysis indexes keyed by file hash."""
import hashlib
import os
import pickle
import zlib

VERSION = 5


def cache_dir():
    d = os.environ.get("LRE_CACHE") or os.path.join(os.path.expanduser("~"), ".cache", "lean-re")
    os.makedirs(d, exist_ok=True)
    return d


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def key_for(path, tag):
    return f"{file_sha256(path)[:24]}-{tag}-v{VERSION}"


def load(key):
    p = os.path.join(cache_dir(), key + ".pkl.z")
    try:
        with open(p, "rb") as f:
            return pickle.loads(zlib.decompress(f.read()))
    except Exception:
        return None


def save(key, obj):
    p = os.path.join(cache_dir(), key + ".pkl.z")
    tmp = p + ".tmp"
    with open(tmp, "wb") as f:
        f.write(zlib.compress(pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL), 6))
    os.replace(tmp, p)
