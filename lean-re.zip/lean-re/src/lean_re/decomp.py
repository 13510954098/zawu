"""Pseudo-C decompilation for native functions.

Backend: angr's decompiler (pip-installable, no external app). Only the target
function's region is recovered (local CFG), so cost does not grow with binary
size. Work runs in a persistent child process that is killed on timeout, so a
pathological function can never hang the agent session.
"""
import os
import re

TIMEOUT = float(os.environ.get("LRE_DECOMP_TIMEOUT", "60"))
MEM_MB = int(os.environ.get("LRE_DECOMP_MEM_MB", "1200"))      # hard cap (watchdog) for the angr worker
RECYCLE_MB = int(MEM_MB * 0.6)                                  # soft: restart between requests
MAX_PROJECTS = int(os.environ.get("LRE_DECOMP_MAX_PROJECTS", "2"))


def available():
    try:
        import importlib.util
        return importlib.util.find_spec("angr") is not None
    except Exception:
        return False


def _loadable(path):
    """CLE rejects Mach-O bundles (MH_BUNDLE=8); a dylib-typed temp copy is equivalent for decompiling."""
    import struct
    import tempfile
    with open(path, "rb") as f:
        head = f.read(16)
    if len(head) == 16 and head[:4] in (b"\xcf\xfa\xed\xfe", b"\xce\xfa\xed\xfe") and struct.unpack_from("<I", head, 12)[0] == 8:
        data = bytearray(open(path, "rb").read())
        struct.pack_into("<I", data, 12, 6)
        fd, tmp = tempfile.mkstemp(suffix=".dylib")
        os.write(fd, bytes(data))
        os.close(fd)
        return tmp
    return path


_PROTO_CACHE = {}
_LIB_ORDER = ("libc.so.6", "msvcrt.dll", "ucrtbase.dll", "kernel32.dll", "ntdll.dll", "user32.dll")


def _lib_prototype(name, arch):
    """Known prototype for an import name from angr's bundled library definitions."""
    from angr.procedures.definitions import SIM_LIBRARIES
    if name in _PROTO_CACHE:
        return _PROTO_CACHE[name]
    found = None
    keys = [k for k in _LIB_ORDER if k in SIM_LIBRARIES] + [k for k in SIM_LIBRARIES if k not in _LIB_ORDER]
    for cand in (name, name[1:] if name.startswith("_") else None):       # Mach-O adds a leading _
        for k in keys if cand else ():
            for lib in SIM_LIBRARIES[k]:
                try:
                    if lib.has_prototype(cand):
                        found = lib.get_prototype(cand, arch=arch)
                        break
                except Exception:
                    continue
            if found is not None:
                break
        if found is not None:
            break
    _PROTO_CACHE[name] = found
    return found


def _set_proto(p, g, proto):
    """Register a prototype with a source rank above angr's own guesses so the decompiler uses it."""
    from angr.calling_conventions import default_cc
    proto = proto.with_arch(p.arch)
    try:
        from angr.knowledge_plugins.functions.function import PrototypeSource
        g.set_prototype(None, proto, source=PrototypeSource.SIGNATURES)
    except (ImportError, AttributeError, TypeError):       # older angr
        g.prototype = proto
    cc_cls = default_cc(p.arch.name, platform=p.simos.name if p.simos else None)
    if cc_cls is not None:
        g.calling_convention = cc_cls(p.arch)


def _apply_prototypes(p, kb, arity):
    """Region-only CFGs never reach angr's SimProcedure hooks, so PLT callees have no prototype and the
    decompiler drops their arguments. Use library prototypes, else lean-re's call-site arity."""
    from angr.sim_type import SimTypeFunction, SimTypeLongLong
    for g in list(kb.functions.values()):
        if not g.name:
            continue
        if not (g.is_plt or g.is_simprocedure or g.name in arity):
            continue
        proto = _lib_prototype(g.name, p.arch)
        if proto is None:
            n = arity.get(g.name)
            if n is None or (g.prototype is not None and len(g.prototype.args) >= n):
                continue
            proto = SimTypeFunction([SimTypeLongLong()] * n, SimTypeLongLong())
        _set_proto(p, g, proto)


def _serve():
    """Worker loop: one JSON request per stdin line, one JSON reply per stdout line."""
    import json
    import logging
    import sys
    logging.disable(logging.CRITICAL)
    out = sys.stdout
    sys.stdout = sys.stderr          # keep angr chatter off the protocol channel
    import angr
    try:
        from .a64_ccall import install
        install()                    # AArch64 flag helpers -> comparisons (angr lacks this rewriter)
    except Exception:
        pass
    projects = {}
    for line in sys.stdin:
        req = json.loads(line)
        path, addr, size, extra = req["path"], req["addr"], req["size"], req.get("extra", [])
        try:
            p = projects.pop(path, None)
            if p is None:
                p = angr.Project(_loadable(path), auto_load_libs=False, load_debug_info=False)
            projects[path] = p                       # most recently used last
            while len(projects) > MAX_PROJECTS:      # bound worker memory (each project holds the loaded image)
                projects.pop(next(iter(projects)))
                import gc
                gc.collect()
            obj = p.loader.main_object
            delta = obj.mapped_base - obj.linked_base
            a = addr + delta
            regions = [(a, a + max(size, 1))] + [(t + delta, t + delta + max(n, 1)) for t, n in extra]
            cfg = p.analyses.CFGFast(regions=regions, function_starts=[r[0] for r in regions], normalize=True,
                                     data_references=True)
            try:   # prototypes for in-region callees (tail-call targets) so call args survive
                p.analyses.CompleteCallingConventions(cfg=cfg.model, recover_variables=True, analyze_callsites=True)
            except Exception:
                pass
            _apply_prototypes(p, cfg.kb, req.get("arity", {}))
            f = cfg.kb.functions.get(a)
            own = req.get("arity", {}).get("@self")
            if f is not None and own and (f.prototype is None or len(f.prototype.args) < own):
                from angr.sim_type import SimTypeFunction, SimTypeLongLong
                _set_proto(p, f, SimTypeFunction([SimTypeLongLong()] * own, SimTypeLongLong()))
            if f is None:
                rep = {"st": "err", "text": "angr found no function at this address"}
            else:
                d = p.analyses.Decompiler(f, cfg=cfg.model)
                rep = {"st": "ok", "text": d.codegen.text if d.codegen else "", "delta": delta}
        except Exception as e:
            rep = {"st": "err", "text": f"{type(e).__name__}: {e}"[:300]}
        try:   # angr knowledge bases only grow; ask the parent to recycle us between requests, long before
            with open("/proc/self/status") as fh:      # the hard watchdog would kill a request mid-flight
                rss = int(fh.read().split("VmRSS:")[1].split()[0]) // 1024
            if rss > RECYCLE_MB:
                rep["recycle"] = rss
        except Exception:
            pass
        out.write(json.dumps(rep) + "\n")
        out.flush()


# ---------------------------------------------------------------- Ghidra backend (optional)

def _ghidra_ok_path(p):
    """Ghidra's ProjectLocator demands an absolute path with no path element starting with '.'."""
    from pathlib import PurePath
    pp = PurePath(p)
    return pp.is_absolute() and not any(part.startswith(".") for part in pp.parts[1:])


def ghidra_projects_dir():
    """Where Ghidra projects live. The default lean-re cache (~/.cache/lean-re) is rejected by Ghidra
    ("Path element starting with '.' is not permitted"), so fall back to a dot-free per-user location."""
    import sys
    import tempfile
    from .cache import cache_dir
    cands = [os.environ.get("LRE_GHIDRA_PROJECTS"), os.path.join(cache_dir(), "ghidra")]
    if sys.platform == "darwin":
        cands.append(os.path.expanduser("~/Library/Caches/lean-re/ghidra"))
    elif os.name == "nt":
        cands.append(os.path.join(os.environ.get("LOCALAPPDATA", ""), "lean-re", "ghidra"))
    uid = os.getuid() if hasattr(os, "getuid") else os.environ.get("USERNAME", "u")
    cands += [f"/var/tmp/lean-re-{uid}/ghidra", os.path.join(tempfile.gettempdir(), f"lean-re-{uid}", "ghidra")]
    for c in cands:
        if c and _ghidra_ok_path(os.path.abspath(c)):
            try:
                os.makedirs(c, exist_ok=True)
                return os.path.abspath(c)
            except OSError:
                continue
    raise RuntimeError("no Ghidra-compatible project directory (set LRE_GHIDRA_PROJECTS to an absolute "
                       "path without dot-prefixed elements)")


def ghidra_dir():
    d = os.environ.get("GHIDRA_INSTALL_DIR") or os.environ.get("LRE_GHIDRA_DIR")
    return d if d and os.path.isfile(os.path.join(d, "support", "launch.sh")) else None


def _java_major(java_home):
    import subprocess
    exe = os.path.join(java_home, "bin", "java") if java_home else "java"
    try:
        out = subprocess.run([exe, "-version"], capture_output=True, text=True, timeout=20).stderr
    except Exception:
        return 0
    m = re.search(r'version "(\d+)', out)
    return int(m.group(1)) if m else 0


_GHIDRA_OK = {}


def ghidra_available():
    """Ghidra needs GHIDRA_INSTALL_DIR, the pyghidra package and a JDK >= 21 (JAVA_HOME or PATH).
    Memoized per configuration: probing `java -version` under load is slow and must not flip the answer."""
    import importlib.util
    conf = (ghidra_dir(), os.environ.get("JAVA_HOME"))
    if conf not in _GHIDRA_OK:
        _GHIDRA_OK[conf] = bool(conf[0]) and importlib.util.find_spec("pyghidra") is not None and \
            _java_major(conf[1]) >= 21
    return _GHIDRA_OK[conf]


def _new_di(program):
    from ghidra.app.decompiler import DecompInterface
    di = DecompInterface()
    try:   # default 50 MB response cap fails on 50k-instruction hand-written asm (AVX-512 GCM)
        from ghidra.app.decompiler import DecompileOptions
        opts = DecompileOptions()
        opts.grabFromProgram(program)
        opts.setMaxPayloadMBytes(int(os.environ.get("LRE_GHIDRA_MAX_PAYLOAD_MB", "512")))
        di.setOptions(opts)
    except Exception:
        pass
    di.openProgram(program)
    return di


def _serve_ghidra():
    import json
    import sys
    import warnings
    warnings.simplefilter("ignore")
    out = sys.stdout
    sys.stdout = sys.stderr
    from pyghidra.launcher import HeadlessPyGhidraLauncher
    launcher = HeadlessPyGhidraLauncher(install_dir=ghidra_dir())
    launcher.add_vmargs(f"-Xmx{os.environ.get('LRE_GHIDRA_MAXMEM', '768m')}", "-XX:+UseSerialGC")
    launcher.start()
    from pyghidra.core import _analyze_program, _setup_project
    from ghidra.program.flatapi import FlatProgramAPI
    from ghidra.util.task import ConsoleTaskMonitor
    progs = {}
    for line in sys.stdin:
        req = json.loads(line)
        path, addr = req["path"], req["addr"]
        try:
            st = progs.pop(path, None)
            if st is None:      # import + auto-analysis once; saved, so later sessions reuse it
                name = re.sub(r"[^\w.-]", "_", req.get("key") or os.path.basename(path))[:80]
                project, program = _setup_project(path, ghidra_projects_dir(), name)
                flat = FlatProgramAPI(program)
                _analyze_program(flat, program)
                project.save(program)
                di = _new_di(program)
                st = (project, program, flat, di)
            progs[path] = st
            while len(progs) > MAX_PROJECTS:
                old_project, old_program, _f, old_di = progs.pop(next(iter(progs)))
                old_di.dispose()
                old_project.close()
            project, program, flat, di = st
            fm, base = program.getFunctionManager(), program.getImageBase().getOffset()
            space = program.getAddressFactory().getDefaultAddressSpace()
            A = space.getAddress          # takes a Java long; flat.toAddr picks the int overload for big VAs
            # deterministic rebase: Ghidra loads PIE ELF at 0x100000, PE/Mach-O/non-PIE at their link base
            delta = base - req.get("base", 0)
            target = A(addr + delta)
            func = fm.getFunctionAt(target)
            if func is None and program.getMemory().contains(target):
                func = flat.createFunction(target, None) or fm.getFunctionContaining(target)
            if func is None:
                rep = {"st": "err", "text": "Ghidra found no function at this address"}
            else:
                tmo = int(max(TIMEOUT, req.get("size", 0) / 1000))
                r = di.decompileFunction(func, tmo, ConsoleTaskMonitor())
                err = str(r.getErrorMessage()) if r is not None and not r.decompileCompleted() else ""
                if r is None or any(x in err for x in ("Stream closed", "process died", "Decompiler process")):
                    # the native decompiler child died (typically after a huge function): restart it once
                    try:
                        di.dispose()
                    except Exception:
                        pass
                    di = _new_di(program)
                    progs[path] = (project, program, flat, di)
                    r = di.decompileFunction(func, tmo, ConsoleTaskMonitor())
                if r is None or not r.decompileCompleted():
                    rep = {"st": "err", "text": "Ghidra: " + (str(r.getErrorMessage()) if r else "no result")[:300]}
                else:
                    rep = {"st": "ok", "text": str(r.getDecompiledFunction().getC()), "delta": delta}
        except Exception as e:
            rep = {"st": "err", "text": f"{type(e).__name__}: {e}"[:300]}
        out.write(json.dumps(rep) + "\n")
        out.flush()


# ---------------------------------------------------------------- worker processes

def _sweep_stale_tmp():
    """Remove private angr temp dirs left behind by lean-re processes that no longer exist."""
    import glob
    import shutil
    import tempfile
    for d in glob.glob(os.path.join(tempfile.gettempdir(), "lre-angr-*-*")):
        try:
            pid = int(os.path.basename(d).split("-")[2])
            os.kill(pid, 0)
        except (ValueError, IndexError):
            continue
        except ProcessLookupError:
            shutil.rmtree(d, ignore_errors=True)
        except PermissionError:
            continue


class _Worker:
    """One persistent child per backend, speaking JSON lines. angr is killed on timeout; Ghidra is left
    running when its first (import + analysis) request is slow and reports 'busy' until that finishes."""

    def __init__(self, backend):
        self.backend, self.proc, self.busy = backend, None, False
        self.pending, self.deaths = None, {}      # path of the in-flight request; worker deaths per path

    def _ensure(self):
        import subprocess
        import sys
        if self.proc is None or self.proc.poll() is not None:
            self._cleanup_tmp()
            env = dict(os.environ)
            if self.backend == "ghidra":
                env.setdefault("GHIDRA_INSTALL_DIR", ghidra_dir() or "")
            else:   # angr spills its runtime DB (LMDB) into TMPDIR and only removes it atexit, which a killed
                    # or recycled worker never reaches: give each worker a private dir we can delete.
                import tempfile
                _sweep_stale_tmp()
                self.tmp = tempfile.mkdtemp(prefix=f"lre-angr-{os.getpid()}-")
                env["TMPDIR"] = self.tmp
            self.proc = subprocess.Popen([sys.executable, "-m", "lean_re.decomp", self.backend], env=env,
                                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                         text=True, bufsize=1)
            self.busy = False

    def kill(self):
        if self.proc is not None:
            self.proc.kill()
            self.proc.wait(5)
        self.proc, self.busy = None, False
        self._cleanup_tmp()

    def _cleanup_tmp(self):
        if getattr(self, "tmp", None):
            import shutil
            shutil.rmtree(self.tmp, ignore_errors=True)
            self.tmp = None

    def _read(self, timeout):
        import json
        import select
        r, _, _ = select.select([self.proc.stdout], [], [], timeout)
        if not r:
            return None
        line = self.proc.stdout.readline()
        if not line:
            self.kill()
            if self.pending:
                self.deaths[self.pending] = self.deaths.get(self.pending, 0) + 1
            return {"st": "err", "text": f"{self.backend} worker exited (out of memory?)"}
        return json.loads(line)

    def request(self, req, timeout):
        import json
        dkey = req["path"] if self.backend == "ghidra" else (req["path"], req.get("addr"))
        if self.deaths.get(dkey, 0) >= 2:
            if self.backend == "ghidra":
                return "err", ("ghidra worker died twice on this binary (likely out of memory; raise "
                               f"LRE_GHIDRA_MAXMEM, currently {os.environ.get('LRE_GHIDRA_MAXMEM', '768m')})"), 0
            return "err", ("angr worker died twice on this function (out of memory; raise LRE_DECOMP_MEM_MB "
                           "or try view=decomp:ghidra)"), 0
        self._ensure()
        if self.busy:                       # finish draining the slow request first
            if self._read(0) is None:
                return "busy", f"{self.backend} is still analyzing a binary in the background", 0
            self.busy = False
            self._ensure()                  # the drained "reply" may have been the worker dying
        self.pending = dkey
        try:
            self.proc.stdin.write(json.dumps(req) + "\n")
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError):  # worker died between requests: restart once
            self.kill()
            self._ensure()
            self.proc.stdin.write(json.dumps(req) + "\n")
            self.proc.stdin.flush()
        rep = self._read(timeout)
        if rep is None:
            if self.backend == "ghidra":
                self.busy = True
                return "busy", ("Ghidra is still working (first-open import/analysis, or a very large function); "
                                "retry later"), 0
            self.kill()
            return "err", f"decompile timed out after {timeout:.0f}s (set LRE_DECOMP_TIMEOUT)", 0
        self.pending = None
        if rep.get("recycle"):
            self.kill()                     # fresh worker on the next request; this reply is still valid
            self.recycles = getattr(self, "recycles", 0) + 1
        elif rep.get("st") == "err" and "exceeded LRE_DECOMP_MEM_MB" in rep.get("text", ""):
            self.kill()                     # watchdog already exiting; reap it and remember the culprit
            self.deaths[dkey] = self.deaths.get(dkey, 0) + 1
        return rep["st"], rep["text"], rep.get("delta", 0)


_WORKERS = {}


def backends(prefer=None):
    """Backends to try, in order. prefer/LRE_DECOMP_BACKEND: auto (Ghidra if installed, angr fallback),
    angr, or ghidra."""
    want = (prefer or os.environ.get("LRE_DECOMP_BACKEND") or "auto").lower()
    have = [b for b, ok in (("ghidra", ghidra_available()), ("angr", available())) if ok]
    if want == "auto":
        return have
    return [want] if want in have else []


def run(backend, path, addr, size, extra=(), arity=None, key=None, timeout=None, base=0):
    w = _WORKERS.setdefault(backend, _Worker(backend))
    req = {"path": os.path.abspath(path), "addr": addr, "size": size, "extra": list(extra),
           "arity": arity or {}, "key": key, "base": base}
    if timeout is None:
        timeout = TIMEOUT if backend == "angr" else float(os.environ.get("LRE_GHIDRA_WAIT", "300"))
    return w.request(req, timeout)


def shutdown(backend=None):
    """Stop worker processes (all, or one backend) to free memory."""
    for b in [backend] if backend else list(_WORKERS):
        w = _WORKERS.pop(b, None)
        if w is not None:
            w.kill()


import atexit  # noqa: E402

atexit.register(shutdown)                 # kill workers + remove their temp dirs when lean-re exits


class Decompiler:                         # backwards-compatible angr entry point
    @staticmethod
    def raw(path, addr, size, extra=(), arity=None, timeout=TIMEOUT):
        return run("angr", path, addr, size, extra, arity, timeout=timeout)


def _rss_watchdog(limit_mb, out):
    """angr can balloon to many GB on one hostile/huge function. RLIMIT_AS is useless here (angr reserves far
    more address space than it touches), so watch real RSS and bail out with a clear protocol reply."""
    import json
    import threading
    import time

    def loop():
        while True:
            try:
                with open("/proc/self/status") as f:
                    rss = int(f.read().split("VmRSS:")[1].split()[0]) // 1024
            except Exception:
                return
            if rss > limit_mb:
                try:
                    out.write(json.dumps({"st": "err", "text": f"angr exceeded LRE_DECOMP_MEM_MB={limit_mb} "
                                          f"(rss {rss} MB) on this function; try view=decomp:ghidra"}) + "\n")
                    out.flush()
                finally:
                    os._exit(3)
            time.sleep(0.2)

    threading.Thread(target=loop, daemon=True).start()


if __name__ == "__main__":
    import sys
    if sys.argv[1:] == ["ghidra"]:
        _serve_ghidra()
    else:
        _rss_watchdog(MEM_MB, sys.stdout)
        _serve()
