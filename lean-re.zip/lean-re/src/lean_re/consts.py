"""Known magic constants and data tables. Tagging these turns raw hex into meaning."""
import re

CONSTS = {
    0x9E3779B9: "golden ratio (TEA/hash combine)", 0x9E3779B1: "xxHash32 PRIME1 / golden ratio",
    0x61C88647: "-golden ratio (TEA delta)", 0x85EBCA77: "xxHash32 PRIME2", 0xC2B2AE3D: "xxHash32 PRIME3",
    0x27D4EB2F: "xxHash32 PRIME4", 0x165667B1: "xxHash32 PRIME5",
    0x9E3779B185EBCA87: "xxHash64 PRIME1", 0xC2B2AE3D27D4EB4F: "xxHash64 PRIME2",
    0xCC9E2D51: "MurmurHash3 c1", 0x1B873593: "MurmurHash3 c2", 0xE6546B64: "MurmurHash3 n",
    0x85EBCA6B: "MurmurHash3 fmix1", 0xC2B2AE35: "MurmurHash3 fmix2",
    0x811C9DC5: "FNV-1 32 offset basis", 0x01000193: "FNV-1 32 prime",
    0xCBF29CE484222325: "FNV-1 64 offset basis", 0x100000001B3: "FNV-1 64 prime",
    0xEDB88320: "CRC-32 poly (reflected)", 0x04C11DB7: "CRC-32 poly", 0x82F63B78: "CRC-32C poly (reflected)",
    0x67452301: "MD5/SHA-1 init A", 0xEFCDAB89: "MD5/SHA-1 init B", 0x98BADCFE: "MD5/SHA-1 init C",
    0x10325476: "MD5/SHA-1 init D", 0xC3D2E1F0: "SHA-1 init E", 0xD76AA478: "MD5 T[1]",
    0x5A827999: "SHA-1 K0", 0x6ED9EBA1: "SHA-1 K1", 0x8F1BBCDC: "SHA-1 K2", 0xCA62C1D6: "SHA-1 K3",
    0x6A09E667: "SHA-256 H0", 0xBB67AE85: "SHA-256 H1", 0x428A2F98: "SHA-256 K0",
    0x6A09E667F3BCC908: "SHA-512 H0", 0x61707865: "ChaCha/Salsa 'expa'", 0x3320646E: "ChaCha/Salsa 'nd 3'",
    0x79622D32: "ChaCha/Salsa '2-by'", 0x6B206574: "ChaCha/Salsa 'te k'", 0xFFF1: "Adler-32 modulus 65521",
    0x5BD1E995: "MurmurHash2 m", 0xC6A4A7935BD1E995: "MurmurHash64A m", 0x7FFFFFFF: "INT32_MAX",
    0x41C64E6D: "LCG multiplier (glibc rand)", 0x343FD: "LCG multiplier (MSVC rand)", 0x6C078965: "MT19937 init mult",
    0x9908B0DF: "MT19937 matrix", 0x2545F4914F6CDD1D: "xorshift64* mult", 0x5851F42D4C957F2D: "PCG multiplier",
    0xDEADBEEF: "debug marker 0xDEADBEEF", 0xCAFEBABE: "Java class / Mach-O fat magic", 0xFEEDFACF: "Mach-O 64 magic",
    0x464C457F: "ELF magic", 0x04034B50: "ZIP local header 'PK\\3\\4'", 0x474E5089: "PNG magic", 0x38464947: "GIF magic",
}

TABLES = [
    (bytes.fromhex("637c777bf26b6fc53001672bfed7ab76"), "AES S-box"),
    (bytes.fromhex("52096ad53036a538bf40a39e81f3d7fb"), "AES inverse S-box"),
    (bytes.fromhex("0000000096300777"), "CRC-32 table (LE)"),
    (bytes.fromhex("982f8a4291443771cffbc0b5a5dbb5e9"), "SHA-256 K table (LE)"),
    (b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", "Base64 alphabet"),
    (b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", "Base64url alphabet"),
    (b"expand 32-byte k", "ChaCha/Salsa sigma"),
]


def tag_const(v: int):
    if v < 0:
        v &= 0xFFFFFFFFFFFFFFFF
    t = CONSTS.get(v)
    if t is None and v > 0xFFFFFFFF:
        t = CONSTS.get(v & 0xFFFFFFFF) if (v >> 32) == 0xFFFFFFFF else None
    return t


def scan_tables(blob: bytes, base: int):
    hits = []
    for pat, name in TABLES:            # re works on bytes and zero-copy memoryviews alike
        m = re.search(re.escape(pat), blob)
        if m:
            hits.append((base + m.start(), name))
    return hits
