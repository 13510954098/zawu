"""JavaScript / Electron application analysis.

Fixes the "692 MB document" failure mode: nothing is materialised as one big
report. Files are indexed lazily (imports, IPC, bridges, risky APIs) and every
match is returned as a short window around the hit, never as a whole
minified line.
"""
import json
import os
import re
import struct

from .budget import clip

JS_EXT = (".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx", ".html", ".htm")


class AsarError(ValueError):
    pass


class Asar:
    MAX_HEADER = 256 << 20

    def __init__(self, path):
        self.path = path
        self.fsize = os.path.getsize(path)
        with open(path, "rb") as f:
            head = f.read(16)
            if len(head) < 16:
                raise AsarError("not an asar archive (file shorter than the 16-byte header)")
            _, hsize, _, jlen = struct.unpack("<IIII", head)
            if jlen > min(self.MAX_HEADER, self.fsize - 16) or hsize > self.fsize:
                raise AsarError(f"corrupt asar: header claims {jlen} bytes of JSON but file is {self.fsize} bytes")
            try:
                self.header = json.loads(f.read(jlen).decode("utf-8"))
            except RecursionError:
                raise AsarError("corrupt asar: header JSON nested too deeply") from None
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                raise AsarError(f"corrupt asar: header is not valid JSON ({str(e)[:60]})") from None
        if not isinstance(self.header, dict):
            raise AsarError("corrupt asar: header JSON is not an object")
        self.base = 8 + hsize
        self.unpacked = os.path.realpath(path + ".unpacked")
        self.files = {}
        self.skipped = 0
        self._walk(self.header)

    def _walk(self, root):
        stack = [(root, "", 0)]                # iterative: hostile headers can nest thousands deep
        while stack:
            node, prefix, depth = stack.pop()
            files = node.get("files")
            if not isinstance(files, dict):
                continue
            for name, ent in files.items():
                if (not isinstance(ent, dict) or not name or name in (".", "..") or "/" in name or "\\" in name
                        or "\0" in name or depth > 256):
                    self.skipped += 1          # path-traversal / garbage entry names never become paths
                    continue
                p = f"{prefix}/{name}" if prefix else name
                if "files" in ent:
                    stack.append((ent, p, depth + 1))
                elif "link" not in ent:
                    self.files[p] = ent

    def size(self, p):
        try:
            return max(0, int(self.files[p].get("size", 0)))
        except (TypeError, ValueError):
            return 0

    def read(self, p):
        ent = self.files[p]
        if ent.get("unpacked"):
            full = os.path.realpath(os.path.join(self.unpacked, p))
            if not full.startswith(self.unpacked + os.sep):   # symlinks inside .unpacked can't escape either
                raise AsarError(f"refusing to read {p!r}: resolves outside {self.unpacked}")
            with open(full, "rb") as f:
                return f.read(64 << 20)
        try:
            off, size = int(ent["offset"]), int(ent["size"])
        except (KeyError, TypeError, ValueError):
            raise AsarError(f"corrupt asar entry {p!r}: bad offset/size") from None
        if off < 0 or size < 0 or self.base + off > self.fsize:
            raise AsarError(f"corrupt asar entry {p!r}: offset {off}/size {size} outside the archive")
        with open(self.path, "rb") as f:
            f.seek(self.base + off)
            return f.read(min(size, self.fsize))


class DirFS:
    def __init__(self, root):
        self.root = root
        self.files = {}
        for d, dirs, fs in os.walk(root):
            dirs[:] = [x for x in dirs if x not in (".git",)]
            for n in fs:
                full = os.path.join(d, n)
                self.files[os.path.relpath(full, root).replace(os.sep, "/")] = full

    def size(self, p):
        return os.path.getsize(self.files[p])

    def read(self, p):
        with open(self.files[p], "rb") as f:
            return f.read()



Q = r"""(['"`])"""
R_IMPORT = re.compile(r"""\brequire\(\s*(['"])([^'"\n]{1,200})\1\s*\)"""
                      r"""|\bfrom\s*(['"])([^'"\n]{1,200})\3"""
                      r"""|\bimport\s*\(?\s*(['"])([^'"\n]{1,200})\5""")
R_ALIAS1 = re.compile(r"\b(ipcRenderer|ipcMain|contextBridge)\s*:\s*([\w$]+)")
R_ALIAS2 = re.compile(r"\b([\w$]+)\s*=\s*[\w$]+\.(ipcRenderer|ipcMain|contextBridge)\b")
IPC_M = ("handle", "handleOnce", "on", "once", "addListener", "invoke", "send", "sendSync",
         "sendTo", "sendToHost", "postMessage", "removeHandler")
ROLE = {"handle": "main-handler", "handleOnce": "main-handler", "invoke": "renderer-invoke",
        "send": "send", "sendSync": "renderer-send", "sendTo": "send", "sendToHost": "send",
        "postMessage": "send", "on": "listener", "once": "listener", "addListener": "listener",
        "removeHandler": "main-handler"}
RISKY = {
    "nodeIntegration:true": re.compile(r"nodeIntegration\s*:\s*(?:true|!0)"),
    "contextIsolation:false": re.compile(r"contextIsolation\s*:\s*(?:false|!1)"),
    "sandbox:false": re.compile(r"\bsandbox\s*:\s*(?:false|!1)"),
    "webSecurity:false": re.compile(r"webSecurity\s*:\s*(?:false|!1)"),
    "shell.openExternal": re.compile(r"\bopenExternal\s*\("),
    "child_process": re.compile(r"""\b(?:execSync|execFile|spawnSync|spawn|exec)\s*\(|child_process"""),
    "eval/Function": re.compile(r"\beval\s*\(|\bnew\s+Function\s*\("),
    "protocol handler": re.compile(r"\bprotocol\.(?:handle|register\w*Protocol|registerSchemesAsPrivileged)\s*\("),
    "remote module": re.compile(r"@electron/remote|enableRemoteModule"),
}
R_URL = re.compile(r"""https?://[^\s'"`<>\\)]{4,200}""")


def ipc_regex(recv):
    names = "|".join(sorted({re.escape(r) for r in recv}, key=len, reverse=True))
    meth = "|".join(IPC_M)
    lit = re.compile(r"(?<![\w$])(" + names + r")\.(" + meth + r")\(\s*(['\"`])([^'\"`\n]{1,160})\3(?=\s*[,)])")
    dyn = re.compile(r"(?<![\w$])(" + names + r")\.(" + meth + r")\(\s*(?!['\"`])([\w$.\[\]]{1,60})")
    return lit, dyn


def resolve_source(path):
    """Directory, .asar, Electron install dir or .app bundle -> (fs, label)."""
    cands = [path, os.path.join(path, "resources", "app.asar"),
             os.path.join(path, "Contents", "Resources", "app.asar"),
             os.path.join(path, "resources", "app")]
    for c in cands:
        if os.path.isfile(c) and c.endswith(".asar"):
            return Asar(c), c
    for c in cands[3:] + [path]:
        if os.path.isdir(c):
            return DirFS(c), c
    raise ValueError("not a JS app directory or .asar")


def line_col(text, off):
    line = text.count("\n", 0, off) + 1
    col = off - (text.rfind("\n", 0, off) + 1)
    return line, col


def window(text, off, width=150):
    a = max(0, off - width // 3)
    b = min(len(text), a + width)
    s = text[a:b].replace("\n", "⏎")
    return ("…" if a else "") + s + ("…" if b < len(text) else "")


class JsApp:
    kind = "jsapp"

    def __init__(self, path, data=None):
        self.fs, self.src = resolve_source(path)
        self.pkg = {}
        if "package.json" in self.fs.files:
            try:
                self.pkg = json.loads(self.fs.read("package.json"))
            except Exception:
                pass
        allf = sorted(self.fs.files)
        self.deps = sorted({p.split("/")[1] if not p.split("/")[1].startswith("@") else "/".join(p.split("/")[1:3])
                            for p in allf if p.startswith("node_modules/") and p.count("/") >= 2})
        code = [p for p in allf if p.lower().endswith(JS_EXT) and not p.startswith("node_modules/")]
        self.code = code or [p for p in allf if p.lower().endswith(JS_EXT)]
        self._text = {}
        self.idx, self.bad = {}, {}
        for p in self.code:
            try:
                self.idx[p] = self._index_file(p)
            except (OSError, ValueError) as e:     # hostile/corrupt entry: skip it, keep the rest of the app
                self.bad[p] = f"{type(e).__name__}: {str(e)[:80]}"
        self.code = [p for p in self.code if p in self.idx]
        self._resolve_dynamic()

    def _resolve_dynamic(self):
        """Resolve channel identifiers (CH, C.SAVE, x.CHANNELS.save) to string constants defined anywhere in the app."""
        if not any(v["dynsites"] for v in self.idx.values()):
            return
        consts = {}
        rx = re.compile(r"(?<![\w$.])([\w$]+)\s*[:=]\s*(['\"`])([^'\"`\n$]{1,120})\2")
        for p in self.idx:
            for m in rx.finditer(self.text(p)):
                consts.setdefault(m.group(1), set()).add(m.group(3))
        for p, ix in self.idx.items():
            left = []
            for expr, meth, off in ix["dynsites"]:
                name = re.split(r"[.\[\]]", expr.strip("[]"))
                name = [x for x in name if x][-1] if any(name) else expr
                vals = consts.get(name.strip("'\""), set())
                if len(vals) == 1:
                    side = "main" if meth in ("handle", "handleOnce") else ("renderer" if meth in ("invoke", "sendSync") else "?")
                    ix["ipc"].append((next(iter(vals)), meth, side, off))
                    ix.setdefault("resolved", []).append((expr, next(iter(vals)), off))
                else:
                    left.append((expr, meth, off))
            ix["dynsites"] = left
            ix["dyn"] = len(left)

    def text(self, p):
        t = self._text.get(p)
        if t is None:
            t = self.fs.read(p).decode("utf-8", "replace")
            if len(self._text) > 64:
                self._text.clear()
            self._text[p] = t
        return t

    def _index_file(self, p):
        t = self.text(p)
        nl = t.count("\n") + 1
        ix = {"size": len(t), "lines": nl, "minified": len(t) / nl > 400, "imports": [],
              "ipc": [], "dyn": 0, "dynsites": [], "bridge": [], "risky": {}, "urls": set()}
        for m in R_IMPORT.finditer(t):
            ix["imports"].append(m.group(2) or m.group(4) or m.group(6))
        recv = {"ipcMain", "ipcRenderer", "webContents"}
        if "ipc" in t or "contextBridge" in t:
            for m in R_ALIAS1.finditer(t):
                recv.add(m.group(2))
            for m in R_ALIAS2.finditer(t):
                recv.add(m.group(1))
            lit, dyn = ipc_regex(recv)
            for m in lit.finditer(t):
                who = m.group(1)
                meth = m.group(2)
                if who == "webContents" or meth in ("handle", "handleOnce", "removeHandler"):
                    side = "main"
                elif meth in ("invoke", "sendSync", "sendToHost"):
                    side = "renderer"
                else:
                    side = "?"
                ix["ipc"].append((m.group(4), meth, side, m.start()))
            ix["dynsites"] = [(m.group(3), m.group(2), m.start()) for m in dyn.finditer(t)
                              if m.group(2) in ("handle", "handleOnce", "invoke", "send", "on", "once", "sendSync")]
            for m in re.finditer(r"(?<![\w$])(" + "|".join(sorted({re.escape(r) for r in recv})) + r")\.(" + "|".join(IPC_M)
                                 + r")\(\s*(['\"`])([^'\"`\n]{1,80})\3\s*\+", t):
                ix["ipc"].append((m.group(4) + "*", m.group(2), "?", m.start()))
            ix["dyn"] = len(ix["dynsites"])
            for m in re.finditer(r"exposeInMainWorld\(\s*(['\"`])([^'\"`]{1,80})\1\s*,", t):
                ix["bridge"].append((m.group(2), self._keys(t, m.end()), m.start()))
        for name, rx in RISKY.items():
            offs = [m.start() for m in rx.finditer(t)][:50]
            if offs:
                ix["risky"][name] = offs
        ix["urls"] = sorted(set(R_URL.findall(t)))[:200]
        return ix

    @staticmethod
    def _keys(t, i):
        while i < len(t) and t[i] in " \t\r\n":
            i += 1
        if i >= len(t) or t[i] != "{":
            m = re.match(r"[\w$.]+", t[i:i + 80])
            return [f"<{m.group()}>"] if m else []
        depth, keys, j, n = 0, [], i, min(len(t), i + 20000)
        tok = re.compile(r"""(['"`])(?:\\.|(?!\1).)*\1|[{}()\[\]]|([\w$]+)\s*(?=[:(,}])""")
        while j < n:
            m = tok.search(t, j, n)
            if not m:
                break
            g = m.group()
            if g in "{([":
                depth += 1
            elif g in "})]":
                depth -= 1
                if depth == 0:
                    break
            elif depth == 1 and m.group(2):
                before = t[max(0, m.start() - 40):m.start()].rstrip()
                if before[-1:] in ("{", ",") or before.endswith("async"):
                    keys.append(m.group(2))
            j = m.end()
        out = []
        for k in keys:
            if k not in out and k not in ("async", "function", "return", "const", "let", "var"):
                out.append(k)
        return out[:40]

    def loc(self, p, off):
        line, col = line_col(self.text(p), off)
        return f"{p}:{line}:{col}"

    # ----------------------------------------------------------------- views
    def channels(self):
        ch = {}
        for p, ix in self.idx.items():
            for name, meth, side, off in ix["ipc"]:
                ch.setdefault(name, []).append((p, meth, side, off))
        return ch

    def overview(self):
        ix = self.idx
        tot = sum(v["size"] for v in ix.values())
        ver = (self.pkg.get("devDependencies", {}) or {}).get("electron") or (self.pkg.get("dependencies", {}) or {}).get("electron")
        L = [f"jsapp {self.pkg.get('name', '?')} {self.pkg.get('version', '')} · source {os.path.basename(self.src)} · "
             f"{len(self.code)} code files ({tot/1e6:.1f} MB, {sum(v['minified'] for v in ix.values())} minified) · "
             f"{len(self.fs.files)} files total" + (f" · electron {ver}" if ver else "")]
        bad, skipped = getattr(self, "bad", {}), getattr(self.fs, "skipped", 0)
        if bad or skipped:
            L.append(f"! skipped {len(bad) + skipped} hostile/corrupt entries"
                     + (": " + clip("; ".join(f"{k} ({v})" for k, v in bad.items()), 200) if bad else
                        " (unsafe names like ../)"))
        if self.pkg.get("main"):
            L.append(f"main entry: {self.pkg['main']}")
        ch = self.channels()
        dyn = sum(v["dyn"] for v in ix.values())
        L.append(f"IPC channels {len(ch)}" + (f" (+{dyn} dynamic/non-literal call sites)" if dyn else "") + ": "
                 + clip(" ".join(sorted(ch)), 400))
        br = [(p, n, k) for p, v in ix.items() for n, k, o in v["bridge"]]
        for p, n, k in br[:6]:
            L.append(f"bridge window.{n} = {{{', '.join(k[:16])}}}  ({p})")
        risky = {}
        for p, v in ix.items():
            for name, offs in v["risky"].items():
                risky.setdefault(name, []).append(f"{p}×{len(offs)}")
        if risky:
            L.append("risk flags: " + " · ".join(f"{k} [{', '.join(v[:3])}]" for k, v in risky.items()))
        big = sorted(ix, key=lambda p: -ix[p]["size"])[:5]
        L.append("largest: " + ", ".join(f"{p}({ix[p]['size']//1024}KB)" for p in big))
        if self.deps:
            L.append(f"node_modules {len(self.deps)}: " + clip(" ".join(self.deps), 300))
        return L

    def list(self, what="files", filt=""):
        rx = re.compile(filt, re.I) if filt else None
        what = (what or "files").lower()
        if what.startswith("file") or what.startswith("mod"):
            return [f"file:{p} {v['size']//1024}KB{' min' if v['minified'] else ''} imports={len(v['imports'])} ipc={len(v['ipc'])}"
                    for p, v in self.idx.items() if not rx or rx.search(p)]
        if what.startswith("ipc") or what.startswith("chan"):
            out = []
            for name, uses in sorted(self.channels().items()):
                if rx and not rx.search(name):
                    continue
                roles = sorted({f"{m}" for p, m, s, o in uses})
                out.append(f"ipc:{name}  uses={len(uses)} [{' '.join(roles)}] files={len({u[0] for u in uses})}")
            return out
        if what.startswith("url"):
            return sorted({u for v in self.idx.values() for u in v["urls"] if not rx or rx.search(u)})
        if what.startswith("dep"):
            return [d for d in self.deps if not rx or rx.search(d)]
        if what.startswith("risk"):
            return [f"{name}: {self.loc(p, o)}" for p, v in self.idx.items() for name, offs in v["risky"].items()
                    for o in offs if not rx or rx.search(name)]
        raise KeyError("list what: files|ipc|urls|deps|risks")

    def find(self, query, kind="any", regex=False):
        rx = re.compile(query if regex else re.escape(query), 0 if regex else re.I)
        out = []
        if kind in ("any", "ipc"):
            for name, uses in sorted(self.channels().items()):
                if rx.search(name):
                    out.append(f"ipc:{name} ({len(uses)} uses: " + ", ".join(sorted({m for _, m, _, _ in uses})) + ")")
        if kind in ("any", "file"):
            out += [f"file:{p}" for p in self.fs.files if rx.search(p)][:200]
        if kind in ("any", "code", "string"):
            for p in self.code:
                t = self.text(p)
                n = 0
                for m in rx.finditer(t):
                    out.append(f"{self.loc(p, m.start())}  {window(t, m.start())}")
                    n += 1
                    if n >= 25:
                        out.append(f"  … more hits in {p} (narrow the query)")
                        break
        return out

    def _parse(self, ident):
        s = ident.strip()
        if s.startswith("ipc:"):
            return "ipc", s[4:], None
        if s.startswith("file:"):
            s = s[5:]
        m = re.fullmatch(r"(.+?):(\d+)(?::(\d+))?", s)
        if m and m.group(1) in self.fs.files:
            return "loc", m.group(1), (int(m.group(2)), int(m.group(3) or 0))
        if s in self.fs.files:
            return "file", s, None
        raise KeyError(f"unknown id {ident!r}; use file:<path>[:line[:col]] or ipc:<channel>")

    def show(self, ident, view="auto"):
        kind, p, pos = self._parse(ident)
        if kind == "ipc":
            return self.xrefs(ident)
        t = self.text(p) if p in self.idx or p.lower().endswith(JS_EXT) else self.fs.read(p).decode("utf-8", "replace")
        if kind == "file":
            if p not in self.idx:
                return t.splitlines()[:400]
            ix = self.idx[p]
            L = [f"file:{p} {ix['size']//1024}KB lines={ix['lines']}{' minified' if ix['minified'] else ''}"]
            if ix["imports"]:
                L.append("imports: " + clip(" ".join(dict.fromkeys(ix["imports"])), 400))
            for name, meth, side, off in ix["ipc"][:60]:
                L.append(f"  ipc {meth}('{name}') at {self.loc(p, off)}")
            for n, k, off in ix["bridge"]:
                L.append(f"  bridge window.{n} = {{{', '.join(k)}}} at {self.loc(p, off)}")
            for name, offs in ix["risky"].items():
                L.append(f"  risk {name}: " + ", ".join(self.loc(p, o).split(':', 1)[1] for o in offs[:6]))
            fns = re.findall(r"(?:^|[\s;])(?:async\s+)?function\s*\*?\s*([\w$]{3,})\s*\(", t[:2_000_000])
            if fns:
                L.append("named functions: " + clip(" ".join(dict.fromkeys(fns)), 500))
            L.append(f"(show file:{p}:<line>[:<col>] for source around a location)")
            return L
        line, col = pos
        lines = t.split("\n")
        if not (1 <= line <= len(lines)):
            raise KeyError("line out of range")
        if len(lines[line - 1]) > 400:   # minified: beautify a local window
            off = sum(len(x) + 1 for x in lines[:line - 1]) + col
            a, b = max(0, off - 500), min(len(t), off + 1500)
            chunk = t[a:off] + "/*@@HIT@@*/" + t[off:b]
            try:
                import jsbeautifier
                o = jsbeautifier.default_options()
                o.indent_size = 2
                chunk = jsbeautifier.beautify(chunk, o)
            except Exception:
                chunk = re.sub(r"([;{}])", r"\1\n", chunk)
            out = []
            for ln in chunk.split("\n"):
                out.append(("▶ " + ln.replace("/*@@HIT@@*/", "")) if "@@HIT@@" in ln else "  " + ln)
            hit = next((i for i, x in enumerate(out) if x.startswith("▶")), 0)
            out = out[max(0, hit - 12):]
            return [f"{p}:{line}:{col} (minified; beautified window, ▶ = location)"] + out
        lo, hi = max(1, line - 12), min(len(lines), line + 30)
        return [f"{p}:{line}"] + [f"{i:>5}{'>' if i == line else ' '} {clip(lines[i - 1], 220)}" for i in range(lo, hi + 1)]

    def xrefs(self, ident, direction="to"):
        kind, p, pos = self._parse(ident)
        if kind == "ipc":
            allch = self.channels()
            uses = list(allch.get(p, []))
            for pat, us in allch.items():
                if pat.endswith("*") and pat != p and p.startswith(pat[:-1]):
                    uses += [(f, m, sd, o) for f, m, sd, o in us]
            res = {(f, o): e for f, v in self.idx.items() for e, val, o in v.get("resolved", [])}
            if not uses:
                return [f"no literal uses of channel '{p}' (dynamic channel names are not resolved)"]
            order = {"handle": 0, "handleOnce": 0, "on": 1, "once": 1, "invoke": 2, "send": 3, "sendSync": 3}
            L = [f"ipc:{p} — {len(uses)} uses (handlers first)"]
            for f, meth, side, off in sorted(uses, key=lambda u: (order.get(u[1], 5), u[0])):
                via = f" [via {res[(f, off)]}]" if (f, off) in res else ""
                L.append(f"  {meth:<8} {self.loc(f, off)}{via}  {window(self.text(f), off, 130)}")
            for f, n, key, at in self._renderer_calls(p):
                L.append(f"  renderer window.{n}.{key}() {self.loc(f, at)}  {window(self.text(f), at, 110)}")
            br = [(f, n, k) for f, v in self.idx.items() for n, k, o in v["bridge"]]
            if br:
                L.append("bridges exposing renderer APIs: " + "; ".join(f"window.{n}{{{','.join(k[:8])}}} ({f})" for f, n, k in br[:4]))
            return L
        base = os.path.splitext(os.path.basename(p))[0]
        L = [f"files importing {p}:"]
        for f, v in self.idx.items():
            hits = [i for i in v["imports"] if os.path.splitext(os.path.basename(i))[0] == base]
            if hits and f != p:
                L.append(f"  file:{f}  ({', '.join(dict.fromkeys(hits))})")
        if direction == "from" and p in self.idx:
            L = [f"{p} imports:"] + [f"  {i}" for i in dict.fromkeys(self.idx[p]["imports"])]
        return L

    def _renderer_calls(self, channel):
        """Bridge keys whose implementation uses `channel`, then renderer call sites of those keys."""
        out = []
        for f, v in self.idx.items():
            t = self.text(f)
            for n, keys, off in v["bridge"]:
                seg = t[off:off + 20000]
                for i, k in enumerate(keys):
                    m = re.search(r"(?<![\w$])" + re.escape(k) + r"\s*[:(]", seg)
                    if not m:
                        continue
                    nxt = len(seg)
                    if i + 1 < len(keys):
                        m2 = re.search(r"(?<![\w$])" + re.escape(keys[i + 1]) + r"\s*[:(]", seg[m.end():])
                        if m2:
                            nxt = m.end() + m2.start()
                    if re.search(r"['\"`]" + re.escape(channel) + r"['\"`]", seg[m.start():nxt]):
                        for g, w in self.idx.items():
                            if g == f:
                                continue
                            tt = self.text(g)
                            if n not in tt:
                                continue
                            for mm in re.finditer(r"[\w$.]*\." + re.escape(k) + r"\(", tt):
                                out.append((g, n, k, mm.start()))
                                if len(out) > 20:
                                    return out
        return out
