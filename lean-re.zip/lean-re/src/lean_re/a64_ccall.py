"""AArch64 flag-helper rewriter for angr's decompiler.

angr ships ccall rewriters for x86, AMD64 and 32-bit ARM but not AArch64, so arm64
output kept raw VEX helpers such as ``arm64g_calculate_condition(1, x & 0xffffffff, 1, 0)``.
AArch64 shares ARM's condition codes and NZCV layout; only the cc_op numbering and the
operand width differ. We map the cc_op onto ARM's and reuse ARM's (exact) rewrite rules,
working at the operation's real width (32 or 64 bits).
"""
from angr.ailment import Expr
from angr.analyses.decompiler.ccall_rewriters import CCALL_REWRITERS
from angr.analyses.decompiler.ccall_rewriters.arm_ccalls import ARMCCallRewriter
from angr.engines.vex.claripy import ccall as C

# ARM64 cc_op -> (ARM cc_op, width)
_OPS = {
    C.ARM64G_CC_OP_COPY: (C.ARMG_CC_OP_COPY, 64),
    C.ARM64G_CC_OP_ADD32: (C.ARMG_CC_OP_ADD, 32), C.ARM64G_CC_OP_ADD64: (C.ARMG_CC_OP_ADD, 64),
    C.ARM64G_CC_OP_SUB32: (C.ARMG_CC_OP_SUB, 32), C.ARM64G_CC_OP_SUB64: (C.ARMG_CC_OP_SUB, 64),
    C.ARM64G_CC_OP_ADC32: (C.ARMG_CC_OP_ADC, 32), C.ARM64G_CC_OP_ADC64: (C.ARMG_CC_OP_ADC, 64),
    C.ARM64G_CC_OP_SBC32: (C.ARMG_CC_OP_SBB, 32), C.ARM64G_CC_OP_SBC64: (C.ARMG_CC_OP_SBB, 64),
    # AArch64 logic ops clear C and V; ARM's LOGIC takes C from dep_2, which VEX sets to 0 here
    C.ARM64G_CC_OP_LOGIC32: (C.ARMG_CC_OP_LOGIC, 32), C.ARM64G_CC_OP_LOGIC64: (C.ARMG_CC_OP_LOGIC, 64),
}
_SIGNED = {C.ARMCondGE, C.ARMCondLT, C.ARMCondGT, C.ARMCondLE}
_UNSIGNED = {C.ARMCondHS, C.ARMCondLO, C.ARMCondHI, C.ARMCondLS}


class AArch64CCallRewriter(ARMCCallRewriter):
    __slots__ = ("_w",)

    def _rewrite(self, ccall):
        if self._original_callee(ccall) != "arm64g_calculate_condition" or len(ccall.operands) != 4:
            return None
        cond_n_op = ccall.operands[0]
        if not isinstance(cond_n_op, Expr.Const):
            return None
        cond, op = (cond_n_op.value_int >> 4) & 0xF, cond_n_op.value_int & 0xF
        if cond == C.ARMCondAL:
            return Expr.Const(ccall.idx, 1, ccall.bits, **ccall.tags)
        if cond == C.ARMCondNV:
            return Expr.Const(ccall.idx, 0, ccall.bits, **ccall.tags)
        if op not in _OPS:
            return None
        arm_op, w = _OPS[op]
        if arm_op == C.ARMG_CC_OP_COPY:
            return None                      # rare (msr nzcv); leave the helper visible
        self._w = w
        d1, d2, d3 = (self._narrow(o, w, ccall) for o in ccall.operands[1:])
        if arm_op == C.ARMG_CC_OP_ADD and isinstance(d2, Expr.Const):
            # cmn x, #c  ==  cmp x, #-c  (exact for EQ/NE; unsigned needs c != 0; signed needs -c representable)
            c = d2.value_int & ((1 << w) - 1)
            if cond in (C.ARMCondEQ, C.ARMCondNE) or (cond in _UNSIGNED and c) or \
                    (cond in _SIGNED and c != 1 << (w - 1)):
                arm_op, d2 = C.ARMG_CC_OP_SUB, self._const(ccall, (-c) & ((1 << w) - 1))
            else:
                return None
        r = self._condition(ccall, cond, arm_op, d1, d2, d3)
        return None if r is None else self._wrap(ccall, r)

    def _narrow(self, e, w, ccall):
        """VEX passes 32-bit operands zero-extended in 64-bit deps (often as ``x & 0xffffffff``)."""
        if e.bits == w:
            return e
        if (isinstance(e, Expr.BinaryOp) and e.op == "And" and isinstance(e.operands[1], Expr.Const)
                and e.operands[1].value_int == (1 << w) - 1):
            e = e.operands[0]
            if e.bits == w:
                return e
        if isinstance(e, Expr.Convert) and not e.is_signed and e.from_bits == w:
            return e.operand
        if isinstance(e, Expr.Const):
            return Expr.Const(self.ail_manager.next_atom(), e.value_int & ((1 << w) - 1), w, **ccall.tags)
        return Expr.Convert(self.ail_manager.next_atom(), e.bits, w, False, e, **ccall.tags)

    def _const(self, ccall, value, bits=None):
        return Expr.Const(self.ail_manager.next_atom(), value, bits or getattr(self, "_w", 32), **ccall.tags)


def install():
    CCALL_REWRITERS.setdefault("AARCH64", AArch64CCallRewriter)
