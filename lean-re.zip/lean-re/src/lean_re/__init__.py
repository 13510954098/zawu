"""lean-re: token-efficient static reverse engineering for coding agents."""
__version__ = "0.6.0"
