"""Session registry + uniform, budgeted dispatch used by both CLI and MCP."""
import os
from collections import OrderedDict

from .budget import DEFAULT_BUDGET, clip, effective_budget, fit, paginate


def detect(path):
    if os.path.isdir(path):
        return "jsapp"
    if path.endswith(".asar"):
        return "jsapp"
    with open(path, "rb") as f:
        head = f.read(4)
    if head[:2] == b"PK":
        return "apk"
    return "native"


def load(path):
    kind = detect(path)
    if kind == "jsapp":
        from .jsapp import JsApp
        return JsApp(path)
    if kind == "apk":
        from .apk import Apk
        return Apk(path)
    from .native import Native
    return Native(path)


def _rss_mb():
    try:
        with open("/proc/self/status") as f:
            return int(f.read().split("VmRSS:")[1].split()[0]) // 1024
    except Exception:
        return 0


def _trim():
    """Hand freed arenas back to the OS so evictions actually lower RSS (glibc only; no-op elsewhere)."""
    try:
        import ctypes
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


class Engine:
    """Handles are stable for the whole session; analyzers are an LRU working set.

    A long-lived MCP server can be asked to open hundreds of targets. Evicted targets keep their handle and
    are reloaded transparently on next use (native targets come back from the on-disk index cache in a
    fraction of the original time)."""

    def __init__(self, max_live=None, soft_mb=None):
        self.live = OrderedDict()   # handle -> analyzer (LRU order)
        self.hpath = {}             # handle -> abspath (never forgotten)
        self.paths = {}             # abspath -> handle
        self.max_live = int(max_live or os.environ.get("LRE_MAX_TARGETS", 8))
        self.soft_mb = int(soft_mb or os.environ.get("LRE_SOFT_MB", 1024))
        self.evictions = 0

    @property
    def targets(self):
        return self.live

    def get(self, target):
        h = target if target in self.hpath else None
        if h is None:
            p = os.path.abspath(os.path.expanduser(target))
            h = self.paths.get(p)
            if h is None:
                if not os.path.exists(p):
                    raise KeyError(f"unknown target {target!r}: pass a path or an open handle like t1")
                h = f"t{len(self.hpath) + 1}"
                self.hpath[h], self.paths[p] = p, h
        if h in self.live:
            self.live.move_to_end(h)
            return h, self.live[h]
        self._make_room()
        self.live[h] = load(self.hpath[h])
        self._shrink(keep=h)
        return h, self.live[h]

    def _make_room(self):
        while len(self.live) >= self.max_live:
            self._evict()

    def _shrink(self, keep):
        while len(self.live) > 1 and _rss_mb() > self.soft_mb:
            if next(iter(self.live)) == keep:
                self.live.move_to_end(keep)
            self._evict()

    def _evict(self):
        h, t = self.live.popitem(last=False)
        close = getattr(t, "close", None)
        if close:
            try:
                close()
            except Exception:
                pass
        del t
        self.evictions += 1
        import gc
        gc.collect()
        _trim()

    def run(self, op, target, budget=DEFAULT_BUDGET, cursor=0, **kw):
        try:
            h, t = self.get(target)
            if op == "open":
                return paginate(t.overview(), cursor, budget, header=f"[{h}] {target}")
            fn = getattr(t, op)
            kw = {k: v for k, v in kw.items() if v not in (None, "")}
            lines = fn(**kw)
            if not lines:
                return fit(clip(f"[{h}] {op}: no results", 400), effective_budget(budget))
            shown = [str(v) for k, v in kw.items() if v not in (False, True, "any", "auto", "to")]
            return paginate(lines, cursor, budget, header=f"[{h}] {op} {' '.join(shown)}".rstrip())
        except KeyError as e:
            return fit(clip(f"error: {e.args[0] if e.args else e}", 600), effective_budget(budget))
        except Exception as e:  # never crash the agent session
            return fit(clip(f"error: {type(e).__name__}: {e}", 600), effective_budget(budget))
