"""MCP server: 6 small tools instead of 139. Every result is token-budgeted."""
try:
    from mcp.server.mcpserver import MCPServer as _Server   # mcp >= 2
except ImportError:  # pragma: no cover
    from mcp.server.fastmcp import FastMCP as _Server       # mcp 1.x

from . import batch
from .budget import clip, effective_budget, fit, paginate
from .engine import Engine

INSTRUCTIONS = (
    "Static reverse engineering of native binaries (ELF/PE/Mach-O), Electron/JS apps (dir or .asar) and APKs. "
    "Start with re_open(path). Ids from any result (f:401136, s:2010, file:main.js:12, ipc:chan, c:Lpkg/Cls;, "
    "m:Lpkg/Cls;->m()V) can be passed to re_show / re_xrefs. Results are paged: pass cursor=N to continue. "
    "For tiny programs plain objdump/rg may be enough; use this when you need names, xrefs or call-site args.")

mcp = _Server("lean-re", instructions=INSTRUCTIONS)
E = Engine()


@mcp.tool()
def re_open(path: str, budget: int = 900) -> str:
    """Open a target (binary, .asar/app dir, .apk); returns handle + compact overview."""
    return E.run("open", path, budget)


@mcp.tool()
def re_find(target: str, query: str, kind: str = "any", regex: bool = False, cursor: int = 0, budget: int = 1200) -> str:
    """Search strings/symbols/code/IPC/classes. kind: any|string|function|import|const|code|ipc|file|class|method."""
    return E.run("find", target, budget, cursor, query=query, kind=kind, regex=regex)


@mcp.tool()
def re_show(target: str, id: str, view: str = "auto", cursor: int = 0, budget: int = 1500) -> str:
    """Show an id: native fn summary (view=asm, or view=decomp for pseudo-C; decomp:angr / decomp:ghidra pick a backend), APK class/method (view=smali), JS file outline or location."""
    return E.run("show", target, budget, cursor, ident=id, view=view)


@mcp.tool()
def re_xrefs(target: str, id: str, direction: str = "to", cursor: int = 0, budget: int = 1200) -> str:
    """Cross-references to (callers/users) or from (callees/strings) an id; ipc:<chan> traces all IPC ends."""
    return E.run("xrefs", target, budget, cursor, ident=id, direction=direction)


@mcp.tool()
def re_list(target: str, what: str = "", filter: str = "", cursor: int = 0, budget: int = 1200) -> str:
    """List: functions|imports|strings|sections|exports (native); files|ipc|urls|deps|risks (js); components|permissions|packages|classes|libs|urls (apk)."""
    return E.run("list", target, budget, cursor, what=what, filt=filter)


@mcp.tool()
def re_batch(paths: list[str], out: str = "", cursor: int = 0, budget: int = 1500) -> str:
    """Parallel triage of many APKs/binaries (dirs or globs). Full rows go to a JSONL file; returns a compact table."""
    try:
        return paginate(batch.run(paths, out or None), cursor, budget)
    except Exception as e:
        return fit(clip(f"error: {type(e).__name__}: {e}", 600), effective_budget(budget))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
