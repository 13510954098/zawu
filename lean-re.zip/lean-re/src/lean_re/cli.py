"""lre CLI — same engine and output as the MCP tools.

  lre open   <target>
  lre find   <target> <query> [--kind K] [--regex]
  lre show   <target> <id> [--view asm|decomp[:angr|:ghidra]|smali|summary]
  lre xrefs  <target> <id> [--from]
  lre list   <target> [what] [--filter RX]
  lre batch  <paths...> [--out file.jsonl]
  lre serve                      # MCP over stdio
Common: --budget N (tokens, default 1200)  --cursor N (continue paged output)
"""
import argparse
import sys

from . import batch
from .budget import paginate
from .engine import Engine


def main(argv=None):
    ap = argparse.ArgumentParser(prog="lre", description="token-efficient static reverse engineering")
    sp = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--budget", type=int, default=1200)
        p.add_argument("--cursor", type=int, default=0)
        return p
    common(sp.add_parser("open")).add_argument("target")
    p = common(sp.add_parser("find"))
    p.add_argument("target"); p.add_argument("query")
    p.add_argument("--kind", default="any"); p.add_argument("--regex", action="store_true")
    p = common(sp.add_parser("show"))
    p.add_argument("target"); p.add_argument("id"); p.add_argument("--view", default="auto")
    p = common(sp.add_parser("xrefs"))
    p.add_argument("target"); p.add_argument("id"); p.add_argument("--from", dest="frm", action="store_true")
    p = common(sp.add_parser("list"))
    p.add_argument("target"); p.add_argument("what", nargs="?", default=""); p.add_argument("--filter", default="")
    p = common(sp.add_parser("batch"))
    p.add_argument("paths", nargs="+"); p.add_argument("--out", default=None); p.add_argument("--workers", type=int)
    sp.add_parser("serve")
    a = ap.parse_args(argv)
    if a.cmd == "serve":
        from .server import main as serve
        return serve()
    if a.cmd == "batch":
        print(paginate(batch.run(a.paths, a.out, a.workers), a.cursor, a.budget))
        return 0
    E = Engine()
    if a.cmd == "open":
        out = E.run("open", a.target, a.budget, a.cursor)
    elif a.cmd == "find":
        out = E.run("find", a.target, a.budget, a.cursor, query=a.query, kind=a.kind, regex=a.regex)
    elif a.cmd == "show":
        out = E.run("show", a.target, a.budget, a.cursor, ident=a.id, view=a.view)
    elif a.cmd == "xrefs":
        out = E.run("xrefs", a.target, a.budget, a.cursor, ident=a.id, direction="from" if a.frm else "to")
    else:
        out = E.run("list", a.target, a.budget, a.cursor, what=a.what, filt=a.filter)
    print(out)
    return 1 if out.startswith("error:") else 0


if __name__ == "__main__":
    sys.exit(main())
