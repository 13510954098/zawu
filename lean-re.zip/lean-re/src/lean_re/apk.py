"""Android APK analysis without a whole-program decompile.

jadx-based pipelines preprocess the entire APK (often tens of minutes) before
answering anything. Here: manifest in ~0.1 s, DEX tables parsed on demand, a
compact xref index (invokes + const-strings) built once in seconds and cached,
and single methods decompiled on request (~ms each) with androguard's DAD.
"""
import re
import zipfile
from collections import Counter, defaultdict

from .budget import clip

try:
    from loguru import logger
    logger.remove()
except Exception:
    pass

NS = "{http://schemas.android.com/apk/res/android}"
INVOKE = set(range(0x6E, 0x73)) | set(range(0x74, 0x79))
DANGEROUS = ("READ_CONTACTS", "WRITE_CONTACTS", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION",
             "ACCESS_BACKGROUND_LOCATION", "CAMERA", "RECORD_AUDIO", "READ_SMS", "SEND_SMS", "RECEIVE_SMS",
             "READ_CALL_LOG", "WRITE_CALL_LOG", "READ_PHONE_STATE", "CALL_PHONE", "READ_EXTERNAL_STORAGE",
             "WRITE_EXTERNAL_STORAGE", "READ_MEDIA_IMAGES", "BODY_SENSORS", "POST_NOTIFICATIONS",
             "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES", "QUERY_ALL_PACKAGES", "BIND_ACCESSIBILITY_SERVICE",
             "MANAGE_EXTERNAL_STORAGE", "READ_PHONE_NUMBERS", "GET_ACCOUNTS", "USE_BIOMETRIC")
R_URL = re.compile(r"https?://[^\s'\"<>]{4,200}")


def _g(getter, default=None):
    """androguard getters raise (KeyError 'Name', ...) on corrupt manifests; degrade to None."""
    try:
        return getter()
    except Exception:
        return default


def manifest_facts(a):
    """Components with effective exported state; works from the manifest only."""
    try:
        x = a.get_android_manifest_xml()
    except Exception:
        x = None
    if x is None:                    # unreadable/obfuscated manifest: keep going with the DEX code
        return [], {"manifest": "unreadable(corrupt/obfuscated AXML)"}
    app = x.find("application")
    try:
        target = int(_g(a.get_target_sdk_version) or 0)
    except (TypeError, ValueError):
        target = 0
    comps = []
    if app is not None:
        for el in app:
            if el.tag not in ("activity", "activity-alias", "service", "receiver", "provider"):
                continue
            name = el.get(NS + "name") or el.get(NS + "targetActivity") or "?"
            exp = el.get(NS + "exported")
            filters = el.findall("intent-filter")
            if exp is None:
                exported = bool(filters) if el.tag != "provider" else target < 17
            else:
                exported = exp.lower() in ("true", "1")
            actions = [f.get(NS + "name") for flt in filters for f in flt.findall("action")]
            comps.append(dict(kind=el.tag, name=name, exported=exported,
                              perm=el.get(NS + "permission") or el.get(NS + "readPermission"),
                              actions=[x for x in actions if x]))
    flags = {}
    if app is not None:
        for k in ("debuggable", "allowBackup", "usesCleartextTraffic", "networkSecurityConfig"):
            v = app.get(NS + k)
            if v is not None:
                flags[k] = v
    return comps, flags


class Apk:
    kind = "apk"

    def __init__(self, path, data=None):
        from androguard.core.apk import APK
        self.path = path
        self.a = APK(path)
        self.zip = zipfile.ZipFile(path)
        self.dex_names = sorted((n for n in self.zip.namelist() if re.fullmatch(r"classes\d*\.dex", n)),
                                key=lambda n: int(re.sub(r"\D", "", n) or 1))
        self.comps, self.flags = manifest_facts(self.a)
        self._dex = None
        self.dex_errors = []
        self._cls = None
        self._xref = None

    def close(self):
        try:
            self.zip.close()
        except Exception:
            pass
        self._dex = self._cls = self._xref = None

    # lazy DEX layer -------------------------------------------------------
    @property
    def dex(self):
        if self._dex is None:
            self._dex = []
            for n in self.dex_names:
                d = self._load_dex(n)
                if d is not None:
                    self._dex.append(d)
        return self._dex

    MAX_DEX = 256 << 20          # largest real-world classesN.dex is ~20 MB; beyond this assume a zip bomb

    def _load_dex(self, n):
        """One DEX; never let a single bad/hostile entry take the whole APK down."""
        import zlib
        from androguard.core.dex import DEX
        info = self.zip.getinfo(n)
        if info.file_size > self.MAX_DEX or (info.compress_size and info.file_size / info.compress_size > 200
                                             and info.file_size > 32 << 20):
            self.dex_errors.append(f"{n}: refused ({info.file_size >> 20} MB uncompressed, "
                                   f"ratio {info.file_size // max(1, info.compress_size)}:1 — zip bomb?)")
            return None
        try:
            with self.zip.open(n) as f:          # bounded read even if the header lies about file_size
                buf = f.read(self.MAX_DEX + 1)
            if len(buf) > self.MAX_DEX:
                self.dex_errors.append(f"{n}: refused (> {self.MAX_DEX >> 20} MB uncompressed)")
                return None
        except Exception as e:
            self.dex_errors.append(f"{n}: unreadable ({type(e).__name__}: {str(e)[:60]})")
            return None
        try:
            return DEX(buf)
        except Exception as e:
            msg = str(e)
            if "Adler32" in msg and len(buf) > 32:
                # packers tamper with the header checksum to break tools; repair and retry
                fixed = buf[:8] + zlib.adler32(buf[12:]).to_bytes(4, "little") + buf[12:]
                try:
                    d = DEX(fixed)
                    self.dex_errors.append(f"{n}: bad header checksum (repaired; file may be tampered)")
                    return d
                except Exception as e2:
                    msg = str(e2)
            self.dex_errors.append(f"{n}: skipped ({type(e).__name__}: {msg[:70]})")
            return None

    @property
    def classes(self):
        if self._cls is None:
            self._cls = {}
            for d in self.dex:
                for c in d.get_classes():
                    self._cls.setdefault(c.get_name(), c)
        return self._cls

    @staticmethod
    def mkey(m):
        return f"{m.get_class_name()}->{m.get_name()}{m.get_descriptor()}".replace(" ", "")

    def xref_index(self):
        """callers[method_key] -> set(caller); strusers[string] -> set(method). Built once."""
        if self._xref is not None:
            return self._xref
        from . import cache
        key = cache.key_for(self.path, "apkxref2")
        hit = cache.load(key)
        if hit is not None:
            self._xref = hit
            return hit
        callers, strusers, ncode = defaultdict(set), defaultdict(set), 0
        for d in self.dex:
            mids = d.get_methods()
            strs = d.get_strings()
            mk = [None] * len(mids)
            for c in d.get_classes():
                for m in c.get_methods():
                    code = m.get_code()
                    if not code:
                        continue
                    ncode += 1
                    me = self.mkey(m)
                    for ins in code.get_bc().get_instructions():
                        op = ins.get_op_value()
                        if op in INVOKE:
                            j = ins.BBBB
                            k = mk[j]
                            if k is None:
                                k = mk[j] = self.mkey(mids[j])
                            callers[k].add(me)
                        elif op == 0x1A or op == 0x1B:
                            j = ins.BBBB if op == 0x1A else ins.BBBBBBBB
                            if j < len(strs):
                                strusers[strs[j]].add(me)
        self._xref = (dict(callers), dict(strusers), ncode)
        cache.save(key, self._xref)
        return self._xref

    # ----------------------------------------------------------------- views
    def overview(self):
        a = self.a
        perms = _g(a.get_permissions) or []
        dang = [p.split(".")[-1] for p in perms if p.split(".")[-1] in DANGEROUS]
        libs = [n for n in self.zip.namelist() if n.startswith("lib/") and n.endswith(".so")]
        abis = sorted({n.split("/")[1] for n in libs})
        L = [f"apk {_g(a.get_package) or '?'} v{_g(a.get_androidversion_name) or '?'} ({_g(a.get_androidversion_code) or '?'}) · "
             f"minSdk {_g(a.get_min_sdk_version) or '?'} target {_g(a.get_target_sdk_version) or '?'} · {len(self.dex_names)} dex"]
        L.append(f"permissions {len(perms)}" + (f" · dangerous: {' '.join(dang)}" if dang else ""))
        exp = [c for c in self.comps if c["exported"] and c["kind"] != "activity-alias"]
        L.append(f"components {len(self.comps)} · exported {len(exp)} (no permission: "
                 f"{sum(1 for c in exp if not c['perm'])})")
        for c in exp[:8]:
            L.append(f"  exported {c['kind']} {c['name']}" + (f" perm={c['perm']}" if c["perm"] else "")
                     + (f" actions={','.join(x.split('.')[-1] for x in c['actions'][:3])}" if c["actions"] else ""))
        if self.flags:
            L.append("app flags: " + " ".join(f"{k}={v}" for k, v in self.flags.items()))
        if libs:
            L.append(f"native libs {len({n.split('/')[-1] for n in libs})} [{' '.join(abis)}]: "
                     + clip(" ".join(sorted({n.split('/')[-1] for n in libs})), 200))
        if self.dex_errors:
            L.append("dex problems: " + clip("; ".join(self.dex_errors), 300))
        L.append("(classes/methods are indexed on first use: list classes · find <text> · show c:<class>)")
        return L

    def list(self, what="components", filt=""):
        return self._warn(self._list(what, filt))

    def _list(self, what="components", filt=""):
        rx = re.compile(filt, re.I) if filt else None
        w = (what or "components").lower()
        if w.startswith("comp"):
            return [f"{c['kind']} {c['name']} exported={c['exported']}" + (f" perm={c['perm']}" if c["perm"] else "")
                    for c in self.comps if not rx or rx.search(c["name"])]
        if w.startswith("perm"):
            return [p for p in (_g(self.a.get_permissions) or []) if not rx or rx.search(p)]
        if w.startswith("pack"):
            cnt = Counter("/".join(n[1:].split("/")[:3]) for n in self.classes)
            return [f"{p}  {n} classes" for p, n in cnt.most_common() if not rx or rx.search(p)]
        if w.startswith("class"):
            return [f"c:{n}" for n in sorted(self.classes) if not rx or rx.search(n)]
        if w.startswith("lib"):
            return [n for n in self.zip.namelist() if n.startswith("lib/") and (not rx or rx.search(n))]
        if w.startswith("url"):
            return sorted({u for d in self.dex for s in d.get_strings() for u in R_URL.findall(s)
                           if not rx or rx.search(u)})
        raise KeyError("list what: components|permissions|packages|classes|libs|urls")

    def find(self, query, kind="any", regex=False):
        return self._warn(self._find(query, kind, regex))

    def _warn(self, rows):
        if self.dex_errors:
            rows = [f"! dex problems: {clip('; '.join(self.dex_errors), 240)}"] + list(rows)
        return rows

    def _find(self, query, kind="any", regex=False):
        rx = re.compile(query if regex else re.escape(query), 0 if regex else re.I)
        out = []
        if kind in ("any", "class"):
            out += [f"c:{n}" for n in sorted(self.classes) if rx.search(n)][:300]
        if kind in ("any", "method"):
            for n, c in sorted(self.classes.items()):
                for m in c.get_methods():
                    if rx.search(m.get_name()):
                        out.append(f"m:{self.mkey(m)}")
                if len(out) > 2000:
                    break
        if kind in ("any", "string"):
            callers, strusers, _ = self.xref_index()
            for s, users in strusers.items():
                if rx.search(s):
                    u = sorted(users)
                    out.append(f'"{clip(s, 100)}" ← ' + ", ".join(f"m:{x}" for x in u[:3]) + (f" (+{len(u)-3})" if len(u) > 3 else ""))
        return out

    def _method(self, ident):
        key = ident[2:] if ident.startswith("m:") else ident
        cls = key.split("->")[0]
        c = self.classes.get(cls)
        if c is None:
            raise KeyError(f"class {cls} not found")
        cands = [m for m in c.get_methods() if self.mkey(m) == key]
        if not cands and "->" in key:
            nm = key.split("->")[1].split("(")[0]
            cands = [m for m in c.get_methods() if m.get_name() == nm]
        if not cands:
            raise KeyError(f"method {key} not found; show c:{cls} lists methods")
        return cands

    def show(self, ident, view="auto"):
        s = ident.strip()
        if s.startswith("c:") or (s.startswith("L") and "->" not in s):
            name = s[2:] if s.startswith("c:") else s
            c = self.classes.get(name)
            if c is None:
                raise KeyError(f"class {name} not found")
            L = [f"c:{name} extends {c.get_superclassname()}"
                 + (f" implements {', '.join(c.get_interfaces())}" if c.get_interfaces() else "")
                 + f" · {c.get_access_flags_string()}"]
            for f in c.get_fields():
                L.append(f"  field {f.get_access_flags_string()} {f.get_name()}: {f.get_descriptor()}")
            for m in c.get_methods():
                code = m.get_code()
                L.append(f"  m:{self.mkey(m)}  {m.get_access_flags_string()} size={code.insns_size if code else 0}")
            return L
        out = []
        for m in self._method(s):
            if view in ("smali", "asm"):
                out.append(f"m:{self.mkey(m)}")
                code = m.get_code()
                if code:
                    off = 0
                    for ins in code.get_bc().get_instructions():
                        out.append(f"  {off:04x} {ins.get_name()} {clip(ins.get_output(), 160)}")
                        off += ins.get_length() // 2
                continue
            out.append(f"// m:{self.mkey(m)}  (DAD decompile, single method)")
            out += self._decompile(m)
        return out

    def _decompile(self, m):
        if not m.get_code():
            return ["  (abstract/native method: no bytecode)"]
        try:
            from androguard.core.analysis.analysis import MethodAnalysis
            from androguard.decompiler.decompile import DvMethod
            dex = next(d for d in self.dex if m.CM.vm is d) if hasattr(m, "CM") else self.dex[0]
            dv = DvMethod(MethodAnalysis(dex, m))
            dv.process(doAST=False)
            return dv.get_source().strip("\n").split("\n")
        except Exception as e:
            return [f"  (decompile failed: {type(e).__name__}: {clip(str(e), 120)}; use view=smali)"]

    def xrefs(self, ident, direction="to"):
        callers, strusers, _ = self.xref_index()
        s = ident.strip()
        if s.startswith("c:"):
            name = s[2:]
            users = sorted({c for k, cs in callers.items() if k.startswith(name + "->") for c in cs
                            if not c.startswith(name + "->")})
            return [f"methods outside {name} that call into it: {len(users)}"] + [f"  m:{u}" for u in users]
        if s.startswith('"') or s.startswith("s:"):
            q = s[2:] if s.startswith("s:") else s.strip('"')
            return [f'"{clip(k, 80)}" used by m:{u}' for k, us in strusers.items() if k == q for u in sorted(us)]
        key = s[2:] if s.startswith("m:") else s
        if direction == "from":
            out = sorted({k for k, cs in callers.items() if key in cs})
            strs = sorted({k for k, us in strusers.items() if key in us})
            return [f"m:{key} calls {len(out)} methods, uses {len(strs)} strings"] + \
                   [f"  → m:{k}" for k in out] + [f'  → "{clip(x, 90)}"' for x in strs]
        cs = callers.get(key)
        if cs is None:
            pref = key.split("(")[0]
            cs = set().union(*[v for k, v in callers.items() if k.startswith(pref + "(")]) if any(
                k.startswith(pref + "(") for k in callers) else set()
        return [f"callers of m:{key}: {len(cs)}"] + [f"  m:{c}" for c in sorted(cs)]
