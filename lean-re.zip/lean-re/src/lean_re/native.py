"""Native binary analysis (ELF / PE / Mach-O; x86-64, x86, arm64).

Built-in, no external decompiler needed. One linear-sweep pass indexes calls,
code/data references and strings; per-function dossiers are computed on demand.
Outputs are short annotated lines, not raw dumps.
"""
import bisect
from array import array

import os
import re

import capstone as C
import lief

from .budget import clip
from .consts import scan_tables, tag_const

try:
    lief.logging.disable()
except Exception:
    pass


def _s(name):
    """LIEF returns raw bytes for non-UTF-8 section/symbol names (packers and malware garble them on purpose)."""
    if isinstance(name, (bytes, bytearray)):
        return bytes(name).decode("utf-8", "backslashreplace")
    return name or ""


IMM = re.compile(r"#?(-?0x[0-9a-fA-F]+)\b|#(-?\d+)\b")
RIPREL = re.compile(r"\[rip ([+-]) (0x[0-9a-f]+)\]")
X86_TERM = {"ret", "retf", "jmp", "ud2", "hlt"}
A64_TERM = {"ret", "b", "br", "brk", "udf"}
PAD = {"nop", "int3", ".byte", "endbr64", "endbr32"}
ARGREGS = {"sysv": ["di", "si", "dx", "cx", "r8", "r9"], "win": ["cx", "dx", "r8", "r9"],
           "a64": ["x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7"]}


# variadic format functions: name -> index of the format argument
FMT_FUNCS = {"printf": 0, "fprintf": 1, "dprintf": 1, "sprintf": 1, "snprintf": 2, "asprintf": 1,
             "syslog": 1, "err": 1, "errx": 1, "warn": 0, "warnx": 0, "wprintf": 0, "fwprintf": 1,
             "swprintf": 2, "_snprintf": 2, "sprintf_s": 2, "fprintf_s": 1, "printf_s": 0,
             "__printf_chk": 1, "__fprintf_chk": 2, "__sprintf_chk": 3, "__snprintf_chk": 4,
             "__dprintf_chk": 2, "__asprintf_chk": 2, "__syslog_chk": 2,
             "scanf": 0, "fscanf": 1, "sscanf": 1, "__isoc99_scanf": 0, "__isoc99_fscanf": 1,
             "__isoc99_sscanf": 1, "__isoc23_scanf": 0, "__isoc23_fscanf": 1, "__isoc23_sscanf": 1}
_FMT_RX = re.compile(r"%(?:(\d+)\$)?[-+ #0']*(\*(?:\d+\$)?|\d+)?(?:\.(\*(?:\d+\$)?|\d+))?"
                     r"(?:hh|h|ll|l|L|q|j|z|Z|t|I64|I32|I)?([diouxXeEfFgGaAcsSpnCm%]|\[)")
REG64 = {"di": "rdi", "si": "rsi", "dx": "rdx", "cx": "rcx"}


def fmt_func(name):
    if not name:
        return None
    name = name.split()[-1]                              # "f:140001480 fprintf" (statically linked)
    if "." in name:                                      # printf.constprop.0 / .isra / .part: ABI may differ
        return None
    i = FMT_FUNCS.get(name)
    if i is None and name.startswith("_") and not name.startswith("__"):
        i = FMT_FUNCS.get(name[1:])                     # Mach-O leading underscore
    return i


def fmt_args(fmt, scan=False):
    """Argument kinds consumed by a printf/scanf format: list of 'i' (integer/pointer) or 'f' (double)."""
    kinds, pos = [], {}
    for m in _FMT_RX.finditer(fmt):
        posn, width, prec, conv = m.groups()
        if conv in ("%", "m"):
            continue
        for w in (width, prec):
            if w and w.startswith("*"):
                kinds.append("i")
        k = "f" if conv in "eEfFgGaA" and not scan else "i"
        if posn:
            pos[int(posn)] = k
        else:
            kinds.append(k)
    if pos:                                              # positional: %2$s %1$d
        return [pos.get(i, "i") for i in range(1, max(pos) + 1)]
    return kinds


def norm_reg(r):
    r = r.strip()
    if re.fullmatch(r"[wx]\d+", r):
        return "x" + r[1:]
    m = re.fullmatch(r"r(\d+)[dwb]?", r)
    if m:
        return "r" + m.group(1)
    m = re.fullmatch(r"[re]?([abcd])[xlh]", r)
    if m:
        return m.group(1) + "x"
    m = re.fullmatch(r"[re]?(si|di|bp|sp)l?", r)
    if m:
        return m.group(1)
    return r


def ascii_tag(v):
    if 0x20202020 <= v <= 0x7E7E7E7E or 0x2020 <= v <= 0x7E7E:
        n = 4 if v > 0xFFFF else 2
        bs = v.to_bytes(n, "little")
        if all(32 <= c < 127 for c in bs):
            return "ascii '" + bs.decode() + "'"
    return None


def _imms(op):
    out = [int(x) for x in op.split(", ")[1:] if re.fullmatch(r"-?\d+", x.strip())] if op else []
    for m in IMM.finditer(op):
        s = m.group(1) or m.group(2)
        try:
            out.append(int(s, 0))
        except ValueError:
            pass
    return out


_KINDS = ("call", "icall", "jmp", "ijmp", "ref", "load", "store", "other")
_KCODE = {k: i for i, k in enumerate(_KINDS)}


class _Refs:
    """target -> [(site, kind)] in columnar form. While indexing, references are appended to two flat
    uint64 arrays (target, site << 3 | kind); finalize() sorts them by target once (stable, so per-target
    order is unchanged) and lookups bisect. ~16 B/ref and no per-target container or int objects;
    a dict of lists of tuples cost ~100 B/ref (libz3: 1.4 M refs, libLLVM: several million)."""

    def __init__(self):
        self._t, self._v = array("q"), array("Q")
        self.T = self.V = None

    @staticmethod
    def _key(t):
        """Targets as signed int64 (computed refs can go negative); values in [2^63, 2^64) wrap."""
        if -(1 << 63) <= t < (1 << 63):
            return t
        if t < (1 << 64):
            return t - (1 << 64)
        return None

    def add(self, tgt, site, kind):
        tgt = self._key(tgt)
        if tgt is None:
            return
        self._t.append(tgt)
        self._v.append(site << 3 | _KCODE.get(kind, 7))

    def finalize(self):
        import numpy as np
        if self.T is None:
            t = np.frombuffer(self._t, dtype=np.int64) if len(self._t) else np.zeros(0, np.int64)
            v = np.frombuffer(self._v, dtype=np.uint64) if len(self._v) else np.zeros(0, np.uint64)
            order = np.argsort(t, kind="stable")
            self.T, self.V = t[order].copy(), v[order].copy()
            self._t = self._v = None
        return self

    def __getstate__(self):
        self.finalize()
        return {"T": self.T, "V": self.V}

    def __setstate__(self, st):
        self.T, self.V, self._t, self._v = st["T"], st["V"], None, None

    def _span(self, tgt):
        self.finalize()
        tgt = self._key(tgt)
        if tgt is None:
            return 0, 0
        return int(self.T.searchsorted(tgt, "left")), int(self.T.searchsorted(tgt, "right"))

    @staticmethod
    def _unpack(vals):
        return [(v >> 3, _KINDS[v & 7]) for v in vals.tolist()]

    def get(self, tgt, default=()):
        i, j = self._span(tgt)
        return default if i == j else self._unpack(self.V[i:j])

    def __getitem__(self, tgt):
        i, j = self._span(tgt)
        if i == j:
            raise KeyError(tgt)
        return self._unpack(self.V[i:j])

    def __contains__(self, tgt):
        i, j = self._span(tgt)
        return i != j

    def keys(self):
        import numpy as np
        self.finalize()
        return np.unique(self.T).tolist()

    def __iter__(self):
        return iter(self.keys())

    def __len__(self):
        return len(self.keys())

    def items(self):
        import numpy as np
        self.finalize()
        if not len(self.T):
            return
        cut = np.flatnonzero(np.diff(self.T)) + 1
        starts = [0] + cut.tolist()
        ends = cut.tolist() + [len(self.T)]
        for i, j in zip(starts, ends):
            yield int(self.T[i]), self._unpack(self.V[i:j])

    def values(self):
        return (v for _k, v in self.items())


class _Calls:
    """[(site, target, kind)] as three parallel arrays (~17 B per call instead of a tuple + ints)."""

    def __init__(self):
        self.s, self.t, self.k = array("Q"), array("Q"), array("B")

    def append(self, item):
        a, t, k = item
        self.s.append(a)
        self.t.append(t)
        self.k.append(_KCODE.get(k, 7))

    def __iter__(self):
        K = _KINDS
        for a, t, k in zip(self.s, self.t, self.k):
            yield a, t, K[k]

    def __len__(self):
        return len(self.s)


class _GView:
    """Read-only dict-like view (get / in / [] / count) over one direction of a _Graph."""

    def __init__(self, g, callers):
        self.g, self.callers = g, callers

    def _span(self, k):
        g = self.g
        code = g.code(k)
        if code is None:
            return None, 0, 0
        arr = g.CK if self.callers else g.DF
        return code, int(arr.searchsorted(code, "left")), int(arr.searchsorted(code, "right"))

    def get(self, k, default=()):
        code, i, j = self._span(k)
        if i == j:
            return default
        g = self.g
        if self.callers:
            return set(g.CF[i:j].tolist())
        return {g.decode(x) for x in g.DK[i:j].tolist()}

    def __getitem__(self, k):
        r = self.get(k, None)
        if r is None:
            raise KeyError(k)
        return r

    def __contains__(self, k):
        _c, i, j = self._span(k)
        return i != j

    def count(self, k):
        _c, i, j = self._span(k)
        return j - i


class _Graph:
    """Call graph in columnar form. Keys are call targets: int addresses, or ("imp", name) / ("ind", slot)
    tuples interned to negative codes. Replaces two defaultdict(set)s that cost ~450 MB on libLLVM.

    DF/DK: unique (caller fn, key) edges sorted by caller  -> callees, counts
    CK/CF: the same edges sorted by key                     -> callers, counts
    RK/RF/RS: every call site sorted by (key, caller, site) -> "called by X at sites" without scanning"""

    def __init__(self):
        self.tkeys, self._tidx = [], {}
        self._f, self._k, self._s = array("q"), array("q"), array("Q")

    def code(self, k):
        if isinstance(k, tuple):
            i = self._tidx.get(k)
            return None if i is None else -(i + 1)
        return k if 0 <= k < (1 << 63) else None

    def decode(self, c):
        return self.tkeys[-c - 1] if c < 0 else c

    def add(self, f, k, site):
        if isinstance(k, tuple):
            i = self._tidx.get(k)
            if i is None:
                i = self._tidx[k] = len(self.tkeys)
                self.tkeys.append(k)
            c = -(i + 1)
        else:
            c = self.code(k)
            if c is None:
                return
        self._f.append(f)
        self._k.append(c)
        self._s.append(site)

    def finalize(self):
        import numpy as np
        F = np.frombuffer(self._f, np.int64).copy() if len(self._f) else np.zeros(0, np.int64)
        K = np.frombuffer(self._k, np.int64).copy() if len(self._k) else np.zeros(0, np.int64)
        S = np.frombuffer(self._s, np.uint64).copy() if len(self._s) else np.zeros(0, np.uint64)
        self._f = self._k = self._s = None
        o = np.lexsort((S, F, K))
        self.RK, self.RF, self.RS = K[o], F[o], S[o]
        o = np.lexsort((K, F))
        df, dk = F[o], K[o]
        keep = np.ones(len(df), bool)
        if len(df):
            keep[1:] = (df[1:] != df[:-1]) | (dk[1:] != dk[:-1])
        self.DF, self.DK = df[keep], dk[keep]
        o = np.lexsort((self.DF, self.DK))
        self.CK, self.CF = self.DK[o], self.DF[o]
        self._views()
        return self

    def _views(self):
        self.callers, self.callees = _GView(self, True), _GView(self, False)

    def sites(self, k, caller):
        code = self.code(k)
        if code is None:
            return []
        i, j = int(self.RK.searchsorted(code, "left")), int(self.RK.searchsorted(code, "right"))
        rf = self.RF[i:j]
        a, b = int(rf.searchsorted(caller, "left")), int(rf.searchsorted(caller, "right"))
        return self.RS[i + a:i + b].tolist()

    def __getstate__(self):
        return {k: getattr(self, k) for k in ("tkeys", "RK", "RF", "RS", "DF", "DK", "CK", "CF")}

    def __setstate__(self, st):
        self.__dict__.update(st)
        self._tidx = {k: i for i, k in enumerate(self.tkeys)}
        self._views()


class _Bitmap:
    """Instruction-start set as one bit per byte of executable section (was a Python set: ~80 B/insn)."""

    def __init__(self, sections):
        self.secs = sorted((va, size, bytearray(size // 8 + 1)) for va, size, _n, content, ex in sections
                           if ex and content)
        self.starts = [x[0] for x in self.secs]

    def _find(self, a):
        i = bisect.bisect_right(self.starts, a) - 1
        if i >= 0:
            va, size, bits = self.secs[i]
            if a < va + size:
                return a - va, bits
        return None, None

    def add(self, a):
        o, bits = self._find(a)
        if bits is not None:
            bits[o >> 3] |= 1 << (o & 7)

    def __contains__(self, a):
        o, bits = self._find(a)
        return bits is not None and bool(bits[o >> 3] & (1 << (o & 7)))


class Native:
    kind = "native"

    # ------------------------------------------------------------------ load
    def __init__(self, path, data=None):
        # `data` is accepted for API compatibility but not retained: LIEF parses from the path and section
        # bytes are zero-copy views of an mmap (page cache, reclaimable) instead of a second private copy.
        self.path = path
        self.size = len(data) if data is not None else os.path.getsize(path)
        del data
        self._mm = None
        try:
            import mmap
            with open(path, "rb") as f:
                self._mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        except (OSError, ValueError):
            pass
        b = lief.parse(path)
        if b is None:
            raise ValueError("unsupported native format")
        if isinstance(b, lief.MachO.FatBinary):
            pick = None
            for i in range(b.size):
                x = b.at(i)
                if x.header.cpu_type in (lief.MachO.Header.CPU_TYPE.X86_64, lief.MachO.Header.CPU_TYPE.ARM64):
                    pick = x
                    break
            b = pick or b.at(0)
        self.b = b
        self.fmt = {lief.Binary.FORMATS.ELF: "ELF", lief.Binary.FORMATS.PE: "PE",
                    lief.Binary.FORMATS.MACHO: "Mach-O"}.get(b.format, str(b.format))
        hdr = b.abstract.header
        A = lief.Header.ARCHITECTURES
        self.is64 = bool(hdr.is_64)
        if hdr.architecture == A.X86_64:
            self.arch, cs = "x86-64", (C.CS_ARCH_X86, C.CS_MODE_64)
        elif hdr.architecture == A.X86:
            self.arch, cs = "x86", (C.CS_ARCH_X86, C.CS_MODE_32)
        elif hdr.architecture == A.ARM64:
            self.arch, cs = "arm64", (C.CS_ARCH_ARM64, C.CS_MODE_ARM)
        else:
            raise ValueError(f"unsupported architecture {hdr.architecture}")
        self.a64 = self.arch == "arm64"
        self.cs = C.Cs(*cs)
        self.cs.skipdata = True
        self.cc = "a64" if self.a64 else ("win" if self.fmt == "PE" else "sysv")
        self.base = b.imagebase if self.fmt == "PE" else 0
        self._load_sections()
        self._load_imports()
        self._cached_index()
        self._release_lief()

    def _release_lief(self):
        """The LIEF object (~170 MB for libLLVM) is only needed while loading/indexing. Keep the few facts
        later views use, then free it and hand the memory back to the OS."""
        b = self.b
        try:
            self.stripped = self.fmt == "ELF" and not any(_s(x.name) == ".symtab" for x in b.sections)
        except Exception:
            self.stripped = False
        self.is_pie = bool(getattr(b, "is_pie", False))
        try:
            self.exports = [(_s(x.name), x.address) for x in b.exported_functions]
        except Exception:
            self.exports = []
        self.imagebase = getattr(b, "imagebase", 0)
        del self.b, b
        import gc
        gc.collect()
        try:
            import ctypes
            ctypes.CDLL("libc.so.6").malloc_trim(0)
        except Exception:
            pass

    CACHED = ("strings", "_str_keys", "calls", "refs", "stub", "fn_starts", "fn_size", "names",
              "graph", "entry")

    @property
    def callers(self):
        return self.graph.callers

    @property
    def callees(self):
        return self.graph.callees

    def _cached_index(self):
        from . import cache
        key = None
        self.cache_key = None
        try:
            key = cache.key_for(self.path, "native")
            self.cache_key = key
            hit = cache.load(key)
        except Exception:
            hit = None
        if hit is not None:
            self.__dict__.update(hit)
            self.from_cache = True
            return
        self.from_cache = False
        self._index()
        self.insn_starts = None   # only needed while discovering functions
        if key:
            try:
                cache.save(key, {k: getattr(self, k) for k in self.CACHED})
            except Exception:
                pass

    def _load_sections(self):
        b = self.b
        self.sections = []  # (va, size, name, bytes, exec)
        for s in b.sections:
            try:
                va = s.virtual_address + self.base
                content = self._view(s)
                ex = False
                if self.fmt == "ELF":
                    ex = s.has(lief.ELF.Section.FLAGS.EXECINSTR)
                    if s.type == lief.ELF.Section.TYPE.NOBITS:
                        content = b""
                elif self.fmt == "PE":
                    ex = s.has_characteristic(lief.PE.Section.CHARACTERISTICS.MEM_EXECUTE)
                else:
                    F = lief.MachO.Section.FLAGS
                    ex = s.has(F.PURE_INSTRUCTIONS) or s.has(F.SOME_INSTRUCTIONS)
                if va == self.base and not content:
                    continue
                name = _s(s.name)
                self.sections.append((va, max(s.size, len(content)), name, content, ex))
            except Exception:
                continue
        self.sections.sort()
        self._sec_starts = [s[0] for s in self.sections]

    def sec_of(self, a):
        i = bisect.bisect_right(self._sec_starts, a) - 1
        if i >= 0:
            s = self.sections[i]
            if s[0] <= a < s[0] + s[1]:
                return s
        return None

    def is_code(self, a):
        s = self.sec_of(a)
        return bool(s and s[4])

    def _view(self, s):
        """Section bytes as a zero-copy slice of the file mmap, verified against LIEF; falls back to a copy
        (fat Mach-O slices, odd layouts)."""
        c = s.content
        n = len(c)
        if self._mm is not None and n:
            try:
                off = int(s.offset)
                if 0 <= off and off + n <= len(self._mm):
                    head, tail = bytes(c[:64]), bytes(c[max(0, n - 64):])
                    mv = memoryview(self._mm)[off:off + n]
                    if mv[:64] == head and mv[max(0, n - 64):] == tail:
                        return mv
            except Exception:
                pass
        return bytes(c)

    def read(self, a, n):
        s = self.sec_of(a)
        if not s or not s[3]:
            return b""
        o = a - s[0]
        return bytes(s[3][o:o + n])

    def _load_imports(self):
        b = self.b
        self.ptr_names = {}  # GOT/IAT slot -> imported symbol
        self.ptr_vals = {}   # slot -> relocated pointer value (PIE tables)
        self.imports = []
        try:
            if self.fmt == "ELF":
                for r in b.relocations:
                    nm = _s(r.symbol.name) if r.has_symbol and r.symbol else ""
                    if nm:
                        self.ptr_names[r.address] = nm
                    elif "RELATIVE" in str(r.type) and r.addend:
                        self.ptr_vals[r.address] = r.addend
                self.imports = sorted({_s(f.name) for f in b.imported_functions if _s(f.name)})
            elif self.fmt == "PE":
                for imp in b.imports:
                    for e in imp.entries:
                        nm = _s(e.name) or f"ord{e.ordinal}"
                        self.ptr_names[self.base + e.iat_address] = nm
                        self.imports.append(nm)
            else:
                import struct as _st
                try:
                    for r in b.relocations:
                        raw = self.read(r.address, 8)
                        if len(raw) == 8:
                            v = _st.unpack("<Q", raw)[0] & 0xFFFFFFFFFF   # strip chained-fixup high bits
                            if self.sec_of(v):
                                self.ptr_vals[r.address] = v
                except Exception:
                    pass
                for bd in b.bindings:
                    if bd.has_symbol:
                        self.ptr_names[bd.address] = _s(bd.symbol.name).lstrip("_")
                self.imports = sorted({_s(f.name).lstrip("_") for f in b.imported_functions if _s(f.name)})
        except Exception:
            pass
        self.imports = sorted(set(self.imports))

    # ----------------------------------------------------------------- index
    SWEEP_CHUNK = 1 << 16

    def _lite(self, code, va):
        """Linear sweep in 64 KB windows. capstone's disasm_lite materialises a cs_insn (~240 B) for every
        instruction of the buffer at once (~1.2 GB for 20 MB of x86 code); windows keep that bounded. Each
        window overlaps the next by 16 bytes (> max x86 insn) and resumes exactly where the last decoded
        instruction ended, so the instruction stream is identical to a single sweep."""
        n, off = len(code), 0
        mv = memoryview(code)
        while off < n:
            end = min(n, off + self.SWEEP_CHUNK)
            nxt = off
            for a, sz, mn, op in self.cs.disasm_lite(bytes(mv[off:min(n, end + 16)]), va + off):
                if a - va >= end:
                    break
                yield a, sz, mn, op
                nxt = a - va + sz
            off = nxt if nxt > off else end

    def _sweep(self, va, code):
        """Yield (addr, size, mnem, op, target, kind) with resolved refs."""
        a64 = self.a64
        page = {}
        for a, sz, mn, op in self._lite(code, va):
            tgt, kind = None, None
            if mn.startswith(("bnd ", "notrack ", "rep ", "lock ")) and " " in mn:
                mn = mn.split(" ", 1)[1]
            if a64:
                if mn == "bl" or mn == "b" or mn.startswith("b.") or mn in ("cbz", "cbnz", "tbz", "tbnz"):
                    m = re.search(r"#(0x[0-9a-f]+)$", op)
                    if m:
                        tgt, kind = int(m.group(1), 16), ("call" if mn == "bl" else "jmp")
                elif mn == "adrp":
                    r, _, v = op.partition(", ")
                    try:
                        page[r] = int(v.lstrip("#"), 16)
                    except ValueError:
                        pass
                elif mn == "adr":
                    r, _, v = op.partition(", ")
                    try:
                        tgt, kind = int(v.lstrip("#"), 16), "ref"
                    except ValueError:
                        pass
                elif mn in ("add", "ldr", "ldrsw", "str", "ldrb", "ldrh"):
                    parts = [x.strip() for x in re.split(r",\s*", op.replace("[", "").replace("]", "").replace("!", ""))]
                    if len(parts) >= 2:
                        srcr = parts[1] if mn == "add" else parts[1]
                        if srcr in page:
                            off = 0
                            if len(parts) >= 3:
                                try:
                                    off = int(parts[2].lstrip("#"), 0)
                                except ValueError:
                                    off = None
                            if off is not None:
                                tgt = page[srcr] + off
                                kind = "ref" if mn == "add" else ("store" if mn == "str" else "load")
                                if mn == "add":
                                    page[parts[0]] = tgt  # keep chain
                if mn in A64_TERM:
                    page.clear()
                elif mn not in ("adrp", "str", "strb", "strh", "stp", "cmp", "cmn", "tst") and not (mn == "add" and tgt is not None):
                    page.pop(op.split(",", 1)[0].strip(), None)
            else:
                if mn == "call" or mn[0] == "j":
                    m = re.fullmatch(r"(?:bnd )?(0x[0-9a-f]+)", op)
                    if m:
                        tgt, kind = int(m.group(1), 16), ("call" if mn == "call" else "jmp")
                if tgt is None:
                    m = RIPREL.search(op)
                    if m:
                        d = int(m.group(2), 16)
                        tgt = a + sz + (d if m.group(1) == "+" else -d)
                        if mn in ("call", "jmp"):
                            kind = "icall" if mn == "call" else "ijmp"
                        elif mn == "lea":
                            kind = "ref"
                        elif op.startswith(("qword ptr [", "dword ptr [", "word ptr [", "byte ptr [", "xmmword ptr [")):
                            kind = "store"
                        else:
                            kind = "load"
                    elif not self.is64:
                        m = re.search(r"\[(0x[0-9a-f]+)\]", op) or re.search(r"(?:^|, )(0x[0-9a-f]{5,})$", op)
                        if m:
                            v = int(m.group(1), 16)
                            if self.sec_of(v):
                                tgt = v
                                kind = "icall" if mn == "call" and "[" in op else ("ref" if "[" not in op else "load")
            yield a, sz, mn, op, tgt, kind

    def _strings(self):
        self.strings = {}
        pat = re.compile(rb"[\x20-\x7e\t\n\r]{4,}")
        wpat = re.compile(rb"(?:[\x20-\x7e]\x00){5,}")
        for va, size, name, content, ex in self.sections:
            if ex or not content:
                continue
            for m in pat.finditer(content):
                s = m.group().decode("ascii", "replace")
                end = m.end()
                if len(s) < 6 and (end >= len(content) or content[end] != 0):
                    continue
                self.strings[va + m.start()] = s
            if self.fmt == "PE":
                for m in wpat.finditer(content):
                    self.strings.setdefault(va + m.start(), m.group().decode("utf-16le", "replace"))
        self._str_keys = sorted(self.strings)

    def string_at(self, a):
        """Return (start, text, offset) if a points into a known string."""
        i = bisect.bisect_right(self._str_keys, a) - 1
        if i >= 0:
            st = self._str_keys[i]
            t = self.strings[st]
            if a < st + len(t) + 1:
                return st, t, a - st
        return None

    def _index(self):
        self._strings()
        self.calls = _Calls()    # (site, target, kind)
        self.refs = _Refs()             # target -> [(site, kind)]
        self.insn_starts = _Bitmap(self.sections)
        stub = {}
        seeds = {}
        endbr = []
        prev_term = True
        for va, size, name, content, ex in self.sections:
            if not ex or not content:
                continue
            is_stub = any(k in name for k in ("plt", "stub", "__auth_stubs"))
            cur = None
            for a, sz, mn, op, tgt, kind in self._sweep(va, content):
                self.insn_starts.add(a)
                if is_stub:
                    if cur is None:
                        cur = a
                    nm = self.ptr_names.get(tgt) if tgt is not None and kind in ("ijmp", "load") else None
                    if nm:
                        stub[cur] = nm
                        stub[a] = nm
                    if mn in X86_TERM or mn in ("br", "nop"):
                        cur = None
                    continue
                if mn in ("endbr64", "endbr32") and prev_term:
                    endbr.append(a)
                prev_term = mn in X86_TERM or mn in A64_TERM or mn in PAD
                if tgt is None:
                    continue
                self.refs.add(tgt, a, kind)
                if kind in ("call", "icall"):
                    self.calls.append((a, tgt, kind))
                    if kind == "call" and self.is_code(tgt):
                        seeds.setdefault(tgt, None)
                elif kind == "ref" and self.is_code(tgt):
                    seeds.setdefault(tgt, None)
        self.stub = stub
        self.refs.finalize()
        self._functions(seeds, endbr)

    def _functions(self, seeds, endbr):
        b = self.b
        names = {}
        sizes = {}
        try:
            for f in b.functions:
                a = f.address + (self.base if self.fmt == "PE" and f.address < self.base else 0)
                if self.is_code(a):
                    seeds.setdefault(a, None)
                    if _s(f.name):
                        names.setdefault(a, _s(f.name).lstrip("_") if self.fmt == "Mach-O" else _s(f.name))
                    if f.size:
                        sizes[a] = f.size
        except Exception:
            pass
        if self.fmt == "PE":
            pd = next((x for x in self.sections if x[2] == ".pdata"), None)
            if pd and pd[3]:
                import struct
                raw = pd[3]
                for i in range(0, len(raw) - 11, 12):
                    beg, end, _u = struct.unpack_from("<III", raw, i)
                    if beg and end > beg and self.is_code(self.base + beg):
                        seeds.setdefault(self.base + beg, None)
                        sizes.setdefault(self.base + beg, end - beg)
            psecs = list(b.sections)
        try:
            for sym in b.symbols:
                if self.fmt == "PE":
                    idx = getattr(sym, "section_idx", 0)
                    if not (0 < idx <= len(psecs)) or _s(sym.name).startswith("."):
                        continue
                    v = self.base + psecs[idx - 1].virtual_address + sym.value
                else:
                    v = sym.value
                if _s(sym.name) and v and self.is_code(v) and _s(sym.name) not in ("$x", "$d"):
                    nm = _s(sym.name).lstrip("_") if self.fmt == "Mach-O" else _s(sym.name)
                    if not nm.startswith((".L", "$")):
                        names.setdefault(v, nm)
                        seeds.setdefault(v, None)
        except Exception:
            pass
        self.entry = b.entrypoint
        if self.is_code(self.entry):
            seeds.setdefault(self.entry, None)
            names.setdefault(self.entry, "entry")
        for slot, v in self.ptr_vals.items():
            if self.is_code(v):
                seeds.setdefault(v, None)
        for a in endbr:
            seeds.setdefault(a, None)
        for a, nm in self.stub.items():
            seeds.pop(a, None)
        for a in list(seeds):
            sec = self.sec_of(a)
            if sec and any(k in sec[2] for k in ("plt", "stub")):
                seeds.pop(a, None)
        starts = sorted(a for a in seeds if a in self.insn_starts or a in names)
        self.fn_starts = starts
        self._sizes = sizes
        self._resize()
        self.names = names
        self._detect_main()
        del self._sizes
        # call graph
        g = _Graph()
        for site, tgt, kind in self.calls:
            f = self.func_of(site)
            if f is None:
                continue
            g.add(f, self.call_key(tgt, kind), site)
        self.graph = g.finalize()

    def _detect_main(self):
        if self.fmt != "ELF" or self.names.get(self.entry) not in ("entry", "_start"):
            return
        last_ref = None
        for a, sz, mn, op, tgt, kind in self.insns(self.entry, min(self.fn_size.get(self.entry, 64), 96)):
            if kind in ("ref", "load") and tgt is not None:
                v = self.ptr_vals.get(tgt, tgt) if kind == "load" else tgt
                if self.is_code(v):
                    last_ref = v
            if kind in ("call", "icall") and last_ref is not None:
                if "libc_start_main" in self.call_name(tgt, kind):
                    if last_ref not in self.names:
                        self.names[last_ref] = "main"
                        if last_ref not in self.fn_size:
                            bisect.insort(self.fn_starts, last_ref)
                            self._resize()
                    return

    def _resize(self):
        """Function extents: symbol/FDE size when it stays inside the section (LIEF misreads some .eh_frame
        ranges — 9k functions of 1 GB in a Unity libil2cpp.so), else up to the next function start."""
        sizes = getattr(self, "_sizes", {})
        self.fn_size = {}
        for i, a in enumerate(self.fn_starts):
            sec = self.sec_of(a)
            end = sec[0] + sec[1]
            sz = sizes.get(a)
            gap = (self.fn_starts[i + 1] if i + 1 < len(self.fn_starts) and self.fn_starts[i + 1] < end else end) - a
            self.fn_size[a] = sz if sz and 0 < sz <= end - a else gap

    # --------------------------------------------------------------- helpers
    def func_of(self, a):
        i = bisect.bisect_right(self.fn_starts, a) - 1
        if i >= 0:
            f = self.fn_starts[i]
            if a < f + self.fn_size.get(f, 0):
                return f
        return None

    def insns(self, a, n):
        code = self.read(a, n)
        return self._sweep(a, code) if code else iter(())

    def fname(self, f):
        nm = self.names.get(f)
        return f"f:{f:x} {nm}" if nm else f"f:{f:x}"

    def call_key(self, tgt, kind):
        if kind == "icall":
            nm = self.ptr_names.get(tgt)
            return ("imp", nm) if nm else ("ind", tgt)
        if tgt in self.stub:
            return ("imp", self.stub[tgt])
        return tgt

    def call_name(self, tgt, kind="call"):
        k = self.call_key(tgt, kind)
        if isinstance(k, tuple):
            return k[1] if k[0] == "imp" else f"[{k[1]:#x}]"
        return self.fname(k)

    def describe(self, a, kind=None):
        """Short meaning of an address: string, import slot, function, data."""
        if a in self.stub:
            return self.stub[a]
        if a in self.ptr_names:
            return f"&{self.ptr_names[a]}"
        st = self.string_at(a)
        if st:
            s0, t, off = st
            return f'"{clip(t[off:], 70)}"'
        if a in self.ptr_vals:
            v = self.ptr_vals[a]
            st = self.string_at(v)
            if st:
                return f'ptr→"{clip(st[1][st[2]:], 60)}"'
            if self.is_code(v):
                return f"ptr→{self.fname(v)}"
        sec = self.sec_of(a)
        if sec and not sec[4] and sec[3]:
            raw = self.read(a, 96)
            z = raw.find(b"\0")
            if 0 < z and all(32 <= c < 127 or c in (9, 10, 13) for c in raw[:z]):
                return f'"{clip(raw[:z].decode("ascii"), 70)}"'
        if self.is_code(a):
            f = self.func_of(a)
            if f == a:
                return self.fname(a)
            return f"{a:#x} (in {self.fname(f)})" if f else f"{a:#x}"
        sec = self.sec_of(a)
        if sec:
            return f"{a:#x} ({sec[2]})"
        return None

    def parse_id(self, ident):
        s = ident.strip()
        if s.startswith("f:") or s.startswith("a:") or s.startswith("s:"):
            s = s[2:]
        s = s.split()[0]
        for k, v in self.names.items():
            if v == s:
                return k
        for k, v in self.stub.items():
            if v == s or v == s.replace("@plt", ""):
                return k
        try:
            return int(s, 16)
        except ValueError:
            raise KeyError(f"unknown id {ident!r}; use list/find to get ids like f:401136")

    # --------------------------------------------------------------- dossier
    def _fn_insns(self, f):
        ins = list(self.insns(f, self.fn_size.get(f, 0)))
        while ins and ins[-1][2] in PAD:
            ins.pop()
        return ins

    def _loops(self, ins, targets, lo, hi):
        """Back-edges a->t where a is reachable from t in the intra-procedural CFG."""
        succ, starts, cur = {}, [], None
        for i, (a, sz, mn, op, t, k) in enumerate(ins):
            if cur is None or a in targets:
                if cur is not None and cur not in succ:
                    succ[cur] = [a]
                cur = a
                starts.append(a)
                succ.setdefault(a, [])
            term = mn in X86_TERM or mn in A64_TERM or mn in ("ret", "retq")
            if k == "jmp" and t is not None:
                if lo <= t < hi:
                    succ[cur].append(t)
                if mn not in ("jmp", "b") and i + 1 < len(ins):
                    succ[cur].append(ins[i + 1][0])
                cur = None
            elif term:
                cur = None
            elif i + 1 < len(ins) and ins[i + 1][0] in targets:
                succ[cur].append(ins[i + 1][0])
        bstart = sorted(succ)

        def block(x):
            j = bisect.bisect_right(bstart, x) - 1
            return bstart[j] if j >= 0 else None
        loops = set()
        for a, sz, mn, op, t, k in ins:
            if k == "jmp" and t is not None and lo <= t <= a:
                src, seen, stack = block(a), set(), [t]
                while stack:
                    x = stack.pop()
                    if x == src:
                        loops.add(t)
                        break
                    if x in seen:
                        continue
                    seen.add(x)
                    stack += [block(y) for y in succ.get(x, []) if block(y) is not None]
        return sorted(loops)

    def _shape(self, f, ins):
        lo, hi = f, f + self.fn_size.get(f, 0)
        jt = [(a, t, mn) for a, sz, mn, op, t, k in ins if k == "jmp" and t is not None]
        targets = {t for a, t, mn in jt if lo <= t < hi}
        loops = self._loops(ins, targets, lo, hi)
        conds = sum(1 for a, t, mn in jt if mn not in ("jmp", "b"))
        tails = [t for a, t, mn in jt if not (lo <= t < hi) and mn in ("jmp", "b")]
        return targets, loops, conds, tails

    def _track(self, val, a, mn, op, t, k):
        """Track constant/known values written to registers (for call args)."""
        ops = [x.strip() for x in op.split(", ")] if op else []
        if not ops:
            return
        dst = norm_reg(ops[0])
        raw = val.setdefault("@raw", {})
        if mn not in ("cmp", "test", "cmn", "tst", "push", "call", "bl") and not mn.startswith(("str", "stp", "stur")):
            raw.pop(dst, None)
        if t is not None and k in ("ref", "load"):
            val[dst] = self.describe(t) or f"{t:#x}"
            if k == "ref":
                raw[dst] = t
        elif mn in ("mov", "movz", "movabs", "movk") and len(ops) == 2:
            iv = _imms(ops[1])
            if iv and not ops[1].startswith(("x", "w", "r", "e")) and "[" not in ops[1]:
                val[dst] = f"{iv[0]:#x}" if abs(iv[0]) > 9 else str(iv[0])
            else:
                src = norm_reg(ops[1])
                val[dst] = val.get(src, "?") if src in val else "?"
                if src in raw:
                    raw[dst] = raw[src]
        elif mn.startswith("ldr") and len(ops) >= 2 and ops[1].startswith("[") and t is None:
            src = norm_reg(ops[1].strip("[]").split(",")[0])
            v = val.get(src, "")
            val[dst] = v[1:] if v.startswith("&") else "?"
        elif mn == "xor" and len(ops) == 2 and ops[0] == ops[1]:
            val[dst] = "0"
        elif mn not in ("cmp", "test", "push", "call", "bl") and dst in val:
            val[dst] = "?"

    def _cstr(self, addr, limit=1024):
        raw = self.read(addr, limit)
        z = raw.find(b"\0")
        return raw[:z if z >= 0 else len(raw)].decode("latin-1")

    def _varargs(self, val, fi, name):
        """Variadic arguments of a printf/scanf-family call from its literal format string, placed per ABI:
        SysV/AArch64-Linux ints in the next GPRs and doubles in xmm/v regs, Win64 by position (rcx,rdx,r8,r9),
        Apple arm64 always on the stack. Returns (kinds, rendered args) or None if the format isn't literal."""
        regs = ARGREGS[self.cc]
        fa = val.get("@raw", {}).get(regs[fi]) if fi < len(regs) else None
        if fa is None:
            return None
        kinds = fmt_args(self._cstr(fa), scan="scanf" in name.split()[-1])
        out, gi, fpi, stack = [], fi + 1, 0, (0x20 if self.cc == "win" else 0)   # Win64: shadow space
        apple64 = self.a64 and self.fmt == "Mach-O"
        for kd in kinds:
            if apple64:
                loc = None
            elif self.cc == "win":
                loc = regs[gi] if gi < 4 else None
                gi += 1
            elif kd == "f":
                loc = (f"xmm{fpi}" if not self.a64 else f"d{fpi}") if fpi < 8 else None
                fpi += 1
            else:
                loc = regs[gi] if gi < len(regs) else None
                gi += 1
            if loc is None:
                out.append(f"<stack+{stack:#x}>")
                stack += 8
            else:
                v = val.get(loc, "?") if kd == "i" else "?"
                out.append(v if v != "?" else f"<{REG64.get(loc, loc)}>")
        return kinds, out

    def dossier(self, f):
        ins = self._fn_insns(f)
        targets, loops, conds, tails = self._shape(f, ins)
        regs = ARGREGS[self.cc]
        val, calls, strs, consts, cmps = {}, [], [], [], []
        varcalls = []
        last_cmp = None
        offs, k64 = {}, {}
        for a, sz, mn, op, t, k in ins:
            if a in targets:
                val.clear()
            if k in ("call", "icall"):
                name = self.call_name(t, k)
                fi = fmt_func(name)
                va = self._varargs(val, fi, name) if fi is not None else None
                if va is not None:
                    args = [val.get(r, "?") for r in regs[:fi + 1]] + va[1]
                    varcalls.append((a, name, fi + 1, va[0]))
                else:
                    args = [val.get(r, "?") for r in regs]
                    while args and args[-1] == "?":
                        args.pop()
                calls.append((a, name, args))
                val.clear()
                continue
            if t is not None and k in ("ref", "load"):
                d = self.describe(t)
                if d and (d.startswith('"') or d.startswith('ptr→"')):
                    strs.append((a, d))
            if mn in ("cmp", "test", "cmn", "tst"):
                iv = _imms(op) if ", " in op else []
                last_cmp = (a, op, iv[-1] if iv else None)
            elif last_cmp and k == "jmp" and mn not in ("jmp", "b"):
                if last_cmp[2] is not None:
                    rt = range_text(offs, last_cmp[1], mn)
                    cmps.append((last_cmp[0], last_cmp[1] + (f"  [{rt}]" if rt else ""), mn))
                last_cmp = None
            if mn not in ("cmp", "test", "cmn", "tst") and k != "jmp":
                note_offset(offs, mn, op)
            vals = _imms(op)
            if self.a64 and mn in ("mov", "movz", "movk", "movn") and vals:
                r = norm_reg(op.split(",")[0])
                sh = re.search(r"lsl #(\d+)", op)
                sh = int(sh.group(1)) if sh else 0
                if mn == "movk":
                    cur = (k64.get(r, 0) & ~(0xFFFF << sh)) | ((vals[0] & 0xFFFF) << sh)
                else:
                    cur = vals[0] << sh
                k64[r] = cur
                vals = [cur]
            for v in vals:
                tg = tag_const(v) or (ascii_tag(v) if (self.a64 and mn == "movk") or mn in ("cmp", "mov", "movabs") and v > 0xFFFF else None)
                if tg:
                    consts.append((a, v, tg))
            self._track(val, a, mn, op, t, k)
        return dict(ins=ins, nblocks=1 + len(targets), loops=loops, conds=conds, tails=tails,
                    calls=calls, strs=strs, consts=consts, cmps=cmps, varcalls=varcalls)

    # ----------------------------------------------------------------- views
    def overview(self):
        named = sum(1 for f in self.fn_starts if f in self.names)
        if self.fmt == "ELF":
            stripped = self.stripped
        else:
            stripped = named < len(self.fn_starts) // 2
        L = [f"native {self.fmt} {self.arch}{' PIE' if self.is_pie else ''}"
             f"{' stripped' if stripped else ''} · {self.size/1024:.1f} KB"]
        main = next((f for f, n in self.names.items() if n == "main"), None)
        if self.entry and self.is_code(self.entry):
            L.append(f"entry {self.fname(self.entry)}" + (f" → main {self.fname(main)}" if main else ""))
        else:
            L.append("no entry point (shared library) · exports " + str(len(self.exports)))
        ex = [f"{s[2]} {s[0]:#x}+{s[1]:#x}" for s in self.sections if s[4] and s[1]]
        L.append("code: " + ", ".join(ex[:6]))
        L.append(f"functions {len(self.fn_starts)} (named {named}) · strings {len(self.strings)} · "
                 f"imports {len(self.imports)}: " + clip(" ".join(self.imports), 300))
        tables = []
        for va, size, name, content, exe in self.sections:
            if content and not exe:
                tables += scan_tables(content, va)
        if tables:
            L.append("signatures: " + ", ".join(f"{n} @{a:#x}" for a, n in tables[:8]))
        try:
            if self.fmt == "ELF":
                cm = next((s for s in self.sections if s[2] == ".comment"), None)
                if cm and cm[3]:
                    L.append("build: " + clip(bytes(cm[3]).replace(b"\0", b" ").decode("latin1").strip(), 120))
        except Exception:
            pass
        big = sorted(self.fn_starts, key=lambda f: -self.fn_size.get(f, 0))[:5]
        L.append("largest: " + ", ".join(f"{self.fname(f)}({self.fn_size[f]})" for f in big))
        return L

    def list(self, what="functions", filt=""):
        what = (what or "functions").lower()
        rx = re.compile(filt, re.I) if filt else None
        out = []
        if what.startswith("func"):
            for f in self.fn_starts:
                nm = self.fname(f)
                if rx and not rx.search(nm):
                    continue
                out.append(f"{nm}  size={self.fn_size.get(f, 0)} callers={self.callers.count(f)} calls={self.callees.count(f)}")
        elif what.startswith("imp"):
            out = [f"{n}  callers={self.callers.count(('imp', n))}" for n in self.imports if not rx or rx.search(n)]
        elif what.startswith("str"):
            out = [f"s:{a:x} \"{clip(t, 120)}\"" for a, t in sorted(self.strings.items()) if not rx or rx.search(t)]
        elif what.startswith("sec"):
            out = [f"{s[2]} {s[0]:#x} size={s[1]:#x}{' exec' if s[4] else ''}" for s in self.sections]
        elif what.startswith("exp"):
            try:
                out = [f"{nm} {ad:#x}" for nm, ad in self.exports]
            except Exception:
                out = []
        else:
            raise KeyError("list what: functions|imports|strings|sections|exports")
        return out

    def find(self, query, kind="any", regex=False):
        rx = re.compile(query if regex else re.escape(query), re.I)
        out = []
        if kind in ("any", "string"):
            for a, t in sorted(self.strings.items()):
                if rx.search(t):
                    users = sorted({self.func_of(s) for s, k in self.refs.get(a, ()) if self.func_of(s)})
                    if not users and a in self.strings:
                        for slot, v in self.ptr_vals.items():
                            if v == a:
                                users = sorted({self.func_of(s) for s, k in self.refs.get(slot, ()) if self.func_of(s)})
                    u = ", ".join(self.fname(x) for x in users[:4]) or "no direct code ref"
                    out.append(f"s:{a:x} \"{clip(t, 90)}\" ← {u}")
        if kind in ("any", "symbol", "function"):
            for f in self.fn_starts:
                nm = self.names.get(f)
                if nm and rx.search(nm):
                    out.append(f"{self.fname(f)} size={self.fn_size.get(f, 0)}")
        if kind in ("any", "import"):
            for n in self.imports:
                if rx.search(n):
                    cs = sorted(self.callers.get(("imp", n), ()))
                    out.append(f"import {n} ← " + (", ".join(self.fname(x) for x in cs[:6]) or "no direct calls"))
        if kind in ("const", "any") and re.fullmatch(r"(0x)?[0-9a-fA-F]{2,16}", query):
            v = int(query, 16)
            for f in self.fn_starts:
                for a, sz, mn, op, t, k in self._fn_insns(f):
                    if v in [x & 0xFFFFFFFFFFFFFFFF for x in _imms(op)]:
                        out.append(f"a:{a:x} {mn} {op}  in {self.fname(f)}")
        return out

    def show(self, ident, view="auto"):
        a = self.parse_id(ident)
        if a in self.strings or (self.string_at(a) and not self.is_code(a)):
            return self.xrefs(f"s:{a:x}")
        f = self.func_of(a)
        if f is None:
            raise KeyError(f"{a:#x} is not inside a known function")
        if view in ("auto", "summary"):
            return self._summary(f)
        if view.split(":")[0] in ("decomp", "c", "pseudo", "decompile"):
            return self._decomp(f, view.split(":", 1)[1] if ":" in view else None)
        return self._asm(f)

    def _decomp(self, f, prefer=None):
        from . import cache, decomp
        order = decomp.backends(prefer)
        if not order:
            want = prefer or os.environ.get("LRE_DECOMP_BACKEND") or "auto"
            return [f"no decompiler backend available ({want}): pip install 'lean-re[decomp]' for angr, or set "
                    "GHIDRA_INSTALL_DIR + JDK 21 + pip install pyghidra for Ghidra. view=summary / view=asm still work."]
        notes, hit, used = [], None, None
        huge = self.fn_size.get(f, 0) > int(os.environ.get("LRE_HUGE_FN", 65536))
        if huge and prefer in (None, "auto") and len(order) > 1 and order[0] == "ghidra":
            order = ["ghidra"]      # angr needs ~1 min and >600 MB here; Ghidra is the right tool, wait for it
            notes.append(f"function is {self.fn_size[f] // 1024} KB: using Ghidra only (angr would take minutes)")
        elif huge and order == ["angr"]:
            notes.append(f"function is {self.fn_size[f] // 1024} KB: angr may need minutes and >600 MB "
                         "(LRE_DECOMP_TIMEOUT / LRE_DECOMP_MEM_MB); Ghidra handles this much better")
        for b in order:
            ck = f"{self.cache_key}-dec3-{b}-{f:x}" if getattr(self, "cache_key", None) else None
            hit = cache.load(ck) if ck else None
            if hit is None:
                hit = self._decomp_live(b, f, fallback=b != order[-1], huge=huge)
                if isinstance(hit, str):
                    notes.append(f"{b}: {hit}")
                    hit = None
                    continue
                if ck:
                    cache.save(ck, hit)
            used = b
            break
        if hit is None:
            return [f"decompile failed for {self.fname(f)}: " + " | ".join(notes) + "; use view=asm"]
        text, delta = hit
        head = (f"// {self.fname(f)}  pseudo-C ({used}; names/consts mapped to lean-re ids; verify against view=asm)")
        lines = [head] + [f"// note: {n}" for n in notes]
        return lines + postprocess_c2(postprocess_c(text, self, delta), delta)

    def _decomp_live(self, backend, f, fallback=False, huge=False):
        """Run one backend; returns (text, delta) or an error string."""
        from . import decomp
        size = self.fn_size.get(f, 0)
        # tail jumps leave the local region; tell angr those targets are functions
        tails = sorted({t for _a, _s, _m, _o, t, k in self.dossier(f)["ins"]
                        if k == "jmp" and t and not f <= t < f + size})
        # auto mode: never make the agent wait on Ghidra's first-open analysis; angr answers meanwhile
        wait = float(os.environ.get("LRE_GHIDRA_AUTO_WAIT", "5")) if backend == "ghidra" and fallback else None
        if backend == "angr" and huge:
            wait = max(float(os.environ.get("LRE_DECOMP_TIMEOUT", "60")), size / 2000)
        elif backend == "ghidra" and huge:
            wait = max(float(os.environ.get("LRE_GHIDRA_WAIT", "300")), size / 1000 + 90)
        st, text, delta = decomp.run(backend, self.path, f, size, [(t, self.fn_size.get(t, 16)) for t in tails[:8]],
                                     self._arity_hints(f), key=getattr(self, "cache_key", None), timeout=wait,
                                     base=self.imagebase)
        if backend == "ghidra" and huge:
            # a 300 KB function leaves the JVM heap and the native decompiler near 1 GB; recycle the worker so
            # the next request starts from the baseline (reopening the analysed project takes ~2 s)
            decomp.shutdown("ghidra")
        if st != "ok" or not text.strip():
            return text or "empty output"
        if backend == "angr":
            imp = [self.call_name(t, "jmp") for t in tails if t not in self.fn_size]
            for nm in imp:   # angr renders a tail jump to an unknown import as a no-return call
                text = re.sub(rf"^(\s*){re.escape(nm)}(\(.*\)); /\* do not return \*/$",
                              rf"\1return {nm}\2;  /* tail call */", text, flags=re.M)
            if imp:
                text = (f"// tail-jumps to import {', '.join(imp)}: no prototype known; argument count "
                        f"inferred from register setup, check view=asm\n") + text
        else:
            text = re.sub(r"\n{3,}", "\n\n", text).strip("\n") + "\n"
        return text, delta

    def _arity_hints(self, f):
        """Import name -> argument count seen at call sites (and before tail jumps), for the decompiler."""
        regs, d, out = ARGREGS[self.cc], self.dossier(f), {}
        for _a, nm, args in d["calls"]:
            if nm and not nm.startswith(("f:", "*", "?")):
                out[nm] = max(out.get(nm, 0), len(args))
        ins = d["ins"]
        for i, (_a, _s, mn, op, t, k) in enumerate(ins):
            if k == "jmp" and mn in ("jmp", "b") and t and t not in self.fn_size:
                written = set()
                for _a2, _s2, mn2, op2, _t2, k2 in reversed(ins[max(0, i - 12):i]):
                    if k2 in ("call", "jmp"):
                        break
                    if op2 and mn2 not in ("cmp", "test", "cmn", "tst", "push", "str", "stp"):
                        written.add(norm_reg(op2.split(",")[0]))
                n = max((j + 1 for j, r in enumerate(regs) if r in written), default=0)
                nm = self.call_name(t, "jmp")
                if n and nm:
                    out[nm] = max(out.get(nm, 0), n)
                    # registers below n that this function never touches are its own pass-through params
                    own = max((j + 1 for j, r in enumerate(regs[:n]) if r not in written), default=0)
                    if own and len(ins) <= 16:
                        out["@self"] = max(out.get("@self", 0), own)
        return out

    def _ptr_hint(self, f):
        tbl = [l for l in self.xrefs(f"f:{f:x}")[1:] if l.startswith("stored as pointer")]
        return ("none direct; " + tbl[0]) if tbl else "none found (maybe called indirectly)"

    def _summary(self, f):
        d = self.dossier(f)
        cs = sorted(self.callers.get(f, ()))
        L = [f"{self.fname(f)}  size={self.fn_size.get(f, 0)} insns={len(d['ins'])} blocks={d['nblocks']} "
             f"cond-branches={d['conds']} loops={len(d['loops'])}",
             "callers: " + (", ".join(self.fname(x) for x in cs[:8]) or self._ptr_hint(f))]
        if d["calls"]:
            L.append("calls:")
            for a, nm, args in d["calls"]:
                L.append(f"  {a:x} {nm}(" + ", ".join(clip(x, 60) for x in args) + ")")
        if d["strs"]:
            L.append("strings: " + " · ".join(f"{s}@{a:x}" for a, s in d["strs"][:12]))
        if d["cmps"]:
            def _c(op):
                iv = _imms(op.split(", ", 1)[-1])
                t = (tag_const(iv[0]) or ascii_tag(iv[0])) if iv else None
                return op + (f" ({t})" if t else "")
            L.append("compares→branch: " + " · ".join(f"{a:x} {_c(op)} →{j}" for a, op, j in d["cmps"][:16]))
        if d["consts"]:
            seen = {}
            for a, v, tg in d["consts"]:
                seen.setdefault((v & 0xFFFFFFFFFFFFFFFF, tg), a)
            L.append("known constants: " + " · ".join(f"{v:#x} {tg} @{a:x}" for (v, tg), a in seen.items()))
        if d["loops"]:
            L.append("loop heads: " + ", ".join(f"{x:x}" for x in d["loops"]))
        if d["tails"]:
            L.append("tail-jumps: " + ", ".join(self.call_name(t) for t in d["tails"][:6]))
        ind = sum(1 for x in d["ins"] if x[5] in ("icall",) and x[4] not in self.ptr_names) + \
            sum(1 for x in d["ins"] if x[2] in ("call", "blr") and x[4] is None and x[5] is None)
        if ind:
            L.append(f"unknowns: {ind} indirect call(s) not resolved statically")
        L.append(f"(view=asm for annotated disassembly of {len(d['ins'])} insns)")
        return L

    def _asm(self, f):
        ins = self._fn_insns(f)
        targets, loops, conds, tails = self._shape(f, ins)
        L = [f"{self.fname(f)}  ({len(ins)} insns)"]
        for a, sz, mn, op, t, k in ins:
            if a in targets and a != f:
                L.append(f".L{a:x}:{'  ; loop head' if a in loops else ''}")
            note = ""
            if t is not None:
                if k in ("call", "icall"):
                    op = self.call_name(t, k)
                elif k == "jmp":
                    op = (f".L{t:x}" if t in targets else self.call_name(t)) + (" ; ↑loop" if t <= a and t >= f else "")
                else:
                    d = self.describe(t)
                    if d:
                        note = d
            if not note:
                tags = [tag_const(v) or (ascii_tag(v) if mn in ("cmp", "mov", "movz", "movk") else None) for v in _imms(op)]
                tags = [x for x in tags if x]
                if tags:
                    note = tags[0]
            L.append(f"  {a:x}  {mn} {op}" + (f"  ; {note}" if note else ""))
        return L

    def xrefs(self, ident, direction="to"):
        a = self.parse_id(ident)
        out = []
        if direction == "from":
            f = self.func_of(a) or a
            for k in sorted(self.callees.get(f, ()), key=str):
                out.append("→ " + (self.fname(k) if isinstance(k, int) else (k[1] if k[0] == "imp" else f"[{k[1]:#x}]")))
            d = self.dossier(f)
            for at, s in d["strs"]:
                out.append(f"→ {s} @{at:x}")
            return out
        key = ("imp", self.stub[a]) if a in self.stub else a
        if isinstance(key, tuple) or a in self.callers:
            for c in sorted(self.callers.get(key, ())):
                sites = self.graph.sites(key, c)
                out.append(f"called by {self.fname(c)} at " + ", ".join(f"{s:x}" for s in sites[:6]))
        slots = [a] + [s for s, v in self.ptr_vals.items() if v == a]
        for slot in slots:
            for s, k in self.refs.get(slot, ()):
                if k in ("call",):
                    continue
                out.append(f"{k} at a:{s:x} in {self.fname(self.func_of(s)) if self.func_of(s) else '?'}"
                           + (" (via pointer table)" if slot != a else ""))
        for slot, v in sorted(self.ptr_vals.items()):
            if v != a:
                continue
            sec = self.sec_of(slot)
            ctx = []
            for nb in (slot - 8, slot + 8, slot - 16):
                dd = self.describe(nb) if nb in self.ptr_vals else None
                if dd and dd.startswith('ptr→"'):
                    ctx.append(dd[4:])
                    break
            out.append(f"stored as pointer at {slot:#x} ({sec[2] if sec else '?'})"
                       + (f" next to {ctx[0]} (likely a registration/dispatch table)" if ctx else ""))
        d = self.describe(a)
        return [f"xrefs to {d or hex(a)}: {len(out)}"] + out


R_LEA_SUB = re.compile(r"(\w+), \[(\w+) - (0x[0-9a-f]+|[0-9]+)\]")
R_A64_SUB = re.compile(r"(\w+), (\w+), #(0x[0-9a-f]+|[0-9]+)")
UNSIGNED_GT = ("ja", "b.hi")
UNSIGNED_LE = ("jbe", "b.ls")


def note_offset(offs, mn, op):
    """Remember `R = S - K` (lea/sub) so a following cmp R,N; ja is read as a range check."""
    m = R_LEA_SUB.fullmatch(op) if mn == "lea" else (R_A64_SUB.fullmatch(op) if mn == "sub" else None)
    if m:
        offs[norm_reg(m.group(1))] = (m.group(2), int(m.group(3), 0))
    elif op:
        offs.pop(norm_reg(op.split(",")[0]), None)


def range_text(offs, cmp_op, jmn):
    parts = cmp_op.split(", ")
    if len(parts) != 2 or jmn not in UNSIGNED_GT + UNSIGNED_LE:
        return None
    iv = _imms(cmp_op)
    if not iv:
        return None
    n = iv[-1]
    r = norm_reg(parts[0])
    src, k = offs.get(r, (parts[0], 0))
    rng = f"{src} ∈ [{k:#x}, {k + n:#x}]"
    return f"range check {rng}" + (" else reject-branch" if jmn in UNSIGNED_GT else " → branch")



R_SUB = re.compile(r"\b(?:sub|FUN)_([0-9a-fA-F]+)\b")        # angr / Ghidra
R_HEX = re.compile(r"\b0x([0-9a-f]{4,16})\b")


def _rename(native, delta):
    def fn(m):
        a = int(m.group(1), 16) - delta
        nm = native.names.get(a) or native.stub.get(a)
        return nm if nm else f"f_{a:x}"
    return fn


def _hexnote(m):
    v = int(m.group(1), 16)
    before = m.string[max(0, m.start() - 8):m.start()]
    valuey = before.rstrip().endswith(("return", "==", "!=", "=", "(", ","))
    if valuey and 0xFFFFFF00 <= v <= 0xFFFFFFFF:
        return f"{m.group(0)} /* {v - (1 << 32)} */"
    if valuey and 0xFFFFFFFFFFFFFF00 <= v:
        return f"{m.group(0)} /* {v - (1 << 64)} */"
    tg = tag_const(v) or ascii_tag(v)
    return f"{m.group(0)} /* {tg} */" if tg else m.group(0)


def postprocess_c(text, native, delta):
    text = R_SUB.sub(_rename(native, delta), text)
    text = R_HEX.sub(_hexnote, text)
    return [ln for ln in text.rstrip().split("\n")]


R_DEC = re.compile(r"(?<![\w.])(-?\d{6,20})(?![\w.])")
R_LABEL = re.compile(r"\b(?:LABEL_0x|LAB_)([0-9a-fA-F]+)\b")
R_DAT = re.compile(r"\b(DAT|PTR_\w+?)_([0-9a-fA-F]{6,16})\b")


def _decnote(m):
    v = int(m.group(1))
    for u in (v & 0xFFFFFFFF, v & 0xFFFFFFFFFFFFFFFF, -v & 0xFFFFFFFF):
        tg = tag_const(u) or (ascii_tag(u) if u <= 0xFFFFFFFF else None)
        if tg:
            return f"{m.group(1)} /* {u:#x} {tg} */"
    return m.group(1)


def postprocess_c2(lines, delta):
    out = []
    for ln in lines:
        ln = R_LABEL.sub(lambda m: f"L_{int(m.group(1), 16) - delta:x}", ln)
        ln = R_DAT.sub(lambda m: f"{m.group(1)}_{int(m.group(2), 16) - delta:x}", ln)
        if "//" not in ln.split("/*")[0]:
            ln = R_DEC.sub(_decnote, ln)
        out.append(ln)
    return out
