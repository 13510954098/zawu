import 'dart:io';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

enum ShaderSuperResMode {
  off('关闭超分 (原生)', []),
  performance(
    '性能优先 (推荐)',
    ['anime_clamp_highlights.glsl', 'anime_restore_lite.glsl'],
  ),
  quality(
    '画质优先 (2x 超分)',
    [
      'anime_clamp_highlights.glsl',
      'anime_restore_lite.glsl',
      'anime_upscale_x2.glsl',
    ],
  );

  final String label;
  final List<String> shaderAssets;
  const ShaderSuperResMode(this.label, this.shaderAssets);
}

/// Hardened MPV controller wrapping `media_kit`.
///
/// Security fix over audited APK:
/// - Restricts FFmpeg `protocol_whitelist` to `https,http,tls,tcp,httpproxy` for
///   network streams (never exposes `file` or `allowed_extensions=ALL` to remote M3U8s).
/// - Supports hot-swappable MIT GLSL shaders and Android native PiP (`floating`).
class AnimeMpvController {
  static const MethodChannel _pipChannel = MethodChannel('floating');

  late final Player player;
  late final VideoController videoController;
  ShaderSuperResMode currentShaderMode = ShaderSuperResMode.off;

  AnimeMpvController() {
    player = Player(
      configuration: const PlayerConfiguration(
        title: 'Lanerc Cleanroom Player',
      ),
    );
    videoController = VideoController(player);
    _applySafeDemuxerOptions();
  }

  Future<void> _applySafeDemuxerOptions() async {
    final native = player.platform;
    if (native is NativePlayer) {
      await native.setProperty(
        'demuxer-lavf-o',
        'seg_max_retry=5,protocol_whitelist=[https,http,tls,tcp]',
      );
      await native.setProperty(
        'stream-lavf-o',
        'reconnect=1,reconnect_streamed=1,reconnect_delay_max=5',
      );
    }
  }

  Future<void> openNetworkStream(String url, {Map<String, String>? headers}) async {
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) {
      throw ArgumentError('Unsupported network stream scheme: $url');
    }
    await player.open(Media(url, httpHeaders: headers));
  }

  Future<void> openLocalCachedFile(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw FileSystemException('Cached video file missing', filePath);
    }
    await player.open(Media(file.uri.toString()));
  }

  Future<void> applyShaderMode(ShaderSuperResMode mode) async {
    currentShaderMode = mode;
    final native = player.platform;
    if (native is! NativePlayer) return;

    if (mode == ShaderSuperResMode.off || mode.shaderAssets.isEmpty) {
      await native.setProperty('glsl-shaders', '');
      return;
    }

    final supportDir = await getApplicationSupportDirectory();
    final shaderDir = Directory(p.join(supportDir.path, 'anime_shaders'));
    if (!await shaderDir.exists()) {
      await shaderDir.create(recursive: true);
    }

    final resolvedPaths = <String>[];
    for (final name in mode.shaderAssets) {
      final outFile = File(p.join(shaderDir.path, name));
      if (!await outFile.exists()) {
        final data = await rootBundle.load('assets/shaders/$name');
        await outFile.writeAsBytes(data.buffer.asUint8List(), flush: true);
      }
      resolvedPaths.add(outFile.path);
    }
    final separator = Platform.isWindows ? ';' : ':';
    await native.setProperty('glsl-shaders', resolvedPaths.join(separator));
  }

  Future<bool> enterPictureInPicture() async {
    if (!Platform.isAndroid) return false;
    try {
      final ok = await _pipChannel.invokeMethod<bool>(
        'enterPip',
        const {'width': 16, 'height': 9},
      );
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> dispose() async {
    await player.dispose();
  }
}
