class HtmlEntityUnescaper {
  static String unescape(String input) {
    if (input.isEmpty || !input.contains('&')) return input;
    return input
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&#39;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&amp;', '&')
        .replaceAll('&nbsp;', ' ');
  }
}

class DynamicSourceManifest {
  final String id;
  final String name;
  final String? staticBaseUrl;
  final List<String> dohServers;
  final List<String> dohTxtDomains;
  final List<String> fallbackConfigUrls;
  final bool useBuiltInDemo;

  const DynamicSourceManifest({
    required this.id,
    required this.name,
    this.staticBaseUrl,
    this.dohServers = const [
      'https://doh.pub/resolve',
      'https://dns.alidns.com/resolve',
      'https://dns.google/resolve',
    ],
    this.dohTxtDomains = const [],
    this.fallbackConfigUrls = const [],
    this.useBuiltInDemo = false,
  });

  factory DynamicSourceManifest.builtInDemo() => const DynamicSourceManifest(
        id: 'builtin_open_demo',
        name: '内置开源演示源 (Blender Open Movies)',
        useBuiltInDemo: true,
      );

  factory DynamicSourceManifest.fromJson(Map<String, dynamic> json) {
    return DynamicSourceManifest(
      id: (json['id'] ?? 'custom_source').toString(),
      name: (json['name'] ?? '自定义动态源').toString(),
      staticBaseUrl: json['staticBaseUrl']?.toString(),
      dohServers: (json['dohServers'] as List?)?.map((e) => e.toString()).toList() ??
          const [
            'https://doh.pub/resolve',
            'https://dns.alidns.com/resolve',
            'https://dns.google/resolve',
          ],
      dohTxtDomains:
          (json['dohTxtDomains'] as List?)?.map((e) => e.toString()).toList() ?? const [],
      fallbackConfigUrls:
          (json['fallbackConfigUrls'] as List?)?.map((e) => e.toString()).toList() ?? const [],
      useBuiltInDemo: json['useBuiltInDemo'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'staticBaseUrl': staticBaseUrl,
        'dohServers': dohServers,
        'dohTxtDomains': dohTxtDomains,
        'fallbackConfigUrls': fallbackConfigUrls,
        'useBuiltInDemo': useBuiltInDemo,
      };
}

class AppConfigModel {
  final String noticeTitle;
  final String noticeBody;
  final String latestVersion;
  final int latestVersionCode;
  final String? updateApkUrl;
  final String? updateSha256;

  const AppConfigModel({
    required this.noticeTitle,
    required this.noticeBody,
    required this.latestVersion,
    required this.latestVersionCode,
    this.updateApkUrl,
    this.updateSha256,
  });

  factory AppConfigModel.fromJson(Map<String, dynamic> json) {
    return AppConfigModel(
      noticeTitle: (json['noticeTitle'] ?? '系统公告').toString(),
      noticeBody: HtmlEntityUnescaper.unescape((json['noticeBody'] ?? '').toString()),
      latestVersion: (json['latestVersion'] ?? '1.0.8').toString(),
      latestVersionCode: int.tryParse('${json['latestVersionCode'] ?? 32}') ?? 32,
      updateApkUrl: json['updateApkUrl']?.toString(),
      updateSha256: json['updateSha256']?.toString(),
    );
  }
}

class VodItem {
  final int vodId;
  final String vodName;
  final String pic;
  final String remarks;
  final String category;
  final List<String> genres;
  final int year;
  final double score;
  final String director;
  final String summary;
  final int weekday;

  const VodItem({
    required this.vodId,
    required this.vodName,
    required this.pic,
    required this.remarks,
    required this.category,
    required this.genres,
    required this.year,
    required this.score,
    required this.director,
    required this.summary,
    this.weekday = 1,
  });

  factory VodItem.fromJson(Map<String, dynamic> json) {
    return VodItem(
      vodId: int.tryParse('${json['vodId'] ?? json['vod_id'] ?? 0}') ?? 0,
      vodName: HtmlEntityUnescaper.unescape((json['vodName'] ?? json['vod_name'] ?? '').toString()),
      pic: (json['pic'] ?? json['vod_pic'] ?? '').toString(),
      remarks: (json['remarks'] ?? json['vod_remarks'] ?? '').toString(),
      category: (json['category'] ?? '日漫').toString(),
      genres: (json['genres'] as List?)?.map((e) => e.toString()).toList() ?? const ['奇幻'],
      year: int.tryParse('${json['year'] ?? 2026}') ?? 2026,
      score: double.tryParse('${json['score'] ?? 9.0}') ?? 9.0,
      director: HtmlEntityUnescaper.unescape((json['director'] ?? '未知').toString()),
      summary: HtmlEntityUnescaper.unescape((json['summary'] ?? '').toString()),
      weekday: int.tryParse('${json['weekday'] ?? 1}') ?? 1,
    );
  }

  Map<String, dynamic> toJson() => {
        'vodId': vodId,
        'vodName': vodName,
        'pic': pic,
        'remarks': remarks,
        'category': category,
        'genres': genres,
        'year': year,
        'score': score,
        'director': director,
        'summary': summary,
        'weekday': weekday,
      };
}

class VodEpisode {
  final int index;
  final String title;
  final String resourceId;

  const VodEpisode({
    required this.index,
    required this.title,
    required this.resourceId,
  });

  factory VodEpisode.fromJson(Map<String, dynamic> json) => VodEpisode(
        index: int.tryParse('${json['index'] ?? 1}') ?? 1,
        title: (json['title'] ?? '01').toString(),
        resourceId: (json['resourceId'] ?? '').toString(),
      );
}

class VodPlayLine {
  final String lineId;
  final String lineName;
  final List<VodEpisode> episodes;

  const VodPlayLine({
    required this.lineId,
    required this.lineName,
    required this.episodes,
  });

  factory VodPlayLine.fromJson(Map<String, dynamic> json) => VodPlayLine(
        lineId: (json['lineId'] ?? 'default').toString(),
        lineName: (json['lineName'] ?? '主线路').toString(),
        episodes: (json['episodes'] as List?)
                ?.map((e) => VodEpisode.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
      );
}

class VodDetail {
  final VodItem item;
  final List<VodPlayLine> playLines;
  final List<VodItem> recommendations;

  const VodDetail({
    required this.item,
    required this.playLines,
    required this.recommendations,
  });

  factory VodDetail.fromJson(Map<String, dynamic> json) => VodDetail(
        item: VodItem.fromJson(Map<String, dynamic>.from(json['item'] as Map)),
        playLines: (json['playLines'] as List?)
                ?.map((e) => VodPlayLine.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
        recommendations: (json['recommendations'] as List?)
                ?.map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
      );
}

class StreamResolveResult {
  final String url;
  final Map<String, String> headers;
  final String format;

  const StreamResolveResult({
    required this.url,
    this.headers = const {},
    this.format = 'mp4',
  });

  factory StreamResolveResult.fromJson(Map<String, dynamic> json) => StreamResolveResult(
        url: (json['url'] ?? '').toString(),
        headers: (json['headers'] as Map?)
                ?.map((k, v) => MapEntry(k.toString(), v.toString())) ??
            const {},
        format: (json['format'] ?? 'mp4').toString(),
      );
}

class BarrageItem {
  final String id;
  final double timeSeconds;
  final String content;
  final int colorHex;
  final bool isTop;

  const BarrageItem({
    required this.id,
    required this.timeSeconds,
    required this.content,
    this.colorHex = 0xFFFFFFFF,
    this.isTop = false,
  });

  factory BarrageItem.fromJson(Map<String, dynamic> json) => BarrageItem(
        id: (json['id'] ?? '').toString(),
        timeSeconds: double.tryParse('${json['timeSeconds'] ?? json['time'] ?? 0}') ?? 0,
        content: HtmlEntityUnescaper.unescape((json['content'] ?? '').toString()),
        colorHex: int.tryParse('${json['colorHex'] ?? 0xFFFFFFFF}') ?? 0xFFFFFFFF,
        isTop: json['isTop'] == true,
      );
}

class CommentItem {
  final String id;
  final String userName;
  final String avatarUrl;
  final String content;
  final String createdAt;
  final int likes;
  final List<CommentItem> replies;

  const CommentItem({
    required this.id,
    required this.userName,
    required this.avatarUrl,
    required this.content,
    required this.createdAt,
    this.likes = 0,
    this.replies = const [],
  });

  factory CommentItem.fromJson(Map<String, dynamic> json) => CommentItem(
        id: (json['id'] ?? '').toString(),
        userName: (json['userName'] ?? '匿名追番人').toString(),
        avatarUrl: (json['avatarUrl'] ?? '').toString(),
        content: HtmlEntityUnescaper.unescape((json['content'] ?? '').toString()),
        createdAt: (json['createdAt'] ?? '刚刚').toString(),
        likes: int.tryParse('${json['likes'] ?? 0}') ?? 0,
        replies: (json['replies'] as List?)
                ?.map((e) => CommentItem.fromJson(Map<String, dynamic>.from(e as Map)))
                .toList() ??
            const [],
      );
}

class HistoryRecord {
  final int? id;
  final int vodID;
  final String vodName;
  final int vodClass;
  final int vodSelect;
  final String pic;
  final int seeTime;
  final int lastTime;

  const HistoryRecord({
    this.id,
    required this.vodID,
    required this.vodName,
    required this.vodClass,
    required this.vodSelect,
    required this.pic,
    required this.seeTime,
    required this.lastTime,
  });

  factory HistoryRecord.fromMap(Map<String, dynamic> map) => HistoryRecord(
        id: map['id'] as int?,
        vodID: (map['vodID'] as num).toInt(),
        vodName: map['vodName'] as String,
        vodClass: (map['vodClass'] as num).toInt(),
        vodSelect: (map['vodSelect'] as num).toInt(),
        pic: map['pic'] as String,
        seeTime: (map['seeTime'] as num).toInt(),
        lastTime: (map['lastTime'] as num).toInt(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'vodID': vodID,
        'vodName': vodName,
        'vodClass': vodClass,
        'vodSelect': vodSelect,
        'pic': pic,
        'seeTime': seeTime,
        'lastTime': lastTime,
      };
}

class DownloadRecord {
  final int? id;
  final String vid;
  final int vodID;
  final String vodName;
  final int vodClass;
  final int vodSelect;
  final String pic;
  final String player;
  final String downloadUrl;
  final String localPath;
  final int fileSize;
  final double progress;
  final String downloadedSpeed;
  final int status; // 0=queued, 1=downloading, 2=completed, 3=paused, 4=failed

  const DownloadRecord({
    this.id,
    required this.vid,
    required this.vodID,
    required this.vodName,
    required this.vodClass,
    required this.vodSelect,
    required this.pic,
    required this.player,
    required this.downloadUrl,
    required this.localPath,
    required this.fileSize,
    required this.progress,
    required this.downloadedSpeed,
    required this.status,
  });

  factory DownloadRecord.fromMap(Map<String, dynamic> map) => DownloadRecord(
        id: map['id'] as int?,
        vid: map['vid'] as String,
        vodID: (map['vodID'] as num).toInt(),
        vodName: map['vodName'] as String,
        vodClass: (map['vodClass'] as num).toInt(),
        vodSelect: (map['vodSelect'] as num).toInt(),
        pic: map['pic'] as String,
        player: map['player'] as String,
        downloadUrl: map['downloadUrl'] as String,
        localPath: map['localPath'] as String,
        fileSize: (map['fileSize'] as num).toInt(),
        progress: (map['progress'] as num).toDouble(),
        downloadedSpeed: map['downloadedSpeed'] as String,
        status: (map['status'] as num).toInt(),
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'vid': vid,
        'vodID': vodID,
        'vodName': vodName,
        'vodClass': vodClass,
        'vodSelect': vodSelect,
        'pic': pic,
        'player': player,
        'downloadUrl': downloadUrl,
        'localPath': localPath,
        'fileSize': fileSize,
        'progress': progress,
        'downloadedSpeed': downloadedSpeed,
        'status': status,
      };
}

class QuizQuestion {
  final int id;
  final String question;
  final List<String> options;
  final int answerIndex;

  const QuizQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.answerIndex,
  });
}

class UserProfile {
  final String userId;
  final String email;
  final String nickName;
  final String? qqNumber;
  final int coins;
  final int downloadQuota;
  final bool passedQuiz;
  final DateTime? adFreeUntil;

  const UserProfile({
    required this.userId,
    required this.email,
    required this.nickName,
    this.qqNumber,
    this.coins = 0,
    this.downloadQuota = 5,
    this.passedQuiz = false,
    this.adFreeUntil,
  });

  String? get avatarUrl => (qqNumber != null && qqNumber!.length >= 5)
      ? 'https://q1.qlogo.cn/g?b=qq&nk=$qqNumber&s=100'
      : null;

  UserProfile copyWith({
    String? nickName,
    String? qqNumber,
    int? coins,
    int? downloadQuota,
    bool? passedQuiz,
    DateTime? adFreeUntil,
  }) {
    return UserProfile(
      userId: userId,
      email: email,
      nickName: nickName ?? this.nickName,
      qqNumber: qqNumber ?? this.qqNumber,
      coins: coins ?? this.coins,
      downloadQuota: downloadQuota ?? this.downloadQuota,
      passedQuiz: passedQuiz ?? this.passedQuiz,
      adFreeUntil: adFreeUntil ?? this.adFreeUntil,
    );
  }

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'email': email,
        'nickName': nickName,
        'qqNumber': qqNumber,
        'coins': coins,
        'downloadQuota': downloadQuota,
        'passedQuiz': passedQuiz,
        'adFreeUntil': adFreeUntil?.toIso8601String(),
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        userId: (json['userId'] ?? '10001').toString(),
        email: (json['email'] ?? '').toString(),
        nickName: (json['nickName'] ?? '追番旅人').toString(),
        qqNumber: json['qqNumber']?.toString(),
        coins: int.tryParse('${json['coins'] ?? 0}') ?? 0,
        downloadQuota: int.tryParse('${json['downloadQuota'] ?? 5}') ?? 5,
        passedQuiz: json['passedQuiz'] == true,
        adFreeUntil: json['adFreeUntil'] != null
            ? DateTime.tryParse(json['adFreeUntil'].toString())
            : null,
      );
}
