import 'package:get/get.dart';
import '../models/vod_models.dart';
import '../storage/local_database.dart';

class UserController extends GetxController {
  final Rxn<UserProfile> profile = Rxn<UserProfile>();
  final RxInt coins = 0.obs;
  final RxInt downloadQuota = 5.obs;
  final RxBool passedQuiz = false.obs;
  final RxInt todayTaskCount = 0.obs;
  final RxList<VodItem> favorites = <VodItem>[].obs;

  bool get isLoggedIn => profile.value != null;

  String get displayName => profile.value?.nickName ?? '登录/注册';

  @override
  void onInit() {
    super.onInit();
    reloadFromStorage();
  }

  void reloadFromStorage() {
    final db = LocalDatabase.instance;
    final saved = db.loadUserProfile();
    profile.value = saved;
    coins.value = saved?.coins ?? db.localCoins;
    downloadQuota.value = saved?.downloadQuota ?? db.localDownloadQuota;
    passedQuiz.value = (saved?.passedQuiz ?? false) || db.hasPassedQuiz;
    todayTaskCount.value = db.todayCoinTaskCount;
    favorites.assignAll(db.getFavorites());
  }

  Future<void> setLoggedInProfile(UserProfile next) async {
    final merged = next.copyWith(
      coins: next.coins > coins.value ? next.coins : coins.value,
      downloadQuota: next.downloadQuota > downloadQuota.value
          ? next.downloadQuota
          : downloadQuota.value,
      passedQuiz: next.passedQuiz || passedQuiz.value,
    );
    profile.value = merged;
    coins.value = merged.coins;
    downloadQuota.value = merged.downloadQuota;
    passedQuiz.value = merged.passedQuiz;
    await LocalDatabase.instance.saveUserProfile(merged);
    await LocalDatabase.instance.setLocalCoins(coins.value);
    await LocalDatabase.instance.setLocalDownloadQuota(downloadQuota.value);
    await LocalDatabase.instance.setPassedQuiz(passedQuiz.value);
  }

  Future<void> updateProfileInfo({String? nickName, String? qqNumber}) async {
    final cur = profile.value;
    if (cur == null) return;
    final updated = cur.copyWith(nickName: nickName, qqNumber: qqNumber);
    profile.value = updated;
    await LocalDatabase.instance.saveUserProfile(updated);
  }

  Future<void> logout() async {
    profile.value = null;
    await LocalDatabase.instance.saveUserProfile(null);
  }

  Future<void> markQuizPassed() async {
    passedQuiz.value = true;
    await LocalDatabase.instance.setPassedQuiz(true);
    if (profile.value != null) {
      final updated = profile.value!.copyWith(passedQuiz: true);
      profile.value = updated;
      await LocalDatabase.instance.saveUserProfile(updated);
    }
  }

  Future<bool> claimDailyCoins({int reward = 30}) async {
    final db = LocalDatabase.instance;
    if (db.todayCoinTaskCount >= 3) return false;
    await db.incrementTodayCoinTask();
    todayTaskCount.value = db.todayCoinTaskCount;
    await _updateCoins(coins.value + reward);
    return true;
  }

  Future<void> claimDownloadQuota({int addQuota = 5}) async {
    downloadQuota.value += addQuota;
    await LocalDatabase.instance.setLocalDownloadQuota(downloadQuota.value);
    if (profile.value != null) {
      final updated = profile.value!.copyWith(downloadQuota: downloadQuota.value);
      profile.value = updated;
      await LocalDatabase.instance.saveUserProfile(updated);
    }
  }

  Future<bool> redeemPerk({required String title, required int cost}) async {
    if (coins.value < cost) return false;
    await _updateCoins(coins.value - cost);
    await LocalDatabase.instance.addRedemptionRecord(title, cost);
    if (title.contains('7天') && profile.value != null) {
      final updated = profile.value!
          .copyWith(adFreeUntil: DateTime.now().add(const Duration(days: 7)));
      profile.value = updated;
      await LocalDatabase.instance.saveUserProfile(updated);
    } else if (title.contains('30天') && profile.value != null) {
      final updated = profile.value!
          .copyWith(adFreeUntil: DateTime.now().add(const Duration(days: 30)));
      profile.value = updated;
      await LocalDatabase.instance.saveUserProfile(updated);
    }
    return true;
  }

  Future<void> _updateCoins(int nextCoins) async {
    coins.value = nextCoins;
    await LocalDatabase.instance.setLocalCoins(nextCoins);
    if (profile.value != null) {
      final updated = profile.value!.copyWith(coins: nextCoins);
      profile.value = updated;
      await LocalDatabase.instance.saveUserProfile(updated);
    }
  }

  bool isFavorite(int vodId) => favorites.any((e) => e.vodId == vodId);

  Future<bool> toggleFavorite(VodItem item) async {
    final added = await LocalDatabase.instance.toggleFavorite(item);
    favorites.assignAll(LocalDatabase.instance.getFavorites());
    return added;
  }

  Future<void> removeFavoriteIds(Set<int> ids) async {
    await LocalDatabase.instance.removeFavorites(ids);
    favorites.assignAll(LocalDatabase.instance.getFavorites());
  }
}
