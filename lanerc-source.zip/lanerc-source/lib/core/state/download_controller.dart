import 'package:dio/dio.dart';
import 'package:get/get.dart';
import '../models/vod_models.dart';
import '../network/api_service.dart';
import '../storage/local_database.dart';

/// Status values:
/// 0 = queued, 1 = downloading, 2 = completed, 3 = paused/failed
class DownloadController extends GetxController {
  final RxList<DownloadRecord> tasks = <DownloadRecord>[].obs;
  final Map<String, CancelToken> _cancelTokens = {};

  List<DownloadRecord> get activeTasks =>
      tasks.where((t) => t.status == 0 || t.status == 1 || t.status == 3).toList();

  List<DownloadRecord> get completedTasks =>
      tasks.where((t) => t.status == 2).toList();

  @override
  void onInit() {
    super.onInit();
    refreshTasks();
  }

  Future<void> refreshTasks() async {
    final list = await LocalDatabase.instance.getDownloads();
    tasks.assignAll(list);
  }

  Future<void> enqueueEpisode({
    required VodItem item,
    required VodPlayLine line,
    required VodEpisode episode,
  }) async {
    final vid = '${item.vodId}_${episode.index}';
    final existingIdx = tasks.indexWhere((e) => e.vid == vid);
    if (existingIdx >= 0 && tasks[existingIdx].status == 2) {
      return;
    }

    final api = Get.find<ApiService>();
    final resolved = await api.resolvePlayback(
      vodId: item.vodId,
      lineId: line.lineId,
      resourceId: episode.resourceId,
    );

    final record = DownloadRecord(
      vid: vid,
      vodID: item.vodId,
      vodName: '${item.vodName} 第${episode.title}集',
      vodClass: item.category == '剧场版' ? 2 : 1,
      vodSelect: episode.index,
      pic: item.pic,
      player: line.lineName,
      downloadUrl: resolved.url,
      localPath: '',
      fileSize: 0,
      progress: 0.0,
      downloadedSpeed: '准备中...',
      status: 1,
    );

    await LocalDatabase.instance.upsertDownload(record);
    await refreshTasks();
    _startDownload(record);
  }

  Future<void> _startDownload(DownloadRecord record) async {
    final token = CancelToken();
    _cancelTokens[record.vid] = token;
    try {
      final file = await LocalDatabase.instance.downloadEpisodeFile(
        record: record,
        cancelToken: token,
        onProgress: (ratio, speed) {
          final idx = tasks.indexWhere((e) => e.vid == record.vid);
          if (idx >= 0) {
            tasks[idx] = DownloadRecord(
              id: tasks[idx].id,
              vid: record.vid,
              vodID: record.vodID,
              vodName: record.vodName,
              vodClass: record.vodClass,
              vodSelect: record.vodSelect,
              pic: record.pic,
              player: record.player,
              downloadUrl: record.downloadUrl,
              localPath: tasks[idx].localPath,
              fileSize: tasks[idx].fileSize,
              progress: ratio.clamp(0.0, 1.0),
              downloadedSpeed: speed,
              status: 1,
            );
          }
        },
      );
      final bytes = await file.length();
      final done = DownloadRecord(
        vid: record.vid,
        vodID: record.vodID,
        vodName: record.vodName,
        vodClass: record.vodClass,
        vodSelect: record.vodSelect,
        pic: record.pic,
        player: record.player,
        downloadUrl: record.downloadUrl,
        localPath: file.path,
        fileSize: bytes,
        progress: 1.0,
        downloadedSpeed: '已完成',
        status: 2,
      );
      await LocalDatabase.instance.upsertDownload(done);
      await refreshTasks();
    } catch (_) {
      final failed = DownloadRecord(
        vid: record.vid,
        vodID: record.vodID,
        vodName: record.vodName,
        vodClass: record.vodClass,
        vodSelect: record.vodSelect,
        pic: record.pic,
        player: record.player,
        downloadUrl: record.downloadUrl,
        localPath: '',
        fileSize: 0,
        progress: 0.0,
        downloadedSpeed: '已暂停',
        status: 3,
      );
      await LocalDatabase.instance.upsertDownload(failed);
      await refreshTasks();
    } finally {
      _cancelTokens.remove(record.vid);
    }
  }

  Future<void> pauseOrRetry(DownloadRecord record) async {
    if (record.status == 1) {
      _cancelTokens[record.vid]?.cancel('paused');
    } else if (record.status == 3 || record.status == 0) {
      final resumed = DownloadRecord(
        vid: record.vid,
        vodID: record.vodID,
        vodName: record.vodName,
        vodClass: record.vodClass,
        vodSelect: record.vodSelect,
        pic: record.pic,
        player: record.player,
        downloadUrl: record.downloadUrl,
        localPath: record.localPath,
        fileSize: record.fileSize,
        progress: record.progress,
        downloadedSpeed: '重连中...',
        status: 1,
      );
      await LocalDatabase.instance.upsertDownload(resumed);
      await refreshTasks();
      _startDownload(resumed);
    }
  }

  Future<void> removeTask(String vid) async {
    _cancelTokens[vid]?.cancel('removed');
    _cancelTokens.remove(vid);
    await LocalDatabase.instance.removeDownload(vid);
    await refreshTasks();
  }
}
