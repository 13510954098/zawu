import 'dart:convert';
import 'dart:math';
import 'package:dio/dio.dart';
import '../models/vod_models.dart';

/// Open-standard Dynamic Source Bootstrap Resolver.
///
/// Supports:
/// 1. Explicit HTTPS static base URL;
/// 2. Random alphanumeric subdomain prefix + DNS-over-HTTPS (DoH) TXT resolution;
/// 3. HTTPS JSON fallback endpoint pool (cleartext HTTP fallbacks are rejected by default).
class DohBootstrapResolver {
  static const String _chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  final Dio _dio;
  final Random _rng = Random.secure();

  DohBootstrapResolver({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              connectTimeout: const Duration(seconds: 5),
              receiveTimeout: const Duration(seconds: 5),
            ));

  String _randomPrefix([int len = 6]) =>
      List.generate(len, (_) => _chars[_rng.nextInt(_chars.length)]).join();

  bool _isSafeOrigin(String candidate, {bool allowLocalhostHttp = true}) {
    final uri = Uri.tryParse(candidate.trim());
    if (uri == null || !uri.hasAuthority) return false;
    if (uri.scheme == 'https') return true;
    if (allowLocalhostHttp &&
        uri.scheme == 'http' &&
        (uri.host == '127.0.0.1' || uri.host == 'localhost' || uri.host == '10.0.2.2')) {
      return true;
    }
    return false;
  }

  String _normalizeBaseUrl(String raw) {
    final trimmed = raw.trim().replaceAll('"', '');
    return trimmed.endsWith('/') ? trimmed : '$trimmed/';
  }

  Future<String?> resolveBaseUrl(DynamicSourceManifest manifest) async {
    if (manifest.useBuiltInDemo) return null;

    if (manifest.staticBaseUrl != null &&
        _isSafeOrigin(manifest.staticBaseUrl!)) {
      return _normalizeBaseUrl(manifest.staticBaseUrl!);
    }

    // Tier 1: Multi-provider DoH TXT resolution with random prefix
    for (final domain in manifest.dohTxtDomains) {
      final fqdn = '${_randomPrefix()}.$domain';
      for (final doh in manifest.dohServers) {
        if (!doh.startsWith('https://')) continue;
        try {
          final resp = await _dio.get(
            doh,
            queryParameters: {'name': fqdn, 'type': 'TXT'},
            options: Options(headers: {'accept': 'application/dns-json'}),
          );
          final data = resp.data is String ? jsonDecode(resp.data as String) : resp.data;
          if (data is Map && data['Answer'] is List) {
            for (final ans in data['Answer'] as List) {
              if (ans is Map && ans['data'] != null) {
                final txt = ans['data'].toString().replaceAll('"', '').trim();
                if (_isSafeOrigin(txt)) {
                  return _normalizeBaseUrl(txt);
                }
              }
            }
          }
        } catch (_) {
          // Try next DoH endpoint
        }
      }
    }

    // Tier 2: HTTPS JSON fallback endpoints
    for (final fallbackUrl in manifest.fallbackConfigUrls) {
      if (!_isSafeOrigin(fallbackUrl)) continue;
      try {
        final resp = await _dio.get(fallbackUrl);
        final data = resp.data is String ? jsonDecode(resp.data as String) : resp.data;
        if (data is Map) {
          final apis = data['apis'] ?? data['endpoints'] ?? data['baseUrl'];
          if (apis is List && apis.isNotEmpty) {
            final firstValid = apis
                .map((e) => e.toString())
                .firstWhere(_isSafeOrigin, orElse: () => '');
            if (firstValid.isNotEmpty) return _normalizeBaseUrl(firstValid);
          } else if (apis is String && _isSafeOrigin(apis)) {
            return _normalizeBaseUrl(apis);
          }
        }
      } catch (_) {
        // Continue to next fallback URL
      }
    }

    return null;
  }
}
