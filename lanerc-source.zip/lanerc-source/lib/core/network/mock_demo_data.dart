import '../models/vod_models.dart';

/// Built-in default catalog backed by CC-BY open animation films so the app
/// delivers a complete, consumer-ready browsing & 1080p playback experience
/// out of the box when no external backend URL is configured.
class MockDemoData {
  static const AppConfigModel config = AppConfigModel(
    noticeTitle: '社区公告',
    noticeBody:
        '欢迎来到追番小站！\n\n1. 若播放偶遇缓冲，可点击播放页底部「换源」切换备用线路或使用「缓存」离线观看。\n2. 完成「我的 -> 入站问答」后即可开启弹幕与评论互动。\n3. 建议定期使用「我的 -> 数据恢复」导出追番与观看记录备份。',
    latestVersion: '1.0.8',
    latestVersionCode: 32,
  );

  static const List<String> hotSearchKeywords = [
    'Spring',
    'Sintel',
    '钢铁之泪',
    '奇幻冒险',
    '大雄兔',
    '机械迷梦',
    '宇宙洗衣店',
    '半机械特工',
  ];

  static const List<VodItem> catalog = [
    VodItem(
      vodId: 101,
      vodName: 'Spring · 春之牧歌',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Spring_-_Blender_Open_Movie-poster.jpg/480px-Spring_-_Blender_Open_Movie-poster.jpg',
      remarks: '连载中 | 更新至7集',
      category: '日漫',
      genres: ['奇幻', '冒险', '治愈', '日常'],
      year: 2026,
      score: 9.6,
      director: 'Andy Goralczyk',
      summary:
          '牧羊少女与忠诚的小狗踏入云海笼罩的远古森林，直面古老的自然巨灵，唤醒被冰封已久的春日生机。',
      weekday: 6,
    ),
    VodItem(
      vodId: 102,
      vodName: 'Sintel · 寻龙战记',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Sintel_poster.jpg/480px-Sintel_poster.jpg',
      remarks: '已完结 | 共12集',
      category: '日漫',
      genres: ['热血', '奇幻', '战斗', '冒险'],
      year: 2026,
      score: 9.7,
      director: 'Colin Levy',
      summary:
          '独自流浪的少女辛特尔救下受伤的幼龙 Scales，当伙伴被巨龙掠走后，她毅然跨越雪山与荒漠踏上宿命征途。',
      weekday: 7,
    ),
    VodItem(
      vodId: 103,
      vodName: '大雄兔的森林日常',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/480px-Big_buck_bunny_poster_big.jpg',
      remarks: '已完结 | 共12集',
      category: '日漫',
      genres: ['搞笑', '日常', '治愈'],
      year: 2025,
      score: 9.3,
      director: 'Sacha Goedegebure',
      summary:
          '性格温厚的大白兔每天在阳光森林里欣赏花草蝴蝶，直到三只调皮松鼠接连挑衅，一场充满机关巧思的反击正式上演。',
      weekday: 1,
    ),
    VodItem(
      vodId: 104,
      vodName: '钢铁之泪：记忆回溯',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Tos-poster.png/480px-Tos-poster.png',
      remarks: '已完结 | 剧场版',
      category: '剧场版',
      genres: ['科幻', '战斗', '穿越', '恋爱'],
      year: 2026,
      score: 9.4,
      director: 'Ian Hubert',
      summary:
          '在未来阿姆斯特丹的穹顶遗迹中，科学家与战术小队重现四十年前那场决定人类命运的离别，试图改写机械暴走的结局。',
      weekday: 3,
    ),
    VodItem(
      vodId: 105,
      vodName: '机械迷梦 Elephants Dream',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Elephants_Dream_s5_both.jpg/640px-Elephants_Dream_s5_both.jpg',
      remarks: '已完结 | 共11集',
      category: '日漫',
      genres: ['奇幻', '科幻', '悬疑'],
      year: 2024,
      score: 9.0,
      director: 'Bassam Kurdali',
      summary:
          '老练的引导者 Proog 带着年轻的 Emo 穿梭在无边无际的齿轮巨塔内部，两人在现实与幻想的边界展开激烈交锋。',
      weekday: 5,
    ),
    VodItem(
      vodId: 106,
      vodName: '宇宙洗衣店：次元漂流',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Cosmos_Laundromat_-_First_Cycle_-_official_poster.jpg/480px-Cosmos_Laundromat_-_First_Cycle_-_official_poster.jpg',
      remarks: '连载中 | 更新至6集',
      category: '日漫',
      genres: ['穿越', '奇幻', '搞笑'],
      year: 2026,
      score: 9.5,
      director: 'Mathieu Auvray',
      summary:
          '孤岛上的绵羊 Franck 遇见神秘推销员 Victor，只要踏入滚筒传送门，就能前往无数平行世界开启全新人生。',
      weekday: 2,
    ),
    VodItem(
      vodId: 107,
      vodName: '特工327：理发店危机',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/Agent_327_Operation_Barbershop_poster.jpg/480px-Agent_327_Operation_Barbershop_poster.jpg',
      remarks: '已完结 | 剧场版',
      category: '剧场版',
      genres: ['战斗', '搞笑', '热血'],
      year: 2025,
      score: 9.2,
      director: 'Hjalti Hjalmarsson',
      summary:
          '王牌特工潜入阿姆斯特丹街角看似普通的理发店，暗门背后竟隐藏着足以颠覆世界的地下秘密基地。',
      weekday: 4,
    ),
    VodItem(
      vodId: 108,
      vodName: '羊驼大冒险 Caminandes',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Spring_-_Blender_Open_Movie-poster.jpg/480px-Spring_-_Blender_Open_Movie-poster.jpg',
      remarks: '已完结 | 共14集',
      category: '日漫',
      genres: ['搞笑', '日常', '校园'],
      year: 2023,
      score: 9.1,
      director: 'Pablo Vazquez',
      summary:
          '高原小羊驼 Koro 为了吃到公路对面鲜嫩的红浆果，与守护领地的企鹅伙伴上演一幕幕妙趣横生的欢喜日常。',
      weekday: 4,
    ),
    VodItem(
      vodId: 109,
      vodName: '苍穹之翼：剧场总集篇',
      pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Sintel_poster.jpg/480px-Sintel_poster.jpg',
      remarks: '已完结 | 剧场版',
      category: '剧场版',
      genres: ['热血', '奇幻', '恋爱'],
      year: 2022,
      score: 8.9,
      director: 'Colin Levy',
      summary:
          '将远古龙族传说与少年羁绊重新编排的高清剧场总集篇，呈现震撼的空战分镜与交响配乐。',
      weekday: 7,
    ),
  ];

  static const List<String> _sampleStreams = [
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
  ];

  static final Map<String, List<BarrageItem>> barrages = {
    'default': [
      const BarrageItem(id: 'b1', timeSeconds: 1.0, content: '第一！前排打卡～', colorHex: 0xFFFFFFFF),
      const BarrageItem(id: 'b2', timeSeconds: 2.8, content: '作画经费在燃烧！！', colorHex: 0xFFFFD54F, isTop: true),
      const BarrageItem(id: 'b3', timeSeconds: 4.5, content: '这一段分镜真的神了', colorHex: 0xFF40C4FF),
      const BarrageItem(id: 'b4', timeSeconds: 6.5, content: '开超分之后画面好清晰', colorHex: 0xFF69F0AE),
      const BarrageItem(id: 'b5', timeSeconds: 9.2, content: '前方高能预警！！', colorHex: 0xFFFF6E6E, isTop: true),
      const BarrageItem(id: 'b6', timeSeconds: 12.0, content: '配乐一响鸡皮疙瘩起来了', colorHex: 0xFFFFFFFF),
    ],
  };

  static final Map<int, List<CommentItem>> comments = {
    101: [
      const CommentItem(
        id: 'c1',
        userName: '夜色追番人',
        avatarUrl: '',
        content: '这季最惊喜的一部！云海森林的光影氛围感直接拉满了，强烈推荐戴耳机看。',
        createdAt: '12分钟前',
        likes: 64,
      ),
      const CommentItem(
        id: 'c2',
        userName: '白羽澪',
        avatarUrl: '',
        content: '小狗太可爱了吧呜呜呜，长按屏幕三倍速跳片头超顺手～',
        createdAt: '45分钟前',
        likes: 29,
      ),
      const CommentItem(
        id: 'c3',
        userName: '星野琉璃',
        avatarUrl: '',
        content: '刚做完入站问答过来打卡，大家记得善用左下角的收藏功能追更！',
        createdAt: '2小时前',
        likes: 17,
      ),
    ],
  };

  static const List<QuizQuestion> entryQuiz = [
    QuizQuestion(
      id: 1,
      question: '在观看番剧发送弹幕时，以下哪种做法最受大家欢迎？',
      options: ['在开头剧透大结局凶手', '结合当前画面友善吐槽或科普细节', '连续刷屏遮挡字幕', '在弹幕里争吵引战'],
      answerIndex: 1,
    ),
    QuizQuestion(
      id: 2,
      question: '如果在高峰期遇到某条线路缓冲较慢，应该怎么处理？',
      options: ['点击播放页底部悬浮栏的「换源」切换线路或「缓存」离线看', '卸载重装手机系统', '把音量调到最大', '关闭屏幕自动旋转'],
      answerIndex: 0,
    ),
    QuizQuestion(
      id: 3,
      question: '更换新手机前，如何完整保留自己的收藏列表与观看进度？',
      options: ['无法保留', '进入「我的 -> 数据恢复」导出备份并在新设备恢复', '截图每一集封面', '清空历史记录'],
      answerIndex: 1,
    ),
    QuizQuestion(
      id: 4,
      question: '播放视频时想临时快速跳过一段过场画面，最便捷的手势是？',
      options: ['长按播放器画面触发倍速快进，松手即恢复原速', '反复退出重进', '切换深色模式', '点击分享按钮'],
      answerIndex: 0,
    ),
    QuizQuestion(
      id: 5,
      question: '在评论区看到他人与自己对剧情理解不同时，恰当的态度是？',
      options: ['人身攻击对方', '尊重多元观点，理性讨论剧情本身', '恶意刷屏覆盖评论区', '私自剧透后续漫画内容'],
      answerIndex: 1,
    ),
  ];

  static VodDetail buildDetail(int vodId) {
    final item = catalog.firstWhere(
      (e) => e.vodId == vodId,
      orElse: () => catalog.first,
    );
    final int epCount = item.category == '剧场版'
        ? 1
        : (item.remarks.contains('7')
            ? 7
            : item.remarks.contains('6')
                ? 6
                : item.remarks.contains('11')
                    ? 11
                    : item.remarks.contains('14')
                        ? 14
                        : 12);

    return VodDetail(
      item: item,
      playLines: [
        VodPlayLine(
          lineId: 'line_hd',
          lineName: '极速蓝光①',
          episodes: List.generate(
            epCount,
            (i) => VodEpisode(
              index: i + 1,
              title: item.category == '剧场版' ? '正片' : '${i + 1}',
              resourceId: '${item.vodId}_hd_${i + 1}',
            ),
          ),
        ),
        VodPlayLine(
          lineId: 'line_cdn',
          lineName: '流畅备线②',
          episodes: List.generate(
            epCount,
            (i) => VodEpisode(
              index: i + 1,
              title: item.category == '剧场版' ? '正片' : '${i + 1}',
              resourceId: '${item.vodId}_cdn_${i + 1}',
            ),
          ),
        ),
        VodPlayLine(
          lineId: 'line_intl',
          lineName: '海外节点③',
          episodes: List.generate(
            epCount,
            (i) => VodEpisode(
              index: i + 1,
              title: item.category == '剧场版' ? '正片' : '${i + 1}',
              resourceId: '${item.vodId}_intl_${i + 1}',
            ),
          ),
        ),
      ],
      recommendations: catalog.where((e) => e.vodId != item.vodId).take(6).toList(),
    );
  }

  static StreamResolveResult resolveStream(String resourceId) {
    final hash = resourceId.codeUnits.fold<int>(0, (a, b) => a + b);
    final url = _sampleStreams[hash % _sampleStreams.length];
    return StreamResolveResult(url: url, format: 'mp4');
  }
}
