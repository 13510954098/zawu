import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart' hide Response;
import '../models/vod_models.dart';
import '../storage/local_database.dart';
import 'doh_bootstrap_resolver.dart';
import 'mock_demo_data.dart';

/// REST API client supporting both built-in ready-to-play catalog mode and
/// a self-hosted / DoH-discovered HTTPS VOD server.
class ApiService extends GetxService {
  late final Dio _dio;
  final DohBootstrapResolver _bootstrap = DohBootstrapResolver();

  final Rx<DynamicSourceManifest> activeManifest =
      DynamicSourceManifest.builtInDemo().obs;
  final RxnString resolvedBaseUrl = RxnString();
  final Rx<AppConfigModel> appConfig = MockDemoData.config.obs;

  bool get isDemoMode =>
      activeManifest.value.useBuiltInDemo || resolvedBaseUrl.value == null;

  Future<ApiService> init() async {
    _dio = Dio(
      BaseOptions(
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 15),
        headers: const {'Accept': 'application/json'},
      ),
    );
    if (kDebugMode) {
      _dio.interceptors.add(LogInterceptor(requestBody: false, responseBody: false));
    }

    final savedJson = LocalDatabase.instance.getSavedSourceManifestJson();
    if (savedJson != null && savedJson.isNotEmpty) {
      try {
        final parsed =
            DynamicSourceManifest.fromJson(jsonDecode(savedJson) as Map<String, dynamic>);
        await applySourceManifest(parsed, persist: false);
      } catch (_) {
        activeManifest.value = DynamicSourceManifest.builtInDemo();
      }
    }
    return this;
  }

  Future<bool> applySourceManifest(DynamicSourceManifest manifest,
      {bool persist = true}) async {
    activeManifest.value = manifest;
    if (manifest.useBuiltInDemo) {
      resolvedBaseUrl.value = null;
    } else {
      final base = await _bootstrap.resolveBaseUrl(manifest);
      resolvedBaseUrl.value = base;
      if (base != null) {
        _dio.options.baseUrl = base;
      }
    }
    if (persist) {
      await LocalDatabase.instance
          .saveSourceManifestJson(jsonEncode(manifest.toJson()));
    }
    appConfig.value = await fetchConfig();
    return manifest.useBuiltInDemo || resolvedBaseUrl.value != null;
  }

  Future<AppConfigModel> fetchConfig() async {
    if (isDemoMode) return MockDemoData.config;
    try {
      final res = await _dio.get('app/config');
      return AppConfigModel.fromJson(Map<String, dynamic>.from(res.data as Map));
    } catch (_) {
      return MockDemoData.config;
    }
  }

  Future<Map<String, List<VodItem>>> fetchHome() async {
    if (isDemoMode) {
      return {
        'banners': MockDemoData.catalog.take(4).toList(),
        'hotNew': MockDemoData.catalog.take(5).toList(),
        'riman': MockDemoData.catalog.where((e) => e.category == '日漫').toList(),
        'movies': MockDemoData.catalog.where((e) => e.category == '剧场版').toList(),
      };
    }
    final res = await _dio.get('app/home');
    final map = Map<String, dynamic>.from(res.data as Map);
    List<VodItem> parseList(String key) =>
        ((map[key] as List?) ?? const [])
            .map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
    return {
      'banners': parseList('banners'),
      'hotNew': parseList('hotNew'),
      'riman': parseList('riman'),
      'movies': parseList('movies'),
    };
  }

  Future<List<VodItem>> fetchFilteredVod({
    required String category,
    String genre = '全部',
    int? year,
    String sortBy = 'time',
  }) async {
    if (isDemoMode) {
      var list = MockDemoData.catalog
          .where((e) => category == '全部' || e.category == category)
          .toList();
      if (genre != '全部') {
        list = list.where((e) => e.genres.contains(genre)).toList();
      }
      if (year != null && year > 0) {
        list = list.where((e) => e.year == year).toList();
      }
      if (sortBy == 'score') {
        list.sort((a, b) => b.score.compareTo(a.score));
      } else {
        list.sort((a, b) => b.year.compareTo(a.year));
      }
      return list;
    }
    final res = await _dio.get('app/vod/filter', queryParameters: {
      'category': category,
      'genre': genre,
      if (year != null && year > 0) 'year': year,
      'sort': sortBy,
    });
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<List<VodItem>> searchVod(String keyword) async {
    final kw = keyword.trim().toLowerCase();
    if (kw.isEmpty) return const [];
    if (isDemoMode) {
      return MockDemoData.catalog.where((e) {
        return e.vodName.toLowerCase().contains(kw) ||
            e.summary.toLowerCase().contains(kw) ||
            e.director.toLowerCase().contains(kw) ||
            e.genres.any((g) => g.toLowerCase().contains(kw));
      }).toList();
    }
    final res = await _dio.get('app/vod/search', queryParameters: {'wd': keyword.trim()});
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<List<VodItem>> fetchRank(String seasonTab) async {
    if (isDemoMode) {
      final copy = [...MockDemoData.catalog];
      if (seasonTab == '一月新番') {
        copy.sort((a, b) => a.vodId.compareTo(b.vodId));
      } else if (seasonTab == '十月新番') {
        copy.sort((a, b) => b.year.compareTo(a.year));
      } else {
        copy.sort((a, b) => b.score.compareTo(a.score));
      }
      return copy;
    }
    final res = await _dio.get('app/rank', queryParameters: {'season': seasonTab});
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<List<VodItem>> fetchWeekSchedule(int weekday) async {
    if (isDemoMode) {
      final filtered =
          MockDemoData.catalog.where((e) => e.weekday == weekday).toList();
      return filtered.isNotEmpty ? filtered : MockDemoData.catalog.take(2).toList();
    }
    final res = await _dio.get('app/week', queryParameters: {'weekday': weekday});
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => VodItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<VodDetail> fetchVodDetail(int vodId) async {
    if (isDemoMode) return MockDemoData.buildDetail(vodId);
    final res = await _dio.get('app/v2/vod/$vodId');
    return VodDetail.fromJson(Map<String, dynamic>.from(res.data as Map));
  }

  Future<StreamResolveResult> resolvePlayback({
    required int vodId,
    required String lineId,
    required String resourceId,
  }) async {
    if (isDemoMode) return MockDemoData.resolveStream(resourceId);
    final res = await _dio.post('app/v2/play', data: {
      'vodId': vodId,
      'lineId': lineId,
      'resourceId': resourceId,
    });
    return StreamResolveResult.fromJson(Map<String, dynamic>.from(res.data as Map));
  }

  Future<List<BarrageItem>> fetchBarrages(int vodId, int episodeIndex) async {
    if (isDemoMode) {
      return List<BarrageItem>.from(
        MockDemoData.barrages['${vodId}_$episodeIndex'] ??
            MockDemoData.barrages['default'] ??
            const [],
      );
    }
    final res = await _dio.get(
      'app/chat/barragev2',
      queryParameters: {'vid': vodId, 'vod': episodeIndex},
    );
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => BarrageItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<BarrageItem> sendBarrage({
    required int vodId,
    required int episodeIndex,
    required double timeSeconds,
    required String content,
    int colorHex = 0xFFFFFFFF,
    bool isTop = false,
  }) async {
    final created = BarrageItem(
      id: 'local_${DateTime.now().millisecondsSinceEpoch}',
      timeSeconds: timeSeconds,
      content: content,
      colorHex: colorHex,
      isTop: isTop,
    );
    if (isDemoMode) {
      final key = '${vodId}_$episodeIndex';
      MockDemoData.barrages
          .putIfAbsent(
            key,
            () => List<BarrageItem>.from(MockDemoData.barrages['default'] ?? const []),
          )
          .add(created);
      return created;
    }
    await _dio.post('app/chat/sendbarrage', data: {
      'vid': vodId,
      'vod': episodeIndex,
      'timeSeconds': timeSeconds,
      'content': content,
      'colorHex': colorHex,
      'isTop': isTop,
    });
    return created;
  }

  Future<List<CommentItem>> fetchComments(int vodId) async {
    if (isDemoMode) {
      return List<CommentItem>.from(
        MockDemoData.comments[vodId] ?? MockDemoData.comments[101] ?? const [],
      );
    }
    final res = await _dio.get('app/chat/comments', queryParameters: {'vid': vodId});
    return ((res.data['items'] as List?) ?? const [])
        .map((e) => CommentItem.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }

  Future<CommentItem> sendComment({
    required int vodId,
    required String userName,
    required String content,
  }) async {
    final item = CommentItem(
      id: 'cm_${DateTime.now().millisecondsSinceEpoch}',
      userName: userName,
      avatarUrl: '',
      content: content,
      createdAt: '刚刚',
    );
    if (isDemoMode) {
      MockDemoData.comments
          .putIfAbsent(
            vodId,
            () => List<CommentItem>.from(MockDemoData.comments[101] ?? const []),
          )
          .insert(0, item);
      return item;
    }
    await _dio.post('app/chat/sendcomment', data: {
      'vid': vodId,
      'userName': userName,
      'content': content,
    });
    return item;
  }

  Future<UserProfile> loginOrRegister({
    required String account,
    required String password,
    String? nickName,
    bool isRegister = false,
  }) async {
    if (!isDemoMode) {
      final path = isRegister ? 'app/auth/register' : 'app/auth/login';
      final res = await _dio.post(path, data: {
        'account': account,
        'password': password,
        if (nickName != null && nickName.isNotEmpty) 'nickName': nickName,
      });
      return UserProfile.fromJson(Map<String, dynamic>.from(res.data as Map));
    }
    final cleanAccount = account.trim();
    final defaultNick = (nickName != null && nickName.trim().isNotEmpty)
        ? nickName.trim()
        : cleanAccount.split('@').first;
    return UserProfile(
      userId: '${10000 + cleanAccount.hashCode.abs() % 89999}',
      email: cleanAccount,
      nickName: defaultNick,
      coins: LocalDatabase.instance.localCoins,
      downloadQuota: LocalDatabase.instance.localDownloadQuota,
      passedQuiz: LocalDatabase.instance.hasPassedQuiz,
    );
  }

  Future<void> submitFeedback({
    required String category,
    required String content,
    int? vodId,
    String? vodName,
  }) async {
    if (isDemoMode) return;
    await _dio.post('app/feedback', data: {
      'category': category,
      'content': content,
      if (vodId != null) 'vodId': vodId,
      if (vodName != null) 'vodName': vodName,
    });
  }

  Future<void> reportContent({
    required bool isBarrage,
    required String targetId,
    required String reason,
  }) async {
    if (isDemoMode) return;
    final path = isBarrage ? 'app/report/barrage' : 'app/report/comment';
    await _dio.post(path, data: {'id': targetId, 'reason': reason});
  }
}
