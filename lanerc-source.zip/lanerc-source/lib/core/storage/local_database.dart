import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../models/vod_models.dart';

/// Local persistence layer backing watch history, offline cache, favorites,
/// welfare coin tasks, entry quiz status, and JSON data recovery.
class LocalDatabase {
  LocalDatabase._();
  static final LocalDatabase instance = LocalDatabase._();

  Database? _db;
  late SharedPreferences _prefs;
  final List<HistoryRecord> _memoryHistory = [];
  final List<DownloadRecord> _memoryDownloads = [];

  Future<void> init({bool inMemoryForTest = false}) async {
    _prefs = await SharedPreferences.getInstance();
    if (inMemoryForTest) return;
    final dbDir = await getDatabasesPath();
    final dbPath = p.join(dbDir, 'anime_player_local.db');
    _db = await openDatabase(
      dbPath,
      version: 2,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vodID INTEGER NOT NULL UNIQUE,
            vodName TEXT NOT NULL,
            vodClass INTEGER NOT NULL,
            vodSelect INTEGER NOT NULL,
            pic TEXT NOT NULL,
            seeTime INTEGER NOT NULL,
            lastTime INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE downloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vid TEXT NOT NULL UNIQUE,
            vodID INTEGER NOT NULL,
            vodName TEXT NOT NULL,
            vodClass INTEGER NOT NULL,
            vodSelect INTEGER NOT NULL,
            pic TEXT NOT NULL,
            player TEXT NOT NULL,
            downloadUrl TEXT NOT NULL,
            localPath TEXT NOT NULL,
            fileSize INTEGER NOT NULL,
            progress REAL NOT NULL,
            downloadedSpeed TEXT NOT NULL,
            status INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  // --- Source Manifest ---
  String? getSavedSourceManifestJson() => _prefs.getString('custom_source_manifest');
  Future<void> saveSourceManifestJson(String json) =>
      _prefs.setString('custom_source_manifest', json);

  // --- Startup Notice Dismissal ---
  bool get hasSeenSessionNotice => _prefs.getBool('seen_notice_v108') ?? false;
  Future<void> markNoticeSeen() => _prefs.setBool('seen_notice_v108', true);

  // --- Theme Settings ---
  bool get isDarkMode => _prefs.getBool('is_dark_mode') ?? false;
  int get accentColorIndex => _prefs.getInt('accent_color_idx') ?? 0;
  Future<void> saveTheme(bool dark, int colorIdx) async {
    await _prefs.setBool('is_dark_mode', dark);
    await _prefs.setInt('accent_color_idx', colorIdx);
  }

  // --- Entry Quiz & Welfare State (works seamlessly in both guest & logged-in modes) ---
  bool get hasPassedQuiz => _prefs.getBool('passed_entry_quiz') ?? false;
  Future<void> setPassedQuiz(bool value) => _prefs.setBool('passed_entry_quiz', value);

  int get localCoins => _prefs.getInt('wallet_coins') ?? 0;
  Future<void> setLocalCoins(int coins) => _prefs.setInt('wallet_coins', coins);

  int get localDownloadQuota => _prefs.getInt('download_quota') ?? 5;
  Future<void> setLocalDownloadQuota(int quota) =>
      _prefs.setInt('download_quota', quota);

  String _todayKey() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  int get todayCoinTaskCount {
    final savedDate = _prefs.getString('task_coin_date');
    if (savedDate != _todayKey()) return 0;
    return _prefs.getInt('task_coin_count') ?? 0;
  }

  Future<void> incrementTodayCoinTask() async {
    final next = todayCoinTaskCount + 1;
    await _prefs.setString('task_coin_date', _todayKey());
    await _prefs.setInt('task_coin_count', next);
  }

  List<Map<String, dynamic>> getRedemptionRecords() {
    final raw = _prefs.getStringList('redemption_records') ?? const [];
    return raw
        .map((e) => Map<String, dynamic>.from(jsonDecode(e) as Map))
        .toList();
  }

  Future<void> addRedemptionRecord(String title, int costCoins) async {
    final records = getRedemptionRecords();
    records.insert(0, {
      'title': title,
      'cost': costCoins,
      'time': DateTime.now().toIso8601String(),
    });
    await _prefs.setStringList(
      'redemption_records',
      records.take(50).map(jsonEncode).toList(),
    );
  }

  // --- User Profile & Auth ---
  UserProfile? loadUserProfile() {
    final raw = _prefs.getString('user_profile');
    if (raw == null || raw.isEmpty) return null;
    try {
      return UserProfile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveUserProfile(UserProfile? profile) async {
    if (profile == null) {
      await _prefs.remove('user_profile');
    } else {
      await _prefs.setString('user_profile', jsonEncode(profile.toJson()));
    }
  }

  // --- Favorites (`我的收藏`) ---
  List<VodItem> getFavorites() {
    final raw = _prefs.getStringList('favorite_vods') ?? const [];
    return raw
        .map((s) => VodItem.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  bool isFavorite(int vodId) => getFavorites().any((e) => e.vodId == vodId);

  Future<bool> toggleFavorite(VodItem item) async {
    final current = getFavorites();
    final idx = current.indexWhere((e) => e.vodId == item.vodId);
    bool added;
    if (idx >= 0) {
      current.removeAt(idx);
      added = false;
    } else {
      current.insert(0, item);
      added = true;
    }
    await _prefs.setStringList(
      'favorite_vods',
      current.map((e) => jsonEncode(e.toJson())).toList(),
    );
    return added;
  }

  Future<void> removeFavorites(Set<int> vodIds) async {
    final remaining =
        getFavorites().where((e) => !vodIds.contains(e.vodId)).toList();
    await _prefs.setStringList(
      'favorite_vods',
      remaining.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  // --- Search History ---
  List<String> getSearchHistory() =>
      _prefs.getStringList('search_keywords') ?? const [];

  Future<void> addSearchKeyword(String kw) async {
    final trimmed = kw.trim();
    if (trimmed.isEmpty) return;
    final list = [...getSearchHistory()]..remove(trimmed);
    list.insert(0, trimmed);
    await _prefs.setStringList('search_keywords', list.take(15).toList());
  }

  Future<void> clearSearchHistory() => _prefs.remove('search_keywords');

  // --- Watch History ---
  Future<void> upsertHistory(HistoryRecord record) async {
    if (_db == null) {
      _memoryHistory.removeWhere((e) => e.vodID == record.vodID);
      _memoryHistory.insert(0, record);
      return;
    }
    await _db!.insert(
      'history',
      record.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<HistoryRecord?> getHistoryForVod(int vodId) async {
    if (_db == null) {
      for (final h in _memoryHistory) {
        if (h.vodID == vodId) return h;
      }
      return null;
    }
    final rows = await _db!.query(
      'history',
      where: 'vodID = ?',
      whereArgs: [vodId],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return HistoryRecord.fromMap(rows.first);
  }

  Future<List<HistoryRecord>> getHistoryList() async {
    if (_db == null) return List<HistoryRecord>.from(_memoryHistory);
    final rows = await _db!.query('history', orderBy: 'lastTime DESC');
    return rows.map(HistoryRecord.fromMap).toList();
  }

  Future<void> deleteHistoryBatch(Iterable<int> vodIds) async {
    for (final id in vodIds) {
      await deleteHistory(id);
    }
  }

  Future<void> deleteHistory(int vodId) async {
    if (_db == null) {
      _memoryHistory.removeWhere((e) => e.vodID == vodId);
      return;
    }
    await _db!.delete('history', where: 'vodID = ?', whereArgs: [vodId]);
  }

  Future<void> clearAllHistory() async {
    if (_db == null) {
      _memoryHistory.clear();
      return;
    }
    await _db!.delete('history');
  }

  // --- Offline Downloads ---
  Future<void> upsertDownload(DownloadRecord record) async {
    if (_db == null) {
      _memoryDownloads.removeWhere((e) => e.vid == record.vid);
      _memoryDownloads.insert(0, record);
      return;
    }
    await _db!.insert(
      'downloads',
      record.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<DownloadRecord>> getDownloads() async {
    if (_db == null) return List<DownloadRecord>.from(_memoryDownloads);
    final rows = await _db!.query('downloads', orderBy: 'id DESC');
    return rows.map(DownloadRecord.fromMap).toList();
  }

  Future<void> removeDownload(String vid) async {
    if (_db == null) {
      _memoryDownloads.removeWhere((e) => e.vid == vid);
      return;
    }
    final rows = await _db!.query('downloads', where: 'vid = ?', whereArgs: [vid]);
    for (final r in rows) {
      final path = r['localPath']?.toString() ?? '';
      if (path.isNotEmpty) {
        final f = File(path);
        if (await f.exists()) await f.delete();
      }
    }
    await _db!.delete('downloads', where: 'vid = ?', whereArgs: [vid]);
  }

  // --- Data Export / Recovery (`数据恢复`) ---
  Future<String> exportBackupJson() async {
    final history = await getHistoryList();
    return jsonEncode({
      'schemaVersion': 2,
      'exportedAt': DateTime.now().toIso8601String(),
      'passedQuiz': hasPassedQuiz,
      'coins': localCoins,
      'favorites': getFavorites().map((e) => e.toJson()).toList(),
      'history': history.map((e) => e.toMap()).toList(),
    });
  }

  Future<int> importBackupJson(String rawJson) async {
    final data = jsonDecode(rawJson) as Map<String, dynamic>;
    int imported = 0;
    if (data['passedQuiz'] == true) {
      await setPassedQuiz(true);
    }
    if (data['coins'] is num) {
      await setLocalCoins((data['coins'] as num).toInt());
    }
    if (data['favorites'] is List) {
      final favs = (data['favorites'] as List)
          .map((e) => jsonEncode(Map<String, dynamic>.from(e as Map)))
          .toList();
      await _prefs.setStringList('favorite_vods', favs);
      imported += favs.length;
    }
    if (data['history'] is List) {
      for (final row in data['history'] as List) {
        final map = Map<String, dynamic>.from(row as Map)..remove('id');
        await upsertHistory(HistoryRecord.fromMap(map));
        imported++;
      }
    }
    return imported;
  }

  // --- SHA-256 File Integrity Verifier ---
  static Future<bool> verifyFileSha256(File file, String expectedHex) async {
    if (!await file.exists()) return false;
    final digest = await sha256.bind(file.openRead()).first;
    return digest.toString().toLowerCase() == expectedHex.trim().toLowerCase();
  }

  Future<File> downloadEpisodeFile({
    required DownloadRecord record,
    required void Function(double progress, String speedText) onProgress,
    CancelToken? cancelToken,
  }) async {
    final dir = await getApplicationDocumentsDirectory();
    final targetDir = Directory(p.join(dir.path, 'offline_videos'));
    if (!await targetDir.exists()) {
      await targetDir.create(recursive: true);
    }
    final savePath = p.join(targetDir.path, '${record.vid}.mp4');
    final dio = Dio();
    int lastBytes = 0;
    DateTime lastTick = DateTime.now();

    await dio.download(
      record.downloadUrl,
      savePath,
      cancelToken: cancelToken,
      onReceiveProgress: (received, total) {
        final now = DateTime.now();
        final elapsedMs = now.difference(lastTick).inMilliseconds;
        String speed = record.downloadedSpeed;
        if (elapsedMs >= 400) {
          final bytesPerSec = ((received - lastBytes) * 1000 / elapsedMs).round();
          speed = bytesPerSec >= 1024 * 1024
              ? '${(bytesPerSec / (1024 * 1024)).toStringAsFixed(2)} MB/s'
              : '${(bytesPerSec / 1024).toStringAsFixed(1)} KB/s';
          lastBytes = received;
          lastTick = now;
        }
        final ratio = total > 0 ? received / total : 0.0;
        onProgress(ratio, speed);
      },
    );
    return File(savePath);
  }
}
