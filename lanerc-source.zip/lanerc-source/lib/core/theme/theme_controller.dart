import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../storage/local_database.dart';

class ThemeController extends GetxController {
  static const List<Color> palettes = [
    Color(0xFF00A8E8), // 晴空蓝 (默认主题色)
    Color(0xFFFF6B9D), // 樱花粉
    Color(0xFF7C4DFF), // 鸢尾紫
    Color(0xFF00C853), // 薄荷绿
    Color(0xFFFF9100), // 落日橙
    Color(0xFF536DFE), // 星夜靛
  ];

  static const List<String> paletteNames = [
    '晴空蓝 (默认)',
    '樱花粉',
    '鸢尾紫',
    '薄荷绿',
    '落日橙',
    '星夜靛',
  ];

  final RxBool isDark = false.obs;
  final RxInt colorIndex = 0.obs;

  @override
  void onInit() {
    super.onInit();
    isDark.value = LocalDatabase.instance.isDarkMode;
    colorIndex.value = LocalDatabase.instance.accentColorIndex
        .clamp(0, palettes.length - 1);
  }

  Color get primaryColor => palettes[colorIndex.value];

  ThemeData get lightTheme {
    final seed = primaryColor;
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      primary: seed,
      brightness: Brightness.light,
      surface: Colors.white,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: scheme,
      primaryColor: seed,
      scaffoldBackgroundColor: Colors.white,
      cardColor: Colors.white,
      dividerColor: const Color(0xFFF0F1F5),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        foregroundColor: Color(0xFF1F2329),
        centerTitle: true,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: Color(0xFF1F2329),
          fontSize: 17,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  ThemeData get darkTheme {
    final seed = primaryColor;
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      primary: seed,
      brightness: Brightness.dark,
      surface: const Color(0xFF181A20),
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      primaryColor: seed,
      scaffoldBackgroundColor: const Color(0xFF111318),
      cardColor: const Color(0xFF1A1D24),
      dividerColor: const Color(0xFF262A34),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF111318),
        surfaceTintColor: Colors.transparent,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: Colors.white,
          fontSize: 17,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Future<void> updateTheme({bool? dark, int? paletteIdx}) async {
    if (dark != null) isDark.value = dark;
    if (paletteIdx != null) {
      colorIndex.value = paletteIdx.clamp(0, palettes.length - 1);
    }
    await LocalDatabase.instance.saveTheme(isDark.value, colorIndex.value);
    Get.changeThemeMode(isDark.value ? ThemeMode.dark : ThemeMode.light);
    Get.changeTheme(isDark.value ? darkTheme : lightTheme);
  }
}
