import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:media_kit/media_kit.dart';
import 'app/routes/app_pages.dart';
import 'app/routes/app_routes.dart';
import 'core/network/api_service.dart';
import 'core/state/download_controller.dart';
import 'core/state/user_controller.dart';
import 'core/storage/local_database.dart';
import 'core/theme/theme_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    MediaKit.ensureInitialized();
  } catch (_) {
    // Safe fallback in headless widget test environments without libmpv.
  }

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  await LocalDatabase.instance.init();
  final themeCtrl = Get.put(ThemeController(), permanent: true);
  Get.put(UserController(), permanent: true);
  await Get.putAsync(() => ApiService().init(), permanent: true);
  Get.put(DownloadController(), permanent: true);

  runApp(AnimeClientApp(themeController: themeCtrl));
}

class AnimeClientApp extends StatelessWidget {
  final ThemeController themeController;
  const AnimeClientApp({super.key, required this.themeController});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => GetMaterialApp(
        title: '追番小站',
        debugShowCheckedModeBanner: false,
        theme: themeController.lightTheme,
        darkTheme: themeController.darkTheme,
        themeMode:
            themeController.isDark.value ? ThemeMode.dark : ThemeMode.light,
        initialRoute: AppRoutes.splash,
        getPages: AppPages.pages,
        defaultTransition: Transition.cupertino,
      ),
    );
  }
}
