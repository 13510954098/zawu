import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/vod_models.dart';
import '../../core/network/api_service.dart';
import '../../widgets/lanerc_ui.dart';
import '../../widgets/vod_card.dart';

class WeekPage extends StatefulWidget {
  @override
  State<WeekPage> createState() => _WeekPageState();
}

class _WeekPageState extends State<WeekPage>
    with SingleTickerProviderStateMixin {
  static const List<String> _days = [
    '周一',
    '周二',
    '周三',
    '周四',
    '周五',
    '周六',
    '周日',
  ];

  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    final initialIdx = (DateTime.now().weekday - 1).clamp(0, 6);
    _tabController = TabController(
      length: 7,
      initialIndex: initialIdx,
      vsync: this,
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: const LanercSubAppBar(title: '番剧排期表'),
      body: Column(
        children: [
          TabBar(
            controller: _tabController,
            labelColor: primary,
            unselectedLabelColor: const Color(0xFF8A9099),
            indicatorSize: TabBarIndicatorSize.label,
            dividerColor: Colors.transparent,
            labelPadding: EdgeInsets.zero,
            indicator: UnderlineTabIndicator(
              borderRadius: BorderRadius.circular(2),
              borderSide: BorderSide(width: 3, color: primary),
            ),
            tabs: _days.map((d) => Tab(height: 38, text: d)).toList(),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: List.generate(
                7,
                (i) => _WeekdayScheduleList(weekday: i + 1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WeekdayScheduleList extends StatefulWidget {
  final int weekday;
  const _WeekdayScheduleList({required this.weekday});

  @override
  State<_WeekdayScheduleList> createState() => _WeekdayScheduleListState();
}

class _WeekdayScheduleListState extends State<_WeekdayScheduleList>
    with AutomaticKeepAliveClientMixin {
  bool _loading = true;
  List<VodItem> _items = const [];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list =
        await Get.find<ApiService>().fetchWeekSchedule(widget.weekday);
    if (!mounted) return;
    setState(() {
      _items = list;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      itemCount: _items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 12,
        crossAxisSpacing: 10,
        childAspectRatio: 0.56,
      ),
      itemBuilder: (_, i) => VodCard(item: _items[i]),
    );
  }
}
