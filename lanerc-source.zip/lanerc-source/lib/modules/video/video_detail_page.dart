import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../app/routes/app_routes.dart';
import '../../core/models/vod_models.dart';
import '../../core/network/api_service.dart';
import '../../core/player/anime_mpv_controller.dart';
import '../../core/state/download_controller.dart';
import '../../core/state/user_controller.dart';
import '../../core/storage/local_database.dart';
import '../../widgets/danmaku_stage.dart';
import '../../widgets/lanerc_ui.dart';
import '../../widgets/vod_card.dart';
import 'package:media_kit_video/media_kit_video.dart';

class VideoDetailPage extends StatefulWidget {
  @override
  State<VideoDetailPage> createState() => _VideoDetailPageState();
}

class _VideoDetailPageState extends State<VideoDetailPage>
    with SingleTickerProviderStateMixin {
  late int _vodId;
  late final TabController _subTabController;
  AnimeMpvController? _mpv;

  final List<StreamSubscription<dynamic>> _subs = [];
  Timer? _osdTimer;
  Timer? _historyTimer;

  bool _loading = true;
  VodDetail? _detail;
  int _lineIndex = 0;
  int _episodeIndex = 0;
  String _currentStreamUrl = '';

  // Player state
  bool _isPlaying = false;
  bool _isBuffering = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  double _playbackRate = 1.0;
  bool _longPressBoosting = false;
  bool _showOsd = true;
  bool _screenLocked = false;
  bool _isFullscreen = false;

  // Gesture overlays
  double _volume = 100.0;
  double _brightnessOverlay = 0.0; // 0 = normal, up to 0.65 dim overlay
  Duration? _dragSeekTarget;
  String? _gestureHint;

  // Danmaku & Comments
  DanmakuConfig _danmakuConfig = const DanmakuConfig();
  List<BarrageItem> _barrages = const [];
  List<CommentItem> _comments = const [];
  int _activeSubTab = 0;

  @override
  void initState() {
    super.initState();
    _vodId = int.tryParse('${Get.parameters['vod'] ?? 101}') ?? 101;
    _subTabController = TabController(length: 2, vsync: this)
      ..addListener(() {
        if (mounted && _activeSubTab != _subTabController.index) {
          setState(() => _activeSubTab = _subTabController.index);
        }
      });

    try {
      WakelockPlus.enable();
    } catch (_) {}

    _initPlayer();
    _loadVod(_vodId);
  }

  void _initPlayer() {
    try {
      final ctrl = AnimeMpvController();
      _mpv = ctrl;
      _subs.add(ctrl.player.stream.playing.listen((p) {
        if (mounted) setState(() => _isPlaying = p);
      }));
      _subs.add(ctrl.player.stream.buffering.listen((b) {
        if (mounted) setState(() => _isBuffering = b);
      }));
      _subs.add(ctrl.player.stream.position.listen((pos) {
        if (mounted && _dragSeekTarget == null) {
          setState(() => _position = pos);
        }
      }));
      _subs.add(ctrl.player.stream.duration.listen((dur) {
        if (mounted) setState(() => _duration = dur);
      }));
      _subs.add(ctrl.player.stream.completed.listen((done) {
        if (done && mounted) _playNextEpisodeIfAvailable();
      }));
    } catch (_) {
      _mpv = null;
    }

    _historyTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _persistHistory();
    });
  }

  @override
  void dispose() {
    _persistHistory();
    _osdTimer?.cancel();
    _historyTimer?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _mpv?.dispose();
    _subTabController.dispose();
    if (_isFullscreen) {
      _exitFullscreen();
    }
    try {
      WakelockPlus.disable();
    } catch (_) {}
    super.dispose();
  }

  Future<void> _loadVod(int targetVodId) async {
    setState(() {
      _vodId = targetVodId;
      _loading = true;
    });
    final api = Get.find<ApiService>();
    final detail = await api.fetchVodDetail(targetVodId);
    final comments = await api.fetchComments(targetVodId);
    final savedHistory =
        await LocalDatabase.instance.getHistoryForVod(targetVodId);

    int initialEpIdx = 0;
    int resumeSec = 0;
    if (savedHistory != null && detail.playLines.isNotEmpty) {
      final eps = detail.playLines.first.episodes;
      final found = eps.indexWhere((e) => e.index == savedHistory.vodSelect);
      if (found >= 0) {
        initialEpIdx = found;
        resumeSec = savedHistory.seeTime;
      }
    }

    if (!mounted) return;
    setState(() {
      _detail = detail;
      _comments = comments;
      _lineIndex = 0;
      _episodeIndex = initialEpIdx;
      _loading = false;
    });

    await _startEpisodePlayback(seekToSeconds: resumeSec);
  }

  Future<void> _startEpisodePlayback({int seekToSeconds = 0}) async {
    final d = _detail;
    if (d == null || d.playLines.isEmpty) return;
    final line = d.playLines[_lineIndex.clamp(0, d.playLines.length - 1)];
    if (line.episodes.isEmpty) return;
    final ep = line.episodes[_episodeIndex.clamp(0, line.episodes.length - 1)];

    final api = Get.find<ApiService>();
    final barrages = await api.fetchBarrages(d.item.vodId, ep.index);
    final stream = await api.resolvePlayback(
      vodId: d.item.vodId,
      lineId: line.lineId,
      resourceId: ep.resourceId,
    );

    if (!mounted) return;
    setState(() {
      _barrages = barrages;
      _currentStreamUrl = stream.url;
    });

    try {
      await _mpv?.openNetworkStream(stream.url, headers: stream.headers);
      if (seekToSeconds > 3) {
        await Future<void>.delayed(const Duration(milliseconds: 450));
        await _mpv?.player.seek(Duration(seconds: seekToSeconds));
      }
    } catch (_) {}

    _scheduleOsdAutoHide();
    await _persistHistory();
  }

  void _playNextEpisodeIfAvailable() {
    final d = _detail;
    if (d == null || d.playLines.isEmpty) return;
    final eps = d.playLines[_lineIndex].episodes;
    if (_episodeIndex + 1 < eps.length) {
      setState(() => _episodeIndex += 1);
      _startEpisodePlayback();
    }
  }

  Future<void> _persistHistory() async {
    final d = _detail;
    if (d == null || d.playLines.isEmpty) return;
    final eps = d.playLines[_lineIndex].episodes;
    if (eps.isEmpty) return;
    final ep = eps[_episodeIndex.clamp(0, eps.length - 1)];
    await LocalDatabase.instance.upsertHistory(
      HistoryRecord(
        vodID: d.item.vodId,
        vodName: d.item.vodName,
        vodClass: d.item.category == '剧场版' ? 2 : 1,
        vodSelect: ep.index,
        pic: d.item.pic,
        seeTime: _position.inSeconds,
        lastTime: DateTime.now().millisecondsSinceEpoch,
      ),
    );
  }

  void _scheduleOsdAutoHide() {
    _osdTimer?.cancel();
    _osdTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _isPlaying) {
        setState(() => _showOsd = false);
      }
    });
  }

  void _toggleFullscreen() {
    if (_isFullscreen) {
      _exitFullscreen();
    } else {
      setState(() => _isFullscreen = true);
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      SystemChrome.setPreferredOrientations(const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    }
  }

  void _exitFullscreen() {
    if (mounted) setState(() => _isFullscreen = false);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
    ]);
  }

  String _fmtDuration(Duration d) {
    final total = d.inSeconds.clamp(0, 360000);
    final m = (total ~/ 60).toString().padLeft(2, '0');
    final s = (total % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    if (_isFullscreen) {
      return WillPopScope(
        onWillPop: () async {
          _exitFullscreen();
          return false;
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          body: _buildPlayerStage(context, fullscreen: true),
        ),
      );
    }

    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      body: Column(
        children: [
          Container(
            color: Colors.black,
            child: SafeArea(
              bottom: false,
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: _buildPlayerStage(context, fullscreen: false),
              ),
            ),
          ),

          // Sub-Player Bar: 简介 | 评论  +  发弹幕 & [弹✓]
          Container(
            height: 44,
            padding: const EdgeInsets.only(right: 10),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              border: Border(
                bottom: BorderSide(color: Theme.of(context).dividerColor),
              ),
            ),
            child: Row(
              children: [
                TabBar(
                  controller: _subTabController,
                  isScrollable: true,
                  tabAlignment: TabAlignment.start,
                  dividerColor: Colors.transparent,
                  labelColor: primary,
                  unselectedLabelColor: const Color(0xFF8A9099),
                  labelStyle: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                  ),
                  indicatorSize: TabBarIndicatorSize.label,
                  indicator: UnderlineTabIndicator(
                    borderRadius: BorderRadius.circular(2),
                    borderSide: BorderSide(width: 3, color: primary),
                  ),
                  tabs: [
                    const Tab(text: '简介'),
                    Tab(
                      text: _comments.isEmpty
                          ? '评论'
                          : '评论 ${_comments.length}',
                    ),
                  ],
                ),
                const Spacer(),
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => _openSendBarrageSheet(context),
                  child: Container(
                    height: 28,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? const Color(0xFF252934)
                          : const Color(0xFFF3F4F7),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      '点我发弹幕~',
                      style: TextStyle(
                        fontSize: 11.5,
                        color: Theme.of(context).hintColor,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(
                    () => _danmakuConfig = _danmakuConfig.copyWith(
                      enabled: !_danmakuConfig.enabled,
                    ),
                  ),
                  onLongPress: () => _openDanmakuSettingsSheet(context),
                  child: Padding(
                    padding: const EdgeInsets.all(5),
                    child: Icon(
                      _danmakuConfig.enabled
                          ? Icons.subtitles_rounded
                          : Icons.subtitles_off_outlined,
                      size: 21,
                      color: _danmakuConfig.enabled
                          ? primary
                          : Theme.of(context).hintColor,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Body + Floating 5-Button Capsule Dock
          Expanded(
            child: _loading || _detail == null
                ? const Center(child: CircularProgressIndicator())
                : Stack(
                    children: [
                      TabBarView(
                        controller: _subTabController,
                        children: [
                          _buildIntroTab(context, _detail!),
                          _buildCommentsTab(context, _detail!),
                        ],
                      ),
                      if (_activeSubTab == 0)
                        Positioned(
                          left: 24,
                          right: 24,
                          bottom: 14 + MediaQuery.of(context).padding.bottom,
                          child: _buildFloatingCapsuleDock(context, _detail!),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerStage(BuildContext context, {required bool fullscreen}) {
    final d = _detail;
    final epTitle = (d != null &&
            d.playLines.isNotEmpty &&
            d.playLines[_lineIndex].episodes.isNotEmpty)
        ? '${d.item.vodName} · 第${d.playLines[_lineIndex].episodes[_episodeIndex].title}集'
        : (d?.item.vodName ?? '加载中...');

    return LayoutBuilder(
      builder: (ctx, box) {
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            setState(() => _showOsd = !_showOsd);
            if (_showOsd) _scheduleOsdAutoHide();
          },
          onDoubleTap: _screenLocked
              ? null
              : () {
                  _mpv?.player.playOrPause();
                  setState(() => _showOsd = true);
                  _scheduleOsdAutoHide();
                },
          onLongPressStart: _screenLocked
              ? null
              : (_) {
                  setState(() => _longPressBoosting = true);
                  _mpv?.player.setRate(3.0);
                },
          onLongPressEnd: _screenLocked
              ? null
              : (_) {
                  setState(() => _longPressBoosting = false);
                  _mpv?.player.setRate(_playbackRate);
                },
          onHorizontalDragUpdate: _screenLocked
              ? null
              : (details) {
                  if (_duration.inSeconds <= 0) return;
                  final deltaSec =
                      ((details.primaryDelta ?? 0) / box.maxWidth * 90).round();
                  final base = (_dragSeekTarget ?? _position).inSeconds;
                  final next =
                      (base + deltaSec).clamp(0, _duration.inSeconds);
                  setState(() {
                    _dragSeekTarget = Duration(seconds: next);
                    _gestureHint =
                        '${_fmtDuration(_dragSeekTarget!)} / ${_fmtDuration(_duration)}';
                  });
                },
          onHorizontalDragEnd: _screenLocked
              ? null
              : (_) {
                  if (_dragSeekTarget != null) {
                    _mpv?.player.seek(_dragSeekTarget!);
                  }
                  setState(() {
                    _dragSeekTarget = null;
                    _gestureHint = null;
                  });
                },
          onVerticalDragUpdate: _screenLocked
              ? null
              : (details) {
                  final dy = -(details.primaryDelta ?? 0);
                  final isLeft = details.localPosition.dx < box.maxWidth / 2;
                  if (isLeft) {
                    final nextDim =
                        (_brightnessOverlay - dy / 260).clamp(0.0, 0.65);
                    final pct = ((1 - nextDim / 0.65) * 100).round();
                    setState(() {
                      _brightnessOverlay = nextDim;
                      _gestureHint = '亮度 $pct%';
                    });
                  } else {
                    final nextVol = (_volume + dy / 2.2).clamp(0.0, 100.0);
                    _mpv?.player.setVolume(nextVol);
                    setState(() {
                      _volume = nextVol;
                      _gestureHint = '音量 ${nextVol.round()}%';
                    });
                  }
                },
          onVerticalDragEnd: _screenLocked
              ? null
              : (_) => setState(() => _gestureHint = null),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // 1. MPV Hardware Video Surface
              if (_mpv != null)
                Video(
                  controller: _mpv!.videoController,
                  controls: NoVideoControls,
                )
              else if (d != null)
                NetworkPoster(url: d.item.pic),

              // 2. Danmaku Overlay
              IgnorePointer(
                ignoring: false,
                child: DanmakuStage(
                  items: _barrages,
                  playbackSeconds: _position.inMilliseconds / 1000.0,
                  config: _danmakuConfig,
                  onReportTap: (b) {
                    Get.find<ApiService>().reportContent(
                      isBarrage: true,
                      targetId: b.id,
                      reason: '用户举报弹幕',
                    );
                    Get.snackbar('已提交举报', '感谢共同维护弹幕礼仪');
                  },
                ),
              ),

              // 3. Simulated Screen Dimming Overlay for left-side brightness gesture
              if (_brightnessOverlay > 0)
                IgnorePointer(
                  child: Container(
                    color: Colors.black.withOpacity(_brightnessOverlay),
                  ),
                ),

              // 4. Buffering Spinner
              if (_isBuffering)
                const Center(
                  child: CircularProgressIndicator(color: Colors.white),
                ),

              // 5. Long-press 3x speed indicator
              if (_longPressBoosting)
                Positioned(
                  top: 14,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black87,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.fast_forward_rounded,
                              color: Colors.cyanAccent, size: 18),
                          SizedBox(width: 4),
                          Text(
                            '3.0x 倍速播放中',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              // 6. Seek / Volume / Brightness Gesture Pill
              if (_gestureHint != null)
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      _gestureHint!,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),

              // 7. OSD Top/Bottom Controls + Lock Button
              if (_showOsd) ...[
                if (!_screenLocked) ...[
                  // Top Bar
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(4, 4, 8, 12),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.black87, Colors.transparent],
                        ),
                      ),
                      child: Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              if (fullscreen) {
                                _exitFullscreen();
                              } else {
                                Get.back<void>();
                              }
                            },
                            icon: const Icon(
                              Icons.arrow_back_rounded,
                              color: Colors.white,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              epTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: '画中画小窗',
                            onPressed: () async {
                              final ok =
                                  await _mpv?.enterPictureInPicture() ?? false;
                              if (!ok) {
                                Get.snackbar('提示', '当前设备环境暂不支持小窗模式');
                              }
                            },
                            icon: const Icon(
                              Icons.picture_in_picture_alt_rounded,
                              color: Colors.white,
                              size: 21,
                            ),
                          ),
                          IconButton(
                            tooltip: '外部播放/投屏',
                            onPressed: () => _openCastOrExternalSheet(context),
                            icon: const Icon(
                              Icons.live_tv_rounded,
                              color: Colors.white,
                              size: 21,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Bottom Bar
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(6, 12, 6, 4),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Colors.black87, Colors.transparent],
                        ),
                      ),
                      child: Row(
                        children: [
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            onPressed: () => _mpv?.player.playOrPause(),
                            icon: Icon(
                              _isPlaying
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded,
                              color: Colors.white,
                              size: 26,
                            ),
                          ),
                          Text(
                            '${_fmtDuration(_position)}/${_fmtDuration(_duration)}',
                            style: const TextStyle(
                                color: Colors.white, fontSize: 11),
                          ),
                          Expanded(
                            child: SliderTheme(
                              data: SliderTheme.of(context).copyWith(
                                trackHeight: 2.5,
                                thumbShape: const RoundSliderThumbShape(
                                    enabledThumbRadius: 6),
                                overlayShape: const RoundSliderOverlayShape(
                                    overlayRadius: 12),
                              ),
                              child: Slider(
                                value: _duration.inSeconds > 0
                                    ? _position.inSeconds
                                        .clamp(0, _duration.inSeconds)
                                        .toDouble()
                                    : 0.0,
                                max: _duration.inSeconds > 0
                                    ? _duration.inSeconds.toDouble()
                                    : 1.0,
                                activeColor:
                                    Theme.of(context).colorScheme.primary,
                                inactiveColor: Colors.white30,
                                onChanged: (v) {
                                  _mpv?.player
                                      .seek(Duration(seconds: v.round()));
                                },
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () => _openSpeedShaderSheet(context),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 6),
                              child: Text(
                                _playbackRate == 1.0
                                    ? '倍速'
                                    : '${_playbackRate}x',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          InkWell(
                            onTap: () => _openDanmakuSettingsSheet(context),
                            child: const Padding(
                              padding: EdgeInsets.symmetric(horizontal: 6),
                              child: Text(
                                '弹幕',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            onPressed: _toggleFullscreen,
                            icon: Icon(
                              fullscreen
                                  ? Icons.fullscreen_exit_rounded
                                  : Icons.fullscreen_rounded,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],

                // Left Lock Button
                Positioned(
                  left: 10,
                  top: 0,
                  bottom: 0,
                  child: Center(
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: () =>
                          setState(() => _screenLocked = !_screenLocked),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: const BoxDecoration(
                          color: Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _screenLocked
                              ? Icons.lock_rounded
                              : Icons.lock_open_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildIntroTab(BuildContext context, VodDetail detail) {
    final primary = Theme.of(context).colorScheme.primary;
    final line = detail.playLines.isNotEmpty
        ? detail.playLines[_lineIndex]
        : const VodPlayLine(lineId: 'default', lineName: '主线路', episodes: []);

    return ListView(
      padding: const EdgeInsets.only(bottom: 92),
      children: [
        // 1. Title & 简介 >
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  detail.item.vodName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 17.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              InkWell(
                onTap: () => _openFullIntroSheet(context, detail.item),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    '简介 >',
                    style: TextStyle(
                      fontSize: 13,
                      color: Theme.of(context).hintColor,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Text(
            detail.item.summary,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12.5,
              height: 1.4,
              color: Theme.of(context).hintColor,
            ),
          ),
        ),

        // 2. 选集 & 展开 ↕
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 16, 14, 10),
          child: Row(
            children: [
              const Text(
                '选集',
                style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                decoration: BoxDecoration(
                  color: primary.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  line.lineName,
                  style: TextStyle(
                    fontSize: 11,
                    color: primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Spacer(),
              InkWell(
                onTap: () => _openFullEpisodeSheet(context, detail),
                child: Text(
                  '展开 ↕',
                  style: TextStyle(
                    fontSize: 12.5,
                    color: Theme.of(context).hintColor,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Horizontal Episode Strip
        SizedBox(
          height: 44,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            scrollDirection: Axis.horizontal,
            itemCount: line.episodes.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (ctx, i) {
              final ep = line.episodes[i];
              final selected = i == _episodeIndex;
              return InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () {
                  setState(() => _episodeIndex = i);
                  _startEpisodePlayback();
                },
                child: Container(
                  constraints: const BoxConstraints(minWidth: 52),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected
                        ? primary.withOpacity(0.12)
                        : (Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF222630)
                            : const Color(0xFFF5F6F8)),
                    borderRadius: BorderRadius.circular(8),
                    border: selected
                        ? Border.all(color: primary, width: 1.2)
                        : null,
                  ),
                  child: Text(
                    ep.title,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight:
                          selected ? FontWeight.w700 : FontWeight.w500,
                      color: selected ? primary : null,
                    ),
                  ),
                ),
              );
            },
          ),
        ),

        // 3. 精彩推荐 3-column grid
        if (detail.recommendations.isNotEmpty) ...[
          const SizedBox(height: 6),
          const LanercSectionHeader(title: '精彩推荐'),
          GridView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: detail.recommendations.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 12,
              crossAxisSpacing: 10,
              childAspectRatio: 0.56,
            ),
            itemBuilder: (ctx, i) {
              final rec = detail.recommendations[i];
              return VodCard(
                item: rec,
                onTapOverride: () => _loadVod(rec.vodId),
              );
            },
          ),
        ],
      ],
    );
  }

  Widget _buildCommentsTab(BuildContext context, VodDetail detail) {
    final commentCtrl = TextEditingController();
    final userCtrl = Get.find<UserController>();

    return Column(
      children: [
        Expanded(
          child: _comments.isEmpty
              ? Center(
                  child: Text(
                    '还没有评论，快来抢沙发吧～',
                    style: TextStyle(color: Theme.of(context).hintColor),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.all(14),
                  itemCount: _comments.length,
                  separatorBuilder: (_, __) => const Divider(height: 22),
                  itemBuilder: (ctx, i) {
                    final c = _comments[i];
                    return GestureDetector(
                      onLongPress: () {
                        Get.find<ApiService>().reportContent(
                          isBarrage: false,
                          targetId: c.id,
                          reason: '举报不当评论',
                        );
                        Get.snackbar('已提交举报', '我们会尽快审核处理');
                      },
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius: 17,
                            backgroundColor: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.15),
                            child: Text(
                              c.userName.characters.first,
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      c.userName,
                                      style: const TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      c.createdAt,
                                      style: TextStyle(
                                        fontSize: 11,
                                        color: Theme.of(context).hintColor,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  c.content,
                                  style: const TextStyle(
                                      fontSize: 13.5, height: 1.4),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              border: Border(
                top: BorderSide(color: Theme.of(context).dividerColor),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: commentCtrl,
                    decoration: InputDecoration(
                      hintText: userCtrl.passedQuiz.value
                          ? '理性讨论，友善发言...'
                          : '通过入站问答后即可发言 (点击右侧前往)',
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () async {
                    if (!userCtrl.passedQuiz.value) {
                      Get.toNamed(AppRoutes.question);
                      return;
                    }
                    final text = commentCtrl.text.trim();
                    if (text.isEmpty) return;
                    final item = await Get.find<ApiService>().sendComment(
                      vodId: detail.item.vodId,
                      userName: userCtrl.profile.value?.nickName ?? '追番旅人',
                      content: text,
                    );
                    commentCtrl.clear();
                    if (mounted) {
                      setState(() => _comments = [item, ..._comments]);
                    }
                  },
                  child: Text(userCtrl.passedQuiz.value ? '发送' : '去答题'),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Floating dark translucent 5-button capsule dock: 收藏 | 反馈 | 换源 | 缓存 | 分享
  Widget _buildFloatingCapsuleDock(BuildContext context, VodDetail detail) {
    final userCtrl = Get.find<UserController>();
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0xE01C2026),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 12,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Obx(() {
        final fav = userCtrl.isFavorite(detail.item.vodId);
        return Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _DockAction(
              icon: fav ? Icons.star_rounded : Icons.star_border_rounded,
              color: fav ? const Color(0xFFFFC107) : Colors.white70,
              label: fav ? '已收藏' : '收藏',
              onTap: () async {
                final added = await userCtrl.toggleFavorite(detail.item);
                Get.snackbar(
                  added ? '已加入收藏' : '已取消收藏',
                  detail.item.vodName,
                  duration: const Duration(seconds: 1),
                );
              },
            ),
            _DockAction(
              icon: Icons.warning_amber_rounded,
              label: '反馈',
              onTap: () => Get.toNamed(
                AppRoutes.errarea,
                arguments: detail.item,
              ),
            ),
            _DockAction(
              icon: Icons.swap_horiz_rounded,
              label: '换源',
              onTap: () => _openSwitchSourceSheet(context, detail),
            ),
            _DockAction(
              icon: Icons.arrow_circle_down_rounded,
              label: '缓存',
              onTap: () => _openDownloadEpisodeSheet(context, detail),
            ),
            _DockAction(
              icon: Icons.share_rounded,
              label: '分享',
              onTap: () => Share.share(
                  '正在看《${detail.item.vodName}》，强烈推荐！'),
            ),
          ],
        );
      }),
    );
  }

  void _openFullIntroSheet(BuildContext context, VodItem item) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      item.vodName,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                  ),
                  Text(
                    '${item.score} 分',
                    style: const TextStyle(
                      color: Colors.amber,
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                '${item.category} · ${item.year} · 导演：${item.director} · ${item.remarks}',
                style: TextStyle(fontSize: 12.5, color: Theme.of(ctx).hintColor),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                children: item.genres
                    .map((g) => Chip(
                          label: Text(g, style: const TextStyle(fontSize: 11.5)),
                          visualDensity: VisualDensity.compact,
                        ))
                    .toList(),
              ),
              const SizedBox(height: 10),
              Text(
                item.summary,
                style: const TextStyle(fontSize: 13.5, height: 1.55),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openFullEpisodeSheet(BuildContext context, VodDetail detail) {
    bool reversed = false;
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) {
          final eps = detail.playLines[_lineIndex].episodes;
          final indices = List.generate(eps.length, (i) => i);
          final ordered = reversed ? indices.reversed.toList() : indices;
          final primary = Theme.of(ctx).colorScheme.primary;
          return SafeArea(
            child: SizedBox(
              height: 360,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 0, 14, 8),
                    child: Row(
                      children: [
                        Text(
                          '全部选集 (${eps.length})',
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                        const Spacer(),
                        TextButton.icon(
                          onPressed: () =>
                              setModal(() => reversed = !reversed),
                          icon: const Icon(Icons.swap_vert_rounded, size: 18),
                          label: Text(reversed ? '倒序' : '正序'),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                      itemCount: ordered.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        childAspectRatio: 2.1,
                      ),
                      itemBuilder: (_, idx) {
                        final realIdx = ordered[idx];
                        final ep = eps[realIdx];
                        final selected = realIdx == _episodeIndex;
                        return InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () {
                            Navigator.of(ctx).pop();
                            setState(() => _episodeIndex = realIdx);
                            _startEpisodePlayback();
                          },
                          child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: selected
                                  ? primary.withOpacity(0.14)
                                  : Theme.of(ctx).dividerColor,
                              borderRadius: BorderRadius.circular(8),
                              border: selected
                                  ? Border.all(color: primary)
                                  : null,
                            ),
                            child: Text(
                              ep.title,
                              style: TextStyle(
                                color: selected ? primary : null,
                                fontWeight: selected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _openSwitchSourceSheet(BuildContext context, VodDetail detail) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '切换播放线路',
                style: TextStyle(fontSize: 16.5, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: List.generate(detail.playLines.length, (i) {
                  final line = detail.playLines[i];
                  return ChoiceChip(
                    selected: i == _lineIndex,
                    label: Text(line.lineName),
                    onSelected: (_) {
                      Navigator.of(ctx).pop();
                      setState(() {
                        _lineIndex = i;
                        if (_episodeIndex >= line.episodes.length) {
                          _episodeIndex = 0;
                        }
                      });
                      _startEpisodePlayback(seekToSeconds: _position.inSeconds);
                    },
                  );
                }),
              ),
              const SizedBox(height: 18),
              const Text(
                'Anime4K 超分画质增强 (GLSL)',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: ShaderSuperResMode.values.map((mode) {
                  final active = _mpv?.currentShaderMode == mode;
                  return ChoiceChip(
                    selected: active,
                    label: Text(mode.label),
                    onSelected: (_) async {
                      await _mpv?.applyShaderMode(mode);
                      if (ctx.mounted) Navigator.of(ctx).pop();
                      setState(() {});
                      Get.snackbar('画质设置已更新', mode.label,
                          duration: const Duration(seconds: 1));
                    },
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openSpeedShaderSheet(BuildContext context) {
    const rates = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0];
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '播放倍速 (提示：长按画面可临时 3.0x 快进)',
                style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: rates.map((r) {
                  return ChoiceChip(
                    selected: _playbackRate == r,
                    label: Text('${r}x'),
                    onSelected: (_) {
                      setState(() => _playbackRate = r);
                      _mpv?.player.setRate(r);
                      Navigator.of(ctx).pop();
                    },
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDanmakuSettingsSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      '弹幕设置',
                      style:
                          TextStyle(fontSize: 16.5, fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    Switch(
                      value: _danmakuConfig.enabled,
                      onChanged: (v) {
                        setState(() =>
                            _danmakuConfig = _danmakuConfig.copyWith(enabled: v));
                        setModal(() {});
                      },
                    ),
                  ],
                ),
                Text('不透明度 ${(_danmakuConfig.opacity * 100).round()}%'),
                Slider(
                  value: _danmakuConfig.opacity,
                  min: 0.2,
                  max: 1.0,
                  onChanged: (v) {
                    setState(() =>
                        _danmakuConfig = _danmakuConfig.copyWith(opacity: v));
                    setModal(() {});
                  },
                ),
                Text('字号大小 ${_danmakuConfig.fontSize.round()}'),
                Slider(
                  value: _danmakuConfig.fontSize,
                  min: 12,
                  max: 24,
                  onChanged: (v) {
                    setState(() =>
                        _danmakuConfig = _danmakuConfig.copyWith(fontSize: v));
                    setModal(() {});
                  },
                ),
                Text('显示区域 ${(_danmakuConfig.areaRatio * 100).round()}%'),
                Slider(
                  value: _danmakuConfig.areaRatio,
                  min: 0.25,
                  max: 1.0,
                  divisions: 3,
                  onChanged: (v) {
                    setState(() =>
                        _danmakuConfig = _danmakuConfig.copyWith(areaRatio: v));
                    setModal(() {});
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _openSendBarrageSheet(BuildContext context) {
    final userCtrl = Get.find<UserController>();
    if (!userCtrl.passedQuiz.value) {
      Get.snackbar('提示', '完成入站问答后即可发送弹幕～');
      Get.toNamed(AppRoutes.question);
      return;
    }
    final ctrl = TextEditingController();
    int selectedColor = 0xFFFFFFFF;
    bool pinTop = false;
    const colors = [
      0xFFFFFFFF,
      0xFFFF5252,
      0xFFFFD54F,
      0xFF69F0AE,
      0xFF40C4FF,
      0xFFE040FB,
    ];

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(
            16,
            4,
            16,
            16 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  for (final c in colors)
                    GestureDetector(
                      onTap: () => setModal(() => selectedColor = c),
                      child: Container(
                        width: 24,
                        height: 24,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          color: Color(c),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: selectedColor == c
                                ? Theme.of(ctx).colorScheme.primary
                                : Colors.grey.shade400,
                            width: selectedColor == c ? 2.5 : 1,
                          ),
                        ),
                      ),
                    ),
                  const Spacer(),
                  FilterChip(
                    selected: pinTop,
                    label: const Text('顶部弹幕'),
                    onSelected: (v) => setModal(() => pinTop = v),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: ctrl,
                      autofocus: true,
                      decoration: const InputDecoration(
                        hintText: '发一条友善的弹幕见证此刻...',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: () async {
                      final text = ctrl.text.trim();
                      if (text.isEmpty || _detail == null) return;
                      final ep =
                          _detail!.playLines[_lineIndex].episodes[_episodeIndex];
                      final sent = await Get.find<ApiService>().sendBarrage(
                        vodId: _detail!.item.vodId,
                        episodeIndex: ep.index,
                        timeSeconds: _position.inMilliseconds / 1000.0 + 0.2,
                        content: text,
                        colorHex: selectedColor,
                        isTop: pinTop,
                      );
                      if (ctx.mounted) Navigator.of(ctx).pop();
                      if (mounted) {
                        setState(() => _barrages = [..._barrages, sent]);
                      }
                    },
                    child: const Text('发送'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDownloadEpisodeSheet(BuildContext context, VodDetail detail) {
    final dlCtrl = Get.find<DownloadController>();
    final line = detail.playLines[_lineIndex];
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 320,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 12, 8),
                child: Row(
                  children: [
                    const Text(
                      '选择离线缓存剧集',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        Get.toNamed(AppRoutes.cache);
                      },
                      child: const Text('查看缓存列表 >'),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                  itemCount: line.episodes.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 2.1,
                  ),
                  itemBuilder: (_, i) {
                    final ep = line.episodes[i];
                    return OutlinedButton(
                      onPressed: () {
                        dlCtrl.enqueueEpisode(
                          item: detail.item,
                          line: line,
                          episode: ep,
                        );
                        Get.snackbar(
                          '已加入离线缓存',
                          '${detail.item.vodName} 第${ep.title}集',
                          duration: const Duration(seconds: 1),
                        );
                      },
                      child: Text(ep.title),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openCastOrExternalSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.open_in_new_rounded),
                title: const Text('调用外部播放器打开'),
                subtitle: const Text('支持系统播放器或第三方本地播放器'),
                onTap: () async {
                  Navigator.of(ctx).pop();
                  final uri = Uri.tryParse(_currentStreamUrl);
                  if (uri != null) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.copy_rounded),
                title: const Text('复制当前视频直链'),
                subtitle: const Text('可用于局域网电视/投影仪投屏播放'),
                onTap: () {
                  Clipboard.setData(ClipboardData(text: _currentStreamUrl));
                  Navigator.of(ctx).pop();
                  Get.snackbar('复制成功', '流媒体播放链接已复制到剪贴板');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DockAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _DockAction({
    required this.icon,
    required this.label,
    this.color = Colors.white70,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 10.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
