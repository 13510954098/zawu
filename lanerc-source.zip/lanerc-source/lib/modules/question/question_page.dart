import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/network/mock_demo_data.dart';
import '../../core/state/user_controller.dart';
import '../../widgets/lanerc_ui.dart';

class QuestionPage extends StatefulWidget {
  @override
  State<QuestionPage> createState() => _QuestionPageState();
}

class _QuestionPageState extends State<QuestionPage> {
  final Map<int, int> _answers = {};

  Future<void> _submitQuiz() async {
    const questions = MockDemoData.entryQuiz;
    if (_answers.length < questions.length) {
      Get.snackbar('提示', '请先答完所有题目再提交哦～');
      return;
    }
    int correct = 0;
    for (final q in questions) {
      if (_answers[q.id] == q.answerIndex) correct++;
    }
    if (correct >= questions.length - 1) {
      await Get.find<UserController>().markQuizPassed();
      Get.back<void>();
      Get.snackbar('恭喜通过！', '答对 $correct/${questions.length} 题，已解锁弹幕与评论发言权限～');
    } else {
      Get.snackbar(
        '还差一点点',
        '当前答对 $correct/${questions.length} 题，至少答对 ${questions.length - 1} 题即可通过',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final userCtrl = Get.find<UserController>();
    const questions = MockDemoData.entryQuiz;

    return Scaffold(
      appBar: const LanercSubAppBar(title: '入站问答'),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
        children: [
          Obx(
            () => userCtrl.passedQuiz.value
                ? Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.verified_rounded, color: Colors.green),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '您已通过入站问答，可自由发送弹幕与评论！',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  )
                : const SizedBox.shrink(),
          ),
          for (int i = 0; i < questions.length; i++) ...[
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Q${i + 1}. ${questions[i].question}',
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 8),
                  for (int optIdx = 0;
                      optIdx < questions[i].options.length;
                      optIdx++)
                    RadioListTile<int>(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      value: optIdx,
                      groupValue: _answers[questions[i].id],
                      onChanged: (val) {
                        if (val != null) {
                          setState(() => _answers[questions[i].id] = val);
                        }
                      },
                      title: Text(
                        questions[i].options[optIdx],
                        style: const TextStyle(fontSize: 13.5),
                      ),
                    ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 8),
          SizedBox(
            height: 44,
            child: FilledButton(
              onPressed: _submitQuiz,
              child: const Text(
                '提交答卷',
                style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
