import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/models/vod_models.dart';
import '../../core/storage/local_database.dart';
import '../../widgets/lanerc_ui.dart';

class HistoryPage extends StatefulWidget {
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<HistoryRecord> _records = const [];
  bool _loading = true;
  bool _editing = false;
  final Set<int> _selectedIds = {};

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final list = await LocalDatabase.instance.getHistoryList();
    if (!mounted) return;
    setState(() {
      _records = list;
      _loading = false;
    });
  }

  String _formatWatchTime(int epochMs) {
    final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
    final now = DateTime.now();
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    if (dt.year == now.year && dt.month == now.month && dt.day == now.day) {
      return '今天 $hh:$mm';
    }
    return '${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')} $hh:$mm';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: LanercSubAppBar(
        title: '历史记录',
        actionText: _records.isEmpty ? null : (_editing ? '完成' : '编辑'),
        onActionTap: () => setState(() {
          _editing = !_editing;
          _selectedIds.clear();
        }),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _records.isEmpty
              ? Center(
                  child: Text(
                    '暂无观看历史记录',
                    style: TextStyle(color: Theme.of(context).hintColor),
                  ),
                )
              : Column(
                  children: [
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.fromLTRB(12, 10, 12, 20),
                        itemCount: _records.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 14),
                        itemBuilder: (ctx, i) {
                          final r = _records[i];
                          final checked = _selectedIds.contains(r.vodID);
                          final tag = r.vodClass == 2 ? '剧场版' : '日漫';
                          return InkWell(
                            borderRadius: BorderRadius.circular(8),
                            onTap: () async {
                              if (_editing) {
                                setState(() {
                                  if (checked) {
                                    _selectedIds.remove(r.vodID);
                                  } else {
                                    _selectedIds.add(r.vodID);
                                  }
                                });
                                return;
                              }
                              await Get.toNamed(AppRoutes.videoPath(r.vodID));
                              _reload();
                            },
                            child: Row(
                              children: [
                                if (_editing)
                                  Checkbox(
                                    value: checked,
                                    onChanged: (_) {
                                      setState(() {
                                        if (checked) {
                                          _selectedIds.remove(r.vodID);
                                        } else {
                                          _selectedIds.add(r.vodID);
                                        }
                                      });
                                    },
                                  ),
                                // 16:9 Thumbnail with top-right category pill
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: SizedBox(
                                    width: 136,
                                    height: 82,
                                    child: Stack(
                                      fit: StackFit.expand,
                                      children: [
                                        NetworkPoster(url: r.pic),
                                        Positioned(
                                          right: 5,
                                          top: 5,
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: Colors.black54,
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                            child: Text(
                                              tag,
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 10,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: SizedBox(
                                    height: 82,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          r.vodName,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 14.5,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 5),
                                        Text(
                                          '已看到第${r.vodSelect}集',
                                          style: TextStyle(
                                            fontSize: 12.5,
                                            color: Theme.of(context).hintColor,
                                          ),
                                        ),
                                        const Spacer(),
                                        Text(
                                          _formatWatchTime(r.lastTime),
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Theme.of(context).hintColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    if (_editing)
                      SafeArea(
                        top: false,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: Theme.of(context).cardColor,
                            border: Border(
                              top: BorderSide(
                                  color: Theme.of(context).dividerColor),
                            ),
                          ),
                          child: Row(
                            children: [
                              TextButton(
                                onPressed: () async {
                                  await LocalDatabase.instance.clearAllHistory();
                                  setState(() {
                                    _editing = false;
                                    _selectedIds.clear();
                                  });
                                  _reload();
                                },
                                child: const Text('清空全部'),
                              ),
                              const Spacer(),
                              FilledButton(
                                onPressed: _selectedIds.isEmpty
                                    ? null
                                    : () async {
                                        await LocalDatabase.instance
                                            .deleteHistoryBatch(_selectedIds);
                                        setState(() {
                                          _editing = false;
                                          _selectedIds.clear();
                                        });
                                        _reload();
                                      },
                                child: Text('删除 (${_selectedIds.length})'),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }
}
