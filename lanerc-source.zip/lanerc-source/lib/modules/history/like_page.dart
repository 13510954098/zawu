import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/state/user_controller.dart';
import '../../widgets/lanerc_ui.dart';
import '../../widgets/vod_card.dart';

class LikePage extends StatefulWidget {
  @override
  State<LikePage> createState() => _LikePageState();
}

class _LikePageState extends State<LikePage> {
  bool _editing = false;
  final Set<int> _selected = {};

  @override
  Widget build(BuildContext context) {
    final userCtrl = Get.find<UserController>();
    return Obx(() {
      final favs = userCtrl.favorites;
      return Scaffold(
        appBar: LanercSubAppBar(
          title: '我的收藏',
          actionText: favs.isEmpty ? null : (_editing ? '完成' : '编辑'),
          onActionTap: () => setState(() {
            _editing = !_editing;
            _selected.clear();
          }),
        ),
        body: favs.isEmpty
            ? Center(
                child: Text(
                  '还没有收藏番剧哦，在播放页点击底部「收藏」即可添加～',
                  style: TextStyle(color: Theme.of(context).hintColor),
                ),
              )
            : Column(
                children: [
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.fromLTRB(12, 10, 12, 20),
                      itemCount: favs.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        mainAxisSpacing: 12,
                        crossAxisSpacing: 10,
                        childAspectRatio: 0.56,
                      ),
                      itemBuilder: (_, idx) {
                        final item = favs[idx];
                        final checked = _selected.contains(item.vodId);
                        return Stack(
                          children: [
                            VodCard(
                              item: item,
                              onTapOverride: _editing
                                  ? () {
                                      setState(() {
                                        if (checked) {
                                          _selected.remove(item.vodId);
                                        } else {
                                          _selected.add(item.vodId);
                                        }
                                      });
                                    }
                                  : null,
                            ),
                            if (_editing)
                              Positioned(
                                right: 6,
                                top: 6,
                                child: CircleAvatar(
                                  radius: 12,
                                  backgroundColor: checked
                                      ? Theme.of(context).colorScheme.primary
                                      : Colors.black54,
                                  child: Icon(
                                    checked
                                        ? Icons.check_rounded
                                        : Icons.circle_outlined,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                  ),
                  if (_editing)
                    SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: _selected.isEmpty
                                ? null
                                : () async {
                                    await userCtrl.removeFavoriteIds(_selected);
                                    setState(() {
                                      _editing = false;
                                      _selected.clear();
                                    });
                                  },
                            child: Text('取消收藏 (${_selected.length})'),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
      );
    });
  }
}
