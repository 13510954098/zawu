import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/state/user_controller.dart';
import '../../core/storage/local_database.dart';
import '../../widgets/lanerc_ui.dart';

class RecoverPage extends StatefulWidget {
  @override
  State<RecoverPage> createState() => _RecoverPageState();
}

class _RecoverPageState extends State<RecoverPage> {
  final TextEditingController _jsonCtrl = TextEditingController();

  @override
  void dispose() {
    _jsonCtrl.dispose();
    super.dispose();
  }

  Future<void> _exportBackup() async {
    final raw = await LocalDatabase.instance.exportBackupJson();
    setState(() => _jsonCtrl.text = raw);
    await Clipboard.setData(ClipboardData(text: raw));
    Get.snackbar('导出成功', '备份数据已生成并自动复制到剪贴板');
  }

  Future<void> _importBackup() async {
    final text = _jsonCtrl.text.trim();
    if (text.isEmpty) {
      Get.snackbar('提示', '请先粘贴备份数据内容');
      return;
    }
    try {
      final count = await LocalDatabase.instance.importBackupJson(text);
      Get.find<UserController>().reloadFromStorage();
      Get.snackbar('恢复成功', '已成功恢复 $count 条追番与历史记录！');
    } catch (e) {
      Get.snackbar('恢复失败', '备份格式无效：$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const LanercSubAppBar(title: '数据恢复'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              '支持一键备份与迁移「我的收藏、观看历史进度、入站问答状态与金币余额」。换机前点击下方导出备份，在新设备上粘贴并点击恢复即可。',
              style: TextStyle(fontSize: 13, height: 1.45),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _exportBackup,
                  icon: const Icon(Icons.upload_file_rounded, size: 19),
                  label: const Text('导出并复制备份'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final raw = await LocalDatabase.instance.exportBackupJson();
                    await Share.share(raw, subject: '追番备份数据');
                  },
                  icon: const Icon(Icons.share_outlined, size: 19),
                  label: const Text('分享备份文本'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          TextField(
            controller: _jsonCtrl,
            maxLines: 9,
            decoration: InputDecoration(
              hintText: '在此粘贴导出的备份 JSON 内容以执行数据恢复...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              OutlinedButton(
                onPressed: () async {
                  final clip = await Clipboard.getData('text/plain');
                  if (clip?.text != null) {
                    setState(() => _jsonCtrl.text = clip!.text!);
                  }
                },
                child: const Text('从剪贴板粘贴'),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: _importBackup,
                  child: const Text('立即恢复数据'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
