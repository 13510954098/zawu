import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/vod_models.dart';
import '../../core/network/api_service.dart';
import '../../core/network/mock_demo_data.dart';
import '../../core/storage/local_database.dart';
import '../../widgets/lanerc_ui.dart';
import '../../widgets/vod_card.dart';

class SearchPage extends StatefulWidget {
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _ctrl = TextEditingController();
  List<String> _history = const [];
  List<VodItem> _results = const [];
  bool _searched = false;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _history = LocalDatabase.instance.getSearchHistory();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _doSearch(String raw) async {
    final kw = raw.trim();
    if (kw.isEmpty) {
      setState(() {
        _searched = false;
        _results = const [];
      });
      return;
    }
    _ctrl.text = kw;
    setState(() {
      _searched = true;
      _loading = true;
    });
    await LocalDatabase.instance.addSearchKeyword(kw);
    final list = await Get.find<ApiService>().searchVod(kw);
    if (!mounted) return;
    setState(() {
      _history = LocalDatabase.instance.getSearchHistory();
      _results = list;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Search Top Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 12, 8),
              child: Row(
                children: [
                  const SizedBox(width: 4),
                  const LanercBackButton(),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      height: 38,
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF20242E)
                            : const Color(0xFFF5F6F8),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: TextField(
                        controller: _ctrl,
                        autofocus: true,
                        textInputAction: TextInputAction.search,
                        onSubmitted: _doSearch,
                        onChanged: (v) {
                          if (v.trim().isEmpty && _searched) {
                            setState(() => _searched = false);
                          }
                        },
                        decoration: InputDecoration(
                          prefixIcon: const Icon(Icons.search_rounded, size: 19),
                          suffixIcon: _ctrl.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.close_rounded, size: 17),
                                  onPressed: () {
                                    _ctrl.clear();
                                    setState(() {
                                      _searched = false;
                                      _results = const [];
                                    });
                                  },
                                )
                              : null,
                          hintText: '今天你想看些什么?',
                          hintStyle: const TextStyle(fontSize: 13.5),
                          border: InputBorder.none,
                          contentPadding:
                              const EdgeInsets.symmetric(vertical: 9),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  InkWell(
                    onTap: () => _doSearch(_ctrl.text),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 4, vertical: 6),
                      child: Text(
                        '搜索',
                        style: TextStyle(
                          color: primary,
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: !_searched
                  ? _buildDiscoveryView(context)
                  : _loading
                      ? const Center(child: CircularProgressIndicator())
                      : _results.isEmpty
                          ? Center(
                              child: Text(
                                '没有找到相关番剧，换个关键词试试吧～',
                                style:
                                    TextStyle(color: Theme.of(context).hintColor),
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.only(bottom: 20),
                              itemCount: _results.length,
                              itemBuilder: (_, i) =>
                                  VodCard.rich(item: _results[i]),
                            ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDiscoveryView(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
      children: [
        if (_history.isNotEmpty) ...[
          Row(
            children: [
              const Text(
                '搜索历史',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded, size: 19),
                onPressed: () async {
                  await LocalDatabase.instance.clearSearchHistory();
                  setState(() => _history = const []);
                },
              ),
            ],
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _history
                .map(
                  (kw) => ActionChip(
                    label: Text(kw, style: const TextStyle(fontSize: 12.5)),
                    onPressed: () => _doSearch(kw),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 20),
        ],
        const Text(
          '热门搜索',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: MockDemoData.hotSearchKeywords.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 4.4,
            mainAxisSpacing: 6,
            crossAxisSpacing: 12,
          ),
          itemBuilder: (_, idx) {
            final kw = MockDemoData.hotSearchKeywords[idx];
            final badgeColor = idx == 0
                ? const Color(0xFFFF5252)
                : idx == 1
                    ? const Color(0xFFFF9100)
                    : idx == 2
                        ? const Color(0xFFFFC400)
                        : Colors.grey;
            return InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () => _doSearch(kw),
              child: Row(
                children: [
                  Container(
                    width: 18,
                    height: 18,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: badgeColor.withOpacity(idx < 3 ? 1.0 : 0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '${idx + 1}',
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: idx < 3 ? Colors.white : null,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      kw,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13.5),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
