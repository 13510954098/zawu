import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/vod_models.dart';
import '../../core/network/api_service.dart';
import '../../widgets/lanerc_ui.dart';

class ErrAreaPage extends StatefulWidget {
  @override
  State<ErrAreaPage> createState() => _ErrAreaPageState();
}

class _ErrAreaPageState extends State<ErrAreaPage> {
  static const List<String> _types = [
    '播放卡顿/加载慢',
    '视频无法播放',
    '音画不同步/字幕问题',
    '集数缺失/顺序错乱',
    '功能建议与体验反馈',
  ];

  String _selectedType = _types.first;
  final TextEditingController _descCtrl = TextEditingController();
  VodItem? _contextVod;

  @override
  void initState() {
    super.initState();
    final arg = Get.arguments;
    if (arg is VodItem) {
      _contextVod = arg;
    }
  }

  @override
  void dispose() {
    _descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const LanercSubAppBar(title: '建议反馈'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_contextVod != null)
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.09),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '关联番剧：《${_contextVod!.vodName}》 (ID: ${_contextVod!.vodId})',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          const Text(
            '问题分类',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _types.map((t) {
              return ChoiceChip(
                selected: _selectedType == t,
                label: Text(t),
                onSelected: (_) => setState(() => _selectedType = t),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          const Text(
            '详细说明',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _descCtrl,
            maxLines: 5,
            decoration: InputDecoration(
              hintText: '请描述遇到的具体情况（例如所在地区、第几集或改进想法），我们会尽快跟进修复～',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 22),
          SizedBox(
            height: 44,
            child: FilledButton(
              onPressed: () async {
                if (_descCtrl.text.trim().isEmpty) {
                  Get.snackbar('提示', '请填写简要问题描述后再提交');
                  return;
                }
                await Get.find<ApiService>().submitFeedback(
                  category: _selectedType,
                  content: _descCtrl.text.trim(),
                  vodId: _contextVod?.vodId,
                  vodName: _contextVod?.vodName,
                );
                Get.back<void>();
                Get.snackbar('感谢反馈', '我们已收到您的反馈，会尽快核实处理！');
              },
              child: const Text(
                '提交反馈',
                style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
