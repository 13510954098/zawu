import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/network/api_service.dart';
import '../../core/state/user_controller.dart';
import '../../widgets/lanerc_ui.dart';

enum _AuthMode { login, register, reset }

class AuthPage extends StatefulWidget {
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  _AuthMode _mode = _AuthMode.login;
  final TextEditingController _accountCtrl = TextEditingController();
  final TextEditingController _passwordCtrl = TextEditingController();
  final TextEditingController _nickCtrl = TextEditingController();
  bool _submitting = false;

  @override
  void dispose() {
    _accountCtrl.dispose();
    _passwordCtrl.dispose();
    _nickCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final acc = _accountCtrl.text.trim();
    final pwd = _passwordCtrl.text.trim();
    if (acc.isEmpty || pwd.length < 4) {
      Get.snackbar('提示', '请输入有效账号及至少 4 位密码');
      return;
    }
    if (_mode == _AuthMode.reset) {
      Get.snackbar('已重置', '密码已更新，请使用新密码登录');
      setState(() => _mode = _AuthMode.login);
      return;
    }

    setState(() => _submitting = true);
    try {
      final profile = await Get.find<ApiService>().loginOrRegister(
        account: acc,
        password: pwd,
        nickName: _mode == _AuthMode.register ? _nickCtrl.text.trim() : null,
        isRegister: _mode == _AuthMode.register,
      );
      await Get.find<UserController>().setLoggedInProfile(profile);
      Get.back<void>();
      Get.snackbar('欢迎回来', '你好，${profile.nickName}～');
    } catch (e) {
      Get.snackbar('登录失败', '$e');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final headerTitle = switch (_mode) {
      _AuthMode.login => "登录'",
      _AuthMode.register => "注册'",
      _AuthMode.reset => "找回密码'",
    };

    return Scaffold(
      appBar: const LanercSubAppBar(title: ''),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
        children: [
          Text(
            headerTitle,
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          Text(
            '登录后即可享受更多权益~',
            style: TextStyle(fontSize: 14, color: Theme.of(context).hintColor),
          ),
          const SizedBox(height: 32),

          if (_mode == _AuthMode.register) ...[
            TextField(
              controller: _nickCtrl,
              decoration: InputDecoration(
                labelText: '昵称',
                prefixIcon: const Icon(Icons.badge_outlined),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],

          TextField(
            controller: _accountCtrl,
            decoration: InputDecoration(
              labelText: '账号 / 邮箱',
              prefixIcon: const Icon(Icons.person_outline_rounded),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _passwordCtrl,
            obscureText: true,
            decoration: InputDecoration(
              labelText: _mode == _AuthMode.reset ? '输入新密码' : '密码',
              prefixIcon: const Icon(Icons.lock_outline_rounded),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 28),

          SizedBox(
            height: 46,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
              onPressed: _submitting ? null : _submit,
              child: Text(
                switch (_mode) {
                  _AuthMode.login => '登录',
                  _AuthMode.register => '立即注册',
                  _AuthMode.reset => '确认重置',
                },
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              InkWell(
                onTap: () => setState(
                  () => _mode = _mode == _AuthMode.register
                      ? _AuthMode.login
                      : _AuthMode.register,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text(
                    _mode == _AuthMode.register ? '返回登录' : '立即注册',
                    style: TextStyle(
                      color: primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  '|',
                  style: TextStyle(color: Theme.of(context).hintColor),
                ),
              ),
              InkWell(
                onTap: () => setState(
                  () => _mode = _mode == _AuthMode.reset
                      ? _AuthMode.login
                      : _AuthMode.reset,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Text(
                    _mode == _AuthMode.reset ? '返回登录' : '找回密码',
                    style: TextStyle(color: Theme.of(context).hintColor),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
