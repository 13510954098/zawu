import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/state/user_controller.dart';
import '../../widgets/lanerc_ui.dart';

class UserInfoPage extends StatefulWidget {
  @override
  State<UserInfoPage> createState() => _UserInfoPageState();
}

class _UserInfoPageState extends State<UserInfoPage> {
  late final TextEditingController _nickCtrl;
  late final TextEditingController _qqCtrl;

  @override
  void initState() {
    super.initState();
    final p = Get.find<UserController>().profile.value;
    _nickCtrl = TextEditingController(text: p?.nickName ?? '');
    _qqCtrl = TextEditingController(text: p?.qqNumber ?? '');
  }

  @override
  void dispose() {
    _nickCtrl.dispose();
    _qqCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userCtrl = Get.find<UserController>();
    return Scaffold(
      appBar: const LanercSubAppBar(title: '个人资料'),
      body: Obx(() {
        final p = userCtrl.profile.value;
        if (p == null) {
          return const Center(child: Text('当前未登录'));
        }
        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(
              child: CircleAvatar(
                radius: 38,
                backgroundColor:
                    Theme.of(context).colorScheme.primary.withOpacity(0.15),
                backgroundImage:
                    p.avatarUrl != null ? NetworkImage(p.avatarUrl!) : null,
                child: p.avatarUrl == null
                    ? Icon(
                        Icons.person_rounded,
                        size: 38,
                        color: Theme.of(context).colorScheme.primary,
                      )
                    : null,
              ),
            ),
            const SizedBox(height: 10),
            Center(
              child: Text(
                'UID: ${p.userId}',
                style: TextStyle(color: Theme.of(context).hintColor),
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _nickCtrl,
              decoration: const InputDecoration(
                labelText: '昵称',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _qqCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'QQ号 (可选，用于自动同步头像)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 22),
            FilledButton(
              onPressed: () async {
                await userCtrl.updateProfileInfo(
                  nickName: _nickCtrl.text.trim(),
                  qqNumber: _qqCtrl.text.trim(),
                );
                Get.snackbar('已保存', '个人资料已更新');
              },
              child: const Text('保存修改'),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent),
              onPressed: () async {
                await userCtrl.logout();
                Get.back<void>();
              },
              child: const Text('退出登录'),
            ),
          ],
        );
      }),
    );
  }
}
