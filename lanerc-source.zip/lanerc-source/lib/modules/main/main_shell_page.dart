import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/network/api_service.dart';
import '../../core/storage/local_database.dart';
import 'tabs/home_tab.dart';
import 'tabs/profile_tab.dart';
import 'tabs/welfare_tab.dart';

class MainShellPage extends StatefulWidget {
  @override
  State<MainShellPage> createState() => _MainShellPageState();
}

class _MainShellPageState extends State<MainShellPage> {
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowNotice());
  }

  Future<void> _maybeShowNotice() async {
    if (!mounted || LocalDatabase.instance.hasSeenSessionNotice) return;
    final cfg = Get.find<ApiService>().appConfig.value;
    if (cfg.noticeBody.trim().isEmpty) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) {
        final primary = Theme.of(ctx).colorScheme.primary;
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 34),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  cfg.noticeTitle,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 14),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 260),
                  child: SingleChildScrollView(
                    child: Text(
                      cfg.noticeBody,
                      style: const TextStyle(fontSize: 13.5, height: 1.55),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 42,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text(
                      '已知晓',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
    await LocalDatabase.instance.markNoticeSeen();
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: IndexedStack(
        index: _tabIndex,
        children: [
          HomeTab(),
          WelfareTab(),
          ProfileTab(),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: isDark ? const Color(0xFF232732) : const Color(0xFFF0F1F5),
              width: 0.8,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _tabIndex,
          onTap: (idx) => setState(() => _tabIndex = idx),
          backgroundColor: Theme.of(context).cardColor,
          elevation: 0,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: primary,
          unselectedItemColor: const Color(0xFF8A9099),
          selectedFontSize: 11.5,
          unselectedFontSize: 11.5,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.smart_display_outlined, size: 25),
              activeIcon: Icon(Icons.smart_display_rounded, size: 25),
              label: '首页',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.card_giftcard_rounded, size: 24),
              activeIcon: Icon(Icons.card_giftcard_rounded, size: 25),
              label: '福利',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline_rounded, size: 25),
              activeIcon: Icon(Icons.person_rounded, size: 25),
              label: '我的',
            ),
          ],
        ),
      ),
    );
  }
}
