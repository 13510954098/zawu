import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/state/user_controller.dart';
import '../../../core/storage/local_database.dart';

class WelfareTab extends StatelessWidget {
  static const List<_PerkItem> _perks = [
    _PerkItem(
      title: '7天免打扰特权',
      cost: 90,
      desc: '授权单台设备纯净畅享7天',
      icon: Icons.verified_outlined,
    ),
    _PerkItem(
      title: '30天免打扰特权',
      cost: 360,
      desc: '授权单台设备纯净畅享30天',
      icon: Icons.workspace_premium_outlined,
    ),
    _PerkItem(
      title: '永久免打扰特权+称号',
      cost: 3000,
      desc: '全设备永久免打扰及专属铭牌',
      icon: Icons.auto_awesome_outlined,
    ),
    _PerkItem(
      title: '精美周边兑换券',
      cost: 6000,
      desc: '可兑换社区限定立牌与手办礼盒',
      icon: Icons.redeem_rounded,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF111318) : const Color(0xFFF7F8FA);
    final userCtrl = Get.find<UserController>();

    return Container(
      color: bg,
      child: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
          children: [
            const Center(
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  '૮福利中心ა',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
              ),
            ),

            // Wallet Card
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primary, primary.withOpacity(0.78)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        '我的金币',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const Spacer(),
                      InkWell(
                        onTap: () => _showRulesDialog(context),
                        child: const Text(
                          '活动规则',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12.5,
                            decoration: TextDecoration.underline,
                            decorationColor: Colors.white70,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Obx(
                        () => Text(
                          '${userCtrl.coins.value}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 34,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      const Spacer(),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white70),
                          visualDensity: VisualDensity.compact,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        onPressed: () => _showRecordsSheet(context),
                        child: const Text('兑换记录', style: TextStyle(fontSize: 12.5)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    '金币可用于兑换免打扰特权和精美实体礼品哦～',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Daily Task Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        '任务列表',
                        style: TextStyle(
                          fontSize: 15.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '每日0点重置可领取次数',
                        style: TextStyle(
                          fontSize: 11.5,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Obx(
                    () => _buildTaskRow(
                      context: context,
                      title: '每日打卡领金币(${userCtrl.todayTaskCount.value}/3)',
                      subtitle: '每次完成打卡任务即可获取 30 金币',
                      buttonText:
                          userCtrl.todayTaskCount.value >= 3 ? '今日已满' : '获取奖励',
                      enabled: userCtrl.todayTaskCount.value < 3,
                      onTap: () async {
                        final ok = await userCtrl.claimDailyCoins(reward: 30);
                        if (ok) {
                          Get.snackbar('领取成功', '金币 +30，已存入我的钱包');
                        }
                      },
                    ),
                  ),
                  const Divider(height: 22),
                  Obx(
                    () => _buildTaskRow(
                      context: context,
                      title: '领取离线下载次数 (剩余 ${userCtrl.downloadQuota.value} 次)',
                      subtitle: '每次完成即可获取 5 次离线缓存权限',
                      buttonText: '获取奖励',
                      enabled: true,
                      onTap: () async {
                        await userCtrl.claimDownloadQuota(addQuota: 5);
                        Get.snackbar('领取成功', '已增加 5 次离线下载额度');
                      },
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),
            const Padding(
              padding: EdgeInsets.only(left: 2, bottom: 10),
              child: Text(
                '福利兑换',
                style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700),
              ),
            ),

            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _perks.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.28,
              ),
              itemBuilder: (ctx, i) {
                final p = _perks[i];
                return InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () async {
                    final ok = await userCtrl.redeemPerk(
                      title: p.title,
                      cost: p.cost,
                    );
                    if (ok) {
                      Get.snackbar('兑换成功', '已兑换「${p.title}」');
                    } else {
                      Get.snackbar('金币不足', '完成上方每日任务可快速积累金币哦～');
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: Theme.of(context).cardColor,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(p.icon, color: primary, size: 20),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: primary.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '${p.cost} 金币',
                                style: TextStyle(
                                  color: primary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Text(
                          p.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          p.desc,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 11,
                            color: Theme.of(context).hintColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTaskRow({
    required BuildContext context,
    required String title,
    required String subtitle,
    required String buttonText,
    required bool enabled,
    required VoidCallback onTap,
  }) {
    final primary = Theme.of(context).colorScheme.primary;
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(context).hintColor,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        SizedBox(
          height: 32,
          child: FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: enabled ? primary : Colors.grey.shade400,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
            onPressed: enabled ? onTap : null,
            child: Text(
              buttonText,
              style: const TextStyle(fontSize: 12, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }

  void _showRulesDialog(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('福利中心规则'),
        content: const Text(
          '1. 每日 00:00 自动重置每日打卡任务次数。\n'
          '2. 金币实时保存于本地与个人账户，可用于兑换免打扰特权及主题装扮。\n'
          '3. 通过「我的 -> 数据恢复」可随收藏与历史记录一并备份金币余额。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('知道了'),
          ),
        ],
      ),
    );
  }

  void _showRecordsSheet(BuildContext context) {
    final records = LocalDatabase.instance.getRedemptionRecords();
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: 320,
          child: records.isEmpty
              ? Center(
                  child: Text(
                    '暂无兑换记录',
                    style: TextStyle(color: Theme.of(ctx).hintColor),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: records.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final r = records[i];
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('${r['title']}'),
                      subtitle: Text('${r['time']}'.split('T').first),
                      trailing: Text(
                        '-${r['cost']} 金币',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }
}

class _PerkItem {
  final String title;
  final int cost;
  final String desc;
  final IconData icon;
  const _PerkItem({
    required this.title,
    required this.cost,
    required this.desc,
    required this.icon,
  });
}
