import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/vod_models.dart';
import '../../../core/network/api_service.dart';
import '../../../core/state/user_controller.dart';
import '../../../widgets/lanerc_ui.dart';
import '../../../widgets/vod_card.dart';

class HomeTab extends StatefulWidget {
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final PageController _bannerController = PageController();
  Timer? _bannerTimer;
  int _bannerPage = 0;

  bool _loadingHome = true;
  List<VodItem> _banners = const [];
  List<VodItem> _hotNew = const [];
  List<VodItem> _rimanHome = const [];
  List<VodItem> _moviesHome = const [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadHome();
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || _banners.length <= 1 || !_bannerController.hasClients) {
        return;
      }
      final next = (_bannerPage + 1) % _banners.length;
      _bannerController.animateToPage(
        next,
        duration: const Duration(milliseconds: 380),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _bannerTimer?.cancel();
    _bannerController.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadHome() async {
    setState(() => _loadingHome = true);
    try {
      final res = await Get.find<ApiService>().fetchHome();
      if (!mounted) return;
      setState(() {
        _banners = res['banners'] ?? const [];
        _hotNew = res['hotNew'] ?? const [];
        _rimanHome = res['riman'] ?? const [];
        _moviesHome = res['movies'] ?? const [];
        _loadingHome = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingHome = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final userCtrl = Get.find<UserController>();

    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Search & Avatar/History Header
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 8, 4),
            child: Row(
              children: [
                Obx(() {
                  final logged = userCtrl.isLoggedIn;
                  final avatar = userCtrl.profile.value?.avatarUrl;
                  return InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => Get.toNamed(
                        logged ? AppRoutes.userinfo : AppRoutes.auth),
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: primary.withOpacity(0.1),
                      ),
                      alignment: Alignment.center,
                      child: logged
                          ? ClipOval(
                              child: avatar != null
                                  ? Image.network(
                                      avatar,
                                      width: 34,
                                      height: 34,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Icon(
                                        Icons.person_rounded,
                                        color: primary,
                                        size: 20,
                                      ),
                                    )
                                  : Icon(
                                      Icons.person_rounded,
                                      color: primary,
                                      size: 20,
                                    ),
                            )
                          : Text(
                              '登录',
                              style: TextStyle(
                                color: primary,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                  );
                }),
                const SizedBox(width: 10),
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => Get.toNamed(AppRoutes.search),
                    child: Container(
                      height: 36,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF20242E)
                            : const Color(0xFFF5F6F8),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.search_rounded,
                            size: 19,
                            color: Theme.of(context).hintColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '今天你想看些什么?',
                            style: TextStyle(
                              fontSize: 13.5,
                              color: Theme.of(context).hintColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                IconButton(
                  tooltip: '历史记录',
                  onPressed: () => Get.toNamed(AppRoutes.history),
                  icon: Icon(
                    Icons.history_rounded,
                    size: 23,
                    color: Theme.of(context).hintColor,
                  ),
                ),
              ],
            ),
          ),

          // Sub-Tabs: 精选 | 日漫 | 剧场版
          TabBar(
            controller: _tabController,
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            dividerColor: Colors.transparent,
            labelColor: primary,
            unselectedLabelColor: const Color(0xFF8A9099),
            labelStyle: const TextStyle(
              fontSize: 16.5,
              fontWeight: FontWeight.w800,
            ),
            unselectedLabelStyle: const TextStyle(
              fontSize: 15.5,
              fontWeight: FontWeight.w500,
            ),
            indicatorSize: TabBarIndicatorSize.label,
            indicator: UnderlineTabIndicator(
              borderRadius: BorderRadius.circular(3),
              borderSide: BorderSide(width: 3.5, color: primary),
            ),
            tabs: const [
              Tab(height: 38, text: '精选'),
              Tab(height: 38, text: '日漫'),
              Tab(height: 38, text: '剧场版'),
            ],
          ),

          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildFeaturedTab(context),
                const _CatalogFilterSubTab(category: '日漫'),
                const _CatalogFilterSubTab(category: '剧场版'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedTab(BuildContext context) {
    if (_loadingHome) {
      return const Center(child: CircularProgressIndicator());
    }
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final pillBg = isDark ? const Color(0xFF1F232D) : const Color(0xFFF6F7F9);

    return RefreshIndicator(
      onRefresh: _loadHome,
      child: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 20),
        children: [
          // 1. Hero Banner Carousel
          if (_banners.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  height: 188,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      PageView.builder(
                        controller: _bannerController,
                        itemCount: _banners.length,
                        onPageChanged: (i) => setState(() => _bannerPage = i),
                        itemBuilder: (ctx, index) {
                          final item = _banners[index];
                          return GestureDetector(
                            onTap: () => Get.toNamed(
                              AppRoutes.videoPath(item.vodId),
                              arguments: item,
                            ),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                NetworkPoster(url: item.pic),
                                Positioned(
                                  left: 0,
                                  right: 0,
                                  bottom: 0,
                                  child: Container(
                                    padding: const EdgeInsets.fromLTRB(
                                        12, 26, 70, 10),
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.bottomCenter,
                                        end: Alignment.topCenter,
                                        colors: [
                                          Color(0xCC000000),
                                          Colors.transparent,
                                        ],
                                      ),
                                    ),
                                    child: Text(
                                      item.vodName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      Positioned(
                        right: 12,
                        bottom: 12,
                        child: Row(
                          children: List.generate(
                            _banners.length,
                            (idx) => AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              margin: const EdgeInsets.only(left: 5),
                              width: _bannerPage == idx ? 14 : 6,
                              height: 6,
                              decoration: BoxDecoration(
                                color: _bannerPage == idx
                                    ? Colors.white
                                    : Colors.white54,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

          // 2. Dual Action Cards: 热度排行榜 & 番剧排期表
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 2),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => Get.toNamed(AppRoutes.rank),
                    child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: pillBg,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.leaderboard_rounded,
                            color: Color(0xFFFF7A45),
                            size: 20,
                          ),
                          SizedBox(width: 7),
                          Text(
                            '热度排行榜',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => Get.toNamed(AppRoutes.week),
                    child: Container(
                      height: 44,
                      decoration: BoxDecoration(
                        color: pillBg,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.calendar_month_rounded,
                            color: Color(0xFFFF5252),
                            size: 20,
                          ),
                          SizedBox(width: 7),
                          Text(
                            '番剧排期表',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 3. 热门新番 Horizontal Strip
          if (_hotNew.isNotEmpty) ...[
            const LanercSectionHeader(title: '热门新番'),
            SizedBox(
              height: 126,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                scrollDirection: Axis.horizontal,
                itemCount: _hotNew.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (ctx, i) => VodCard.landscape(item: _hotNew[i]),
              ),
            ),
          ],

          // 4. 日漫 3-Column Grid
          if (_rimanHome.isNotEmpty) ...[
            LanercSectionHeader(
              title: '日漫',
              onMoreTap: () => _tabController.animateTo(1),
            ),
            _buildThreeColumnGrid(_rimanHome.take(6).toList()),
          ],

          // 5. 剧场版 3-Column Grid
          if (_moviesHome.isNotEmpty) ...[
            LanercSectionHeader(
              title: '剧场版',
              onMoreTap: () => _tabController.animateTo(2),
            ),
            _buildThreeColumnGrid(_moviesHome.take(6).toList()),
          ],
        ],
      ),
    );
  }

  Widget _buildThreeColumnGrid(List<VodItem> items) {
    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 12,
        crossAxisSpacing: 10,
        childAspectRatio: 0.56,
      ),
      itemBuilder: (ctx, i) => VodCard(item: items[i]),
    );
  }
}

class _CatalogFilterSubTab extends StatefulWidget {
  final String category;
  const _CatalogFilterSubTab({required this.category});

  @override
  State<_CatalogFilterSubTab> createState() => _CatalogFilterSubTabState();
}

class _CatalogFilterSubTabState extends State<_CatalogFilterSubTab>
    with AutomaticKeepAliveClientMixin {
  static const List<String> _genres = [
    '全部',
    '热血',
    '穿越',
    '奇幻',
    '战斗',
    '搞笑',
    '日常',
    '恋爱',
    '校园',
    '科幻',
    '治愈',
  ];
  static const List<String> _years = [
    '全部',
    '2026',
    '2025',
    '2024',
    '2023',
    '2022',
  ];

  String _selectedGenre = '全部';
  String _selectedYear = '全部';
  String _sortBy = 'time';
  bool _loading = true;
  List<VodItem> _items = const [];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    setState(() => _loading = true);
    final parsedYear =
        _selectedYear == '全部' ? null : int.tryParse(_selectedYear);
    final list = await Get.find<ApiService>().fetchFilteredVod(
      category: widget.category,
      genre: _selectedGenre,
      year: parsedYear,
      sortBy: _sortBy,
    );
    if (!mounted) return;
    setState(() {
      _items = list;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return RefreshIndicator(
      onRefresh: _reload,
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildFilterRow(
                    options: _genres,
                    active: _selectedGenre,
                    onSelect: (v) {
                      setState(() => _selectedGenre = v);
                      _reload();
                    },
                  ),
                  const SizedBox(height: 6),
                  _buildFilterRow(
                    options: _years,
                    active: _selectedYear,
                    onSelect: (v) {
                      setState(() => _selectedYear = v);
                      _reload();
                    },
                  ),
                  const SizedBox(height: 6),
                  _buildFilterRow(
                    options: const ['按时间', '按评分'],
                    active: _sortBy == 'score' ? '按评分' : '按时间',
                    onSelect: (v) {
                      setState(() => _sortBy = v == '按评分' ? 'score' : 'time');
                      _reload();
                    },
                  ),
                ],
              ),
            ),
          ),
          if (_loading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_items.isEmpty)
            SliverFillRemaining(
              hasScrollBody: false,
              child: Center(
                child: Text(
                  '当前筛选条件下暂无番剧',
                  style: TextStyle(color: Theme.of(context).hintColor),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (ctx, idx) => VodCard(item: _items[idx]),
                  childCount: _items.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.56,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFilterRow({
    required List<String> options,
    required String active,
    required ValueChanged<String> onSelect,
  }) {
    final primary = Theme.of(context).colorScheme.primary;
    return SizedBox(
      height: 32,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        scrollDirection: Axis.horizontal,
        itemCount: options.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (ctx, i) {
          final opt = options[i];
          final selected = opt == active;
          return InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => onSelect(opt),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: selected ? primary.withOpacity(0.13) : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                opt,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  color: selected
                      ? primary
                      : Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.color
                          ?.withOpacity(0.75),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
