import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../../app/routes/app_routes.dart';
import '../../../core/models/vod_models.dart';
import '../../../core/network/api_service.dart';
import '../../../core/state/user_controller.dart';
import '../../../core/theme/theme_controller.dart';

class ProfileTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF111318) : const Color(0xFFF7F8FA);
    final userCtrl = Get.find<UserController>();

    return Material(
      color: bg,
      child: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
          children: [
            // 1. User Avatar & Login Header
            Obx(() {
              final logged = userCtrl.isLoggedIn;
              final p = userCtrl.profile.value;
              return InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () =>
                    Get.toNamed(logged ? AppRoutes.userinfo : AppRoutes.auth),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                  child: Row(
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: primary.withOpacity(0.14),
                          border: Border.all(
                            color: primary.withOpacity(0.25),
                            width: 1.5,
                          ),
                        ),
                        child: ClipOval(
                          child: (p?.avatarUrl != null)
                              ? Image.network(
                                  p!.avatarUrl!,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Icon(
                                    Icons.face_retouching_natural_rounded,
                                    size: 32,
                                    color: primary,
                                  ),
                                )
                              : Icon(
                                  Icons.face_retouching_natural_rounded,
                                  size: 32,
                                  color: primary,
                                ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              logged ? p!.nickName : '登录/注册',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              logged
                                  ? 'UID: ${p!.userId}  ·  ${userCtrl.passedQuiz.value ? "正式会员" : "待通过入站问答"}'
                                  : '不可以哦,主人还没有登录呢～',
                              style: TextStyle(
                                fontSize: 12.5,
                                color: Theme.of(context).hintColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.chevron_right_rounded,
                        color: Theme.of(context).hintColor,
                      ),
                    ],
                  ),
                ),
              );
            }),

            const SizedBox(height: 14),

            // 2. 4-Column Quick Bar: 我的收藏 | 历史记录 | 离线缓存 | 我的消息
            Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _QuickIconItem(
                    icon: Icons.favorite_border_rounded,
                    label: '我的收藏',
                    onTap: () => Get.toNamed(AppRoutes.like),
                  ),
                  _QuickIconItem(
                    icon: Icons.history_toggle_off_rounded,
                    label: '历史记录',
                    onTap: () => Get.toNamed(AppRoutes.history),
                  ),
                  _QuickIconItem(
                    icon: Icons.create_new_folder_outlined,
                    label: '离线缓存',
                    onTap: () => Get.toNamed(AppRoutes.cache),
                  ),
                  _QuickIconItem(
                    icon: Icons.mark_email_unread_outlined,
                    label: '我的消息',
                    onTap: () => _showMessagesSheet(context),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // 3. Dual Feature Cards: 入站问答 & 主题切换
            Row(
              children: [
                Expanded(
                  child: Obx(
                    () => InkWell(
                      borderRadius: BorderRadius.circular(14),
                      onTap: () => Get.toNamed(AppRoutes.question),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: primary.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Icons.quiz_outlined,
                                color: primary,
                                size: 22,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    '入站问答',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    userCtrl.passedQuiz.value
                                        ? '已通过入站测试'
                                        : '通过问答后才能发言噢',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: Theme.of(context).hintColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => _showThemePickerSheet(context),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: primary.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Icon(
                              Icons.palette_outlined,
                              color: primary,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '主题切换',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '挑选一款心仪的配色吧',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Theme.of(context).hintColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // 4. Card Group A: 建议反馈 & 分享应用
            Material(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(14),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  _MenuRow(
                    icon: Icons.assignment_outlined,
                    title: '建议反馈',
                    onTap: () => Get.toNamed(AppRoutes.errarea),
                  ),
                  const Divider(height: 1, indent: 48),
                  _MenuRow(
                    icon: Icons.ios_share_rounded,
                    title: '分享应用',
                    onTap: () => Share.share('一起追番吧！支持高清倍速、弹幕互动与离线缓存～'),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // 5. Card Group B: 免责声明 | 检测更新 | 数据恢复
            Material(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(14),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  _MenuRow(
                    icon: Icons.info_outline_rounded,
                    title: '免责声明',
                    onTap: () => _showDisclaimerDialog(context),
                  ),
                  const Divider(height: 1, indent: 48),
                  _MenuRow(
                    icon: Icons.system_update_alt_rounded,
                    title: '检测更新',
                    onTap: () => _showUpdateDialog(context),
                  ),
                  const Divider(height: 1, indent: 48),
                  _MenuRow(
                    icon: Icons.settings_backup_restore_rounded,
                    title: '数据恢复',
                    onTap: () => Get.toNamed(AppRoutes.recover),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMessagesSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '我的消息',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 14),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: CircleAvatar(
                  backgroundColor:
                      Theme.of(ctx).colorScheme.primary.withOpacity(0.14),
                  child: Icon(
                    Icons.notifications_active_outlined,
                    color: Theme.of(ctx).colorScheme.primary,
                  ),
                ),
                title: const Text('欢迎加入社区'),
                subtitle: const Text('完成入站问答即可发送弹幕与评论，祝你追番愉快～'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showThemePickerSheet(BuildContext context) {
    final themeCtrl = Get.find<ThemeController>();
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Obx(
            () => Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text(
                      '主题切换',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                    ),
                    const Spacer(),
                    const Text('深色模式', style: TextStyle(fontSize: 13.5)),
                    const SizedBox(width: 6),
                    Switch(
                      value: themeCtrl.isDark.value,
                      onChanged: (v) => themeCtrl.updateTheme(dark: v),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: List.generate(
                    ThemeController.palettes.length,
                    (idx) {
                      final selected = themeCtrl.colorIndex.value == idx;
                      final color = ThemeController.palettes[idx];
                      return ChoiceChip(
                        selected: selected,
                        avatar: CircleAvatar(backgroundColor: color, radius: 8),
                        label: Text(ThemeController.paletteNames[idx]),
                        onSelected: (_) =>
                            themeCtrl.updateTheme(paletteIdx: idx),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDisclaimerDialog(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('免责声明'),
        content: const Text(
          '本客户端仅提供本地视频播放、弹幕渲染与收藏进度管理技术服务。\n\n'
          '请仅接入您拥有合法授权的流媒体内容源，尊重创作者版权与社区公序良俗。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('已知晓'),
          ),
        ],
      ),
    );
  }

  void _showUpdateDialog(BuildContext context) {
    final api = Get.find<ApiService>();
    final cfg = api.appConfig.value;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('版本检测'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('当前版本：v${cfg.latestVersion} (${cfg.latestVersionCode})'),
            const SizedBox(height: 8),
            const Text('当前已是最新版本，所有组件均经过 SHA-256 完整性校验。'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              _showSourceEndpointDialog(context);
            },
            child: const Text('线路/接口设置'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('确定'),
          ),
        ],
      ),
    );
  }

  void _showSourceEndpointDialog(BuildContext context) {
    final api = Get.find<ApiService>();
    final ctrl = TextEditingController(
      text: api.activeManifest.value.staticBaseUrl ?? '',
    );
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('片源接口配置'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ctrl,
              decoration: const InputDecoration(
                labelText: '服务端地址 (留空使用内置片库)',
                hintText: 'https://your-server.example.com/',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await api.applySourceManifest(DynamicSourceManifest.builtInDemo());
              if (ctx.mounted) Navigator.of(ctx).pop();
              Get.snackbar('已切换', '已恢复默认内置片库');
            },
            child: const Text('恢复默认'),
          ),
          FilledButton(
            onPressed: () async {
              final url = ctrl.text.trim();
              if (url.isEmpty) {
                await api
                    .applySourceManifest(DynamicSourceManifest.builtInDemo());
              } else {
                await api.applySourceManifest(
                  DynamicSourceManifest(
                    id: 'custom_https',
                    name: '自建服务节点',
                    staticBaseUrl: url.endsWith('/') ? url : '$url/',
                  ),
                );
              }
              if (ctx.mounted) Navigator.of(ctx).pop();
              Get.snackbar('保存成功', '片源线路已更新');
            },
            child: const Text('保存'),
          ),
        ],
      ),
    );
  }
}

class _QuickIconItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickIconItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 26),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _MenuRow({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Icon(icon, size: 22),
      title: Text(
        title,
        style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w500),
      ),
      trailing: Icon(
        Icons.chevron_right_rounded,
        size: 20,
        color: Theme.of(context).hintColor,
      ),
    );
  }
}
