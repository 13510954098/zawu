import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/vod_models.dart';
import '../../core/network/api_service.dart';
import '../../widgets/lanerc_ui.dart';
import '../../widgets/vod_card.dart';

class RankPage extends StatefulWidget {
  @override
  State<RankPage> createState() => _RankPageState();
}

class _RankPageState extends State<RankPage> {
  static const List<String> _seasons = ['四月新番', '一月新番', '十月新番'];
  String _selectedSeason = _seasons.first;
  bool _loading = true;
  List<VodItem> _items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await Get.find<ApiService>().fetchRank(_selectedSeason);
    if (!mounted) return;
    setState(() {
      _items = list;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      appBar: const LanercSubAppBar(title: '૮排行榜ა'),
      body: Column(
        children: [
          // Season pill buttons: 四月新番 | 一月新番 | 十月新番
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: _seasons.map((s) {
                final active = s == _selectedSeason;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () {
                      setState(() => _selectedSeason = s);
                      _load();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 7),
                      decoration: BoxDecoration(
                        color: active
                            ? primary
                            : primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        s,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: active ? Colors.white : primary,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: _items.length,
                    itemBuilder: (_, idx) => VodCard.rich(
                      item: _items[idx],
                      rankIndex: idx + 1,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
