import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/network/api_service.dart';

class SplashPage extends StatefulWidget {
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    try {
      await Get.find<ApiService>().fetchConfig();
    } catch (_) {}
    await Future<void>.delayed(const Duration(milliseconds: 450));
    if (mounted) {
      Get.offAllNamed(AppRoutes.main);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: primary.withOpacity(0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                Icons.live_tv_rounded,
                size: 40,
                color: primary,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '正在加载番剧资源...',
              style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w500),
            ),
          ],
        ),
      ),
    );
  }
}
