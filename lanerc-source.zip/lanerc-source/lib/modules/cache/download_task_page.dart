import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/state/download_controller.dart';
import '../../widgets/lanerc_ui.dart';

class DownloadTaskPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final dlCtrl = Get.find<DownloadController>();
    return Scaffold(
      appBar: const LanercSubAppBar(title: '下载队列'),
      body: Obx(() {
        final active = dlCtrl.activeTasks;
        if (active.isEmpty) {
          return Center(
            child: Text(
              '当前没有正在进行的下载任务',
              style: TextStyle(color: Theme.of(context).hintColor),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(14),
          itemCount: active.length,
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemBuilder: (_, idx) {
            final t = active[idx];
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          t.vodName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: () => dlCtrl.pauseOrRetry(t),
                        icon: Icon(
                          t.status == 1
                              ? Icons.pause_circle_outline_rounded
                              : Icons.play_circle_outline_rounded,
                        ),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        onPressed: () => dlCtrl.removeTask(t.vid),
                        icon: const Icon(Icons.close_rounded, size: 20),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: t.progress.clamp(0.0, 1.0),
                    minHeight: 5,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Text(
                        '${(t.progress * 100).toStringAsFixed(1)}%',
                        style: TextStyle(
                          fontSize: 12,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        t.downloadedSpeed,
                        style: TextStyle(
                          fontSize: 12,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      }),
    );
  }
}
