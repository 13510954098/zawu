import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/state/download_controller.dart';
import '../../widgets/lanerc_ui.dart';

class CachePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final dlCtrl = Get.find<DownloadController>();
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: const LanercSubAppBar(title: '离线缓存'),
      body: Obx(() {
        final active = dlCtrl.activeTasks;
        final done = dlCtrl.completedTasks;

        return ListView(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
          children: [
            // Top Active Download Task Card
            InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => Get.toNamed(AppRoutes.downloadTask),
              child: Container(
                height: 64,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xFF1F232E)
                      : const Color(0xFFF6F7F9),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: primary.withOpacity(0.14),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.downloading_rounded,
                        color: primary,
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        active.isEmpty
                            ? '当前暂无下载任务'
                            : '正在下载 (${active.length}) · ${active.first.downloadedSpeed}',
                        style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Icon(
                      Icons.chevron_right_rounded,
                      color: Theme.of(context).hintColor,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),
            const Text(
              '已下载',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 3),
            Text(
              '左滑可删除已经下载到本地的视频文件',
              style: TextStyle(
                fontSize: 12,
                color: Theme.of(context).hintColor,
              ),
            ),
            const SizedBox(height: 12),

            if (done.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 56),
                child: Center(
                  child: Text(
                    '暂无已缓存的视频文件',
                    style: TextStyle(color: Theme.of(context).hintColor),
                  ),
                ),
              )
            else
              ...done.map(
                (item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Dismissible(
                    key: ValueKey(item.vid),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      decoration: BoxDecoration(
                        color: Colors.redAccent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.delete_forever_rounded,
                        color: Colors.white,
                      ),
                    ),
                    onDismissed: (_) => dlCtrl.removeTask(item.vid),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => Get.toNamed(
                        AppRoutes.cachedVideoPath(item.vodID),
                        arguments: item,
                      ),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: SizedBox(
                              width: 126,
                              height: 74,
                              child: NetworkPoster(url: item.pic),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.vodName,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '${(item.fileSize / (1024 * 1024)).toStringAsFixed(1)} MB · 本地离线直播',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Theme.of(context).hintColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Icon(Icons.play_circle_outline_rounded,
                              color: primary),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      }),
    );
  }
}
