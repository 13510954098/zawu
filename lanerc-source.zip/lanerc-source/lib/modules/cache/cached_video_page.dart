import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../../core/models/vod_models.dart';
import '../../core/player/anime_mpv_controller.dart';
import '../../core/state/download_controller.dart';
import '../../widgets/lanerc_ui.dart';

class CachedVideoPage extends StatefulWidget {
  @override
  State<CachedVideoPage> createState() => _CachedVideoPageState();
}

class _CachedVideoPageState extends State<CachedVideoPage> {
  AnimeMpvController? _mpv;
  DownloadRecord? _record;
  String? _error;

  @override
  void initState() {
    super.initState();
    final arg = Get.arguments;
    if (arg is DownloadRecord) {
      _record = arg;
    } else {
      final vodId = int.tryParse('${Get.parameters['vod'] ?? 0}') ?? 0;
      final list = Get.find<DownloadController>().completedTasks;
      for (final item in list) {
        if (item.vodID == vodId) {
          _record = item;
          break;
        }
      }
    }
    _openLocal();
  }

  Future<void> _openLocal() async {
    if (_record == null) {
      setState(() => _error = '未找到本地缓存记录');
      return;
    }
    try {
      final ctrl = AnimeMpvController();
      _mpv = ctrl;
      await ctrl.openLocalCachedFile(_record!.localPath);
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => _error = '本地文件读取失败: $e');
    }
  }

  @override
  void dispose() {
    _mpv?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: LanercSubAppBar(title: _record?.vodName ?? '本地缓存播放'),
      backgroundColor: Colors.black,
      body: Center(
        child: _error != null
            ? Text(_error!, style: const TextStyle(color: Colors.white70))
            : _mpv == null
                ? const CircularProgressIndicator(color: Colors.white)
                : AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Video(controller: _mpv!.videoController),
                  ),
      ),
    );
  }
}
