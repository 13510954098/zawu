abstract class AppRoutes {
  static const splash = '/splash';
  static const main = '/main';
  static const auth = '/auth';
  static const recover = '/recover';
  static const userinfo = '/userinfo';
  static const question = '/question';
  static const search = '/search';
  static const video = '/video/:vod';
  static const rank = '/rank';
  static const week = '/week';
  static const history = '/history';
  static const like = '/like';
  static const cache = '/cache';
  static const cachedVideo = '/cached_video/:vod';
  static const downloadTask = '/download_task';
  static const sponsor = '/sponsor';
  static const errarea = '/errarea';

  static String videoPath(int vodId) => '/video/$vodId';
  static String cachedVideoPath(int vodId) => '/cached_video/$vodId';
}
