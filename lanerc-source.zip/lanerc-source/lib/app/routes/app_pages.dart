import 'package:get/get.dart';
import '../../modules/auth/auth_page.dart';
import '../../modules/auth/userinfo_page.dart';
import '../../modules/cache/cache_page.dart';
import '../../modules/cache/cached_video_page.dart';
import '../../modules/cache/download_task_page.dart';
import '../../modules/errarea/errarea_page.dart';
import '../../modules/history/history_page.dart';
import '../../modules/history/like_page.dart';
import '../../modules/main/main_shell_page.dart';
import '../../modules/question/question_page.dart';
import '../../modules/rank/rank_page.dart';
import '../../modules/recover/recover_page.dart';
import '../../modules/search/search_page.dart';
import '../../modules/splash/splash_page.dart';
import '../../modules/sponsor/sponsor_page.dart';
import '../../modules/video/video_detail_page.dart';
import '../../modules/week/week_page.dart';
import 'app_routes.dart';

class AppPages {
  static final List<GetPage<dynamic>> pages = [
    GetPage(name: AppRoutes.splash, page: () => SplashPage()),
    GetPage(name: AppRoutes.main, page: () => MainShellPage()),
    GetPage(name: AppRoutes.auth, page: () => AuthPage()),
    GetPage(name: AppRoutes.userinfo, page: () => UserInfoPage()),
    GetPage(name: AppRoutes.question, page: () => QuestionPage()),
    GetPage(name: AppRoutes.search, page: () => SearchPage()),
    GetPage(name: AppRoutes.video, page: () => VideoDetailPage()),
    GetPage(name: AppRoutes.errarea, page: () => ErrAreaPage()),
    GetPage(name: AppRoutes.history, page: () => HistoryPage()),
    GetPage(name: AppRoutes.like, page: () => LikePage()),
    GetPage(name: AppRoutes.sponsor, page: () => SponsorPage()),
    GetPage(name: AppRoutes.cache, page: () => CachePage()),
    GetPage(name: AppRoutes.recover, page: () => RecoverPage()),
    GetPage(name: AppRoutes.cachedVideo, page: () => CachedVideoPage()),
    GetPage(name: AppRoutes.downloadTask, page: () => DownloadTaskPage()),
    GetPage(name: AppRoutes.week, page: () => WeekPage()),
    GetPage(name: AppRoutes.rank, page: () => RankPage()),
  ];
}
