import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../app/routes/app_routes.dart';
import '../core/models/vod_models.dart';
import 'lanerc_ui.dart';

enum VodCardLayout { portrait, landscape, horizontalRich }

class VodCard extends StatelessWidget {
  final VodItem item;
  final bool horizontal;
  final VodCardLayout? layout;
  final int? rankIndex;
  final VoidCallback? onTapOverride;

  const VodCard({
    super.key,
    required this.item,
    this.horizontal = false,
    this.layout,
    this.rankIndex,
    this.onTapOverride,
  });

  const VodCard.landscape({
    super.key,
    required this.item,
    this.onTapOverride,
  })  : horizontal = false,
        layout = VodCardLayout.landscape,
        rankIndex = null;

  const VodCard.rich({
    super.key,
    required this.item,
    this.rankIndex,
    this.onTapOverride,
  })  : horizontal = true,
        layout = VodCardLayout.horizontalRich;

  VodCardLayout get _resolvedLayout {
    if (layout != null) return layout!;
    return horizontal ? VodCardLayout.horizontalRich : VodCardLayout.portrait;
  }

  void _openDetail() {
    if (onTapOverride != null) {
      onTapOverride!();
      return;
    }
    Get.toNamed(AppRoutes.videoPath(item.vodId), arguments: item);
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: _openDetail,
      child: switch (_resolvedLayout) {
        VodCardLayout.portrait => _buildPortrait(context),
        VodCardLayout.landscape => _buildLandscape(context),
        VodCardLayout.horizontalRich => _buildRichHorizontal(context),
      },
    );
  }

  /// 3-column vertical anime card (`已完结 | 共12集`, bold title, space-separated tags).
  Widget _buildPortrait(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(9),
            child: Stack(
              fit: StackFit.expand,
              children: [
                NetworkPoster(url: item.pic),
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(6, 16, 6, 5),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xD9000000), Colors.transparent],
                      ),
                    ),
                    child: Text(
                      item.remarks,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          item.vodName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12.8),
        ),
        const SizedBox(height: 1),
        Text(
          item.genres.join(' '),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Theme.of(context).hintColor, fontSize: 11),
        ),
      ],
    );
  }

  /// Wide 16:10 card used in `热门新番` horizontal strip.
  Widget _buildLandscape(BuildContext context) {
    return SizedBox(
      width: 158,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(9),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  NetworkPoster(url: item.pic),
                  Positioned(
                    right: 6,
                    bottom: 5,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        item.remarks.split('|').last.trim(),
                        style: const TextStyle(
                            color: Colors.white, fontSize: 10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            item.vodName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  /// Full-width rich horizontal card used on `/rank` (`૮排行榜ა`) and `/search`.
  Widget _buildRichHorizontal(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final statusBadge =
        item.remarks.contains('连载') ? '连载中' : '完结';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 98,
              height: 134,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  NetworkPoster(url: item.pic),
                  if (rankIndex != null)
                    Positioned(
                      left: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: rankIndex! <= 3
                              ? (rankIndex == 1
                                  ? const Color(0xFFFF5252)
                                  : rankIndex == 2
                                      ? const Color(0xFFFF9100)
                                      : const Color(0xFFFFC400))
                              : Colors.black54,
                          borderRadius: const BorderRadius.only(
                            bottomRight: Radius.circular(8),
                          ),
                        ),
                        child: Text(
                          'TOP $rankIndex',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    )
                  else
                    Positioned(
                      right: 5,
                      top: 5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(
                          color: primary.withOpacity(0.9),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          statusBadge,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: SizedBox(
              height: 134,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.vodName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${item.director} | ${item.year}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).hintColor,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Expanded(
                    child: Text(
                      item.summary,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        height: 1.38,
                        color: Theme.of(context)
                            .textTheme
                            .bodyMedium
                            ?.color
                            ?.withOpacity(0.8),
                      ),
                    ),
                  ),
                  Text(
                    item.genres.take(3).join(' \\ '),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11.5,
                      color: primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
