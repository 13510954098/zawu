import 'package:flutter/material.dart';
import '../core/models/vod_models.dart';

class DanmakuConfig {
  final bool enabled;
  final double opacity;
  final double fontSize;
  final double areaRatio; // 0.25, 0.5, 0.75, 1.0
  final double durationSeconds; // smaller = faster

  const DanmakuConfig({
    this.enabled = true,
    this.opacity = 0.9,
    this.fontSize = 15.0,
    this.areaRatio = 0.5,
    this.durationSeconds = 7.5,
  });

  DanmakuConfig copyWith({
    bool? enabled,
    double? opacity,
    double? fontSize,
    double? areaRatio,
    double? durationSeconds,
  }) {
    return DanmakuConfig(
      enabled: enabled ?? this.enabled,
      opacity: opacity ?? this.opacity,
      fontSize: fontSize ?? this.fontSize,
      areaRatio: areaRatio ?? this.areaRatio,
      durationSeconds: durationSeconds ?? this.durationSeconds,
    );
  }
}

/// Time-synchronized Danmaku overlay supporting rolling & top-pinned barrages
/// plus tap-to-report callback.
class DanmakuStage extends StatelessWidget {
  final List<BarrageItem> items;
  final double playbackSeconds;
  final DanmakuConfig config;
  final void Function(BarrageItem item)? onReportTap;

  const DanmakuStage({
    required this.items,
    required this.playbackSeconds,
    required this.config,
    this.onReportTap,
  });

  @override
  Widget build(BuildContext context) {
    if (!config.enabled || items.isEmpty) return const SizedBox.shrink();

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final maxHeight = constraints.maxHeight * config.areaRatio;
        final laneHeight = config.fontSize + 10;
        final laneCount = (maxHeight / laneHeight).floor().clamp(1, 12);

        final visible = items.where((b) {
          final delta = playbackSeconds - b.timeSeconds;
          return delta >= 0 && delta <= config.durationSeconds;
        }).toList();

        return Opacity(
          opacity: config.opacity.clamp(0.1, 1.0),
          child: Stack(
            clipBehavior: Clip.hardEdge,
            children: [
              for (int i = 0; i < visible.length; i++)
                _buildBarrageNode(
                  item: visible[i],
                  lane: i % laneCount,
                  laneHeight: laneHeight,
                  stageWidth: width,
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBarrageNode({
    required BarrageItem item,
    required int lane,
    required double laneHeight,
    required double stageWidth,
  }) {
    final progress =
        ((playbackSeconds - item.timeSeconds) / config.durationSeconds)
            .clamp(0.0, 1.0);
    final top = 8.0 + lane * laneHeight;

    final textWidget = GestureDetector(
      onLongPress: onReportTap != null ? () => onReportTap!(item) : null,
      child: Text(
        item.content,
        style: TextStyle(
          color: Color(item.colorHex | 0xFF000000),
          fontSize: config.fontSize,
          fontWeight: FontWeight.w600,
          shadows: const [
            Shadow(color: Colors.black87, blurRadius: 3, offset: Offset(1, 1)),
          ],
        ),
      ),
    );

    if (item.isTop) {
      return Positioned(
        top: top,
        left: 0,
        right: 0,
        child: Center(child: textWidget),
      );
    }

    final estimatedTextWidth = item.content.length * config.fontSize;
    final x = stageWidth - (stageWidth + estimatedTextWidth) * progress;
    return Positioned(
      top: top,
      left: x,
      child: textWidget,
    );
  }
}
