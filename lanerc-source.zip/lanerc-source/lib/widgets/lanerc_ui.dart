import 'package:flutter/material.dart';
import 'package:get/get.dart';

/// Signature circular primary-accent `<` back button used across sub-pages.
class LanercBackButton extends StatelessWidget {
  final VoidCallback? onTap;
  const LanercBackButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Center(
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap ?? () => Get.back<void>(),
        child: Container(
          width: 26,
          height: 26,
          decoration: BoxDecoration(
            color: primary,
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: const Icon(
            Icons.chevron_left_rounded,
            size: 20,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

/// Clean sub-page AppBar with signature left circular `<` button, centered
/// title, and optional right action label (e.g. `编辑`).
class LanercSubAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String? actionText;
  final VoidCallback? onActionTap;
  final bool showBack;

  const LanercSubAppBar({
    super.key,
    required this.title,
    this.actionText,
    this.onActionTap,
    this.showBack = true,
  });

  @override
  Size get preferredSize => const Size.fromHeight(50);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      toolbarHeight: 50,
      leadingWidth: 56,
      leading: showBack ? const LanercBackButton() : null,
      title: Text(
        title,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
      ),
      actions: [
        if (actionText != null)
          TextButton(
            onPressed: onActionTap,
            child: Text(
              actionText!,
              style: TextStyle(
                fontSize: 14,
                color: Theme.of(context).hintColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        const SizedBox(width: 4),
      ],
    );
  }
}

/// Section header with a translucent accent circle behind the first character
/// (`热门新番`, `日漫`, `剧场版`, `精彩推荐`) and optional right circular chevron.
class LanercSectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onMoreTap;

  const LanercSectionHeader({
    super.key,
    required this.title,
    this.onMoreTap,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                left: -3,
                top: 2,
                child: Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    color: primary.withOpacity(0.22),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
          const Spacer(),
          if (onMoreTap != null)
            InkWell(
              customBorder: const CircleBorder(),
              onTap: onMoreTap,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  color: primary,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Icon(
                  Icons.chevron_right_rounded,
                  size: 15,
                  color: Colors.white,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class NetworkPoster extends StatelessWidget {
  final String url;
  final BoxFit fit;

  const NetworkPoster({
    super.key,
    required this.url,
    this.fit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    if (url.isEmpty) {
      return _placeholder(primary);
    }
    return Image.network(
      url,
      fit: fit,
      errorBuilder: (_, __, ___) => _placeholder(primary),
    );
  }

  Widget _placeholder(Color primary) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            primary.withOpacity(0.28),
            const Color(0xFF263238),
          ],
        ),
      ),
      alignment: Alignment.center,
      child: const Icon(
        Icons.smart_display_rounded,
        color: Colors.white70,
        size: 32,
      ),
    );
  }
}
