# 净室产品交互与全栈架构规范（CLEANROOM UX & ARCHITECTURE SPEC）

本文档面向从未见过原版应用的工程师与产品人员，精确定义客户端每一处视觉比例、交互手势、路由状态机、本地数据库表结构与服务端接口契约。

---

## 一、全局视觉与设计语言（Design Tokens）

| 维度 | 规范定义 |
| :--- | :--- |
| **默认主色（Primary）** | 晴空蓝 `#00A8E8`（另含樱花粉 `#FF6B9D`、鸢尾紫 `#7C4DFF`、薄荷绿 `#00C853`、落日橙 `#FF9100`、星夜靛 `#536DFE` 及深色模式） |
| **背景层级** | 首页与列表页底色 `#FFFFFF`；`福利` 与 `我的` 分组卡片底色 `#F7F8FA`，卡片白底 `#FFFFFF` + `14dp` 圆角 |
| **二级页面顶栏（`LanercSubAppBar`）** | 高度 `50dp`，左侧固定 `26×26dp` 纯主色实心圆内嵌白色 `<` 图标（`LanercBackButton`），标题居中 `17sp Bold`，右侧可选文字操作键（如 `编辑`） |
| **分区标题（`LanercSectionHeader`）** | 首字左上方叠放 `20×20dp` `22%` 透明度主色圆斑，标题 `16.5sp ExtraBold`，右侧可选 `20×20dp` 实心主色圆 `>` 跳转按钮 |
| **三列竖版番剧卡（`VodCard`）** | 网格 `crossAxisCount: 3, childAspectRatio: 0.56`，圆角 `9dp`；封面底部黑色渐变条居中显示更新状态（如 `已完结 | 共12集`），下方一行粗体片名 + 一行空格分隔题材浅灰副标题 |
| **排行榜/搜索横版富卡片（`VodCard.rich`）** | 左侧 `98×134dp` 竖版封面（左上角 `TOP 1~3` 勋章或右上角完结角标），右侧依次为片名、`导演 | 年份`、3 行剧情摘要、底部主色斜杠标签（`校园 \ 恋爱 \ 日常`） |

---

## 二、17 条路由清单与页面交互细则

| 路由路径 | 页面组件 | 普通用户核心交互与布局 |
| :--- | :--- | :--- |
| `/splash` | `SplashPage` | 拉取全局公告配置后平滑进入 `/main` |
| `/main` | `MainShellPage` | 首次进入弹出居中圆角系统公告（底部全宽主色胶囊键 `已知晓`）；底部固定三栏：`首页`、`福利`、`我的` |
| `/search` | `SearchPage` | 顶栏返回圆钮 + `今天你想看些什么?` 搜索框 + 右侧 `搜索`；默认展示搜索历史（可清空）与双列编号热搜榜，提交后原地展示富横卡结果 |
| `/rank` | `RankPage` | 顶栏 `૮排行榜ა` + 季度胶囊切换（`四月新番 / 一月新番 / 十月新番`）+ 富横卡榜单 |
| `/week` | `WeekPage` | 顶栏 `番剧排期表` + `周一` 至 `周日` 七栏（自动定位当天星期）+ 三列番剧网格 |
| `/video/:vod` | `VideoDetailPage` | 顶部 16:9 MPV 播放器 + 中部 `简介 / 评论` 与 `点我发弹幕~` + 选集与推荐 + **底部悬浮深色半透明五键胶囊栏（收藏/反馈/换源/缓存/分享）** |
| `/history` | `HistoryPage` | 左侧 `136×82dp` 横版缩略图（右上角 `日漫/剧场版` 角标），右侧片名、`已看到第X集`、`今天 HH:mm`；右上角 `编辑` 开启多选删除与清空 |
| `/like` | `LikePage` | 三列收藏网格，右上角 `编辑` 开启角标勾选批量取消收藏 |
| `/cache` | `CachePage` | 顶部下载任务入口卡（`当前暂无下载任务` / `正在下载`）+ `已下载` 列表（支持**左滑删除本地文件**，点击进入离线播放） |
| `/download_task` | `DownloadTaskPage` | 实时显示分集下载进度条、速率（KB/s, MB/s），支持暂停/续传/移除 |
| `/cached_video/:vod` | `CachedVideoPage` | 纯本地离线 MPV 视频播放页 |
| `/auth` | `AuthPage` | 大字标题 `登录'` + `登录后即可享受更多权益~`，账号密码输入 + 全宽圆角登录键 + 底部 `立即注册 \| 找回密码` |
| `/userinfo` | `UserInfoPage` | 修改昵称、绑定 QQ 号同步头像、查看 UID 与退出登录 |
| `/question` | `QuestionPage` | 5 道社区弹幕礼仪单选题，答对 4 题即解锁弹幕与评论发送权限 |
| `/recover` | `RecoverPage` | 一键生成/复制/分享包含收藏、观看历史、金币与答题状态的 JSON 备份，支持跨设备粘贴恢复 |
| `/errarea` | `ErrAreaPage` | 自动携带当前播放番剧上下文，选择问题分类标签并提交文字描述 |
| `/sponsor` | `SponsorPage` | 社区支持说明页 |

---

## 三、MPV 播放器手势与状态机规范

1. **单击画面**：切换顶/底渐变控制栏与左侧锁屏圆钮显隐；播放状态下无操作 4 秒自动隐藏。开启锁屏后屏蔽除解锁键外的一切触控以防握持误触。
2. **双击画面**：立即切换 `播放 / 暂停`。
3. **长按画面**：顶部弹出 `3.0x 倍速播放中` 提示并调用 `player.setRate(3.0)`；手指抬起瞬间恢复用户原设定倍速。
4. **水平滑动**：按屏幕宽度映射 `±90s` 进度预览胶囊，松手执行精准 `seek`。
5. **垂直滑动**：左半屏调节画面亮度遮罩，右半屏调节播放器音量（`0% ~ 100%`）。
6. **画中画（PiP）**：通过 Android 原生 `MethodChannel('floating')` 调用 `enterPictureInPictureMode(Rational(16, 9))`。
7. **GLSL 超分管线**：将 `assets/shaders/*.glsl` 解压至应用支持目录后注入 MPV `glsl-shaders` 属性，支持播放中无感切换。

---

## 四、REST JSON 服务端接口契约（`server/server.py`）

- `GET /app/config`：返回公告标题、正文与最新版本号/SHA-256。
- `GET /app/home`：返回 `banners`、`hotNew`、`riman`、`movies` 四组列表。
- `GET /app/vod/filter?category=&genre=&year=&sort=`：多维分类筛选。
- `GET /app/vod/search?wd=`：关键词直搜。
- `GET /app/rank?season=`：季度热度榜。
- `GET /app/week?weekday=1..7`：每日新番排期。
- `GET /app/v2/vod/{id}`：番剧详情、多条播放线路（`playLines`）与相关推荐。
- `POST /app/v2/play`：解析分集直链（`mp4` / `m3u8`）与自定义请求头。
- `GET /app/chat/barragev2?vid=&vod=` & `POST /app/chat/sendbarrage`：分集时间轴弹幕读写。
- `GET /app/chat/comments?vid=` & `POST /app/chat/sendcomment`：番剧评论读写。
- `POST /app/auth/login` & `POST /app/auth/register`：账号注册登录。
- `POST /app/feedback` / `/app/report/*`：报错反馈与内容举报。
