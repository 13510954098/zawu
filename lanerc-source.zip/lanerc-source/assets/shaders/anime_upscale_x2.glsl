// MIT License - Clean-room GLSL Directional Upscale & Sharpen Pass for MPV (HOOKED)
//!HOOK MAIN
//!BIND HOOKED
//!DESC Cleanroom_Upscale_Sharpen_x2
//!WIDTH HOOKED.w 2 *
//!HEIGHT HOOKED.h 2 *

vec4 hook() {
    vec2 pos = HOOKED_pos;
    vec2 pt = HOOKED_pt;
    vec4 c  = HOOKED_tex(pos);
    vec4 nw = HOOKED_tex(pos + vec2(-0.5, -0.5) * pt);
    vec4 ne = HOOKED_tex(pos + vec2( 0.5, -0.5) * pt);
    vec4 sw = HOOKED_tex(pos + vec2(-0.5,  0.5) * pt);
    vec4 se = HOOKED_tex(pos + vec2( 0.5,  0.5) * pt);
    vec4 avg = (nw + ne + sw + se) * 0.25;
    vec4 minC = min(min(nw, ne), min(sw, se));
    vec4 maxC = max(max(nw, ne), max(sw, se));
    return clamp(c + (c - avg) * 0.65, minC, maxC);
}
