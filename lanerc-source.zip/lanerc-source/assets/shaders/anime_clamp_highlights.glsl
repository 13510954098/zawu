// MIT License - Clean-room GLSL Highlight Clamp Pre-pass for MPV (HOOKED)
//!HOOK MAIN
//!BIND HOOKED
//!DESC Cleanroom_Clamp_Highlights

vec4 hook() {
    vec4 c = HOOKED_texOff(vec2(0.0));
    return clamp(c, 0.0, 1.0);
}
