// MIT License - Clean-room GLSL Edge-Aware Line Restore Pass for MPV (HOOKED)
//!HOOK MAIN
//!BIND HOOKED
//!DESC Cleanroom_Restore_LineArt

vec4 hook() {
    vec2 pt = HOOKED_pt;
    vec4 center = HOOKED_tex(HOOKED_pos);
    vec4 n = HOOKED_tex(HOOKED_pos + vec2(0.0, -pt.y));
    vec4 s = HOOKED_tex(HOOKED_pos + vec2(0.0,  pt.y));
    vec4 w = HOOKED_tex(HOOKED_pos + vec2(-pt.x, 0.0));
    vec4 e = HOOKED_tex(HOOKED_pos + vec2( pt.x, 0.0));
    vec4 blur = (n + s + w + e) * 0.25;
    vec4 edge = center - blur;
    return clamp(center + edge * 0.45, 0.0, 1.0);
}
