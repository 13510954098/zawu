#!/usr/bin/env python3
"""
Turnkey Self-Hosted VOD, Danmaku, Comment & Auth Backend (SQLite + Standard Library)
====================================================================================
Implements the complete REST JSON API consumed by the Flutter client so an operator
can launch a production-structured backend with zero third-party Python dependencies,
and optionally import any standard JSON / MacCMS-style licensed catalog.

Usage:
  python3 server/server.py --host 0.0.0.0 --port 8080
  python3 server/server.py --import-json my_catalog.json --port 8080
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

DB_PATH = os.environ.get("VOD_DB_PATH", os.path.join(os.path.dirname(__file__), "vod_data.db"))

SEED_VOD = [
    {
        "vodId": 101,
        "vodName": "Spring · 春之牧歌",
        "pic": "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Spring_-_Blender_Open_Movie-poster.jpg/480px-Spring_-_Blender_Open_Movie-poster.jpg",
        "remarks": "连载中 | 更新至7集",
        "category": "日漫",
        "genres": ["奇幻", "冒险", "治愈", "日常"],
        "year": 2026,
        "score": 9.6,
        "director": "Andy Goralczyk",
        "summary": "牧羊少女与忠诚的小狗踏入云海笼罩的远古森林，直面古老的自然巨灵，唤醒被冰封已久的春日生机。",
        "weekday": 6,
        "playLines": [
            {
                "lineId": "line_hd",
                "lineName": "极速蓝光①",
                "episodes": [
                    {"index": i, "title": str(i), "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"}
                    for i in range(1, 8)
                ],
            },
            {
                "lineId": "line_cdn",
                "lineName": "流畅备线②",
                "episodes": [
                    {"index": i, "title": str(i), "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"}
                    for i in range(1, 8)
                ],
            },
        ],
    },
    {
        "vodId": 102,
        "vodName": "Sintel · 寻龙战记",
        "pic": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Sintel_poster.jpg/480px-Sintel_poster.jpg",
        "remarks": "已完结 | 共12集",
        "category": "日漫",
        "genres": ["热血", "奇幻", "战斗", "冒险"],
        "year": 2026,
        "score": 9.7,
        "director": "Colin Levy",
        "summary": "独自流浪的少女辛特尔救下受伤的幼龙 Scales，当伙伴被巨龙掠走后，她毅然跨越雪山与荒漠踏上宿命征途。",
        "weekday": 7,
        "playLines": [
            {
                "lineId": "line_hd",
                "lineName": "极速蓝光①",
                "episodes": [
                    {"index": i, "title": str(i), "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"}
                    for i in range(1, 13)
                ],
            }
        ],
    },
    {
        "vodId": 104,
        "vodName": "钢铁之泪：记忆回溯",
        "pic": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/70/Tos-poster.png/480px-Tos-poster.png",
        "remarks": "已完结 | 剧场版",
        "category": "剧场版",
        "genres": ["科幻", "战斗", "穿越", "恋爱"],
        "year": 2026,
        "score": 9.4,
        "director": "Ian Hubert",
        "summary": "在未来阿姆斯特丹的穹顶遗迹中，科学家与战术小队重现四十年前那场决定人类命运的离别。",
        "weekday": 3,
        "playLines": [
            {
                "lineId": "line_hd",
                "lineName": "极速蓝光①",
                "episodes": [
                    {"index": 1, "title": "正片", "url": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"}
                ],
            }
        ],
    },
]


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS vod (
                vod_id INTEGER PRIMARY KEY,
                vod_name TEXT NOT NULL,
                pic TEXT NOT NULL,
                remarks TEXT NOT NULL,
                category TEXT NOT NULL,
                genres_json TEXT NOT NULL,
                year INTEGER NOT NULL,
                score REAL NOT NULL,
                director TEXT NOT NULL,
                summary TEXT NOT NULL,
                weekday INTEGER NOT NULL,
                play_lines_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS barrages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vod_id INTEGER NOT NULL,
                episode_idx INTEGER NOT NULL,
                time_seconds REAL NOT NULL,
                content TEXT NOT NULL,
                color_hex INTEGER NOT NULL,
                is_top INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vod_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                likes INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                account TEXT NOT NULL UNIQUE,
                password_sha256 TEXT NOT NULL,
                nick_name TEXT NOT NULL,
                coins INTEGER NOT NULL DEFAULT 30,
                passed_quiz INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                vod_id INTEGER,
                created_at INTEGER NOT NULL
            );
            """
        )
        cur = conn.execute("SELECT COUNT(*) AS c FROM vod").fetchone()
        if cur["c"] == 0:
            for item in SEED_VOD:
                upsert_vod_dict(conn, item)
            conn.execute(
                "INSERT INTO barrages (vod_id, episode_idx, time_seconds, content, color_hex, is_top) VALUES (101, 1, 1.5, '前排打卡！高清秒开～', 16777215, 0)"
            )
            conn.execute(
                "INSERT INTO comments (vod_id, user_name, content, created_at, likes) VALUES (101, '追番小助手', '欢迎使用自建服务端，支持实时弹幕与评论同步！', '刚刚', 12)"
            )


def upsert_vod_dict(conn: sqlite3.Connection, item: dict) -> None:
    conn.execute(
        """
        INSERT INTO vod (vod_id, vod_name, pic, remarks, category, genres_json, year, score, director, summary, weekday, play_lines_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(vod_id) DO UPDATE SET
            vod_name=excluded.vod_name,
            pic=excluded.pic,
            remarks=excluded.remarks,
            category=excluded.category,
            genres_json=excluded.genres_json,
            year=excluded.year,
            score=excluded.score,
            director=excluded.director,
            summary=excluded.summary,
            weekday=excluded.weekday,
            play_lines_json=excluded.play_lines_json
        """,
        (
            int(item["vodId"]),
            item["vodName"],
            item.get("pic", ""),
            item.get("remarks", "已完结"),
            item.get("category", "日漫"),
            json.dumps(item.get("genres", ["奇幻"]), ensure_ascii=False),
            int(item.get("year", 2026)),
            float(item.get("score", 9.0)),
            item.get("director", "未知"),
            item.get("summary", ""),
            int(item.get("weekday", 1)),
            json.dumps(item.get("playLines", []), ensure_ascii=False),
        ),
    )


def row_to_vod_item(row: sqlite3.Row) -> dict:
    return {
        "vodId": row["vod_id"],
        "vodName": row["vod_name"],
        "pic": row["pic"],
        "remarks": row["remarks"],
        "category": row["category"],
        "genres": json.loads(row["genres_json"]),
        "year": row["year"],
        "score": row["score"],
        "director": row["director"],
        "summary": row["summary"],
        "weekday": row["weekday"],
    }


class ApiHandler(BaseHTTPRequestHandler):
    def _send_json(self, payload: dict, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        self.wfile.write(raw)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_OPTIONS(self) -> None:
        self._send_json({"ok": True})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        qs = parse_qs(parsed.query)

        if path == "/app/config":
            self._send_json(
                {
                    "noticeTitle": "系统公告",
                    "noticeBody": "欢迎来到追番小站！支持多线路切换、实时弹幕互动与离线缓存。",
                    "latestVersion": "1.0.8",
                    "latestVersionCode": 32,
                }
            )
            return

        with get_conn() as conn:
            if path == "/app/home":
                rows = conn.execute("SELECT * FROM vod ORDER BY score DESC").fetchall()
                items = [row_to_vod_item(r) for r in rows]
                self._send_json(
                    {
                        "banners": items[:4],
                        "hotNew": items[:6],
                        "riman": [x for x in items if x["category"] == "日漫"],
                        "movies": [x for x in items if x["category"] == "剧场版"],
                    }
                )
                return

            if path == "/app/vod/filter":
                cat = qs.get("category", ["全部"])[0]
                genre = qs.get("genre", ["全部"])[0]
                year = qs.get("year", [None])[0]
                sort_by = qs.get("sort", ["time"])[0]
                order_sql = "score DESC" if sort_by == "score" else "year DESC, vod_id DESC"
                rows = conn.execute(f"SELECT * FROM vod ORDER BY {order_sql}").fetchall()
                items = [row_to_vod_item(r) for r in rows]
                if cat != "全部":
                    items = [x for x in items if x["category"] == cat]
                if genre != "全部":
                    items = [x for x in items if genre in x["genres"]]
                if year and year.isdigit():
                    items = [x for x in items if x["year"] == int(year)]
                self._send_json({"items": items})
                return

            if path == "/app/vod/search":
                wd = qs.get("wd", [""])[0].strip().lower()
                rows = conn.execute("SELECT * FROM vod").fetchall()
                items = [
                    row_to_vod_item(r)
                    for r in rows
                    if wd in r["vod_name"].lower() or wd in r["summary"].lower() or wd in r["director"].lower()
                ]
                self._send_json({"items": items})
                return

            if path == "/app/rank":
                rows = conn.execute("SELECT * FROM vod ORDER BY score DESC").fetchall()
                self._send_json({"items": [row_to_vod_item(r) for r in rows]})
                return

            if path == "/app/week":
                wd = int(qs.get("weekday", ["1"])[0])
                rows = conn.execute("SELECT * FROM vod WHERE weekday = ?", (wd,)).fetchall()
                if not rows:
                    rows = conn.execute("SELECT * FROM vod LIMIT 3").fetchall()
                self._send_json({"items": [row_to_vod_item(r) for r in rows]})
                return

            if path.startswith("/app/v2/vod/"):
                vod_id = int(path.split("/")[-1])
                row = conn.execute("SELECT * FROM vod WHERE vod_id = ?", (vod_id,)).fetchone()
                if not row:
                    self._send_json({"error": "not_found"}, 404)
                    return
                raw_lines = json.loads(row["play_lines_json"])
                client_lines = []
                for line in raw_lines:
                    eps = [
                        {
                            "index": ep["index"],
                            "title": ep["title"],
                            "resourceId": f"{vod_id}:{line['lineId']}:{ep['index']}",
                        }
                        for ep in line.get("episodes", [])
                    ]
                    client_lines.append(
                        {"lineId": line["lineId"], "lineName": line["lineName"], "episodes": eps}
                    )
                rec_rows = conn.execute(
                    "SELECT * FROM vod WHERE vod_id != ? LIMIT 6", (vod_id,)
                ).fetchall()
                self._send_json(
                    {
                        "item": row_to_vod_item(row),
                        "playLines": client_lines,
                        "recommendations": [row_to_vod_item(r) for r in rec_rows],
                    }
                )
                return

            if path == "/app/chat/barragev2":
                vid = int(qs.get("vid", ["0"])[0])
                ep = int(qs.get("vod", ["1"])[0])
                rows = conn.execute(
                    "SELECT * FROM barrages WHERE vod_id = ? AND episode_idx = ? ORDER BY time_seconds ASC",
                    (vid, ep),
                ).fetchall()
                self._send_json(
                    {
                        "items": [
                            {
                                "id": str(r["id"]),
                                "timeSeconds": r["time_seconds"],
                                "content": r["content"],
                                "colorHex": r["color_hex"],
                                "isTop": bool(r["is_top"]),
                            }
                            for r in rows
                        ]
                    }
                )
                return

            if path == "/app/chat/comments":
                vid = int(qs.get("vid", ["0"])[0])
                rows = conn.execute(
                    "SELECT * FROM comments WHERE vod_id = ? ORDER BY id DESC", (vid,)
                ).fetchall()
                self._send_json(
                    {
                        "items": [
                            {
                                "id": str(r["id"]),
                                "userName": r["user_name"],
                                "avatarUrl": "",
                                "content": r["content"],
                                "createdAt": r["created_at"],
                                "likes": r["likes"],
                            }
                            for r in rows
                        ]
                    }
                )
                return

        self._send_json({"error": "unknown_endpoint"}, 404)

    def do_POST(self) -> None:
        path = urlparse(self.path).path.rstrip("/")
        body = self._read_json()

        with get_conn() as conn:
            if path == "/app/v2/play":
                vod_id = int(body.get("vodId", 0))
                line_id = body.get("lineId", "")
                res_id = str(body.get("resourceId", ""))
                ep_idx = int(res_id.split(":")[-1]) if ":" in res_id else 1
                row = conn.execute("SELECT play_lines_json FROM vod WHERE vod_id = ?", (vod_id,)).fetchone()
                url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
                if row:
                    for line in json.loads(row["play_lines_json"]):
                        if line["lineId"] == line_id:
                            for ep in line.get("episodes", []):
                                if int(ep["index"]) == ep_idx:
                                    url = ep["url"]
                                    break
                fmt = "m3u8" if ".m3u8" in url else "mp4"
                self._send_json({"url": url, "headers": {}, "format": fmt})
                return

            if path == "/app/chat/sendbarrage":
                conn.execute(
                    "INSERT INTO barrages (vod_id, episode_idx, time_seconds, content, color_hex, is_top) VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        int(body.get("vid", 0)),
                        int(body.get("vod", 1)),
                        float(body.get("timeSeconds", 0.0)),
                        str(body.get("content", ""))[:120],
                        int(body.get("colorHex", 0xFFFFFFFF)),
                        1 if body.get("isTop") else 0,
                    ),
                )
                self._send_json({"ok": True})
                return

            if path == "/app/chat/sendcomment":
                conn.execute(
                    "INSERT INTO comments (vod_id, user_name, content, created_at, likes) VALUES (?, ?, ?, ?, 0)",
                    (
                        int(body.get("vid", 0)),
                        str(body.get("userName", "追番旅人"))[:32],
                        str(body.get("content", ""))[:500],
                        time.strftime("%Y-%m-%d %H:%M"),
                    ),
                )
                self._send_json({"ok": True})
                return

            if path in ("/app/auth/register", "/app/auth/login"):
                acc = str(body.get("account", "")).strip()
                pwd = str(body.get("password", ""))
                pwd_hash = hashlib.sha256(pwd.encode("utf-8")).hexdigest()
                row = conn.execute("SELECT * FROM users WHERE account = ?", (acc,)).fetchone()
                if path == "/app/auth/register" or row is None:
                    nick = str(body.get("nickName") or acc.split("@")[0] or "追番人")
                    conn.execute(
                        "INSERT OR REPLACE INTO users (account, password_sha256, nick_name) VALUES (?, ?, ?)",
                        (acc, pwd_hash, nick),
                    )
                    row = conn.execute("SELECT * FROM users WHERE account = ?", (acc,)).fetchone()
                elif row["password_sha256"] != pwd_hash:
                    self._send_json({"error": "invalid_credentials"}, 401)
                    return
                self._send_json(
                    {
                        "userId": str(10000 + row["user_id"]),
                        "email": row["account"],
                        "nickName": row["nick_name"],
                        "coins": row["coins"],
                        "downloadQuota": 5,
                        "passedQuiz": bool(row["passed_quiz"]),
                    }
                )
                return

            if path in ("/app/feedback", "/app/report/barrage", "/app/report/comment"):
                conn.execute(
                    "INSERT INTO feedback (category, content, vod_id, created_at) VALUES (?, ?, ?, ?)",
                    (
                        str(body.get("category", path)),
                        str(body.get("content", body.get("reason", ""))),
                        body.get("vodId"),
                        int(time.time()),
                    ),
                )
                self._send_json({"ok": True})
                return

        self._send_json({"error": "unknown_endpoint"}, 404)


def main() -> None:
    parser = argparse.ArgumentParser(description="Anime VOD Self-Hosted Backend")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--import-json", help="Import custom VOD catalog JSON file")
    args = parser.parse_args()

    init_db()
    if args.import_json:
        with open(args.import_json, "r", encoding="utf-8") as f, get_conn() as conn:
            data = json.load(f)
            items = data if isinstance(data, list) else data.get("items", [])
            for item in items:
                upsert_vod_dict(conn, item)
            print(f"Imported {len(items)} VOD entries into {DB_PATH}")

    server = ThreadingHTTPServer((args.host, args.port), ApiHandler)
    print(f"Backend listening on http://{args.host}:{args.port}/")
    server.serve_forever()


if __name__ == "__main__":
    main()
