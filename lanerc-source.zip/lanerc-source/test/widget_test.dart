import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:lanerc_cleanroom/core/models/vod_models.dart';
import 'package:lanerc_cleanroom/core/network/api_service.dart';
import 'package:lanerc_cleanroom/core/network/mock_demo_data.dart';
import 'package:lanerc_cleanroom/core/state/download_controller.dart';
import 'package:lanerc_cleanroom/core/state/user_controller.dart';
import 'package:lanerc_cleanroom/core/storage/local_database.dart';
import 'package:lanerc_cleanroom/core/theme/theme_controller.dart';
import 'package:lanerc_cleanroom/main.dart';

void main() {
  setUp(() async {
    Get.reset();
    SharedPreferences.setMockInitialValues({'seen_notice_v108': true});
    await LocalDatabase.instance.init(inMemoryForTest: true);
  });

  test('HtmlEntityUnescaper & backup/restore persistence round-trip', () async {
    expect(
      HtmlEntityUnescaper.unescape('Re：&quot;暴食&quot;的权能 &#39;test&#39;'),
      'Re："暴食"的权能 \'test\'',
    );

    final sample = MockDemoData.catalog.first;
    final added = await LocalDatabase.instance.toggleFavorite(sample);
    expect(added, isTrue);

    await LocalDatabase.instance.upsertHistory(
      HistoryRecord(
        vodID: sample.vodId,
        vodName: sample.vodName,
        vodClass: 1,
        vodSelect: 3,
        pic: sample.pic,
        seeTime: 142,
        lastTime: 1700000000000,
      ),
    );
    await LocalDatabase.instance.setPassedQuiz(true);
    await LocalDatabase.instance.setLocalCoins(90);

    final backupJson = await LocalDatabase.instance.exportBackupJson();
    expect(backupJson.contains(sample.vodName), isTrue);

    await LocalDatabase.instance.clearAllHistory();
    await LocalDatabase.instance.removeFavorites({sample.vodId});
    expect(LocalDatabase.instance.getFavorites(), isEmpty);

    final restoredCount =
        await LocalDatabase.instance.importBackupJson(backupJson);
    expect(restoredCount, 2);
    expect(LocalDatabase.instance.getFavorites().first.vodId, sample.vodId);
    final hist = await LocalDatabase.instance.getHistoryForVod(sample.vodId);
    expect(hist?.vodSelect, 3);
    expect(hist?.seeTime, 142);
  });

  testWidgets('Full consumer shell renders Home, Welfare, and Profile tabs',
      (WidgetTester tester) async {
    final themeCtrl = Get.put(ThemeController(), permanent: true);
    Get.put(UserController(), permanent: true);
    await Get.putAsync(() => ApiService().init(), permanent: true);
    Get.put(DownloadController(), permanent: true);

    await tester.pumpWidget(AnimeClientApp(themeController: themeCtrl));
    await tester.pump(const Duration(milliseconds: 600));
    await tester.pumpAndSettle();

    // Verify Home Tab layout elements
    expect(find.text('今天你想看些什么?'), findsOneWidget);
    expect(find.text('精选'), findsOneWidget);
    expect(find.text('日漫'), findsWidgets);
    expect(find.text('剧场版'), findsWidgets);
    expect(find.text('热度排行榜'), findsOneWidget);
    expect(find.text('番剧排期表'), findsOneWidget);

    // Switch to 福利 Tab
    await tester.tap(find.text('福利'));
    await tester.pumpAndSettle();
    expect(find.text('૮福利中心ა'), findsOneWidget);
    expect(find.text('我的金币'), findsOneWidget);

    // Switch to 我的 Tab
    await tester.tap(find.text('我的'));
    await tester.pumpAndSettle();
    expect(find.text('我的收藏'), findsOneWidget);
    expect(find.text('历史记录'), findsOneWidget);
    expect(find.text('离线缓存'), findsOneWidget);
    expect(find.text('入站问答'), findsOneWidget);
    expect(find.text('主题切换'), findsOneWidget);
    expect(find.text('数据恢复'), findsOneWidget);
  });
}
