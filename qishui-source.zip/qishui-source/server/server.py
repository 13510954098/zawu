import base64
import hashlib
import hmac
import json
import math
import os
import struct
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

GATEWAY_SECRET = b"cleanroom-local-gateway-hmac-key"
ENTITLEMENT_SECRET = b"cleanroom-local-entitlement-key!"

S_BOX = [
    0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76,
    0xCA, 0x82, 0xC9, 0x7D, 0xFA, 0x59, 0x47, 0xF0, 0xAD, 0xD4, 0xA2, 0xAF, 0x9C, 0xA4, 0x72, 0xC0,
    0xB7, 0xFD, 0x93, 0x26, 0x36, 0x3F, 0xF7, 0xCC, 0x34, 0xA5, 0xE5, 0xF1, 0x71, 0xD8, 0x31, 0x15,
    0x04, 0xC7, 0x23, 0xC3, 0x18, 0x96, 0x05, 0x9A, 0x07, 0x12, 0x80, 0xE2, 0xEB, 0x27, 0xB2, 0x75,
    0x09, 0x83, 0x2C, 0x1A, 0x1B, 0x6E, 0x5A, 0xA0, 0x52, 0x3B, 0xD6, 0xB3, 0x29, 0xE3, 0x2F, 0x84,
    0x53, 0xD1, 0x00, 0xED, 0x20, 0xFC, 0xB1, 0x5B, 0x6A, 0xCB, 0xBE, 0x39, 0x4A, 0x4C, 0x58, 0xCF,
    0xD0, 0xEF, 0xAA, 0xFB, 0x43, 0x4D, 0x33, 0x85, 0x45, 0xF9, 0x02, 0x7F, 0x50, 0x3C, 0x9F, 0xA8,
    0x51, 0xA3, 0x40, 0x8F, 0x92, 0x9D, 0x38, 0xF5, 0xBC, 0xB6, 0xDA, 0x21, 0x10, 0xFF, 0xF3, 0xD2,
    0xCD, 0x0C, 0x13, 0xEC, 0x5F, 0x97, 0x44, 0x17, 0xC4, 0xA7, 0x7E, 0x3D, 0x64, 0x5D, 0x19, 0x73,
    0x60, 0x81, 0x4F, 0xDC, 0x22, 0x2A, 0x90, 0x88, 0x46, 0xEE, 0xB8, 0x14, 0xDE, 0x5E, 0x0B, 0xDB,
    0xE0, 0x32, 0x3A, 0x0A, 0x49, 0x06, 0x24, 0x5C, 0xC2, 0xD3, 0xAC, 0x62, 0x91, 0x95, 0xE4, 0x79,
    0xE7, 0xC8, 0x37, 0x6D, 0x8D, 0xD5, 0x4E, 0xA9, 0x6C, 0x56, 0xF4, 0xEA, 0x65, 0x7A, 0xAE, 0x08,
    0xBA, 0x78, 0x25, 0x2E, 0x1C, 0xA6, 0xB4, 0xC6, 0xE8, 0xDD, 0x74, 0x1F, 0x4B, 0xBD, 0x8B, 0x8A,
    0x70, 0x3E, 0xB5, 0x66, 0x48, 0x03, 0xF6, 0x0E, 0x61, 0x35, 0x57, 0xB9, 0x86, 0xC1, 0x1D, 0x9E,
    0xE1, 0xF8, 0x98, 0x11, 0x69, 0xD9, 0x8E, 0x94, 0x9B, 0x1E, 0x87, 0xE9, 0xCE, 0x55, 0x28, 0xDF,
    0x8C, 0xA1, 0x89, 0x0D, 0xBF, 0xE6, 0x42, 0x68, 0x41, 0x99, 0x2D, 0x0F, 0xB0, 0x54, 0xBB, 0x16,
]

R_CON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def _xtime(x: int) -> int:
    return ((x << 1) ^ (((x >> 7) & 1) * 0x1B)) & 0xFF


def expand_key_128(key: bytes) -> bytearray:
    rk = bytearray(176)
    rk[:16] = key
    generated = 16
    rcon_idx = 1
    while generated < 176:
        temp = bytearray(rk[generated - 4 : generated])
        if generated % 16 == 0:
            temp = bytearray([
                S_BOX[temp[1]] ^ R_CON[rcon_idx],
                S_BOX[temp[2]],
                S_BOX[temp[3]],
                S_BOX[temp[0]],
            ])
            rcon_idx += 1
        for i in range(4):
            rk[generated] = rk[generated - 16] ^ temp[i]
            generated += 1
    return rk


def aes128_encrypt_block(block: bytes, rk: bytearray) -> bytearray:
    s = bytearray(block)

    def add_rk(rnd: int) -> None:
        base = rnd * 16
        for idx in range(16):
            s[idx] ^= rk[base + idx]

    def sub_bytes() -> None:
        for idx in range(16):
            s[idx] = S_BOX[s[idx]]

    def shift_rows() -> None:
        s[1], s[5], s[9], s[13] = s[5], s[9], s[13], s[1]
        s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
        s[15], s[11], s[7], s[3] = s[11], s[7], s[3], s[15]

    def mix_columns() -> None:
        for c in range(4):
            i = c * 4
            a0, a1, a2, a3 = s[i], s[i + 1], s[i + 2], s[i + 3]
            t = a0 ^ a1 ^ a2 ^ a3
            s[i] ^= t ^ _xtime(a0 ^ a1)
            s[i + 1] ^= t ^ _xtime(a1 ^ a2)
            s[i + 2] ^= t ^ _xtime(a2 ^ a3)
            s[i + 3] ^= t ^ _xtime(a3 ^ a0)

    add_rk(0)
    for r in range(1, 10):
        sub_bytes()
        shift_rows()
        mix_columns()
        add_rk(r)
    sub_bytes()
    shift_rows()
    add_rk(10)
    return s


def aes128_ctr_transform(data: bytes, key16: bytes, nonce8: bytes, initial_counter: int = 0) -> bytes:
    rk = expand_key_128(key16)
    out = bytearray(len(data))
    blk_idx = initial_counter
    for off in range(0, len(data), 16):
        ctr_blk = nonce8 + struct.pack(">Q", blk_idx)
        ks = aes128_encrypt_block(ctr_blk, rk)
        end = min(off + 16, len(data))
        for j in range(off, end):
            out[j] = data[j] ^ ks[j - off]
        blk_idx += 1
    return bytes(out)


TRACK_DB = [
    {
        "id": "luna_trk_101",
        "title": "霓虹失重 (Neon Weightless)",
        "artist": "林屿 / NovaLab",
        "album": "子夜频率 Vol.1",
        "moodScene": "抖音热歌",
        "durationMs": 24000,
        "bpm": 122,
        "chordHz": [261.63, 329.63, 392.00, 493.88],
        "colorPrimary": 0xFF00C853,
        "colorSecondary": 0xFF0E2A1E,
        "likeCount": 48200,
        "commentCount": 1920,
        "vipOnly": False,
        "qualities": ["标准", "极高", "无损 FLAC", "空间音频"],
        "lyrics": [
            {"timeMs": 0, "text": "霓虹把高架桥染成青色银河", "translation": "Neon paints the overpass into a cyan galaxy"},
            {"timeMs": 4500, "text": "耳机里鼓点刚好踩中脉搏", "translation": "The beat in my headphones hits right on the pulse"},
            {"timeMs": 9500, "text": "晚风吹散白天的所有沉默", "translation": "Night breeze scatters all the silence of the day"},
            {"timeMs": 14500, "text": "在这一秒让引力彻底失重", "translation": "Let gravity lose its weight in this very second"},
        ],
        "comments": [
            {"id": "c1", "author": "海盐汽水", "content": "开全景空间音效听前奏真的起鸡皮疙瘩！", "likes": 3412, "timeLabel": "2小时前"}
        ],
    },
    {
        "id": "luna_trk_102",
        "title": "海岛末班车",
        "artist": "苏夏",
        "album": "潮汐信件",
        "moodScene": "深夜EMO",
        "durationMs": 24000,
        "bpm": 88,
        "chordHz": [220.00, 261.63, 329.63, 392.00],
        "colorPrimary": 0xFF2979FF,
        "colorSecondary": 0xFF0E1D3A,
        "likeCount": 62900,
        "commentCount": 4108,
        "vipOnly": False,
        "qualities": ["标准", "极高", "无损 FLAC", "空间音频"],
        "lyrics": [
            {"timeMs": 0, "text": "沿海公路路灯一盏盏退后", "translation": "Streetlights along the coastal road fade one by one"},
            {"timeMs": 6000, "text": "车窗倒映着没说出口的温柔", "translation": "The window reflects unspoken tenderness"},
        ],
        "comments": [],
    },
    {
        "id": "luna_trk_103",
        "title": "山海入梦令",
        "artist": "云裳乐团",
        "album": "东方幻想录",
        "moodScene": "国风新韵",
        "durationMs": 24000,
        "bpm": 104,
        "chordHz": [293.66, 329.63, 392.00, 440.00],
        "colorPrimary": 0xFFFF6D00,
        "colorSecondary": 0xFF33190A,
        "likeCount": 35800,
        "commentCount": 1480,
        "vipOnly": True,
        "qualities": ["标准", "极高", "无损 FLAC", "空间音频"],
        "lyrics": [
            {"timeMs": 0, "text": "竹影摇碎一池星河微光", "translation": "Bamboo shadows shatter starlight on the pond"},
            {"timeMs": 6000, "text": "长笛横吹引来山海回响", "translation": "Flute notes summon echoes across mountains and seas"},
        ],
        "comments": [],
    },
]


def synthesize_demo_wav(freq_hz: float = 261.63, duration_sec: int = 1, sample_rate: int = 8000) -> bytes:
    num_samples = sample_rate * duration_sec
    pcm = bytearray()
    for i in range(num_samples):
        t = i / sample_rate
        val = int(math.sin(2.0 * math.pi * freq_hz * t) * 14000)
        pcm += struct.pack("<hh", val, val)
    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF",
        36 + len(pcm),
        b"WAVE",
        b"fmt ",
        16,
        1,
        2,
        sample_rate,
        sample_rate * 4,
        4,
        16,
        b"data",
        len(pcm),
    )
    return header + bytes(pcm)


def verify_gateway_headers(method: str, path: str, query_dict: dict, body_bytes: bytes, headers) -> bool:
    ts = headers.get("X-Clean-Ts", "")
    nonce = headers.get("X-Clean-Nonce", "")
    did = headers.get("X-Clean-Did", "")
    sig = headers.get("X-Clean-Sig", "")
    if not (ts and nonce and did and sig):
        return True
    try:
        ts_val = int(ts)
    except ValueError:
        return False
    now_ms = int(time.time() * 1000)
    if abs(now_ms - ts_val) > 300000:
        return False
    canonical_query = "&".join(f"{k}={query_dict[k]}" for k in sorted(query_dict.keys()))
    body_hash = hashlib.sha256(body_bytes).hexdigest()
    canonical = f"{method.upper()}\n{path}\n{canonical_query}\n{ts}\n{nonce}\n{did}\n{body_hash}"
    expected = hmac.new(GATEWAY_SECRET, canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)


def issue_entitlement_dict(user_id: str, minutes: int) -> dict:
    now_ms = int(time.time() * 1000)
    exp_ms = now_ms + minutes * 60 * 1000
    tier = "REWARDED_FREE_LISTEN"
    msg = f"{user_id}|{tier}|{exp_ms}|{minutes}".encode("utf-8")
    sig = hmac.new(ENTITLEMENT_SECRET, msg, hashlib.sha256).hexdigest()
    return {
        "userId": user_id,
        "tier": tier,
        "expireAtMs": exp_ms,
        "grantedMinutes": minutes,
        "hmacHex": sig,
    }


class LunaCleanRoomHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args) -> None:
        return

    def _send_json(self, status: int, payload: dict) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        qmap = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        if not verify_gateway_headers("GET", parsed.path, qmap, b"", self.headers):
            self._send_json(401, {"error": "invalid_gateway_signature"})
            return

        if parsed.path == "/luna/feed":
            mood = qmap.get("mood", "全部推荐")
            items = TRACK_DB if mood == "全部推荐" else [t for t in TRACK_DB if t["moodScene"] == mood]
            self._send_json(200, {"tracks": items or TRACK_DB})
        elif parsed.path == "/luna/search":
            kw = qmap.get("q", "").lower()
            items = [
                t
                for t in TRACK_DB
                if kw in t["title"].lower() or kw in t["artist"].lower() or kw in t["moodScene"].lower()
            ]
            self._send_json(200, {"tracks": items})
        elif parsed.path == "/luna/stream/encrypted_wav":
            media_id = qmap.get("mediaId", "luna_trk_101")
            plain = synthesize_demo_wav()
            session_key = os.urandom(16)
            nonce = os.urandom(8)
            cipher = aes128_ctr_transform(plain, session_key, nonce)
            self._send_json(
                200,
                {
                    "mediaId": media_id,
                    "keyHex": session_key.hex(),
                    "nonceHex": nonce.hex(),
                    "cipherB64": base64.b64encode(cipher).decode("ascii"),
                    "plainSha256": hashlib.sha256(plain).hexdigest(),
                },
            )
        else:
            self._send_json(200, {"status": "ok", "service": "qishui_cleanroom_server"})

    def do_POST(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length > 0 else b"{}"
        if not verify_gateway_headers("POST", parsed.path, {}, body, self.headers):
            self._send_json(401, {"error": "invalid_gateway_signature"})
            return

        data = json.loads(body.decode("utf-8") or "{}")
        if parsed.path == "/luna/advert/incentive/done":
            uid = str(data.get("userId", "luna_local_user_01"))
            mins = int(data.get("minutes", 30))
            self._send_json(200, issue_entitlement_dict(uid, mins))
        elif parsed.path == "/luna/ai/creation/gen":
            prompt = str(data.get("prompt", "星河灵感")).strip() or "星河灵感"
            mood = str(data.get("moodScene", "抖音热歌"))
            bpm = int(data.get("bpm", 118))
            created = {
                "id": f"ai_srv_{int(time.time() * 1000)}",
                "title": f"{prompt} (AI 生成)",
                "artist": "汽水 AI 实验室",
                "album": "AI 灵感单曲",
                "moodScene": mood,
                "durationMs": 20000,
                "bpm": bpm,
                "chordHz": [261.63, 329.63, 392.00, 523.25],
                "colorPrimary": 0xFF7C4DFF,
                "colorSecondary": 0xFF1B1238,
                "likeCount": 1,
                "commentCount": 0,
                "vipOnly": False,
                "qualities": ["标准", "极高", "无损 FLAC", "空间音频"],
                "lyrics": [
                    {"timeMs": 0, "text": f"由灵感「{prompt}」唤醒夜色声场", "translation": ""},
                    {"timeMs": 6000, "text": "合成波与心跳在耳畔共振", "translation": ""},
                ],
                "comments": [],
            }
            TRACK_DB.insert(0, created)
            self._send_json(200, {"track": created})
        else:
            self._send_json(200, {"ok": True})


def run_server(host: str = "127.0.0.1", port: int = 8478) -> None:
    httpd = ThreadingHTTPServer((host, port), LunaCleanRoomHandler)
    httpd.serve_forever()


if __name__ == "__main__":
    run_server()
