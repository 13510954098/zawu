import io
import json
import math
import os
import sqlite3
import struct
import time
import urllib.parse
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qishui_server.db")
WAV_MEM_CACHE = {}

SEED_TRACKS = [
    {
        "id": "trk_01",
        "title": "薄荷汽水与落日海湾",
        "artist": "橘子海屿",
        "album": "夏日气泡特调",
        "channel": "推荐",
        "durationSec": 20,
        "bpm": 112,
        "chordFreqs": [261.63, 392.00, 440.00, 349.23],
        "primaryColorValue": 0xFF00C978,
        "secondaryColorValue": 0xFF134E5E,
        "qualityBadge": "Hi-Res",
        "isVip": False,
        "isAiGenerated": False,
        "likesCount": 48200,
        "commentsCount": 1640,
        "sharesCount": 920,
        "lrc": "[00:00.00]海风吹散傍晚六点的云朵|Sea breeze clears the twilight clouds\n[00:04.00]冰镇薄荷在玻璃杯里闪烁|Chilled mint sparkles inside the glass\n[00:08.00]耳机分你一半听潮汐起落|Sharing an earbud as tides rise and fall\n[00:12.00]橘色落日把影子拉得很慢|Orange sunset stretches our shadows slow\n[00:16.00]这一刻心动随气泡升空|Heartbeats float upward with every bubble",
        "streamUrl": "/media/track/trk_01.wav",
    },
    {
        "id": "trk_02",
        "title": "霓虹高架桥 02:15",
        "artist": "午夜合成器",
        "album": "不眠都市电台",
        "channel": "电音派对",
        "durationSec": 20,
        "bpm": 126,
        "chordFreqs": [220.00, 261.63, 329.63, 392.00],
        "primaryColorValue": 0xFF7C5CFF,
        "secondaryColorValue": 0xFF1F1147,
        "qualityBadge": "臻品母带",
        "isVip": True,
        "isAiGenerated": False,
        "likesCount": 91300,
        "commentsCount": 3120,
        "sharesCount": 2050,
        "lrc": "[00:00.00]穿过凌晨两点半的隧道灯光|Cruising past 2:30 AM tunnel lights\n[00:04.00]合成器低频在胸口微微震荡|Synth sub-bass hums softly in my chest\n[00:08.00]后视镜折返整座城市的星河|Rearview mirror bends the city galaxy\n[00:12.00]不问终点只管把音量推高|No destination just turn the gain up\n[00:16.00]在赛博夜色里自由失重|Weightless inside the neon night",
        "streamUrl": "/media/track/trk_02.wav",
    },
    {
        "id": "trk_03",
        "title": "烟雨入江南",
        "artist": "云山折扇",
        "album": "山河听风录",
        "channel": "国风新韵",
        "durationSec": 20,
        "bpm": 92,
        "chordFreqs": [293.66, 329.63, 392.00, 440.00],
        "primaryColorValue": 0xFF2EC4B6,
        "secondaryColorValue": 0xFF1B3B48,
        "qualityBadge": "无损 SQ",
        "isVip": False,
        "isAiGenerated": False,
        "likesCount": 62500,
        "commentsCount": 2190,
        "sharesCount": 1480,
        "lrc": "[00:00.00]青石阶上落满一宿春雨声|Spring rain lingers on mossy stone steps\n[00:04.00]乌篷船摇碎桥下灯火几盏|Oars ripple lantern reflections below the arch\n[00:08.00]竹笛轻叹吹开远山薄雾|Bamboo flute parts the distant mountain mist\n[00:12.00]一盏新茶温热旧时书信|Fresh tea warms pages of an old letter\n[00:16.00]人间清欢不过此刻微风|Quiet joy is simply this gentle breeze",
        "streamUrl": "/media/track/trk_03.wav",
    },
    {
        "id": "trk_04",
        "title": "银河便利店打烊前",
        "artist": "白日梦航线",
        "album": "温柔宇宙漫游",
        "channel": "深夜治愈",
        "durationSec": 20,
        "bpm": 84,
        "chordFreqs": [246.94, 329.63, 369.99, 493.88],
        "primaryColorValue": 0xFFFF6B8B,
        "secondaryColorValue": 0xFF2D1936,
        "qualityBadge": "Hi-Res",
        "isVip": False,
        "isAiGenerated": False,
        "likesCount": 73400,
        "commentsCount": 4080,
        "sharesCount": 1890,
        "lrc": "[00:00.00]街角暖黄灯牌还在等你回家|Warm corner sign still waits for you\n[00:04.00]热牛奶蒸腾出小小的云霞|Warm milk rises in tiny clouds\n[00:08.00]把今天所有的疲惫轻轻放下|Set down every trace of tired weight\n[00:12.00]星星落在窗台替你说晚安|Stars land on the sill to whisper goodnight\n[00:16.00]明天醒来又是晴朗出发|Wake tomorrow to a clear departure",
        "streamUrl": "/media/track/trk_04.wav",
    },
]


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS tracks (id TEXT PRIMARY KEY, channel TEXT, payload TEXT)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS comments (id TEXT PRIMARY KEY, track_id TEXT, payload TEXT, created_at INTEGER)"
    )
    count = conn.execute("SELECT COUNT(*) FROM tracks").fetchone()[0]
    if count == 0:
        for item in SEED_TRACKS:
            conn.execute(
                "INSERT INTO tracks (id, channel, payload) VALUES (?, ?, ?)",
                (item["id"], item["channel"], json.dumps(item, ensure_ascii=False)),
            )
        seed_cm = {
            "id": "cm_seed_1",
            "trackId": "trk_01",
            "author": "海盐气泡水",
            "content": "服务端实时合成的立体声和弦太清透了！",
            "likedCount": 520,
            "timeLabel": "刚刚",
            "atSecond": 3,
        }
        conn.execute(
            "INSERT INTO comments (id, track_id, payload, created_at) VALUES (?, ?, ?, ?)",
            (seed_cm["id"], "trk_01", json.dumps(seed_cm, ensure_ascii=False), int(time.time())),
        )
        conn.commit()
    conn.close()


def synthesize_wav(track_id):
    if track_id in WAV_MEM_CACHE:
        return WAV_MEM_CACHE[track_id]
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT payload FROM tracks WHERE id = ?", (track_id,)).fetchone()
    conn.close()
    meta = json.loads(row[0]) if row else SEED_TRACKS[0]
    notes = meta.get("chordFreqs") or [261.63, 329.63, 392.00, 523.25]
    bpm = max(60, int(meta.get("bpm", 108)))
    duration_sec = min(20, max(6, int(meta.get("durationSec", 16))))
    sample_rate = 22050
    total_frames = sample_rate * duration_sec
    beat_sec = 60.0 / bpm
    bar_sec = beat_sec * 4.0

    pcm = bytearray()
    for i in range(total_frames):
        t = i / sample_rate
        bar_idx = int(t / bar_sec)
        root = float(notes[bar_idx % len(notes)])
        third = root * 1.2599
        fifth = root * 1.4983
        beat_pos = (t % beat_sec) / beat_sec
        arp = float(notes[int(t / (beat_sec * 0.5)) % len(notes)]) * 2.0
        env = math.exp(-3.0 * beat_pos)
        pad_l = 0.20 * math.sin(2 * math.pi * root * t) + 0.14 * math.sin(2 * math.pi * third * t + 0.2) + 0.10 * math.sin(2 * math.pi * fifth * t)
        pad_r = 0.20 * math.sin(2 * math.pi * root * t + 0.1) + 0.14 * math.sin(2 * math.pi * third * t) + 0.10 * math.sin(2 * math.pi * fifth * t + 0.3)
        pluck = 0.22 * env * math.sin(2 * math.pi * arp * t)
        bass = 0.24 * math.exp(-2.0 * beat_pos) * math.sin(2 * math.pi * (root * 0.5) * t)
        left = max(-0.95, min(0.95, pad_l + pluck * 0.9 + bass))
        right = max(-0.95, min(0.95, pad_r + pluck * 1.1 + bass))
        pcm += struct.pack("<hh", int(left * 32767), int(right * 32767))

    out = io.BytesIO()
    with wave.open(out, "wb") as wf:
        wf.setnchannels(2)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(bytes(pcm))
    data = out.getvalue()
    WAV_MEM_CACHE[track_id] = data
    return data


class QishuiRequestHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send_json(self, obj, status=200):
        raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/api/health":
            self._send_json({"ok": True, "service": "qishui-cleanroom-server"})
            return

        if parsed.path == "/api/feed":
            channel = (qs.get("channel") or ["推荐"])[0]
            conn = sqlite3.connect(DB_PATH)
            rows = conn.execute("SELECT payload FROM tracks").fetchall()
            conn.close()
            all_tracks = [json.loads(r[0]) for r in rows]
            if channel not in ("推荐", "随心听"):
                filtered = [t for t in all_tracks if t.get("channel") == channel]
                if filtered:
                    all_tracks = filtered
            self._send_json({"tracks": all_tracks})
            return

        if parsed.path == "/api/search":
            q = ((qs.get("q") or [""])[0]).strip().lower()
            conn = sqlite3.connect(DB_PATH)
            rows = conn.execute("SELECT payload FROM tracks").fetchall()
            conn.close()
            items = [json.loads(r[0]) for r in rows]
            if q:
                items = [
                    t
                    for t in items
                    if q in t["title"].lower()
                    or q in t["artist"].lower()
                    or q in t["album"].lower()
                ]
            self._send_json({"tracks": items})
            return

        if parsed.path == "/api/comments":
            track_id = (qs.get("trackId") or ["trk_01"])[0]
            conn = sqlite3.connect(DB_PATH)
            rows = conn.execute(
                "SELECT payload FROM comments WHERE track_id = ? ORDER BY created_at DESC",
                (track_id,),
            ).fetchall()
            conn.close()
            self._send_json({"comments": [json.loads(r[0]) for r in rows]})
            return

        if parsed.path == "/api/room":
            self._send_json(
                {
                    "roomId": "RM-8801",
                    "roomTitle": "深夜气泡电台 · 一起听",
                    "hostName": "星河漫游者",
                    "onlineCount": 5,
                    "currentTrackId": "trk_01",
                    "positionMs": 3600,
                    "isPlaying": True,
                    "messages": [
                        {"sender": "星河漫游者", "text": "已连接本地实时合成电台", "timeLabel": "刚刚"}
                    ],
                }
            )
            return

        if parsed.path.startswith("/media/track/") and parsed.path.endswith(".wav"):
            track_id = parsed.path[len("/media/track/") : -len(".wav")]
            wav_bytes = synthesize_wav(track_id)
            total = len(wav_bytes)
            range_hdr = self.headers.get("Range")
            if range_hdr and range_hdr.startswith("bytes="):
                parts = range_hdr[6:].split("-")
                start = int(parts[0]) if parts[0] else 0
                end = int(parts[1]) if len(parts) > 1 and parts[1] else total - 1
                end = min(end, total - 1)
                chunk = wav_bytes[start : end + 1]
                self.send_response(206)
                self.send_header("Content-Type", "audio/wav")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                self.send_header("Content-Length", str(len(chunk)))
                self.end_headers()
                self.wfile.write(chunk)
                return
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(total))
            self.end_headers()
            self.wfile.write(wav_bytes)
            return

        self._send_json({"error": "not_found"}, status=404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or "0")
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}") if length > 0 else {}

        if self.path == "/api/comments":
            now_ms = int(time.time() * 1000)
            cm = {
                "id": f"cm_{now_ms}",
                "trackId": str(body.get("trackId") or "trk_01"),
                "author": str(body.get("author") or "汽水听友"),
                "content": str(body.get("content") or ""),
                "likedCount": 1,
                "timeLabel": "刚刚",
                "atSecond": int(body.get("atSecond") or 0),
            }
            conn = sqlite3.connect(DB_PATH)
            conn.execute(
                "INSERT INTO comments (id, track_id, payload, created_at) VALUES (?, ?, ?, ?)",
                (cm["id"], cm["trackId"], json.dumps(cm, ensure_ascii=False), now_ms),
            )
            conn.commit()
            conn.close()
            self._send_json({"comment": cm})
            return

        if self.path == "/api/ai/compose":
            now_ms = int(time.time() * 1000)
            prompt = str(body.get("prompt") or "气泡即兴夜曲").strip() or "气泡即兴夜曲"
            style = str(body.get("style") or "海风 CityPop").strip()
            track_id = f"ai_{now_ms}"
            trk = {
                "id": track_id,
                "title": prompt[:14],
                "artist": f"AI 灵感工坊 · {style}",
                "album": "AI 原创单曲集",
                "channel": "推荐",
                "durationSec": 20,
                "bpm": 110,
                "chordFreqs": [261.63, 329.63, 392.00, 493.88],
                "primaryColorValue": 0xFF00F090,
                "secondaryColorValue": 0xFF163A4A,
                "qualityBadge": "AI 母带",
                "isVip": False,
                "isAiGenerated": True,
                "likesCount": 1,
                "commentsCount": 0,
                "sharesCount": 0,
                "lrc": f"[00:00.00]{prompt}|AI Studio · {style}\n[00:05.00]合成律动在耳畔缓缓展开|Cleanroom Synth Engine",
                "streamUrl": f"/media/track/{track_id}.wav",
            }
            conn = sqlite3.connect(DB_PATH)
            conn.execute(
                "INSERT INTO tracks (id, channel, payload) VALUES (?, ?, ?)",
                (track_id, "推荐", json.dumps(trk, ensure_ascii=False)),
            )
            conn.commit()
            conn.close()
            self._send_json({"track": trk})
            return

        self._send_json({"error": "not_found"}, status=404)


def run_server():
    init_db()
    port = int(os.environ.get("PORT", "8790"))
    httpd = ThreadingHTTPServer(("0.0.0.0", port), QishuiRequestHandler)
    httpd.serve_forever()


if __name__ == "__main__":
    run_server()
