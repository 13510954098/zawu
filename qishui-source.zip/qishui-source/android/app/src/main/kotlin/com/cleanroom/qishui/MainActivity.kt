package com.cleanroom.qishui

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
