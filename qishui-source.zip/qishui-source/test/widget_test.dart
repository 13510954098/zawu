import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:qishui_cleanroom/core/audio/pcm_wav_synthesizer.dart';
import 'package:qishui_cleanroom/core/network/demo_catalog.dart';
import 'package:qishui_cleanroom/core/security/cleanroom_guard_engine.dart';
import 'package:qishui_cleanroom/core/state/luna_app_state.dart';
import 'package:qishui_cleanroom/main.dart';

void main() {
  test('NIST FIPS-197 AES-128-CTR, HMAC gateway signing, and entitlement ledger verify cleanly', () {
    final fipsKey = CleanRoomGuardEngine.hexDecode('2b7e151628aed2a6abf7158809cf4f3c');
    final fipsPlain = CleanRoomGuardEngine.hexDecode('3243f6a8885a308d313198a2e0370734');
    final fipsBlock = CleanRoomAes128Ctr.encryptBlock(fipsPlain, fipsKey);
    expect(
      CleanRoomGuardEngine.hexEncode(fipsBlock),
      equals('3925841d02dc09fbdc118597196a0b32'),
    );

    final guard = CleanRoomGuardEngine();
    final track = DemoCatalog.initialTracks().first;
    final wav = PcmWavSynthesizer.buildStereoWav(track, maxSeconds: 2);
    expect(String.fromCharCodes(wav.sublist(0, 4)), equals('RIFF'));
    expect(String.fromCharCodes(wav.sublist(8, 12)), equals('WAVE'));

    final slice = Uint8List.sublistView(wav, 0, 1024);
    final packet = guard.sealAudioChunk(mediaId: track.id, plainWavBytes: slice);
    final restored = guard.openAudioChunk(packet);
    expect(restored, equals(slice));

    final headers = guard.signGatewayRequest(
      method: 'GET',
      path: '/luna/feed',
      query: {'mood': '抖音热歌'},
      timestampMs: 1700000000000,
    );
    expect(
      guard.verifyGatewayRequest(
        method: 'GET',
        path: '/luna/feed',
        headers: headers,
        query: {'mood': '抖音热歌'},
        nowMs: 1700000010000,
      ),
      isTrue,
    );

    final ticket = guard.issueRewardedEntitlement(
      userId: 'u_test',
      grantMinutes: 30,
      nowMs: 1700000000000,
    );
    expect(guard.verifyEntitlementTicket(ticket, nowMs: 1700000500000), isTrue);
    expect(guard.verifyEntitlementTicket(ticket, nowMs: 1700009999999), isFalse);
  });

  testWidgets('Full 5-tab navigation including ProtocolGuardPage renders without error', (WidgetTester tester) async {
    final state = LunaAppState();
    await state.bootstrap(enableNativeAudio: false);

    await tester.pumpWidget(QishuiCleanRoomApp(state: state));
    await tester.pump();

    expect(find.textContaining('霓虹失重'), findsWidgets);

    await tester.tap(find.text('发现'));
    await tester.pumpAndSettle();
    expect(find.text('发现电台与热歌榜'), findsOneWidget);

    await tester.tap(find.text('AI创作'));
    await tester.pumpAndSettle();
    expect(find.text('AI 灵感成曲'), findsOneWidget);

    await tester.tap(find.text('流控'));
    await tester.pumpAndSettle();
    expect(find.textContaining('AES-128-CTR'), findsOneWidget);
    expect(find.textContaining('HMAC-SHA256'), findsOneWidget);

    await tester.tap(find.text('我的'));
    await tester.pumpAndSettle();
    expect(find.textContaining('汽水乐迷'), findsOneWidget);
  });
}
