import 'package:flutter_test/flutter_test.dart';
import 'package:get/get.dart';
import 'package:qishui_cleanroom/app/routes/app_routes.dart';
import 'package:qishui_cleanroom/main.dart';

void main() {
  setUp(() async {
    Get.testMode = true;
    Get.reset();
    await bootstrapDependencies();
  });

  tearDown(() {
    Get.reset();
  });

  testWidgets('Shell renders vertical feed and switches across all four tabs', (tester) async {
    await tester.pumpWidget(const QishuiCleanroomApp(initialRoute: AppRoutes.shell));
    await tester.pump(const Duration(milliseconds: 300));

    expect(find.text('推荐'), findsWidgets);
    expect(find.text('薄荷汽水与落日海湾'), findsWidgets);

    await tester.tap(find.text('发现'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('发现音乐'), findsOneWidget);
    expect(find.text('官方风向榜'), findsOneWidget);

    await tester.tap(find.text('AI创作'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('AI 音乐实验室'), findsOneWidget);
    expect(find.text('立即生成并试听'), findsOneWidget);

    await tester.tap(find.text('我的'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('自建歌单'), findsOneWidget);
    expect(find.text('车载驾驶大屏模式'), findsOneWidget);
  });

  testWidgets('Car mode and search routes render interactive controls', (tester) async {
    await tester.pumpWidget(const QishuiCleanroomApp(initialRoute: AppRoutes.carMode));
    await tester.pump(const Duration(milliseconds: 250));

    expect(find.text('汽水车载行车模式'), findsOneWidget);
    expect(find.text('红心收藏'), findsOneWidget);
    expect(find.text('下一首'), findsOneWidget);
  });
}
