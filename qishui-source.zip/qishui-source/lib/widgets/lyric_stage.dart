import 'package:flutter/material.dart';
import '../core/models/music_models.dart';
import '../core/theme/soda_theme.dart';

class LyricStage extends StatelessWidget {
  final List<LyricLine> lines;
  final int activeIndex;
  final ValueChanged<Duration> onSeekLine;
  final VoidCallback onCollapse;

  const LyricStage({
    super.key,
    required this.lines,
    required this.activeIndex,
    required this.onSeekLine,
    required this.onCollapse,
  });

  @override
  Widget build(BuildContext context) {
    if (lines.isEmpty) {
      return GestureDetector(
        onTap: onCollapse,
        child: const Center(
          child: Text(
            '纯音乐或暂无时间轴歌词，轻触返回唱片',
            style: TextStyle(color: SodaPalette.textSecondary, fontSize: 15),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: onCollapse,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 36),
        itemCount: lines.length,
        itemBuilder: (context, idx) {
          final item = lines[idx];
          final isCurrent = idx == activeIndex;
          return InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => onSeekLine(Duration(milliseconds: item.timeMs)),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.text,
                    style: TextStyle(
                      color: isCurrent ? SodaPalette.accent : Colors.white60,
                      fontSize: isCurrent ? 21 : 16,
                      fontWeight: isCurrent ? FontWeight.w800 : FontWeight.w500,
                      height: 1.35,
                    ),
                  ),
                  if (item.subText.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      item.subText,
                      style: TextStyle(
                        color: isCurrent
                            ? Colors.white.withValues(alpha: 0.85)
                            : Colors.white38,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
