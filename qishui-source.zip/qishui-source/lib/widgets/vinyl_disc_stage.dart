import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/models/music_models.dart';
import '../core/theme/soda_theme.dart';

class VinylDiscStage extends StatefulWidget {
  final MusicTrack track;
  final bool isPlaying;
  final bool coverMode;
  final VoidCallback onTapStage;

  const VinylDiscStage({
    super.key,
    required this.track,
    required this.isPlaying,
    this.coverMode = false,
    required this.onTapStage,
  });

  @override
  State<VinylDiscStage> createState() => _VinylDiscStageState();
}

class _VinylDiscStageState extends State<VinylDiscStage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spinController;

  @override
  void initState() {
    super.initState();
    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    );
    if (widget.isPlaying) {
      _spinController.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant VinylDiscStage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isPlaying && !_spinController.isAnimating) {
      _spinController.repeat();
    } else if (!widget.isPlaying && _spinController.isAnimating) {
      _spinController.stop();
    }
  }

  @override
  void dispose() {
    _spinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.coverMode) {
      return GestureDetector(
        onTap: widget.onTapStage,
        child: Center(
          child: Container(
            width: 286,
            height: 286,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  widget.track.primaryColor,
                  widget.track.secondaryColor,
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.track.primaryColor.withValues(alpha: 0.36),
                  blurRadius: 36,
                  spreadRadius: 4,
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  right: -24,
                  top: -24,
                  child: Container(
                    width: 140,
                    height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(alpha: 0.12),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.32),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          '${widget.track.channel} · ${widget.track.bpm} BPM',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        widget.track.album,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        widget.track.artist,
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: widget.onTapStage,
      child: Center(
        child: SizedBox(
          width: 280,
          height: 280,
          child: AnimatedBuilder(
            animation: _spinController,
            builder: (context, child) {
              return Transform.rotate(
                angle: _spinController.value * 2 * math.pi,
                child: child,
              );
            },
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(
                  colors: [
                    Color(0xFF2B303C),
                    Color(0xFF11131A),
                    Color(0xFF1D212B),
                    Color(0xFF0A0B0F),
                  ],
                  stops: [0.35, 0.62, 0.82, 1.0],
                ),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.12),
                  width: 6,
                ),
                boxShadow: [
                  BoxShadow(
                    color: widget.track.primaryColor.withValues(alpha: 0.30),
                    blurRadius: 34,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Center(
                child: Container(
                  width: 148,
                  height: 148,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        widget.track.primaryColor,
                        widget.track.secondaryColor,
                      ],
                    ),
                    border: Border.all(color: SodaPalette.bgPrimary, width: 4),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.graphic_eq_rounded, color: Colors.white, size: 28),
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          child: Text(
                            widget.track.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          width: 18,
                          height: 18,
                          decoration: const BoxDecoration(
                            color: SodaPalette.bgPrimary,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
