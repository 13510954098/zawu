import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../core/models/music_models.dart';
import '../core/player/bach_player_controller.dart';
import '../core/state/library_controller.dart';
import '../core/theme/soda_theme.dart';

void showDspAndQualitySheet(BuildContext context, BachPlayerController player) {
  const qualities = ['标准 128k', '极高 HQ', '无损 SQ', 'Hi-Res'];
  const bandLabels = ['60Hz', '230Hz', '910Hz', '3.6kHz', '14kHz'];

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Obx(() {
            final preset = player.activePreset.value;
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '汽水音效与音质引擎',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                    ),
                    Text(
                      preset.name,
                      style: const TextStyle(
                        color: SodaPalette.accent,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  height: 96,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: SodaPalette.bgCard,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: List.generate(5, (i) {
                      final gain = i < preset.bands.length ? preset.bands[i] : 0.0;
                      final norm = ((gain + 10.0) / 20.0).clamp(0.12, 1.0);
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Expanded(
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 220),
                                width: 14,
                                height: 52 * norm,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(99),
                                  gradient: const LinearGradient(
                                    begin: Alignment.bottomCenter,
                                    end: Alignment.topCenter,
                                    colors: [
                                      SodaPalette.accentSecondary,
                                      SodaPalette.accent,
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            bandLabels[i],
                            style: const TextStyle(
                              fontSize: 10,
                              color: SodaPalette.textSecondary,
                            ),
                          ),
                        ],
                      );
                    }),
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: player.dspPresets.map((item) {
                    final selected = item.id == preset.id;
                    return ChoiceChip(
                      label: Text(item.name),
                      selected: selected,
                      selectedColor: SodaPalette.accent.withValues(alpha: 0.24),
                      labelStyle: TextStyle(
                        color: selected ? SodaPalette.accent : Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                      onSelected: (_) => player.applyDspPreset(item),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 8),
                Text(
                  preset.subtitle,
                  style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                ),
                const SizedBox(height: 18),
                const Text(
                  '在线流媒体音质档位',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: qualities.map((q) {
                    final selected = player.selectedQuality.value == q;
                    return ChoiceChip(
                      label: Text(q),
                      selected: selected,
                      selectedColor: SodaPalette.accentSecondary.withValues(alpha: 0.30),
                      onSelected: (_) => player.selectedQuality.value = q,
                    );
                  }).toList(),
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      '睡眠定时关闭',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                    ),
                    if (player.sleepRemainSec.value > 0)
                      Text(
                        '剩余 ${SodaTheme.formatDuration(Duration(seconds: player.sleepRemainSec.value))}',
                        style: const TextStyle(color: SodaPalette.accent, fontSize: 12),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [0, 15, 30, 60].map((mins) {
                    final label = mins == 0 ? '关闭' : '$mins 分钟';
                    return ActionChip(
                      label: Text(label),
                      onPressed: () => player.configureSleepTimer(mins),
                    );
                  }).toList(),
                ),
              ],
            );
          }),
        ),
      );
    },
  );
}

void showTrackCommentsSheet(
  BuildContext context,
  BachPlayerController player,
  LibraryController library,
) {
  final track = player.currentTrack;
  final inputCtrl = TextEditingController();
  final comments = <TrackComment>[].obs;
  final loading = true.obs;

  player.api.fetchComments(track.id).then((list) {
    comments.assignAll(list);
    loading.value = false;
  });

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      return Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: SafeArea(
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.68,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Obx(
                        () => Text(
                          '歌曲热评 (${comments.length})',
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                        ),
                      ),
                      Text(
                        track.title,
                        style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: Colors.white12),
                Expanded(
                  child: Obx(() {
                    if (loading.value) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    return ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: comments.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (_, i) {
                        final cm = comments[i];
                        return Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: SodaPalette.bgCard,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    radius: 14,
                                    backgroundColor: SodaPalette.accent.withValues(alpha: 0.2),
                                    child: Text(
                                      cm.author.characters.first,
                                      style: const TextStyle(
                                        color: SodaPalette.accent,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      cm.author,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    cm.timeLabel,
                                    style: const TextStyle(
                                      color: SodaPalette.textSecondary,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(cm.content, style: const TextStyle(fontSize: 14, height: 1.4)),
                              const SizedBox(height: 8),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '共鸣点 ${SodaTheme.formatDuration(Duration(seconds: cm.atSecond))}',
                                    style: const TextStyle(
                                      color: SodaPalette.accent,
                                      fontSize: 11,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.thumb_up_alt_outlined,
                                        size: 14,
                                        color: SodaPalette.textSecondary,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        SodaTheme.formatCount(cm.likedCount),
                                        style: const TextStyle(
                                          color: SodaPalette.textSecondary,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }),
                ),
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  color: SodaPalette.bgCard,
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: inputCtrl,
                          decoration: InputDecoration(
                            hintText: '留下此刻听歌心情...',
                            isDense: true,
                            filled: true,
                            fillColor: SodaPalette.bgPrimary,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(999),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 10,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: SodaPalette.accent,
                          foregroundColor: Colors.black,
                        ),
                        onPressed: () async {
                          final text = inputCtrl.text.trim();
                          if (text.isEmpty) return;
                          inputCtrl.clear();
                          final added = await player.api.postComment(
                            trackId: track.id,
                            author: library.nickname.value,
                            content: text,
                            atSecond: player.position.value.inSeconds,
                          );
                          comments.insert(0, added);
                        },
                        child: const Text('发送'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

void showPlayQueueSheet(
  BuildContext context,
  BachPlayerController player,
  LibraryController library,
) {
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) {
      return SafeArea(
        child: Obx(() {
          final modeLabel = switch (player.loopMode.value) {
            LoopPlayMode.sequence => '列表循环',
            LoopPlayMode.single => '单曲循环',
            LoopPlayMode.shuffle => '随机漫游',
          };
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '当前播放队列 (${player.queue.length})',
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                    TextButton.icon(
                      onPressed: player.cycleLoopMode,
                      icon: const Icon(Icons.repeat_rounded, size: 18),
                      label: Text(modeLabel),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: ListView.builder(
                    itemCount: player.queue.length,
                    itemBuilder: (_, idx) {
                      final item = player.queue[idx];
                      final active = idx == player.currentIndex.value;
                      return ListTile(
                        leading: Icon(
                          active ? Icons.equalizer_rounded : Icons.music_note_rounded,
                          color: active ? SodaPalette.accent : Colors.white54,
                        ),
                        title: Text(
                          item.title,
                          style: TextStyle(
                            color: active ? SodaPalette.accent : Colors.white,
                            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          '${item.artist} · ${item.qualityBadge}',
                          style: const TextStyle(
                            color: SodaPalette.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.playlist_add_rounded),
                          onPressed: () {
                            final firstName = library.userPlaylists.keys.isEmpty
                                ? '我的红心私藏'
                                : library.userPlaylists.keys.first;
                            library.addTrackToUserPlaylist(firstName, item.id);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('已加入歌单「$firstName」')),
                            );
                          },
                        ),
                        onTap: () {
                          player.selectIndex(idx, autoPlay: true);
                          Navigator.of(ctx).pop();
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        }),
      );
    },
  );
}
