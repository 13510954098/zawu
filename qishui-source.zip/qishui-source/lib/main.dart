import 'package:flutter/material.dart';
import 'app/luna_theme.dart';
import 'core/state/luna_app_state.dart';
import 'modules/shell/main_shell_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appState = LunaAppState();
  await appState.bootstrap(enableNativeAudio: true);
  runApp(QishuiCleanRoomApp(state: appState));
}

class QishuiCleanRoomApp extends StatelessWidget {
  final LunaAppState state;

  const QishuiCleanRoomApp({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '汽水音乐 CleanRoom',
      debugShowCheckedModeBanner: false,
      theme: LunaTheme.darkTheme(),
      home: MainShellPage(state: state),
    );
  }
}
