import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:media_kit/media_kit.dart';
import 'app/routes/app_pages.dart';
import 'app/routes/app_routes.dart';
import 'core/network/api_service.dart';
import 'core/player/bach_player_controller.dart';
import 'core/state/library_controller.dart';
import 'core/theme/soda_theme.dart';

Future<void> bootstrapDependencies() async {
  if (!Get.isRegistered<ApiService>()) {
    final api = ApiService();
    await api.init();
    Get.put<ApiService>(api, permanent: true);
  }
  if (!Get.isRegistered<LibraryController>()) {
    Get.put<LibraryController>(LibraryController(), permanent: true);
  }
  if (!Get.isRegistered<BachPlayerController>()) {
    Get.put<BachPlayerController>(BachPlayerController(), permanent: true);
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (!Platform.environment.containsKey('FLUTTER_TEST')) {
    MediaKit.ensureInitialized();
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  }
  await bootstrapDependencies();
  runApp(const QishuiCleanroomApp());
}

class QishuiCleanroomApp extends StatelessWidget {
  final String initialRoute;

  const QishuiCleanroomApp({
    super.key,
    this.initialRoute = AppRoutes.splash,
  });

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: '汽水音乐 Clean',
      debugShowCheckedModeBanner: false,
      theme: SodaTheme.darkTheme(),
      initialRoute: initialRoute,
      getPages: AppPages.pages,
    );
  }
}
