import 'package:get/get.dart';
import '../../modules/auth/auth_page.dart';
import '../../modules/car/car_mode_page.dart';
import '../../modules/playlist/playlist_detail_page.dart';
import '../../modules/room/listen_room_page.dart';
import '../../modules/search/search_page.dart';
import '../../modules/settings/settings_page.dart';
import '../../modules/shell/main_shell_page.dart';
import '../../modules/splash/splash_page.dart';
import 'app_routes.dart';

class AppPages {
  static final List<GetPage<dynamic>> pages = [
    GetPage(name: AppRoutes.splash, page: () => const SplashPage()),
    GetPage(name: AppRoutes.shell, page: () => const MainShellPage()),
    GetPage(name: AppRoutes.search, page: () => const SearchPage()),
    GetPage(name: AppRoutes.playlistDetail, page: () => const PlaylistDetailPage()),
    GetPage(name: AppRoutes.carMode, page: () => const CarModePage()),
    GetPage(name: AppRoutes.listenRoom, page: () => const ListenRoomPage()),
    GetPage(name: AppRoutes.auth, page: () => const AuthPage()),
    GetPage(name: AppRoutes.settings, page: () => const SettingsPage()),
  ];
}
