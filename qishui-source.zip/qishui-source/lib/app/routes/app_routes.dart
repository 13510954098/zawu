class AppRoutes {
  static const String splash = '/';
  static const String shell = '/shell';
  static const String search = '/search';
  static const String playlistDetail = '/playlist';
  static const String carMode = '/car';
  static const String listenRoom = '/room';
  static const String auth = '/auth';
  static const String settings = '/settings';
}
