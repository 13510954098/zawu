import 'package:flutter/material.dart';

class LunaTheme {
  static const Color neonMint = Color(0xFF00E676);
  static const Color deepBg = Color(0xFF0B0D12);
  static const Color cardBg = Color(0xFF151922);
  static const Color subtleText = Color(0xFF9AA4B2);

  static ThemeData darkTheme() {
    const scheme = ColorScheme.dark(
      primary: neonMint,
      secondary: Color(0xFF00BFA5),
      surface: deepBg,
      surfaceContainerHighest: cardBg,
      onPrimary: Color(0xFF051B0E),
      onSurface: Colors.white,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: deepBg,
      colorScheme: scheme,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: neonMint,
        inactiveTrackColor: Colors.white.withValues(alpha: 0.20),
        thumbColor: Colors.white,
        trackHeight: 2.8,
      ),
    );
  }
}
