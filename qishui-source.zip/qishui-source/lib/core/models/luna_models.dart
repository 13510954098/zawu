import 'package:flutter/material.dart';

class LyricLine {
  final int timeMs;
  final String text;
  final String translation;

  const LyricLine({
    required this.timeMs,
    required this.text,
    this.translation = '',
  });

  factory LyricLine.fromJson(Map<String, dynamic> json) {
    return LyricLine(
      timeMs: (json['timeMs'] as num?)?.toInt() ?? 0,
      text: json['text']?.toString() ?? '',
      translation: json['translation']?.toString() ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'timeMs': timeMs,
        'text': text,
        'translation': translation,
      };
}

class TrackComment {
  final String id;
  final String author;
  final String content;
  final int likes;
  final String timeLabel;

  const TrackComment({
    required this.id,
    required this.author,
    required this.content,
    required this.likes,
    required this.timeLabel,
  });

  factory TrackComment.fromJson(Map<String, dynamic> json) {
    return TrackComment(
      id: json['id']?.toString() ?? '',
      author: json['author']?.toString() ?? '乐迷',
      content: json['content']?.toString() ?? '',
      likes: (json['likes'] as num?)?.toInt() ?? 0,
      timeLabel: json['timeLabel']?.toString() ?? '刚刚',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'author': author,
        'content': content,
        'likes': likes,
        'timeLabel': timeLabel,
      };
}

class LunaTrack {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String moodScene;
  final int durationMs;
  final int bpm;
  final List<double> chordHz;
  final int colorPrimary;
  final int colorSecondary;
  final int likeCount;
  final int commentCount;
  final bool vipOnly;
  final List<String> qualities;
  final List<LyricLine> lyrics;
  final List<TrackComment> comments;

  const LunaTrack({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.moodScene,
    required this.durationMs,
    required this.bpm,
    required this.chordHz,
    required this.colorPrimary,
    required this.colorSecondary,
    required this.likeCount,
    required this.commentCount,
    required this.vipOnly,
    required this.qualities,
    required this.lyrics,
    required this.comments,
  });

  List<Color> get gradientColors => [
        Color(colorPrimary),
        Color(colorSecondary),
        const Color(0xFF0B0D12),
      ];

  factory LunaTrack.fromJson(Map<String, dynamic> json) {
    final rawChord = (json['chordHz'] as List?) ?? const [261.63, 329.63, 392.00];
    final rawLyrics = (json['lyrics'] as List?) ?? const [];
    final rawComments = (json['comments'] as List?) ?? const [];
    final rawQualities = (json['qualities'] as List?) ?? const ['标准', '极高', '无损 FLAC', '空间音频'];
    return LunaTrack(
      id: json['id']?.toString() ?? 'trk_0',
      title: json['title']?.toString() ?? '未命名曲目',
      artist: json['artist']?.toString() ?? '独立音乐人',
      album: json['album']?.toString() ?? '单曲集',
      moodScene: json['moodScene']?.toString() ?? '抖音热歌',
      durationMs: (json['durationMs'] as num?)?.toInt() ?? 16000,
      bpm: (json['bpm'] as num?)?.toInt() ?? 116,
      chordHz: rawChord.map((e) => (e as num).toDouble()).toList(),
      colorPrimary: (json['colorPrimary'] as num?)?.toInt() ?? 0xFF1DB954,
      colorSecondary: (json['colorSecondary'] as num?)?.toInt() ?? 0xFF123524,
      likeCount: (json['likeCount'] as num?)?.toInt() ?? 1200,
      commentCount: (json['commentCount'] as num?)?.toInt() ?? 86,
      vipOnly: json['vipOnly'] == true,
      qualities: rawQualities.map((e) => e.toString()).toList(),
      lyrics: rawLyrics
          .whereType<Map>()
          .map((e) => LyricLine.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      comments: rawComments
          .whereType<Map>()
          .map((e) => TrackComment.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'moodScene': moodScene,
        'durationMs': durationMs,
        'bpm': bpm,
        'chordHz': chordHz,
        'colorPrimary': colorPrimary,
        'colorSecondary': colorSecondary,
        'likeCount': likeCount,
        'commentCount': commentCount,
        'vipOnly': vipOnly,
        'qualities': qualities,
        'lyrics': lyrics.map((e) => e.toJson()).toList(),
        'comments': comments.map((e) => e.toJson()).toList(),
      };
}

enum PlayLoopMode { sequence, single, shuffle }

enum AudioEffectPreset {
  off,
  samiSpatial,
  clearVocal,
  deepBass,
  vinylWarmth,
  liveHouse,
}

extension AudioEffectPresetMeta on AudioEffectPreset {
  String get label {
    switch (this) {
      case AudioEffectPreset.off:
        return '原声直通';
      case AudioEffectPreset.samiSpatial:
        return '全景空间音效';
      case AudioEffectPreset.clearVocal:
        return '清澈人声增强';
      case AudioEffectPreset.deepBass:
        return '超重低音脉冲';
      case AudioEffectPreset.vinylWarmth:
        return '复古黑胶暖声';
      case AudioEffectPreset.liveHouse:
        return 'LiveHouse 现场';
    }
  }

  List<double> get bandsDb {
    switch (this) {
      case AudioEffectPreset.off:
        return const [0, 0, 0, 0, 0];
      case AudioEffectPreset.samiSpatial:
        return const [3.5, 1.5, -0.5, 2.8, 4.2];
      case AudioEffectPreset.clearVocal:
        return const [-1.5, 0.5, 4.0, 3.2, 1.5];
      case AudioEffectPreset.deepBass:
        return const [6.0, 4.2, -1.0, 0.5, 1.5];
      case AudioEffectPreset.vinylWarmth:
        return const [2.8, 2.2, 1.0, -1.2, -2.5];
      case AudioEffectPreset.liveHouse:
        return const [3.0, 1.8, 0.0, 2.5, 3.8];
    }
  }
}

class HistoryEntry {
  final LunaTrack track;
  final int playedAtMs;
  final double completionRate;

  const HistoryEntry({
    required this.track,
    required this.playedAtMs,
    required this.completionRate,
  });
}

class DownloadTaskEntry {
  final String trackId;
  final String title;
  final String artist;
  final String quality;
  final double progress;
  final String localHash;
  final int completedAtMs;

  const DownloadTaskEntry({
    required this.trackId,
    required this.title,
    required this.artist,
    required this.quality,
    required this.progress,
    required this.localHash,
    required this.completedAtMs,
  });
}

class ListenTogetherRoom {
  final String roomId;
  final String hostName;
  final List<String> members;
  final String syncedTrackId;
  final List<String> messages;

  const ListenTogetherRoom({
    required this.roomId,
    required this.hostName,
    required this.members,
    required this.syncedTrackId,
    required this.messages,
  });
}

class AiChatItem {
  final bool isUser;
  final String text;
  final List<LunaTrack> recommendedTracks;

  const AiChatItem({
    required this.isUser,
    required this.text,
    this.recommendedTracks = const [],
  });
}
