import 'package:flutter/material.dart';

class LyricLine {
  final int timeMs;
  final String text;
  final String subText;

  const LyricLine({
    required this.timeMs,
    required this.text,
    this.subText = '',
  });

  static List<LyricLine> parseLrc(String raw) {
    final lines = <LyricLine>[];
    final reg = RegExp(r'\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\](.*)');
    for (final row in raw.split('\n')) {
      final m = reg.firstMatch(row.trim());
      if (m == null) continue;
      final min = int.tryParse(m.group(1) ?? '0') ?? 0;
      final sec = int.tryParse(m.group(2) ?? '0') ?? 0;
      final fracRaw = m.group(3) ?? '0';
      final ms = fracRaw.length == 2
          ? (int.tryParse(fracRaw) ?? 0) * 10
          : (int.tryParse(fracRaw) ?? 0);
      final body = (m.group(4) ?? '').trim();
      if (body.isEmpty) continue;
      final parts = body.split('|');
      lines.add(
        LyricLine(
          timeMs: (min * 60 + sec) * 1000 + ms,
          text: parts.first.trim(),
          subText: parts.length > 1 ? parts.sublist(1).join(' ').trim() : '',
        ),
      );
    }
    lines.sort((a, b) => a.timeMs.compareTo(b.timeMs));
    return lines;
  }
}

class MusicTrack {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String channel;
  final int durationSec;
  final int bpm;
  final List<double> chordFreqs;
  final int primaryColorValue;
  final int secondaryColorValue;
  final String qualityBadge;
  final bool isVip;
  final bool isAiGenerated;
  final int likesCount;
  final int commentsCount;
  final int sharesCount;
  final String lrc;
  final String streamUrl;

  const MusicTrack({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.channel,
    required this.durationSec,
    required this.bpm,
    required this.chordFreqs,
    required this.primaryColorValue,
    required this.secondaryColorValue,
    required this.qualityBadge,
    this.isVip = false,
    this.isAiGenerated = false,
    required this.likesCount,
    required this.commentsCount,
    required this.sharesCount,
    required this.lrc,
    this.streamUrl = '',
  });

  Color get primaryColor => Color(primaryColorValue);
  Color get secondaryColor => Color(secondaryColorValue);
  List<LyricLine> get parsedLyrics => LyricLine.parseLrc(lrc);

  MusicTrack copyWith({
    String? id,
    String? title,
    String? artist,
    String? album,
    String? channel,
    int? durationSec,
    int? bpm,
    List<double>? chordFreqs,
    int? primaryColorValue,
    int? secondaryColorValue,
    String? qualityBadge,
    bool? isVip,
    bool? isAiGenerated,
    int? likesCount,
    int? commentsCount,
    int? sharesCount,
    String? lrc,
    String? streamUrl,
  }) {
    return MusicTrack(
      id: id ?? this.id,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      channel: channel ?? this.channel,
      durationSec: durationSec ?? this.durationSec,
      bpm: bpm ?? this.bpm,
      chordFreqs: chordFreqs ?? this.chordFreqs,
      primaryColorValue: primaryColorValue ?? this.primaryColorValue,
      secondaryColorValue: secondaryColorValue ?? this.secondaryColorValue,
      qualityBadge: qualityBadge ?? this.qualityBadge,
      isVip: isVip ?? this.isVip,
      isAiGenerated: isAiGenerated ?? this.isAiGenerated,
      likesCount: likesCount ?? this.likesCount,
      commentsCount: commentsCount ?? this.commentsCount,
      sharesCount: sharesCount ?? this.sharesCount,
      lrc: lrc ?? this.lrc,
      streamUrl: streamUrl ?? this.streamUrl,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
      'album': album,
      'channel': channel,
      'durationSec': durationSec,
      'bpm': bpm,
      'chordFreqs': chordFreqs,
      'primaryColorValue': primaryColorValue,
      'secondaryColorValue': secondaryColorValue,
      'qualityBadge': qualityBadge,
      'isVip': isVip,
      'isAiGenerated': isAiGenerated,
      'likesCount': likesCount,
      'commentsCount': commentsCount,
      'sharesCount': sharesCount,
      'lrc': lrc,
      'streamUrl': streamUrl,
    };
  }

  factory MusicTrack.fromMap(Map<String, dynamic> map) {
    final rawFreqs = map['chordFreqs'];
    final freqs = rawFreqs is List
        ? rawFreqs.map((e) => (e as num).toDouble()).toList()
        : <double>[261.63, 329.63, 392.00, 493.88];
    return MusicTrack(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? '').toString(),
      artist: (map['artist'] ?? '').toString(),
      album: (map['album'] ?? '').toString(),
      channel: (map['channel'] ?? '推荐').toString(),
      durationSec: (map['durationSec'] as num?)?.toInt() ?? 24,
      bpm: (map['bpm'] as num?)?.toInt() ?? 108,
      chordFreqs: freqs,
      primaryColorValue: (map['primaryColorValue'] as num?)?.toInt() ?? 0xFF00C978,
      secondaryColorValue: (map['secondaryColorValue'] as num?)?.toInt() ?? 0xFF283593,
      qualityBadge: (map['qualityBadge'] ?? 'Hi-Res').toString(),
      isVip: map['isVip'] == true || map['isVip'] == 1,
      isAiGenerated: map['isAiGenerated'] == true || map['isAiGenerated'] == 1,
      likesCount: (map['likesCount'] as num?)?.toInt() ?? 1200,
      commentsCount: (map['commentsCount'] as num?)?.toInt() ?? 86,
      sharesCount: (map['sharesCount'] as num?)?.toInt() ?? 45,
      lrc: (map['lrc'] ?? '').toString(),
      streamUrl: (map['streamUrl'] ?? '').toString(),
    );
  }
}

class MusicPlaylist {
  final String id;
  final String title;
  final String subtitle;
  final String tag;
  final int accentColorValue;
  final List<String> trackIds;
  final int playCount;

  const MusicPlaylist({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.tag,
    required this.accentColorValue,
    required this.trackIds,
    required this.playCount,
  });

  Color get accentColor => Color(accentColorValue);

  factory MusicPlaylist.fromMap(Map<String, dynamic> map) {
    final ids = (map['trackIds'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];
    return MusicPlaylist(
      id: (map['id'] ?? '').toString(),
      title: (map['title'] ?? '').toString(),
      subtitle: (map['subtitle'] ?? '').toString(),
      tag: (map['tag'] ?? '精选').toString(),
      accentColorValue: (map['accentColorValue'] as num?)?.toInt() ?? 0xFF00F090,
      trackIds: ids,
      playCount: (map['playCount'] as num?)?.toInt() ?? 18500,
    );
  }
}

class TrackComment {
  final String id;
  final String trackId;
  final String author;
  final String content;
  final int likedCount;
  final String timeLabel;
  final int atSecond;

  const TrackComment({
    required this.id,
    required this.trackId,
    required this.author,
    required this.content,
    required this.likedCount,
    required this.timeLabel,
    this.atSecond = 0,
  });

  factory TrackComment.fromMap(Map<String, dynamic> map) {
    return TrackComment(
      id: (map['id'] ?? '').toString(),
      trackId: (map['trackId'] ?? '').toString(),
      author: (map['author'] ?? '汽水听友').toString(),
      content: (map['content'] ?? '').toString(),
      likedCount: (map['likedCount'] as num?)?.toInt() ?? 1,
      timeLabel: (map['timeLabel'] ?? '刚刚').toString(),
      atSecond: (map['atSecond'] as num?)?.toInt() ?? 0,
    );
  }
}

class DspPreset {
  final String id;
  final String name;
  final String subtitle;
  final String mpvFilter;
  final List<double> bands;

  const DspPreset({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.mpvFilter,
    required this.bands,
  });

  factory DspPreset.fromMap(Map<String, dynamic> map) {
    final b = (map['bands'] as List?)?.map((e) => (e as num).toDouble()).toList() ??
        <double>[0, 0, 0, 0, 0];
    return DspPreset(
      id: (map['id'] ?? 'flat').toString(),
      name: (map['name'] ?? '原声直通').toString(),
      subtitle: (map['subtitle'] ?? '').toString(),
      mpvFilter: (map['mpvFilter'] ?? '').toString(),
      bands: b,
    );
  }
}

class ListenRoomMessage {
  final String sender;
  final String text;
  final String timeLabel;

  const ListenRoomMessage({
    required this.sender,
    required this.text,
    required this.timeLabel,
  });

  factory ListenRoomMessage.fromMap(Map<String, dynamic> map) {
    return ListenRoomMessage(
      sender: (map['sender'] ?? '房主').toString(),
      text: (map['text'] ?? '').toString(),
      timeLabel: (map['timeLabel'] ?? '刚刚').toString(),
    );
  }
}

class ListenRoomState {
  final String roomId;
  final String roomTitle;
  final String hostName;
  final int onlineCount;
  final String currentTrackId;
  final int positionMs;
  final bool isPlaying;
  final List<ListenRoomMessage> messages;

  const ListenRoomState({
    required this.roomId,
    required this.roomTitle,
    required this.hostName,
    required this.onlineCount,
    required this.currentTrackId,
    required this.positionMs,
    required this.isPlaying,
    required this.messages,
  });

  factory ListenRoomState.fromMap(Map<String, dynamic> map) {
    final msgs = (map['messages'] as List?)
            ?.map((e) => ListenRoomMessage.fromMap(Map<String, dynamic>.from(e as Map)))
            .toList() ??
        <ListenRoomMessage>[];
    return ListenRoomState(
      roomId: (map['roomId'] ?? 'RM-8801').toString(),
      roomTitle: (map['roomTitle'] ?? '深夜气泡电台 · 一起听').toString(),
      hostName: (map['hostName'] ?? '星河漫游者').toString(),
      onlineCount: (map['onlineCount'] as num?)?.toInt() ?? 3,
      currentTrackId: (map['currentTrackId'] ?? 'trk_01').toString(),
      positionMs: (map['positionMs'] as num?)?.toInt() ?? 0,
      isPlaying: map['isPlaying'] != false,
      messages: msgs,
    );
  }
}
