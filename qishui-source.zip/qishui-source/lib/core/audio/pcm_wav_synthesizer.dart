import 'dart:math' as math;
import 'dart:typed_data';
import '../models/luna_models.dart';

class PcmWavSynthesizer {
  static Uint8List buildStereoWav(
    LunaTrack track, {
    int sampleRate = 22050,
    int maxSeconds = 8,
    AudioEffectPreset preset = AudioEffectPreset.off,
  }) {
    final durationSec = math.min(maxSeconds, math.max(4, track.durationMs ~/ 1000));
    final numSamples = sampleRate * durationSec;
    final numChannels = 2;
    final bytesPerSample = 2;
    final dataSize = numSamples * numChannels * bytesPerSample;
    final totalSize = 44 + dataSize;
    final out = ByteData(totalSize);

    void writeAscii(int offset, String s) {
      for (var i = 0; i < s.length; i++) {
        out.setUint8(offset + i, s.codeUnitAt(i));
      }
    }

    writeAscii(0, 'RIFF');
    out.setUint32(4, totalSize - 8, Endian.little);
    writeAscii(8, 'WAVE');
    writeAscii(12, 'fmt ');
    out.setUint32(16, 16, Endian.little);
    out.setUint16(20, 1, Endian.little);
    out.setUint16(22, numChannels, Endian.little);
    out.setUint32(24, sampleRate, Endian.little);
    out.setUint32(28, sampleRate * numChannels * bytesPerSample, Endian.little);
    out.setUint16(32, numChannels * bytesPerSample, Endian.little);
    out.setUint16(34, 16, Endian.little);
    writeAscii(36, 'data');
    out.setUint32(40, dataSize, Endian.little);

    final chords = track.chordHz.isEmpty ? const [261.63, 329.63, 392.0] : track.chordHz;
    final beatSec = 60.0 / math.max(60, track.bpm);
    final bands = preset.bandsDb;
    final bassGain = math.pow(10.0, bands[0] / 24.0).toDouble();
    final vocalGain = math.pow(10.0, bands[2] / 24.0).toDouble();
    final spatialWidth = preset == AudioEffectPreset.samiSpatial ? 0.35 : 0.12;

    var writePos = 44;
    for (var i = 0; i < numSamples; i++) {
      final t = i / sampleRate;
      final beatIdx = (t / beatSec).floor();
      final beatPhase = (t % beatSec) / beatSec;
      final noteHz = chords[beatIdx % chords.length];
      final fifthHz = chords[(beatIdx + 1) % chords.length];
      final bassHz = chords[0] * 0.5;

      final env = math.exp(-3.2 * beatPhase) * 0.65 + 0.35;
      final fadeIn = t < 0.25 ? (t / 0.25) : 1.0;
      final fadeOut = (durationSec - t) < 0.35 ? ((durationSec - t) / 0.35) : 1.0;
      final masterEnv = env * fadeIn * fadeOut;

      final lead = math.sin(2.0 * math.pi * noteHz * t) * 0.32 * vocalGain;
      final harmony = math.sin(2.0 * math.pi * fifthHz * t + 0.4) * 0.20;
      final subBass = math.sin(2.0 * math.pi * bassHz * t) * 0.24 * bassGain;
      final shimmer = math.sin(2.0 * math.pi * noteHz * 2.0 * t) * 0.08;

      final panMod = math.sin(2.0 * math.pi * 0.6 * t) * spatialWidth;
      final mono = (lead + harmony + subBass + shimmer) * masterEnv;
      final left = (mono * (1.0 - panMod)).clamp(-0.95, 0.95);
      final right = (mono * (1.0 + panMod)).clamp(-0.95, 0.95);

      out.setInt16(writePos, (left * 32767).round(), Endian.little);
      out.setInt16(writePos + 2, (right * 32767).round(), Endian.little);
      writePos += 4;
    }

    return out.buffer.asUint8List();
  }
}
