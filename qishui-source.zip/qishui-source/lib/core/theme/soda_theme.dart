import 'package:flutter/material.dart';

class SodaPalette {
  static const Color bgPrimary = Color(0xFF0B0D12);
  static const Color bgElevated = Color(0xFF151923);
  static const Color bgCard = Color(0xFF1C2130);
  static const Color accent = Color(0xFF00F090);
  static const Color accentSecondary = Color(0xFF7C5CFF);
  static const Color textPrimary = Color(0xFFF5F7FA);
  static const Color textSecondary = Color(0xFF9BA3B4);
  static const Color danger = Color(0xFFFF4D6D);
  static const Color gold = Color(0xFFFFCF5C);
}

class SodaTheme {
  static ThemeData darkTheme() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: SodaPalette.bgPrimary,
      primaryColor: SodaPalette.accent,
      colorScheme: const ColorScheme.dark(
        primary: SodaPalette.accent,
        secondary: SodaPalette.accentSecondary,
        surface: SodaPalette.bgElevated,
        error: SodaPalette.danger,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        foregroundColor: SodaPalette.textPrimary,
      ),
      cardTheme: CardThemeData(
        color: SodaPalette.bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: SodaPalette.accent,
        inactiveTrackColor: Colors.white24,
        thumbColor: Colors.white,
        overlayColor: SodaPalette.accent.withValues(alpha: 0.18),
        trackHeight: 3.0,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6.0),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: SodaPalette.bgElevated,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      ),
    );
  }

  static String formatDuration(Duration d) {
    final total = d.inSeconds < 0 ? 0 : d.inSeconds;
    final m = (total ~/ 60).toString().padLeft(2, '0');
    final s = (total % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  static String formatCount(int value) {
    if (value >= 10000) {
      return '${(value / 10000).toStringAsFixed(1)}w';
    }
    if (value >= 1000) {
      return '${(value / 1000).toStringAsFixed(1)}k';
    }
    return value.toString();
  }
}
