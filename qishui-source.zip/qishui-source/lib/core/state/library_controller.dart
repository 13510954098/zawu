import 'dart:io';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/music_models.dart';
import '../network/mock_catalog.dart';
import '../player/wav_synthesizer.dart';
import '../storage/luna_database.dart';

class LibraryController extends GetxController {
  final RxString nickname = '星河漫游听友'.obs;
  final RxString signature = '随时随地，懂你想听的气泡旋律'.obs;
  final RxBool isLoggedIn = true.obs;
  final RxInt freeListenMinutes = 90.obs;

  final RxSet<String> likedIds = <String>{}.obs;
  final RxList<MusicTrack> historyTracks = <MusicTrack>[].obs;
  final RxList<MusicTrack> downloadedTracks = <MusicTrack>[].obs;
  final RxList<MusicTrack> aiCreatedTracks = <MusicTrack>[].obs;
  final RxMap<String, List<String>> userPlaylists = <String, List<String>>{}.obs;

  @override
  void onInit() {
    super.onInit();
    refreshAll();
  }

  Future<void> refreshAll() async {
    final likes = await LunaDatabase.instance.loadLikedIds();
    likedIds
      ..clear()
      ..addAll(likes);
    historyTracks.assignAll(await LunaDatabase.instance.loadHistory());
    downloadedTracks.assignAll(await LunaDatabase.instance.loadDownloads());
    aiCreatedTracks.assignAll(await LunaDatabase.instance.loadAiCreations());
    userPlaylists.assignAll(await LunaDatabase.instance.loadUserPlaylists());

    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final prefs = await SharedPreferences.getInstance();
        nickname.value = prefs.getString('qishui_nick') ?? nickname.value;
        freeListenMinutes.value = prefs.getInt('qishui_free_mins') ?? 90;
      } catch (_) {}
    }
  }

  bool isLiked(String trackId) => likedIds.contains(trackId);

  Future<void> toggleLike(MusicTrack track) async {
    final nextState = !likedIds.contains(track.id);
    if (nextState) {
      likedIds.add(track.id);
    } else {
      likedIds.remove(track.id);
    }
    await LunaDatabase.instance.setLiked(track, nextState);
  }

  List<MusicTrack> get likedTrackObjects {
    final pool = <String, MusicTrack>{
      for (final t in MockCatalog.tracks) t.id: t,
      for (final t in aiCreatedTracks) t.id: t,
      for (final t in historyTracks) t.id: t,
    };
    return likedIds.map((id) => pool[id]).whereType<MusicTrack>().toList();
  }

  Future<String> cacheTrackOffline(MusicTrack track) async {
    String savedPath = 'mem://${track.id}.wav';
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final docs = await getApplicationDocumentsDirectory();
        final folder = Directory(p.join(docs.path, 'qishui_offline_audio'));
        if (!await folder.exists()) {
          await folder.create(recursive: true);
        }
        final target = File(p.join(folder.path, '${track.id}.wav'));
        final bytes = WavSynthesizer.buildTrackWav(track, maxSeconds: 20);
        await target.writeAsBytes(bytes, flush: true);
        savedPath = target.path;
      } catch (_) {}
    }
    await LunaDatabase.instance.saveDownload(track, savedPath);
    downloadedTracks.assignAll(await LunaDatabase.instance.loadDownloads());
    return savedPath;
  }

  Future<void> registerAiTrack(MusicTrack track) async {
    await LunaDatabase.instance.saveAiCreation(track);
    aiCreatedTracks.assignAll(await LunaDatabase.instance.loadAiCreations());
  }

  Future<void> createPlaylist(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) return;
    final current = userPlaylists[clean] ?? <String>[];
    await LunaDatabase.instance.upsertUserPlaylist(clean, current);
    userPlaylists.assignAll(await LunaDatabase.instance.loadUserPlaylists());
  }

  Future<void> addTrackToUserPlaylist(String playlistName, String trackId) async {
    final existing = List<String>.from(userPlaylists[playlistName] ?? <String>[]);
    if (!existing.contains(trackId)) {
      existing.add(trackId);
      await LunaDatabase.instance.upsertUserPlaylist(playlistName, existing);
      userPlaylists.assignAll(await LunaDatabase.instance.loadUserPlaylists());
    }
  }

  Future<void> claimBonusListenMinutes(int addMins) async {
    freeListenMinutes.value += addMins;
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt('qishui_free_mins', freeListenMinutes.value);
      } catch (_) {}
    }
  }

  Future<void> updateProfile({required String newNick, required String newBio}) async {
    if (newNick.trim().isNotEmpty) nickname.value = newNick.trim();
    if (newBio.trim().isNotEmpty) signature.value = newBio.trim();
    isLoggedIn.value = true;
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('qishui_nick', nickname.value);
      } catch (_) {}
    }
  }
}
