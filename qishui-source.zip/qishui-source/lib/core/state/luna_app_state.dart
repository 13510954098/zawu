import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import '../models/luna_models.dart';
import '../network/demo_catalog.dart';
import '../network/luna_api_client.dart';
import '../player/bach_shadow_player.dart';
import '../security/cleanroom_guard_engine.dart';
import '../storage/luna_local_store.dart';

class LunaAppState extends ChangeNotifier {
  final CleanRoomGuardEngine guard = CleanRoomGuardEngine();
  late final LunaApiClient api = LunaApiClient(guard: guard);
  final LunaLocalStore store = LunaLocalStore();
  final BachShadowPlayer player = BachShadowPlayer();

  List<LunaTrack> feedTracks = DemoCatalog.initialTracks();
  int currentIndex = 0;
  String selectedMood = '全部推荐';
  String selectedQuality = '空间音频';
  AudioEffectPreset effectPreset = AudioEffectPreset.samiSpatial;
  PlayLoopMode loopMode = PlayLoopMode.sequence;
  bool showLyricsOverlay = false;
  bool showFloatingDesktopLyric = false;
  int sleepTimerMinutes = 0;

  EntitlementTicket? activeTicket;
  ListenTogetherRoom? togetherRoom;
  final List<AiChatItem> aiMessages = [
    AiChatItem(
      isUser: false,
      text: '你好，我是汽水 AI 找歌与创作助手。告诉我你此刻的心情、场景或节奏，我可以直接为你推荐或现场合成新曲。',
    ),
  ];

  GatewaySignedHeaders? lastSignedHeaders;
  StreamEnvelopePacket? lastEnvelopePacket;
  bool lastDecryptionVerified = false;

  LunaTrack get currentTrack =>
      feedTracks.isNotEmpty ? feedTracks[currentIndex.clamp(0, feedTracks.length - 1)] : DemoCatalog.initialTracks().first;

  bool get hasVipOrRewardedAccess {
    final t = activeTicket;
    if (t == null) return false;
    return guard.verifyEntitlementTicket(t);
  }

  int get remainingFreeMinutes {
    final t = activeTicket;
    if (t == null) return 0;
    final diff = t.expireAtMs - DateTime.now().millisecondsSinceEpoch;
    if (diff <= 0) return 0;
    return (diff / 60000).ceil();
  }

  int get activeLyricIndex {
    final lines = currentTrack.lyrics;
    if (lines.isEmpty) return 0;
    final pos = player.positionMs;
    var idx = 0;
    for (var i = 0; i < lines.length; i++) {
      if (pos >= lines[i].timeMs) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }

  Future<void> bootstrap({bool enableNativeAudio = true, bool offlineOnly = false}) async {
    if (!offlineOnly) {
      await store.init();
    }
    player.onTick = (posMs, completed) {
      if (completed) {
        onTrackCompleted();
      } else {
        notifyListeners();
      }
    };
    await player.init(enableNative: enableNativeAudio);
    feedTracks = offlineOnly
        ? DemoCatalog.initialTracks()
        : await api.fetchFeed(mood: selectedMood);
    _refreshGuardDiagnostics();
    _prebufferNext();
    await player.loadAndPlay(currentTrack, preset: effectPreset, autoPlay: false);
    notifyListeners();
  }

  void _prebufferNext() {
    if (feedTracks.length < 2) return;
    final nextIdx = (currentIndex + 1) % feedTracks.length;
    player.prebufferShadowNext(feedTracks[nextIdx], effectPreset);
  }

  void _refreshGuardDiagnostics() {
    lastSignedHeaders = guard.signGatewayRequest(
      method: 'GET',
      path: '/luna/feed',
      query: {'mood': selectedMood, 'quality': selectedQuality},
    );
    final wav = player.getOrSynthesizeWav(currentTrack, effectPreset);
    final sampleSlice = Uint8List.sublistView(wav, 0, wav.length < 2048 ? wav.length : 2048);
    final sealed = guard.sealAudioChunk(mediaId: currentTrack.id, plainWavBytes: sampleSlice);
    final opened = guard.openAudioChunk(sealed);
    lastEnvelopePacket = sealed;
    lastDecryptionVerified = opened.length == sampleSlice.length;
  }

  Future<void> selectTrackIndex(int index, {bool autoPlay = true}) async {
    if (feedTracks.isEmpty) return;
    final prev = currentTrack;
    final rate = player.durationMs > 0 ? (player.positionMs / player.durationMs) : 0.25;
    await store.recordHistory(prev, rate);

    currentIndex = index.clamp(0, feedTracks.length - 1);
    _prebufferNext();
    _refreshGuardDiagnostics();
    await player.loadAndPlay(currentTrack, preset: effectPreset, autoPlay: autoPlay);
    if (togetherRoom != null) {
      togetherRoom = ListenTogetherRoom(
        roomId: togetherRoom!.roomId,
        hostName: togetherRoom!.hostName,
        members: togetherRoom!.members,
        syncedTrackId: currentTrack.id,
        messages: [
          ...togetherRoom!.messages,
          '已同步切歌至《${currentTrack.title}》',
        ],
      );
    }
    notifyListeners();
  }

  Future<void> onTrackCompleted() async {
    if (loopMode == PlayLoopMode.single) {
      await selectTrackIndex(currentIndex, autoPlay: true);
      return;
    }
    final nextIdx = (currentIndex + 1) % feedTracks.length;
    await selectTrackIndex(nextIdx, autoPlay: true);
  }

  Future<void> togglePlay() async {
    await player.togglePlayPause();
    notifyListeners();
  }

  Future<void> seekToMs(int ms) async {
    await player.seekTo(ms);
    notifyListeners();
  }

  Future<void> changeMood(String mood) async {
    selectedMood = mood;
    final list = await api.fetchFeed(mood: mood);
    if (list.isNotEmpty) {
      feedTracks = list;
      currentIndex = 0;
      _prebufferNext();
      await player.loadAndPlay(currentTrack, preset: effectPreset, autoPlay: player.isPlaying);
    }
    notifyListeners();
  }

  Future<void> setAudioEffect(AudioEffectPreset preset) async {
    effectPreset = preset;
    _prebufferNext();
    _refreshGuardDiagnostics();
    await player.loadAndPlay(currentTrack, preset: preset, autoPlay: player.isPlaying);
    notifyListeners();
  }

  void setQuality(String q) {
    selectedQuality = q;
    _refreshGuardDiagnostics();
    notifyListeners();
  }

  void cycleLoopMode() {
    final next = (loopMode.index + 1) % PlayLoopMode.values.length;
    loopMode = PlayLoopMode.values[next];
    notifyListeners();
  }

  void toggleLyricsMode() {
    showLyricsOverlay = !showLyricsOverlay;
    notifyListeners();
  }

  void toggleFloatingDesktopLyric() {
    showFloatingDesktopLyric = !showFloatingDesktopLyric;
    notifyListeners();
  }

  void setSleepTimer(int minutes) {
    sleepTimerMinutes = minutes;
    notifyListeners();
  }

  bool isLiked(String trackId) => store.likedTrackIds.contains(trackId);

  Future<void> toggleLikeCurrent([String? id]) async {
    await store.toggleLike(id ?? currentTrack.id);
    notifyListeners();
  }

  Future<void> addCommentToCurrent(String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    final cur = currentTrack;
    final updated = LunaTrack(
      id: cur.id,
      title: cur.title,
      artist: cur.artist,
      album: cur.album,
      moodScene: cur.moodScene,
      durationMs: cur.durationMs,
      bpm: cur.bpm,
      chordHz: cur.chordHz,
      colorPrimary: cur.colorPrimary,
      colorSecondary: cur.colorSecondary,
      likeCount: cur.likeCount,
      commentCount: cur.commentCount + 1,
      vipOnly: cur.vipOnly,
      qualities: cur.qualities,
      lyrics: cur.lyrics,
      comments: [
        TrackComment(
          id: 'usr_${DateTime.now().millisecondsSinceEpoch}',
          author: '我',
          content: clean,
          likes: 1,
          timeLabel: '刚刚',
        ),
        ...cur.comments,
      ],
    );
    feedTracks[currentIndex] = updated;
    notifyListeners();
  }

  Future<void> cacheTrackOffline(LunaTrack track) async {
    final wav = player.getOrSynthesizeWav(track, effectPreset);
    final digest = sha256.convert(wav).toString().substring(0, 16);
    await store.saveDownload(
      DownloadTaskEntry(
        trackId: track.id,
        title: track.title,
        artist: track.artist,
        quality: selectedQuality,
        progress: 1.0,
        localHash: digest,
        completedAtMs: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    notifyListeners();
  }

  Future<void> claimRewardedListenMinutes({int minutes = 30}) async {
    activeTicket = await api.claimRewardedFreeListen(
      userId: 'luna_local_user_01',
      minutes: minutes,
    );
    notifyListeners();
  }

  void startOrStopListenTogether() {
    if (togetherRoom != null) {
      togetherRoom = null;
    } else {
      togetherRoom = ListenTogetherRoom(
        roomId: 'LT-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}',
        hostName: '我 (房主)',
        members: const ['我', '海盐汽水', '夜跑选手'],
        syncedTrackId: currentTrack.id,
        messages: [
          '已开启一起听房间，实时同步毫秒级播放进度',
          '海盐汽水 加入了房间',
        ],
      );
    }
    notifyListeners();
  }

  void sendTogetherFlashMessage(String msg) {
    if (togetherRoom == null || msg.trim().isEmpty) return;
    togetherRoom = ListenTogetherRoom(
      roomId: togetherRoom!.roomId,
      hostName: togetherRoom!.hostName,
      members: togetherRoom!.members,
      syncedTrackId: togetherRoom!.syncedTrackId,
      messages: [...togetherRoom!.messages, '我：${msg.trim()}'],
    );
    notifyListeners();
  }

  Future<LunaTrack> composeWithAi({
    required String prompt,
    required String mood,
    required int bpm,
  }) async {
    final created = await api.createAiTrack(prompt: prompt, moodScene: mood, bpm: bpm);
    feedTracks = [created, ...feedTracks];
    await selectTrackIndex(0, autoPlay: true);
    return created;
  }

  Future<void> askAiAssistant(String query) async {
    final q = query.trim();
    if (q.isEmpty) return;
    aiMessages.add(AiChatItem(isUser: true, text: q));
    notifyListeners();

    final matches = await api.searchTracks(q);
    final picks = matches.isNotEmpty ? matches.take(2).toList() : DemoCatalog.initialTracks().take(2).toList();
    aiMessages.add(
      AiChatItem(
        isUser: false,
        text: '根据「$q」的情绪与声场特征，为你精选了 ${picks.length} 首契合曲目，点击卡片即可无缝切入播放：',
        recommendedTracks: picks,
      ),
    );
    notifyListeners();
  }

  Future<void> runLiveEnvelopeCheck() async {
    final wav = player.getOrSynthesizeWav(currentTrack, effectPreset);
    final slice = Uint8List.sublistView(wav, 0, wav.length < 4096 ? wav.length : 4096);
    final pkt = await api.fetchServerEncryptedEnvelope(currentTrack.id, slice);
    if (pkt != null) {
      final plain = guard.openAudioChunk(pkt);
      lastEnvelopePacket = pkt;
      lastDecryptionVerified = plain.length == slice.length;
    }
    lastSignedHeaders = guard.signGatewayRequest(
      method: 'POST',
      path: '/luna/stream/verify',
      body: '{"mediaId":"${currentTrack.id}"}',
    );
    notifyListeners();
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }
}
