import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../models/music_models.dart';

class WavSynthesizer {
  static Uint8List buildTrackWav(MusicTrack track, {int maxSeconds = 16}) {
    const sampleRate = 22050;
    const channels = 2;
    final seconds = track.durationSec.clamp(6, maxSeconds);
    final totalFrames = sampleRate * seconds;
    final dataBytes = totalFrames * channels * 2;
    final buffer = ByteData(44 + dataBytes);

    void writeAscii(int offset, String s) {
      for (var i = 0; i < s.length; i++) {
        buffer.setUint8(offset + i, s.codeUnitAt(i));
      }
    }

    writeAscii(0, 'RIFF');
    buffer.setUint32(4, 36 + dataBytes, Endian.little);
    writeAscii(8, 'WAVE');
    writeAscii(12, 'fmt ');
    buffer.setUint32(16, 16, Endian.little);
    buffer.setUint16(20, 1, Endian.little);
    buffer.setUint16(22, channels, Endian.little);
    buffer.setUint32(24, sampleRate, Endian.little);
    buffer.setUint32(28, sampleRate * channels * 2, Endian.little);
    buffer.setUint16(32, channels * 2, Endian.little);
    buffer.setUint16(34, 16, Endian.little);
    writeAscii(36, 'data');
    buffer.setUint32(40, dataBytes, Endian.little);

    final notes = track.chordFreqs.isEmpty
        ? <double>[261.63, 329.63, 392.00, 523.25]
        : track.chordFreqs;
    final beatSec = 60.0 / (track.bpm <= 0 ? 108 : track.bpm);
    final barSec = beatSec * 4.0;

    var writeOffset = 44;
    for (var i = 0; i < totalFrames; i++) {
      final t = i / sampleRate;
      final barIndex = (t / barSec).floor();
      final root = notes[barIndex % notes.length];
      final fifth = root * 1.4983;
      final third = root * 1.2599;
      final beatPos = (t % beatSec) / beatSec;
      final env = math.exp(-3.2 * beatPos);
      final arpFreq = notes[((t / (beatSec * 0.5)).floor()) % notes.length] * 2.0;

      final padL = 0.20 * math.sin(2 * math.pi * root * t) +
          0.14 * math.sin(2 * math.pi * third * t + 0.25) +
          0.11 * math.sin(2 * math.pi * fifth * t);
      final padR = 0.20 * math.sin(2 * math.pi * root * t + 0.12) +
          0.14 * math.sin(2 * math.pi * third * t) +
          0.11 * math.sin(2 * math.pi * fifth * t + 0.35);

      final pluck = 0.22 * env * math.sin(2 * math.pi * arpFreq * t);
      final bass = 0.24 * math.exp(-2.0 * beatPos) * math.sin(2 * math.pi * (root * 0.5) * t);
      final fade = t < 0.25
          ? (t / 0.25)
          : (t > seconds - 0.5 ? ((seconds - t) / 0.5).clamp(0.0, 1.0) : 1.0);

      final left = ((padL + pluck * 0.9 + bass) * fade).clamp(-0.95, 0.95);
      final right = ((padR + pluck * 1.1 + bass) * fade).clamp(-0.95, 0.95);

      buffer.setInt16(writeOffset, (left * 32767).round(), Endian.little);
      buffer.setInt16(writeOffset + 2, (right * 32767).round(), Endian.little);
      writeOffset += 4;
    }
    return buffer.buffer.asUint8List();
  }

  static Future<String?> materializeLocalWav(MusicTrack track) async {
    if (Platform.environment.containsKey('FLUTTER_TEST')) {
      return null;
    }
    try {
      final dir = await getTemporaryDirectory();
      final outDir = Directory(p.join(dir.path, 'qishui_synth_cache'));
      if (!await outDir.exists()) {
        await outDir.create(recursive: true);
      }
      final file = File(p.join(outDir.path, '${track.id}.wav'));
      if (!await file.exists()) {
        final bytes = buildTrackWav(track);
        await file.writeAsBytes(bytes, flush: true);
      }
      return file.path;
    } catch (_) {
      return null;
    }
  }
}
