import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../audio/pcm_wav_synthesizer.dart';
import '../models/luna_models.dart';

class BachShadowPlayer {
  Player? _activeNativePlayer;
  final Map<String, Uint8List> _shadowPcmCache = {};
  Timer? _fallbackTicker;
  bool _nativeReady = false;
  bool _isPlaying = false;
  int _positionMs = 0;
  int _durationMs = 24000;
  String? _prebufferedNextId;
  void Function(int posMs, bool completed)? onTick;

  bool get isPlaying => _isPlaying;
  int get positionMs => _positionMs;
  int get durationMs => _durationMs;
  String? get shadowPrebufferedTrackId => _prebufferedNextId;
  bool get isNativeEngineActive => _nativeReady;

  Future<void> init({bool enableNative = true}) async {
    if (!enableNative) return;
    try {
      MediaKit.ensureInitialized();
      _activeNativePlayer = Player();
      _nativeReady = true;
      _activeNativePlayer!.stream.position.listen((pos) {
        if (_isPlaying) {
          _positionMs = pos.inMilliseconds;
          onTick?.call(_positionMs, false);
        }
      });
      _activeNativePlayer!.stream.completed.listen((done) {
        if (done) {
          onTick?.call(_durationMs, true);
        }
      });
    } catch (_) {
      _nativeReady = false;
    }
  }

  Uint8List getOrSynthesizeWav(LunaTrack track, AudioEffectPreset preset) {
    final key = '${track.id}_${preset.name}';
    final cached = _shadowPcmCache[key];
    if (cached != null) return cached;
    final wav = PcmWavSynthesizer.buildStereoWav(track, preset: preset);
    if (_shadowPcmCache.length > 8) {
      _shadowPcmCache.remove(_shadowPcmCache.keys.first);
    }
    _shadowPcmCache[key] = wav;
    return wav;
  }

  void prebufferShadowNext(LunaTrack? nextTrack, AudioEffectPreset preset) {
    if (nextTrack == null) {
      _prebufferedNextId = null;
      return;
    }
    getOrSynthesizeWav(nextTrack, preset);
    _prebufferedNextId = nextTrack.id;
  }

  Future<void> loadAndPlay(
    LunaTrack track, {
    required AudioEffectPreset preset,
    bool autoPlay = true,
  }) async {
    _positionMs = 0;
    _durationMs = track.durationMs;
    _isPlaying = autoPlay;
    _fallbackTicker?.cancel();

    final wavBytes = getOrSynthesizeWav(track, preset);

    if (_nativeReady && _activeNativePlayer != null) {
      try {
        final dir = await getTemporaryDirectory();
        final file = File(p.join(dir.path, 'luna_${track.id}_${preset.name}.wav'));
        await file.writeAsBytes(wavBytes, flush: true);
        await _activeNativePlayer!.open(Media(file.path), play: autoPlay);
      } catch (_) {
        _startSimulatedClock();
      }
    } else if (autoPlay) {
      _startSimulatedClock();
    }
  }

  void _startSimulatedClock() {
    _fallbackTicker?.cancel();
    if (!_isPlaying) return;
    _fallbackTicker = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!_isPlaying) return;
      _positionMs += 250;
      if (_positionMs >= _durationMs) {
        _positionMs = 0;
        onTick?.call(_durationMs, true);
      } else {
        onTick?.call(_positionMs, false);
      }
    });
  }

  Future<void> togglePlayPause() async {
    _isPlaying = !_isPlaying;
    if (_nativeReady && _activeNativePlayer != null) {
      try {
        await _activeNativePlayer!.playOrPause();
        return;
      } catch (_) {}
    }
    if (_isPlaying) {
      _startSimulatedClock();
    } else {
      _fallbackTicker?.cancel();
    }
  }

  Future<void> seekTo(int targetMs) async {
    _positionMs = targetMs.clamp(0, _durationMs);
    if (_nativeReady && _activeNativePlayer != null) {
      try {
        await _activeNativePlayer!.seek(Duration(milliseconds: _positionMs));
      } catch (_) {}
    }
    onTick?.call(_positionMs, false);
  }

  void dispose() {
    _fallbackTicker?.cancel();
    _activeNativePlayer?.dispose();
  }
}
