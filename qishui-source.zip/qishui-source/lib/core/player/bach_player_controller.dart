import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:media_kit/media_kit.dart' hide Track;
import '../models/music_models.dart';
import '../network/api_service.dart';
import '../network/mock_catalog.dart';
import '../storage/luna_database.dart';
import 'wav_synthesizer.dart';

enum LoopPlayMode { sequence, single, shuffle }

enum StageVisualMode { vinyl, cover, lyrics }

class BachPlayerController extends GetxController {
  final ApiService api = Get.find<ApiService>();

  final RxList<MusicTrack> queue = <MusicTrack>[].obs;
  final RxInt currentIndex = 0.obs;
  final RxString activeChannel = '推荐'.obs;
  final RxBool isPlaying = false.obs;
  final Rx<Duration> position = Duration.zero.obs;
  final Rx<Duration> duration = const Duration(seconds: 20).obs;
  final Rx<LoopPlayMode> loopMode = LoopPlayMode.sequence.obs;
  final Rx<StageVisualMode> stageMode = StageVisualMode.vinyl.obs;
  final RxString selectedQuality = 'Hi-Res'.obs;
  final RxBool showFloatingLyrics = false.obs;
  final RxInt sleepRemainSec = 0.obs;

  final RxList<DspPreset> dspPresets = <DspPreset>[].obs;
  final Rx<DspPreset> activePreset = MockCatalog.fallbackDspPresets.first.obs;

  Player? _primaryPlayer;
  Player? _shadowPlayer;
  String _shadowPreloadedTrackId = '';
  Timer? _fallbackTickTimer;
  Timer? _sleepTimer;
  final List<StreamSubscription<dynamic>> _subs = [];

  bool get _isTestEnv => Platform.environment.containsKey('FLUTTER_TEST');

  MusicTrack get currentTrack {
    if (queue.isEmpty) return MockCatalog.tracks.first;
    final safeIdx = currentIndex.value.clamp(0, queue.length - 1);
    return queue[safeIdx];
  }

  int get currentLyricIndex {
    final lines = currentTrack.parsedLyrics;
    if (lines.isEmpty) return -1;
    final posMs = position.value.inMilliseconds;
    var active = 0;
    for (var i = 0; i < lines.length; i++) {
      if (posMs >= lines[i].timeMs) {
        active = i;
      } else {
        break;
      }
    }
    return active;
  }

  @override
  void onInit() {
    super.onInit();
    queue.assignAll(MockCatalog.tracks);
    duration.value = Duration(seconds: currentTrack.durationSec);
    _loadDspPresets();
    _initNativePlayers();
    loadChannel('推荐', autoPlay: false);
  }

  Future<void> _loadDspPresets() async {
    try {
      final raw = await rootBundle.loadString('assets/presets/dsp_presets.json');
      final list = (jsonDecode(raw) as List)
          .map((e) => DspPreset.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList();
      if (list.isNotEmpty) {
        dspPresets.assignAll(list);
        activePreset.value = list.first;
        return;
      }
    } catch (_) {}
    dspPresets.assignAll(MockCatalog.fallbackDspPresets);
    activePreset.value = dspPresets.first;
  }

  void _initNativePlayers() {
    if (_isTestEnv) return;
    try {
      _primaryPlayer = Player();
      _shadowPlayer = Player();
      _subs.add(
        _primaryPlayer!.stream.playing.listen((playing) {
          isPlaying.value = playing;
        }),
      );
      _subs.add(
        _primaryPlayer!.stream.position.listen((pos) {
          position.value = pos;
        }),
      );
      _subs.add(
        _primaryPlayer!.stream.duration.listen((dur) {
          if (dur.inMilliseconds > 500) {
            duration.value = dur;
          }
        }),
      );
      _subs.add(
        _primaryPlayer!.stream.completed.listen((done) {
          if (done) {
            _onTrackCompleted();
          }
        }),
      );
    } catch (_) {
      _primaryPlayer = null;
      _shadowPlayer = null;
    }
  }

  Future<void> loadChannel(String channel, {bool autoPlay = true}) async {
    activeChannel.value = channel;
    final fetched = await api.fetchFeed(channel: channel);
    if (fetched.isNotEmpty) {
      queue.assignAll(fetched);
      currentIndex.value = 0;
      await selectIndex(0, autoPlay: autoPlay);
    }
  }

  Future<void> replaceQueueAndPlay(List<MusicTrack> tracks, int startIndex) async {
    if (tracks.isEmpty) return;
    queue.assignAll(tracks);
    await selectIndex(startIndex.clamp(0, tracks.length - 1), autoPlay: true);
  }

  Future<void> playSpecificTrack(MusicTrack track) async {
    final existingIdx = queue.indexWhere((t) => t.id == track.id);
    if (existingIdx >= 0) {
      await selectIndex(existingIdx, autoPlay: true);
      return;
    }
    queue.insert(0, track);
    await selectIndex(0, autoPlay: true);
  }

  Future<void> selectIndex(int index, {bool autoPlay = true}) async {
    if (queue.isEmpty) return;
    final clamped = index.clamp(0, queue.length - 1);
    currentIndex.value = clamped;
    final track = queue[clamped];
    position.value = Duration.zero;
    duration.value = Duration(seconds: track.durationSec);
    selectedQuality.value = track.qualityBadge;
    await LunaDatabase.instance.recordHistory(track);

    if (_primaryPlayer != null) {
      final source = await _resolvePlayableUri(track);
      if (source != null) {
        try {
          await _primaryPlayer!.open(Media(source), play: autoPlay);
          await _applyMpvFilter(activePreset.value.mpvFilter);
          isPlaying.value = autoPlay;
          _preloadNextIntoShadow();
          return;
        } catch (_) {}
      }
    }

    if (autoPlay) {
      _startFallbackClock();
    } else {
      _stopFallbackClock();
    }
  }

  Future<String?> _resolvePlayableUri(MusicTrack track) async {
    if (track.streamUrl.isNotEmpty) {
      if (track.streamUrl.startsWith('http://') || track.streamUrl.startsWith('https://')) {
        if (api.serverOnline.value) {
          return track.streamUrl;
        }
      } else if (await File(track.streamUrl).exists()) {
        return track.streamUrl;
      }
    }
    if (api.serverOnline.value) {
      return '${api.baseUrl.value}/media/track/${track.id}.wav';
    }
    return WavSynthesizer.materializeLocalWav(track);
  }

  Future<void> _preloadNextIntoShadow() async {
    if (_shadowPlayer == null || queue.length < 2) return;
    final nextTrack = queue[(currentIndex.value + 1) % queue.length];
    if (_shadowPreloadedTrackId == nextTrack.id) return;
    _shadowPreloadedTrackId = nextTrack.id;
    final uri = await _resolvePlayableUri(nextTrack);
    if (uri == null) return;
    try {
      await _shadowPlayer!.open(Media(uri), play: false);
    } catch (_) {}
  }

  void _startFallbackClock() {
    _fallbackTickTimer?.cancel();
    isPlaying.value = true;
    if (_isTestEnv) return;
    _fallbackTickTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!isPlaying.value) return;
      final next = position.value + const Duration(milliseconds: 250);
      if (next >= duration.value) {
        _onTrackCompleted();
      } else {
        position.value = next;
      }
    });
  }

  void _stopFallbackClock() {
    _fallbackTickTimer?.cancel();
    isPlaying.value = false;
  }

  void _onTrackCompleted() {
    if (loopMode.value == LoopPlayMode.single) {
      seekTo(Duration.zero);
      if (!isPlaying.value) togglePlayPause();
      return;
    }
    nextTrack();
  }

  Future<void> togglePlayPause() async {
    if (_primaryPlayer != null && !_isTestEnv) {
      try {
        await _primaryPlayer!.playOrPause();
        isPlaying.value = _primaryPlayer!.state.playing;
        return;
      } catch (_) {}
    }
    if (isPlaying.value) {
      _stopFallbackClock();
    } else {
      _startFallbackClock();
    }
  }

  Future<void> seekTo(Duration target) async {
    final safe = Duration(
      milliseconds: target.inMilliseconds.clamp(0, duration.value.inMilliseconds),
    );
    position.value = safe;
    if (_primaryPlayer != null && !_isTestEnv) {
      try {
        await _primaryPlayer!.seek(safe);
      } catch (_) {}
    }
  }

  Future<void> nextTrack() async {
    if (queue.isEmpty) return;
    if (loopMode.value == LoopPlayMode.shuffle && queue.length > 1) {
      final rng = math.Random();
      var candidate = rng.nextInt(queue.length);
      if (candidate == currentIndex.value) {
        candidate = (candidate + 1) % queue.length;
      }
      await selectIndex(candidate, autoPlay: true);
      return;
    }
    final nextIdx = (currentIndex.value + 1) % queue.length;
    await selectIndex(nextIdx, autoPlay: true);
  }

  Future<void> previousTrack() async {
    if (queue.isEmpty) return;
    final prevIdx = (currentIndex.value - 1 + queue.length) % queue.length;
    await selectIndex(prevIdx, autoPlay: true);
  }

  void cycleLoopMode() {
    const modes = LoopPlayMode.values;
    loopMode.value = modes[(loopMode.value.index + 1) % modes.length];
  }

  void cycleStageMode() {
    const modes = StageVisualMode.values;
    stageMode.value = modes[(stageMode.value.index + 1) % modes.length];
  }

  Future<void> applyDspPreset(DspPreset preset) async {
    activePreset.value = preset;
    await _applyMpvFilter(preset.mpvFilter);
  }

  Future<void> _applyMpvFilter(String filterExpr) async {
    if (_primaryPlayer == null || _isTestEnv) return;
    try {
      final platform = _primaryPlayer!.platform as dynamic;
      await platform.setProperty('af', filterExpr);
    } catch (_) {}
  }

  void configureSleepTimer(int minutes) {
    _sleepTimer?.cancel();
    if (minutes <= 0) {
      sleepRemainSec.value = 0;
      return;
    }
    sleepRemainSec.value = minutes * 60;
    if (_isTestEnv) return;
    _sleepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (sleepRemainSec.value <= 1) {
        sleepRemainSec.value = 0;
        timer.cancel();
        if (isPlaying.value) {
          togglePlayPause();
        }
      } else {
        sleepRemainSec.value -= 1;
      }
    });
  }

  @override
  void onClose() {
    _fallbackTickTimer?.cancel();
    _sleepTimer?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _primaryPlayer?.dispose();
    _shadowPlayer?.dispose();
    super.onClose();
  }
}
