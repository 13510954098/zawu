import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:crypto/crypto.dart';

class CleanRoomAes128Ctr {
  static const List<int> _sBox = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
  ];

  static const List<int> _rCon = [
    0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36,
  ];

  static int _xtime(int x) => ((x << 1) ^ (((x >> 7) & 1) * 0x1b)) & 0xff;

  static Uint8List _expandKey(Uint8List key) {
    if (key.length != 16) {
      throw ArgumentError('AES-128 key must be 16 bytes');
    }
    final roundKeys = Uint8List(176);
    roundKeys.setRange(0, 16, key);
    final temp = Uint8List(4);
    var bytesGenerated = 16;
    var rconIdx = 1;

    while (bytesGenerated < 176) {
      for (var i = 0; i < 4; i++) {
        temp[i] = roundKeys[bytesGenerated - 4 + i];
      }
      if (bytesGenerated % 16 == 0) {
        final t = temp[0];
        temp[0] = _sBox[temp[1]] ^ _rCon[rconIdx];
        temp[1] = _sBox[temp[2]];
        temp[2] = _sBox[temp[3]];
        temp[3] = _sBox[t];
        rconIdx++;
      }
      for (var i = 0; i < 4; i++) {
        roundKeys[bytesGenerated] = roundKeys[bytesGenerated - 16] ^ temp[i];
        bytesGenerated++;
      }
    }
    return roundKeys;
  }

  static Uint8List encryptBlock(Uint8List input, Uint8List key) {
    final rk = _expandKey(key);
    return _cipherBlock(input, rk);
  }

  static Uint8List _cipherBlock(Uint8List input, Uint8List rk) {
    final s = Uint8List.fromList(input);

    void addRoundKey(int round) {
      final base = round * 16;
      for (var i = 0; i < 16; i++) {
        s[i] ^= rk[base + i];
      }
    }

    void subBytes() {
      for (var i = 0; i < 16; i++) {
        s[i] = _sBox[s[i]];
      }
    }

    void shiftRows() {
      final t1 = s[1];
      s[1] = s[5];
      s[5] = s[9];
      s[9] = s[13];
      s[13] = t1;

      final t2 = s[2];
      final t6 = s[6];
      s[2] = s[10];
      s[6] = s[14];
      s[10] = t2;
      s[14] = t6;

      final t3 = s[15];
      s[15] = s[11];
      s[11] = s[7];
      s[7] = s[3];
      s[3] = t3;
    }

    void mixColumns() {
      for (var c = 0; c < 4; c++) {
        final i = c * 4;
        final a0 = s[i];
        final a1 = s[i + 1];
        final a2 = s[i + 2];
        final a3 = s[i + 3];
        final t = a0 ^ a1 ^ a2 ^ a3;
        s[i] ^= t ^ _xtime(a0 ^ a1);
        s[i + 1] ^= t ^ _xtime(a1 ^ a2);
        s[i + 2] ^= t ^ _xtime(a2 ^ a3);
        s[i + 3] ^= t ^ _xtime(a3 ^ a0);
      }
    }

    addRoundKey(0);
    for (var round = 1; round < 10; round++) {
      subBytes();
      shiftRows();
      mixColumns();
      addRoundKey(round);
    }
    subBytes();
    shiftRows();
    addRoundKey(10);
    return s;
  }

  static Uint8List transformCtr(Uint8List data, Uint8List key16, Uint8List nonce8, {int initialCounter = 0}) {
    if (nonce8.length != 8) {
      throw ArgumentError('CTR nonce must be 8 bytes');
    }
    final rk = _expandKey(key16);
    final out = Uint8List(data.length);
    final counterBlock = Uint8List(16);
    counterBlock.setRange(0, 8, nonce8);

    var blockIndex = initialCounter;
    for (var offset = 0; offset < data.length; offset += 16) {
      var v = blockIndex;
      for (var b = 15; b >= 8; b--) {
        counterBlock[b] = v & 0xff;
        v >>= 8;
      }
      final keystream = _cipherBlock(counterBlock, rk);
      final chunkEnd = math.min(offset + 16, data.length);
      for (var i = offset; i < chunkEnd; i++) {
        out[i] = data[i] ^ keystream[i - offset];
      }
      blockIndex++;
    }
    return out;
  }
}

class StreamEnvelopePacket {
  final String mediaId;
  final Uint8List sessionKey;
  final Uint8List nonce;
  final Uint8List cipherBytes;
  final String plainSha256;

  const StreamEnvelopePacket({
    required this.mediaId,
    required this.sessionKey,
    required this.nonce,
    required this.cipherBytes,
    required this.plainSha256,
  });
}

class GatewaySignedHeaders {
  final String timestamp;
  final String nonce;
  final String deviceDigest;
  final String signatureHex;
  final String canonicalString;

  const GatewaySignedHeaders({
    required this.timestamp,
    required this.nonce,
    required this.deviceDigest,
    required this.signatureHex,
    required this.canonicalString,
  });

  Map<String, String> toMap() => {
        'X-Clean-Ts': timestamp,
        'X-Clean-Nonce': nonce,
        'X-Clean-Did': deviceDigest,
        'X-Clean-Sig': signatureHex,
      };
}

class EntitlementTicket {
  final String userId;
  final String tier;
  final int expireAtMs;
  final int grantedMinutes;
  final String hmacHex;

  const EntitlementTicket({
    required this.userId,
    required this.tier,
    required this.expireAtMs,
    required this.grantedMinutes,
    required this.hmacHex,
  });

  bool isActiveAt(int nowMs) => expireAtMs > nowMs;

  String toTokenString() {
    final payload = jsonEncode({
      'uid': userId,
      'tier': tier,
      'exp': expireAtMs,
      'min': grantedMinutes,
    });
    final b64 = base64UrlEncode(utf8.encode(payload));
    return '$b64.$hmacHex';
  }
}

class CleanRoomGuardEngine {
  final Uint8List gatewaySecret;
  final Uint8List entitlementSecret;
  int _monotonicNonce = 1000;

  CleanRoomGuardEngine({
    Uint8List? gatewaySecret,
    Uint8List? entitlementSecret,
  })  : gatewaySecret = gatewaySecret ??
            Uint8List.fromList(utf8.encode('cleanroom-local-gateway-hmac-key')),
        entitlementSecret = entitlementSecret ??
            Uint8List.fromList(utf8.encode('cleanroom-local-entitlement-key!'));

  static Uint8List randomBytes(int length, {int? seed}) {
    final rng = seed != null ? math.Random(seed) : math.Random.secure();
    return Uint8List.fromList(List<int>.generate(length, (_) => rng.nextInt(256)));
  }

  static String hexEncode(List<int> bytes) {
    final sb = StringBuffer();
    for (final b in bytes) {
      sb.write(b.toRadixString(16).padLeft(2, '0'));
    }
    return sb.toString();
  }

  static Uint8List hexDecode(String hex) {
    final clean = hex.trim();
    final out = Uint8List(clean.length ~/ 2);
    for (var i = 0; i < out.length; i++) {
      out[i] = int.parse(clean.substring(i * 2, i * 2 + 2), radix: 16);
    }
    return out;
  }

  StreamEnvelopePacket sealAudioChunk({
    required String mediaId,
    required Uint8List plainWavBytes,
    Uint8List? sessionKey16,
    Uint8List? nonce8,
  }) {
    final key = sessionKey16 ?? randomBytes(16);
    final nonce = nonce8 ?? randomBytes(8);
    final digest = sha256.convert(plainWavBytes).toString();
    final encrypted = CleanRoomAes128Ctr.transformCtr(plainWavBytes, key, nonce);
    return StreamEnvelopePacket(
      mediaId: mediaId,
      sessionKey: key,
      nonce: nonce,
      cipherBytes: encrypted,
      plainSha256: digest,
    );
  }

  Uint8List openAudioChunk(StreamEnvelopePacket packet) {
    final decrypted = CleanRoomAes128Ctr.transformCtr(
      packet.cipherBytes,
      packet.sessionKey,
      packet.nonce,
    );
    final actualSha = sha256.convert(decrypted).toString();
    if (actualSha != packet.plainSha256) {
      throw StateError('Stream integrity digest mismatch');
    }
    return decrypted;
  }

  GatewaySignedHeaders signGatewayRequest({
    required String method,
    required String path,
    Map<String, String> query = const {},
    String body = '',
    String deviceSeed = 'cleanroom-android-pixel',
    int? timestampMs,
  }) {
    _monotonicNonce += 1;
    final ts = (timestampMs ?? DateTime.now().millisecondsSinceEpoch).toString();
    final nonce = _monotonicNonce.toString();
    final sortedKeys = query.keys.toList()..sort();
    final canonicalQuery = sortedKeys.map((k) => '$k=${query[k]}').join('&');
    final bodyHash = sha256.convert(utf8.encode(body)).toString();
    final did = sha256.convert(utf8.encode(deviceSeed)).toString().substring(0, 24);
    final canonical = '${method.toUpperCase()}\n$path\n$canonicalQuery\n$ts\n$nonce\n$did\n$bodyHash';
    final mac = Hmac(sha256, gatewaySecret).convert(utf8.encode(canonical)).toString();
    return GatewaySignedHeaders(
      timestamp: ts,
      nonce: nonce,
      deviceDigest: did,
      signatureHex: mac,
      canonicalString: canonical,
    );
  }

  bool verifyGatewayRequest({
    required String method,
    required String path,
    required GatewaySignedHeaders headers,
    Map<String, String> query = const {},
    String body = '',
    int maxSkewMs = 300000,
    int? nowMs,
  }) {
    final tsVal = int.tryParse(headers.timestamp);
    if (tsVal == null) return false;
    final refNow = nowMs ?? DateTime.now().millisecondsSinceEpoch;
    if ((refNow - tsVal).abs() > maxSkewMs) return false;
    final sortedKeys = query.keys.toList()..sort();
    final canonicalQuery = sortedKeys.map((k) => '$k=${query[k]}').join('&');
    final bodyHash = sha256.convert(utf8.encode(body)).toString();
    final canonical =
        '${method.toUpperCase()}\n$path\n$canonicalQuery\n${headers.timestamp}\n${headers.nonce}\n${headers.deviceDigest}\n$bodyHash';
    final expected = Hmac(sha256, gatewaySecret).convert(utf8.encode(canonical)).toString();
    return expected == headers.signatureHex;
  }

  EntitlementTicket issueRewardedEntitlement({
    required String userId,
    required int grantMinutes,
    String tier = 'REWARDED_FREE_LISTEN',
    int? nowMs,
  }) {
    final baseNow = nowMs ?? DateTime.now().millisecondsSinceEpoch;
    final exp = baseNow + grantMinutes * 60 * 1000;
    final msg = '$userId|$tier|$exp|$grantMinutes';
    final sig = Hmac(sha256, entitlementSecret).convert(utf8.encode(msg)).toString();
    return EntitlementTicket(
      userId: userId,
      tier: tier,
      expireAtMs: exp,
      grantedMinutes: grantMinutes,
      hmacHex: sig,
    );
  }

  bool verifyEntitlementTicket(EntitlementTicket ticket, {int? nowMs}) {
    final msg = '${ticket.userId}|${ticket.tier}|${ticket.expireAtMs}|${ticket.grantedMinutes}';
    final expected = Hmac(sha256, entitlementSecret).convert(utf8.encode(msg)).toString();
    if (expected != ticket.hmacHex) return false;
    final checkNow = nowMs ?? DateTime.now().millisecondsSinceEpoch;
    return ticket.isActiveAt(checkNow);
  }
}
