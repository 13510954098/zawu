import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/music_models.dart';

class LunaDatabase {
  static final LunaDatabase instance = LunaDatabase._();
  LunaDatabase._();

  Database? _db;
  final Set<String> _memLikes = {'trk_01'};
  final List<MusicTrack> _memHistory = [];
  final List<MusicTrack> _memDownloads = [];
  final List<MusicTrack> _memAiTracks = [];
  final Map<String, List<String>> _memCustomPlaylists = {
    '我的红心私藏': ['trk_01', 'trk_04'],
  };

  bool get _isTestEnv => Platform.environment.containsKey('FLUTTER_TEST');

  Future<Database?> _database() async {
    if (_isTestEnv) return null;
    if (_db != null) return _db;
    try {
      final dbRoot = await getDatabasesPath();
      final dbPath = p.join(dbRoot, 'qishui_cleanroom.db');
      _db = await openDatabase(
        dbPath,
        version: 1,
        onCreate: (db, version) async {
          await db.execute(
            'CREATE TABLE liked_tracks (id TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at INTEGER NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE play_history (id TEXT PRIMARY KEY, payload TEXT NOT NULL, played_at INTEGER NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE offline_downloads (id TEXT PRIMARY KEY, payload TEXT NOT NULL, local_path TEXT NOT NULL, saved_at INTEGER NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE ai_creations (id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE user_playlists (name TEXT PRIMARY KEY, track_ids TEXT NOT NULL, updated_at INTEGER NOT NULL)',
          );
        },
      );
      return _db;
    } catch (_) {
      return null;
    }
  }

  Future<Set<String>> loadLikedIds() async {
    final db = await _database();
    if (db == null) return Set<String>.from(_memLikes);
    final rows = await db.query('liked_tracks', columns: ['id']);
    return rows.map((r) => (r['id'] ?? '').toString()).where((s) => s.isNotEmpty).toSet();
  }

  Future<void> setLiked(MusicTrack track, bool liked) async {
    if (liked) {
      _memLikes.add(track.id);
    } else {
      _memLikes.remove(track.id);
    }
    final db = await _database();
    if (db == null) return;
    if (liked) {
      await db.insert(
        'liked_tracks',
        {
          'id': track.id,
          'payload': jsonEncode(track.toMap()),
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } else {
      await db.delete('liked_tracks', where: 'id = ?', whereArgs: [track.id]);
    }
  }

  Future<void> recordHistory(MusicTrack track) async {
    _memHistory.removeWhere((t) => t.id == track.id);
    _memHistory.insert(0, track);
    final db = await _database();
    if (db == null) return;
    await db.insert(
      'play_history',
      {
        'id': track.id,
        'payload': jsonEncode(track.toMap()),
        'played_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MusicTrack>> loadHistory() async {
    final db = await _database();
    if (db == null) return List<MusicTrack>.from(_memHistory);
    final rows = await db.query('play_history', orderBy: 'played_at DESC', limit: 60);
    return rows
        .map((r) => MusicTrack.fromMap(jsonDecode((r['payload'] ?? '{}').toString()) as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveDownload(MusicTrack track, String localPath) async {
    final updated = track.copyWith(streamUrl: localPath);
    _memDownloads.removeWhere((t) => t.id == track.id);
    _memDownloads.insert(0, updated);
    final db = await _database();
    if (db == null) return;
    await db.insert(
      'offline_downloads',
      {
        'id': track.id,
        'payload': jsonEncode(updated.toMap()),
        'local_path': localPath,
        'saved_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MusicTrack>> loadDownloads() async {
    final db = await _database();
    if (db == null) return List<MusicTrack>.from(_memDownloads);
    final rows = await db.query('offline_downloads', orderBy: 'saved_at DESC');
    return rows
        .map((r) => MusicTrack.fromMap(jsonDecode((r['payload'] ?? '{}').toString()) as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveAiCreation(MusicTrack track) async {
    _memAiTracks.removeWhere((t) => t.id == track.id);
    _memAiTracks.insert(0, track);
    final db = await _database();
    if (db == null) return;
    await db.insert(
      'ai_creations',
      {
        'id': track.id,
        'payload': jsonEncode(track.toMap()),
        'created_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<MusicTrack>> loadAiCreations() async {
    final db = await _database();
    if (db == null) return List<MusicTrack>.from(_memAiTracks);
    final rows = await db.query('ai_creations', orderBy: 'created_at DESC');
    return rows
        .map((r) => MusicTrack.fromMap(jsonDecode((r['payload'] ?? '{}').toString()) as Map<String, dynamic>))
        .toList();
  }

  Future<Map<String, List<String>>> loadUserPlaylists() async {
    final db = await _database();
    if (db == null) return Map<String, List<String>>.from(_memCustomPlaylists);
    final rows = await db.query('user_playlists', orderBy: 'updated_at DESC');
    if (rows.isEmpty) {
      return Map<String, List<String>>.from(_memCustomPlaylists);
    }
    final out = <String, List<String>>{};
    for (final r in rows) {
      final name = (r['name'] ?? '').toString();
      final list = (jsonDecode((r['track_ids'] ?? '[]').toString()) as List)
          .map((e) => e.toString())
          .toList();
      if (name.isNotEmpty) out[name] = list;
    }
    return out;
  }

  Future<void> upsertUserPlaylist(String name, List<String> trackIds) async {
    _memCustomPlaylists[name] = List<String>.from(trackIds);
    final db = await _database();
    if (db == null) return;
    await db.insert(
      'user_playlists',
      {
        'name': name,
        'track_ids': jsonEncode(trackIds),
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
