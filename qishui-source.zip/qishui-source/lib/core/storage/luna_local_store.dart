import 'dart:convert';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../models/luna_models.dart';

class LunaLocalStore {
  Database? _db;
  SharedPreferences? _prefs;
  final Set<String> _memLikes = {'luna_trk_101'};
  final List<HistoryEntry> _memHistory = [];
  final List<DownloadTaskEntry> _memDownloads = [];
  int _syncCursor = 1001;

  Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      final savedLikes = _prefs?.getStringList('keva_liked_ids');
      if (savedLikes != null) {
        _memLikes
          ..clear()
          ..addAll(savedLikes);
      }
      _syncCursor = _prefs?.getInt('keva_bytesync_cursor') ?? 1001;
    } catch (_) {}

    try {
      final dbDir = await getDatabasesPath();
      final dbPath = p.join(dbDir, 'luna_cleanroom_v1.db');
      _db = await openDatabase(
        dbPath,
        version: 1,
        onCreate: (db, version) async {
          await db.execute(
            'CREATE TABLE IF NOT EXISTS history_playable (id TEXT PRIMARY KEY, playableJson TEXT NOT NULL, insertTimeStampMs INTEGER NOT NULL, completionRate REAL NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE IF NOT EXISTS downloaded_track (id TEXT PRIMARY KEY, title TEXT NOT NULL, artist TEXT NOT NULL, quality TEXT NOT NULL, progress REAL NOT NULL, localHash TEXT NOT NULL, completeTime INTEGER NOT NULL)',
          );
          await db.execute(
            'CREATE TABLE IF NOT EXISTS user_subscription_info (user_id TEXT PRIMARY KEY, tier TEXT NOT NULL, expire_date INTEGER NOT NULL, granted_minutes INTEGER NOT NULL, hmac_hex TEXT NOT NULL)',
          );
        },
      );
      await _hydrateFromDb();
    } catch (_) {}
  }

  Future<void> _hydrateFromDb() async {
    final db = _db;
    if (db == null) return;
    final hRows = await db.query('history_playable', orderBy: 'insertTimeStampMs DESC', limit: 40);
    _memHistory.clear();
    for (final r in hRows) {
      final raw = jsonDecode(r['playableJson'].toString()) as Map<String, dynamic>;
      _memHistory.add(
        HistoryEntry(
          track: LunaTrack.fromJson(raw),
          playedAtMs: (r['insertTimeStampMs'] as num).toInt(),
          completionRate: (r['completionRate'] as num).toDouble(),
        ),
      );
    }

    final dRows = await db.query('downloaded_track', orderBy: 'completeTime DESC');
    _memDownloads.clear();
    for (final r in dRows) {
      _memDownloads.add(
        DownloadTaskEntry(
          trackId: r['id'].toString(),
          title: r['title'].toString(),
          artist: r['artist'].toString(),
          quality: r['quality'].toString(),
          progress: (r['progress'] as num).toDouble(),
          localHash: r['localHash'].toString(),
          completedAtMs: (r['completeTime'] as num).toInt(),
        ),
      );
    }
  }

  Set<String> get likedTrackIds => Set.unmodifiable(_memLikes);
  List<HistoryEntry> get history => List.unmodifiable(_memHistory);
  List<DownloadTaskEntry> get downloads => List.unmodifiable(_memDownloads);
  int get syncCursor => _syncCursor;

  Future<void> toggleLike(String trackId) async {
    if (_memLikes.contains(trackId)) {
      _memLikes.remove(trackId);
    } else {
      _memLikes.add(trackId);
    }
    _syncCursor += 1;
    try {
      await _prefs?.setStringList('keva_liked_ids', _memLikes.toList());
      await _prefs?.setInt('keva_bytesync_cursor', _syncCursor);
    } catch (_) {}
  }

  Future<void> recordHistory(LunaTrack track, double completionRate) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    _memHistory.removeWhere((e) => e.track.id == track.id);
    _memHistory.insert(
      0,
      HistoryEntry(
        track: track,
        playedAtMs: now,
        completionRate: completionRate.clamp(0.05, 1.0),
      ),
    );
    try {
      await _db?.insert(
        'history_playable',
        {
          'id': track.id,
          'playableJson': jsonEncode(track.toJson()),
          'insertTimeStampMs': now,
          'completionRate': completionRate.clamp(0.05, 1.0),
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (_) {}
  }

  Future<void> saveDownload(DownloadTaskEntry item) async {
    _memDownloads.removeWhere((e) => e.trackId == item.trackId);
    _memDownloads.insert(0, item);
    try {
      await _db?.insert(
        'downloaded_track',
        {
          'id': item.trackId,
          'title': item.title,
          'artist': item.artist,
          'quality': item.quality,
          'progress': item.progress,
          'localHash': item.localHash,
          'completeTime': item.completedAtMs,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (_) {}
  }
}
