import 'dart:io';
import 'dart:math' as math;
import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/music_models.dart';
import 'mock_catalog.dart';

class ApiService extends GetxService {
  static const String _prefServerKey = 'qishui_server_base_url';
  final RxString baseUrl = 'http://127.0.0.1:8790'.obs;
  final RxBool serverOnline = false.obs;

  late Dio _dio;
  final Map<String, List<TrackComment>> _localComments = {
    for (final entry in MockCatalog.initialComments.entries)
      entry.key: List<TrackComment>.from(entry.value),
  };

  Future<ApiService> init() async {
    _dio = Dio(
      BaseOptions(
        connectTimeout: const Duration(milliseconds: 1400),
        receiveTimeout: const Duration(milliseconds: 2500),
      ),
    );
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final prefs = await SharedPreferences.getInstance();
        final saved = prefs.getString(_prefServerKey);
        if (saved != null && saved.trim().isNotEmpty) {
          baseUrl.value = saved.trim();
        }
        await checkHealth();
      } catch (_) {}
    }
    return this;
  }

  Future<void> updateBaseUrl(String url) async {
    final cleaned = url.trim().replaceAll(RegExp(r'/+$'), '');
    if (cleaned.isEmpty) return;
    baseUrl.value = cleaned;
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefServerKey, cleaned);
    }
    await checkHealth();
  }

  Future<bool> checkHealth() async {
    if (Platform.environment.containsKey('FLUTTER_TEST')) {
      serverOnline.value = false;
      return false;
    }
    try {
      final resp = await _dio.get('${baseUrl.value}/api/health');
      final ok = resp.statusCode == 200;
      serverOnline.value = ok;
      return ok;
    } catch (_) {
      serverOnline.value = false;
      return false;
    }
  }

  Future<List<MusicTrack>> fetchFeed({String channel = '推荐'}) async {
    if (!Platform.environment.containsKey('FLUTTER_TEST')) {
      try {
        final resp = await _dio.get(
          '${baseUrl.value}/api/feed',
          queryParameters: {'channel': channel},
        );
        if (resp.statusCode == 200 && resp.data is Map) {
          serverOnline.value = true;
          final items = (resp.data['tracks'] as List?) ?? [];
          if (items.isNotEmpty) {
            return items
                .map((e) {
                  final map = Map<String, dynamic>.from(e as Map);
                  final rawStream = (map['streamUrl'] ?? '').toString();
                  if (rawStream.startsWith('/')) {
                    map['streamUrl'] = '${baseUrl.value}$rawStream';
                  }
                  return MusicTrack.fromMap(map);
                })
                .toList();
          }
        }
      } catch (_) {
        serverOnline.value = false;
      }
    }
    if (channel == '推荐' || channel == '随心听') {
      final list = List<MusicTrack>.from(MockCatalog.tracks);
      if (channel == '随心听') {
        return list.reversed.toList();
      }
      return list;
    }
    final filtered = MockCatalog.tracks.where((t) => t.channel == channel).toList();
    return filtered.isEmpty ? List<MusicTrack>.from(MockCatalog.tracks) : filtered;
  }

  Future<List<MusicTrack>> searchTracks(String query) async {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return List<MusicTrack>.from(MockCatalog.tracks);
    if (serverOnline.value) {
      try {
        final resp = await _dio.get(
          '${baseUrl.value}/api/search',
          queryParameters: {'q': query.trim()},
        );
        if (resp.statusCode == 200 && resp.data is Map) {
          final items = (resp.data['tracks'] as List?) ?? [];
          return items
              .map((e) {
                final map = Map<String, dynamic>.from(e as Map);
                final rawStream = (map['streamUrl'] ?? '').toString();
                if (rawStream.startsWith('/')) {
                  map['streamUrl'] = '${baseUrl.value}$rawStream';
                }
                return MusicTrack.fromMap(map);
              })
              .toList();
        }
      } catch (_) {}
    }
    return MockCatalog.tracks
        .where(
          (t) =>
              t.title.toLowerCase().contains(q) ||
              t.artist.toLowerCase().contains(q) ||
              t.album.toLowerCase().contains(q) ||
              t.channel.toLowerCase().contains(q),
        )
        .toList();
  }

  Future<List<TrackComment>> fetchComments(String trackId) async {
    if (serverOnline.value) {
      try {
        final resp = await _dio.get(
          '${baseUrl.value}/api/comments',
          queryParameters: {'trackId': trackId},
        );
        if (resp.statusCode == 200 && resp.data is Map) {
          final items = (resp.data['comments'] as List?) ?? [];
          return items
              .map((e) => TrackComment.fromMap(Map<String, dynamic>.from(e as Map)))
              .toList();
        }
      } catch (_) {}
    }
    return List<TrackComment>.from(
      _localComments[trackId] ??
          [
            TrackComment(
              id: 'seed_$trackId',
              trackId: trackId,
              author: '漫游听歌人',
              content: '这首编曲很有空间层次感，戴上耳机体验绝佳。',
              likedCount: 168,
              timeLabel: '刚刚',
              atSecond: 3,
            ),
          ],
    );
  }

  Future<TrackComment> postComment({
    required String trackId,
    required String author,
    required String content,
    required int atSecond,
  }) async {
    if (serverOnline.value) {
      try {
        final resp = await _dio.post(
          '${baseUrl.value}/api/comments',
          data: {
            'trackId': trackId,
            'author': author,
            'content': content,
            'atSecond': atSecond,
          },
        );
        if (resp.statusCode == 200 && resp.data is Map && resp.data['comment'] is Map) {
          return TrackComment.fromMap(Map<String, dynamic>.from(resp.data['comment'] as Map));
        }
      } catch (_) {}
    }
    final created = TrackComment(
      id: 'cm_${DateTime.now().millisecondsSinceEpoch}',
      trackId: trackId,
      author: author,
      content: content,
      likedCount: 1,
      timeLabel: '刚刚',
      atSecond: atSecond,
    );
    final bucket = _localComments.putIfAbsent(trackId, () => []);
    bucket.insert(0, created);
    return created;
  }

  Future<MusicTrack> composeAiTrack({
    required String prompt,
    required String style,
    required String customLyrics,
  }) async {
    if (serverOnline.value) {
      try {
        final resp = await _dio.post(
          '${baseUrl.value}/api/ai/compose',
          data: {
            'prompt': prompt,
            'style': style,
            'lyrics': customLyrics,
          },
        );
        if (resp.statusCode == 200 && resp.data is Map && resp.data['track'] is Map) {
          final map = Map<String, dynamic>.from(resp.data['track'] as Map);
          final rawStream = (map['streamUrl'] ?? '').toString();
          if (rawStream.startsWith('/')) {
            map['streamUrl'] = '${baseUrl.value}$rawStream';
          }
          return MusicTrack.fromMap(map);
        }
      } catch (_) {}
    }

    final seed = prompt.hashCode.abs() + DateTime.now().millisecond;
    final rng = math.Random(seed);
    final scalePool = <List<double>>[
      [261.63, 329.63, 392.00, 493.88],
      [220.00, 293.66, 349.23, 440.00],
      [246.94, 311.13, 369.99, 466.16],
      [293.66, 369.99, 440.00, 523.25],
    ];
    final palettePool = <List<int>>[
      [0xFF00F090, 0xFF163A4A],
      [0xFF7C5CFF, 0xFF23164B],
      [0xFFFF6B8B, 0xFF3A1830],
      [0xFF00BBF9, 0xFF102A45],
    ];
    final colors = palettePool[seed % palettePool.length];
    final cleanPrompt = prompt.trim().isEmpty ? '星河气泡即兴曲' : prompt.trim();
    final lines = customLyrics.trim().isNotEmpty
        ? customLyrics
            .trim()
            .split('\n')
            .where((l) => l.trim().isNotEmpty)
            .toList()
        : [
            '在 $style 的夜色里按下播放键',
            '$cleanPrompt 化作跃动的音符光线',
            '微风穿过耳畔带走整日喧嚣',
            '让合成旋律陪你抵达黎明海岸',
          ];
    final lrcBuf = StringBuffer();
    for (var i = 0; i < lines.length; i++) {
      final sec = (i * 4).toString().padLeft(2, '0');
      lrcBuf.writeln('[00:$sec.00]${lines[i]}|AI Studio · $style');
    }

    return MusicTrack(
      id: 'ai_${DateTime.now().millisecondsSinceEpoch}',
      title: cleanPrompt.length > 14 ? cleanPrompt.substring(0, 14) : cleanPrompt,
      artist: 'AI 灵感工坊 · $style',
      album: 'AI 原创单曲集',
      channel: '推荐',
      durationSec: 20,
      bpm: 96 + rng.nextInt(36),
      chordFreqs: scalePool[seed % scalePool.length],
      primaryColorValue: colors[0],
      secondaryColorValue: colors[1],
      qualityBadge: 'AI 母带',
      isVip: false,
      isAiGenerated: true,
      likesCount: 1,
      commentsCount: 0,
      sharesCount: 0,
      lrc: lrcBuf.toString().trim(),
    );
  }

  Future<ListenRoomState> fetchListenRoom(String currentTrackId) async {
    if (serverOnline.value) {
      try {
        final resp = await _dio.get('${baseUrl.value}/api/room');
        if (resp.statusCode == 200 && resp.data is Map) {
          return ListenRoomState.fromMap(Map<String, dynamic>.from(resp.data as Map));
        }
      } catch (_) {}
    }
    return ListenRoomState(
      roomId: 'RM-8801',
      roomTitle: '深夜气泡电台 · 一起听',
      hostName: '星河漫游者',
      onlineCount: 4,
      currentTrackId: currentTrackId,
      positionMs: 4200,
      isPlaying: true,
      messages: const [
        ListenRoomMessage(sender: '星河漫游者', text: '欢迎进来一起听歌，切了首很舒服的夜曲～', timeLabel: '1分钟前'),
        ListenRoomMessage(sender: '薄荷冰块', text: '鼓点一出来整个人都放松了', timeLabel: '刚刚'),
      ],
    );
  }
}
