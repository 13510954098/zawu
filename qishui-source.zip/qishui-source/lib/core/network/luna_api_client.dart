import 'dart:convert';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import '../models/luna_models.dart';
import '../security/cleanroom_guard_engine.dart';
import 'demo_catalog.dart';

class LunaApiClient {
  final Dio _dio;
  final CleanRoomGuardEngine guard;
  String baseUrl;

  LunaApiClient({
    required this.guard,
    this.baseUrl = 'http://127.0.0.1:8478',
  }) : _dio = Dio(
          BaseOptions(
            connectTimeout: const Duration(milliseconds: 1200),
            receiveTimeout: const Duration(milliseconds: 1800),
          ),
        );

  Future<List<LunaTrack>> fetchFeed({String mood = '全部推荐'}) async {
    const path = '/luna/feed';
    final query = {'mood': mood};
    final signed = guard.signGatewayRequest(method: 'GET', path: path, query: query);
    try {
      final resp = await _dio.get(
        '$baseUrl$path',
        queryParameters: query,
        options: Options(headers: signed.toMap()),
      );
      final data = resp.data;
      if (data is Map && data['tracks'] is List) {
        return (data['tracks'] as List)
            .whereType<Map>()
            .map((e) => LunaTrack.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}

    final all = DemoCatalog.initialTracks();
    if (mood == '全部推荐') return all;
    return all.where((t) => t.moodScene == mood).toList();
  }

  Future<List<LunaTrack>> searchTracks(String keyword) async {
    final trimmed = keyword.trim().toLowerCase();
    const path = '/luna/search';
    final query = {'q': trimmed};
    final signed = guard.signGatewayRequest(method: 'GET', path: path, query: query);
    try {
      final resp = await _dio.get(
        '$baseUrl$path',
        queryParameters: query,
        options: Options(headers: signed.toMap()),
      );
      final data = resp.data;
      if (data is Map && data['tracks'] is List) {
        return (data['tracks'] as List)
            .whereType<Map>()
            .map((e) => LunaTrack.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {}

    final all = DemoCatalog.initialTracks();
    if (trimmed.isEmpty) return all;
    return all.where((t) {
      return t.title.toLowerCase().contains(trimmed) ||
          t.artist.toLowerCase().contains(trimmed) ||
          t.moodScene.toLowerCase().contains(trimmed) ||
          t.album.toLowerCase().contains(trimmed);
    }).toList();
  }

  Future<LunaTrack> createAiTrack({
    required String prompt,
    required String moodScene,
    required int bpm,
  }) async {
    const path = '/luna/ai/creation/gen';
    final payload = jsonEncode({
      'prompt': prompt,
      'moodScene': moodScene,
      'bpm': bpm,
    });
    final signed = guard.signGatewayRequest(method: 'POST', path: path, body: payload);
    try {
      final resp = await _dio.post(
        '$baseUrl$path',
        data: payload,
        options: Options(
          headers: {
            ...signed.toMap(),
            'Content-Type': 'application/json',
          },
        ),
      );
      if (resp.data is Map && resp.data['track'] is Map) {
        return LunaTrack.fromJson(Map<String, dynamic>.from(resp.data['track']));
      }
    } catch (_) {}

    final cleanPrompt = prompt.trim().isEmpty ? '星河汽水灵感' : prompt.trim();
    final nowId = DateTime.now().millisecondsSinceEpoch;
    final seed = cleanPrompt.codeUnits.fold<int>(0, (a, b) => a + b);
    final baseFreq = 220.0 + (seed % 5) * 32.0;
    return LunaTrack(
      id: 'ai_trk_$nowId',
      title: '$cleanPrompt (AI 创作版)',
      artist: '汽水 AI 作曲实验室',
      album: 'AI 灵感专辑',
      moodScene: moodScene,
      durationMs: 20000,
      bpm: bpm,
      chordHz: [baseFreq, baseFreq * 1.25, baseFreq * 1.5, baseFreq * 1.875],
      colorPrimary: 0xFF7C4DFF,
      colorSecondary: 0xFF1B1238,
      likeCount: 1,
      commentCount: 0,
      vipOnly: false,
      qualities: const ['标准', '极高', '无损 FLAC', '空间音频'],
      lyrics: [
        LyricLine(timeMs: 0, text: '围绕「$cleanPrompt」点亮第一束音符'),
        const LyricLine(timeMs: 5000, text: '合成器穿过夜色与海风的边界'),
        const LyricLine(timeMs: 10000, text: '每一次节拍都是自由生长的回响'),
        const LyricLine(timeMs: 15000, text: '在无尽声场中与你再次相遇'),
      ],
      comments: const [],
    );
  }

  Future<EntitlementTicket> claimRewardedFreeListen({
    required String userId,
    int minutes = 30,
  }) async {
    const path = '/luna/advert/incentive/done';
    final payload = jsonEncode({'userId': userId, 'minutes': minutes});
    final signed = guard.signGatewayRequest(method: 'POST', path: path, body: payload);
    try {
      final resp = await _dio.post(
        '$baseUrl$path',
        data: payload,
        options: Options(
          headers: {
            ...signed.toMap(),
            'Content-Type': 'application/json',
          },
        ),
      );
      if (resp.data is Map) {
        final m = Map<String, dynamic>.from(resp.data);
        return EntitlementTicket(
          userId: m['userId']?.toString() ?? userId,
          tier: m['tier']?.toString() ?? 'REWARDED_FREE_LISTEN',
          expireAtMs: (m['expireAtMs'] as num).toInt(),
          grantedMinutes: (m['grantedMinutes'] as num).toInt(),
          hmacHex: m['hmacHex']?.toString() ?? '',
        );
      }
    } catch (_) {}

    return guard.issueRewardedEntitlement(userId: userId, grantMinutes: minutes);
  }

  Future<StreamEnvelopePacket?> fetchServerEncryptedEnvelope(String mediaId, Uint8List fallbackPlainWav) async {
    const path = '/luna/stream/encrypted_wav';
    final query = {'mediaId': mediaId};
    final signed = guard.signGatewayRequest(method: 'GET', path: path, query: query);
    try {
      final resp = await _dio.get(
        '$baseUrl$path',
        queryParameters: query,
        options: Options(headers: signed.toMap()),
      );
      if (resp.data is Map) {
        final m = Map<String, dynamic>.from(resp.data);
        return StreamEnvelopePacket(
          mediaId: mediaId,
          sessionKey: CleanRoomGuardEngine.hexDecode(m['keyHex'].toString()),
          nonce: CleanRoomGuardEngine.hexDecode(m['nonceHex'].toString()),
          cipherBytes: base64Decode(m['cipherB64'].toString()),
          plainSha256: m['plainSha256'].toString(),
        );
      }
    } catch (_) {}
    return guard.sealAudioChunk(mediaId: mediaId, plainWavBytes: fallbackPlainWav);
  }
}
