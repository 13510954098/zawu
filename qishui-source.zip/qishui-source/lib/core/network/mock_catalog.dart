import '../models/music_models.dart';

class MockCatalog {
  static const List<String> channels = [
    '推荐',
    '随心听',
    '电音派对',
    '国风新韵',
    '深夜治愈',
  ];

  static const List<String> hotKeywords = [
    '霓虹海风',
    '赛博气泡',
    '长安夜雨',
    '微醺晚风',
    'AI 合成波',
    '城市漫游指南',
    '银河便利店',
    '零点耳机',
  ];

  static final List<MusicTrack> tracks = [
    const MusicTrack(
      id: 'trk_01',
      title: '薄荷汽水与落日海湾',
      artist: '橘子海屿',
      album: '夏日气泡特调',
      channel: '推荐',
      durationSec: 20,
      bpm: 112,
      chordFreqs: [261.63, 392.00, 440.00, 349.23],
      primaryColorValue: 0xFF00C978,
      secondaryColorValue: 0xFF134E5E,
      qualityBadge: 'Hi-Res',
      isVip: false,
      likesCount: 48200,
      commentsCount: 1640,
      sharesCount: 920,
      lrc: '[00:00.00]海风吹散傍晚六点的云朵|Sea breeze clears the twilight clouds\n'
          '[00:04.00]冰镇薄荷在玻璃杯里闪烁|Chilled mint sparkles inside the glass\n'
          '[00:08.00]耳机分你一半听潮汐起落|Sharing an earbud as tides rise and fall\n'
          '[00:12.00]橘色落日把影子拉得很慢|Orange sunset stretches our shadows slow\n'
          '[00:16.00]这一刻心动随气泡升空|Heartbeats float upward with every bubble',
    ),
    const MusicTrack(
      id: 'trk_02',
      title: '霓虹高架桥 02:15',
      artist: '午夜合成器',
      album: '不眠都市电台',
      channel: '电音派对',
      durationSec: 20,
      bpm: 126,
      chordFreqs: [220.00, 261.63, 329.63, 392.00],
      primaryColorValue: 0xFF7C5CFF,
      secondaryColorValue: 0xFF1F1147,
      qualityBadge: '臻品母带',
      isVip: true,
      likesCount: 91300,
      commentsCount: 3120,
      sharesCount: 2050,
      lrc: '[00:00.00]穿过凌晨两点半的隧道灯光|Cruising past 2:30 AM tunnel lights\n'
          '[00:04.00]合成器低频在胸口微微震荡|Synth sub-bass hums softly in my chest\n'
          '[00:08.00]后视镜折返整座城市的星河|Rearview mirror bends the city galaxy\n'
          '[00:12.00]不问终点只管把音量推高|No destination just turn the gain up\n'
          '[00:16.00]在赛博夜色里自由失重|Weightless inside the neon night',
    ),
    const MusicTrack(
      id: 'trk_03',
      title: '烟雨入江南',
      artist: '云山折扇',
      album: '山河听风录',
      channel: '国风新韵',
      durationSec: 20,
      bpm: 92,
      chordFreqs: [293.66, 329.63, 392.00, 440.00],
      primaryColorValue: 0xFF2EC4B6,
      secondaryColorValue: 0xFF1B3B48,
      qualityBadge: '无损 SQ',
      isVip: false,
      likesCount: 62500,
      commentsCount: 2190,
      sharesCount: 1480,
      lrc: '[00:00.00]青石阶上落满一宿春雨声|Spring rain lingers on mossy stone steps\n'
          '[00:04.00]乌篷船摇碎桥下灯火几盏|Oars ripple lantern reflections below the arch\n'
          '[00:08.00]竹笛轻叹吹开远山薄雾|Bamboo flute parts the distant mountain mist\n'
          '[00:12.00]一盏新茶温热旧时书信|Fresh tea warms pages of an old letter\n'
          '[00:16.00]人间清欢不过此刻微风|Quiet joy is simply this gentle breeze',
    ),
    const MusicTrack(
      id: 'trk_04',
      title: '银河便利店打烊前',
      artist: '白日梦航线',
      album: '温柔宇宙漫游',
      channel: '深夜治愈',
      durationSec: 20,
      bpm: 84,
      chordFreqs: [246.94, 329.63, 369.99, 493.88],
      primaryColorValue: 0xFFFF6B8B,
      secondaryColorValue: 0xFF2D1936,
      qualityBadge: 'Hi-Res',
      isVip: false,
      likesCount: 73400,
      commentsCount: 4080,
      sharesCount: 1890,
      lrc: '[00:00.00]街角暖黄灯牌还在等你回家|Warm corner sign still waits for you\n'
          '[00:04.00]热牛奶蒸腾出小小的云霞|Warm milk rises in tiny clouds\n'
          '[00:08.00]把今天所有的疲惫轻轻放下|Set down every trace of tired weight\n'
          '[00:12.00]星星落在窗台替你说晚安|Stars land on the sill to whisper goodnight\n'
          '[00:16.00]明天醒来又是晴朗出发|Wake tomorrow to a clear departure',
    ),
    const MusicTrack(
      id: 'trk_05',
      title: '失重脉冲 Pulse 909',
      artist: '极光回路',
      album: '未来舞池指南',
      channel: '电音派对',
      durationSec: 20,
      bpm: 132,
      chordFreqs: [196.00, 293.66, 329.63, 392.00],
      primaryColorValue: 0xFF00BBF9,
      secondaryColorValue: 0xFF0B2545,
      qualityBadge: '全景声',
      isVip: true,
      likesCount: 53900,
      commentsCount: 980,
      sharesCount: 760,
      lrc: '[00:00.00]鼓点切开静止的空气节拍|Kick drums slice through frozen air\n'
          '[00:04.00]激光束在天际线交错盛开|Laser beams bloom across the skyline\n'
          '[00:08.00]每一次滤波升起都是新次元|Every filter sweep opens a new dimension\n'
          '[00:12.00]跟随节拍甩掉所有引力束缚|Drop gravity and ride the rhythm\n'
          '[00:16.00]直到黎明第一缕光降临|Until the first ray of dawn arrives',
    ),
    const MusicTrack(
      id: 'trk_06',
      title: '风吹过七号站台',
      artist: '夏末邮差',
      album: '慢车时刻表',
      channel: '随心听',
      durationSec: 20,
      bpm: 100,
      chordFreqs: [261.63, 329.63, 293.66, 392.00],
      primaryColorValue: 0xFFFF9F1C,
      secondaryColorValue: 0xFF3D2618,
      qualityBadge: '极高 HQ',
      isVip: false,
      likesCount: 38900,
      commentsCount: 1320,
      sharesCount: 640,
      lrc: '[00:00.00]绿皮火车缓缓驶离旧站台|Slow train glides away from Platform Seven\n'
          '[00:04.00]白衬衫被风鼓起少年时代|Wind fills white shirts like younger days\n'
          '[00:08.00]麦浪翻滚过窗外整片金黄|Golden wheat waves roll outside the glass\n'
          '[00:12.00]那些没说出口的珍重与期待|Unspoken farewells and bright hopes\n'
          '[00:16.00]都写进旋律里沿途盛开|All written into melodies blooming ahead',
    ),
    const MusicTrack(
      id: 'trk_07',
      title: '长安夜宴灯如昼',
      artist: '司南乐坊',
      album: '盛唐幻音集',
      channel: '国风新韵',
      durationSec: 20,
      bpm: 106,
      chordFreqs: [329.63, 392.00, 440.00, 523.25],
      primaryColorValue: 0xFFE71D36,
      secondaryColorValue: 0xFF3A0CA3,
      qualityBadge: '无损 SQ',
      isVip: false,
      likesCount: 81200,
      commentsCount: 2740,
      sharesCount: 1920,
      lrc: '[00:00.00]朱雀街口千树花灯次第明|A thousand lanterns light Vermilion Street\n'
          '[00:04.00]琵琶急雨惊起檐角铜铃声|Pipa notes awaken bronze eaves bells\n'
          '[00:08.00]举杯邀月共赏今宵千里明|Raise a cup to the bright moon overhead\n'
          '[00:12.00]衣袂翩跹舞尽千年风雅情|Flowing sleeves dance through timeless grace\n'
          '[00:16.00]曲终人未散月影落长亭|Melody lingers as moonbeams touch the pavilion',
    ),
    const MusicTrack(
      id: 'trk_08',
      title: '雨声落在黑胶唱片上',
      artist: '留声机房间',
      album: '零点独处指南',
      channel: '深夜治愈',
      durationSec: 20,
      bpm: 78,
      chordFreqs: [220.00, 277.18, 329.63, 415.30],
      primaryColorValue: 0xFF4EA8DE,
      secondaryColorValue: 0xFF14213D,
      qualityBadge: 'Hi-Res',
      isVip: false,
      likesCount: 67800,
      commentsCount: 3560,
      sharesCount: 1410,
      lrc: '[00:00.00]唱针轻轻触碰旋转的纹路|Stylus softly meets the spinning groove\n'
          '[00:04.00]窗外细雨敲打安静的夜幕|Gentle rain taps against the quiet night\n'
          '[00:08.00]台灯圈出一小片温暖孤岛|Desk lamp circles a warm little island\n'
          '[00:12.00]思绪随着慢拍一点点舒展|Thoughts unwind along the unhurried beat\n'
          '[00:16.00]愿今夜好梦如海浪轻拂|May sweet dreams drift in like soft waves',
    ),
  ];

  static final List<MusicPlaylist> playlists = [
    const MusicPlaylist(
      id: 'pl_daily',
      title: '每日 30 首 · 懂你想听',
      subtitle: '根据你的听歌口味实时调配专属气泡歌单',
      tag: '私人定制',
      accentColorValue: 0xFF00F090,
      trackIds: ['trk_01', 'trk_02', 'trk_04', 'trk_06', 'trk_03', 'trk_08'],
      playCount: 328000,
    ),
    const MusicPlaylist(
      id: 'pl_neon',
      title: '夜间驾驶 · 高架桥合成波',
      subtitle: '适合兜风与夜跑的复古未来主义电子律动',
      tag: '电音潮流',
      accentColorValue: 0xFF7C5CFF,
      trackIds: ['trk_02', 'trk_05', 'trk_01'],
      playCount: 194000,
    ),
    const MusicPlaylist(
      id: 'pl_guofeng',
      title: '新国风 · 山河入梦来',
      subtitle: '丝竹管弦碰撞现代电子编曲的东方美学',
      tag: '国风精选',
      accentColorValue: 0xFF2EC4B6,
      trackIds: ['trk_03', 'trk_07', 'trk_06'],
      playCount: 256000,
    ),
    const MusicPlaylist(
      id: 'pl_sleep',
      title: '零点助眠 · 温柔白噪音与慢歌',
      subtitle: '关掉焦虑，把耳机交给夜晚与晚风',
      tag: '深夜电台',
      accentColorValue: 0xFFFF6B8B,
      trackIds: ['trk_04', 'trk_08', 'trk_06', 'trk_01'],
      playCount: 412000,
    ),
  ];

  static final List<MusicPlaylist> charts = [
    const MusicPlaylist(
      id: 'chart_hot',
      title: '汽水热歌榜',
      subtitle: '全站实时热度飙升 TOP 单曲',
      tag: '每小时更新',
      accentColorValue: 0xFFFF4D6D,
      trackIds: ['trk_02', 'trk_07', 'trk_04', 'trk_08', 'trk_03', 'trk_01'],
      playCount: 980000,
    ),
    const MusicPlaylist(
      id: 'chart_viral',
      title: '潮流发现榜',
      subtitle: '短视频高赞 BGM 与独立音乐人新作',
      tag: '每日更新',
      accentColorValue: 0xFF00F090,
      trackIds: ['trk_01', 'trk_05', 'trk_03', 'trk_06'],
      playCount: 645000,
    ),
    const MusicPlaylist(
      id: 'chart_indie',
      title: '原创星光榜',
      subtitle: '新锐唱作人与 AI 共创先锋作品',
      tag: '每周更新',
      accentColorValue: 0xFF7C5CFF,
      trackIds: ['trk_06', 'trk_04', 'trk_08', 'trk_05'],
      playCount: 310000,
    ),
  ];

  static final Map<String, List<TrackComment>> initialComments = {
    'trk_01': [
      const TrackComment(
        id: 'c_101',
        trackId: 'trk_01',
        author: '海盐气泡水',
        content: '前奏一响瞬间回到夏天的海边公路，晚风和冰汽水全都齐了！',
        likedCount: 2340,
        timeLabel: '12分钟前',
        atSecond: 2,
      ),
      const TrackComment(
        id: 'c_102',
        trackId: 'trk_01',
        author: '耳机分你一半',
        content: '开了汽水电音音效之后低频太舒服了，单曲循环第三十遍。',
        likedCount: 892,
        timeLabel: '1小时前',
        atSecond: 8,
      ),
    ],
    'trk_02': [
      const TrackComment(
        id: 'c_201',
        trackId: 'trk_02',
        author: '夜航飞行员',
        content: '凌晨下班开车走内环高架必听，合成器氛围感拉满。',
        likedCount: 4150,
        timeLabel: '25分钟前',
        atSecond: 4,
      ),
    ],
  };

  static const List<DspPreset> fallbackDspPresets = [
    DspPreset(
      id: 'flat',
      name: '原声直通',
      subtitle: '无染色零增益参考监听',
      mpvFilter: '',
      bands: [0.0, 0.0, 0.0, 0.0, 0.0],
    ),
    DspPreset(
      id: 'soda_edm',
      name: '汽水电音',
      subtitle: '瞬态低频下潜与高频空气感增强',
      mpvFilter: 'lavfi=[bass=g=6:f=95,treble=g=4:f=9000]',
      bands: [6.0, 2.5, -1.0, 2.0, 4.5],
    ),
    DspPreset(
      id: 'vocal_clear',
      name: '清澈人声',
      subtitle: '突出中频细节与近场呼吸感',
      mpvFilter: 'lavfi=[equalizer=f=2400:t=q:w=1.2:g=4.5]',
      bands: [-1.5, 1.0, 4.5, 3.0, 1.0],
    ),
    DspPreset(
      id: 'vinyl_warm',
      name: '黑胶暖声',
      subtitle: '模拟温暖中低频谐波与柔和滚降',
      mpvFilter: 'lavfi=[bass=g=3.5:f=140,treble=g=-2.0:f=10000]',
      bands: [3.5, 3.0, 1.0, -1.0, -2.5],
    ),
    DspPreset(
      id: 'spatial_club',
      name: '全景环绕',
      subtitle: '立体声场扩展与空间混响包裹',
      mpvFilter: 'lavfi=[extrastereo=m=1.65]',
      bands: [3.0, 1.5, 0.5, 2.5, 3.5],
    ),
  ];
}
