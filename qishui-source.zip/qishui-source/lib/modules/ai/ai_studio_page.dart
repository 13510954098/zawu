import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/network/demo_catalog.dart';
import '../../core/state/luna_app_state.dart';

class AiStudioPage extends StatefulWidget {
  final LunaAppState state;
  final VoidCallback onJumpToFeed;

  const AiStudioPage({
    super.key,
    required this.state,
    required this.onJumpToFeed,
  });

  @override
  State<AiStudioPage> createState() => _AiStudioPageState();
}

class _AiStudioPageState extends State<AiStudioPage> {
  final TextEditingController _promptCtrl = TextEditingController(text: '海边日落汽水气泡合成波');
  final TextEditingController _chatCtrl = TextEditingController();
  String _mood = '抖音热歌';
  double _bpm = 118;
  bool _creating = false;

  @override
  void dispose() {
    _promptCtrl.dispose();
    _chatCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.state;
    return DefaultTabController(
      length: 2,
      child: SafeArea(
        child: Column(
          children: [
            const TabBar(
              indicatorColor: LunaTheme.neonMint,
              labelColor: LunaTheme.neonMint,
              tabs: [
                Tab(text: 'AI 灵感成曲'),
                Tab(text: 'AI 找歌对话'),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  _buildComposerTab(context, st),
                  _buildAssistantTab(context, st),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildComposerTab(BuildContext context, LunaAppState st) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: LunaTheme.cardBg,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('输入画面或歌词意象合成新曲', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(
                controller: _promptCtrl,
                maxLines: 2,
                decoration: const InputDecoration(
                  hintText: '例如：雨夜霓虹街角、轻快复古鼓点...',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 14),
              const Text('曲风声场', style: TextStyle(fontSize: 13, color: Colors.white70)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: DemoCatalog.moodScenes.skip(1).map((m) {
                  return ChoiceChip(
                    label: Text(m),
                    selected: _mood == m,
                    onSelected: (_) => setState(() => _mood = m),
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              Text('目标律动速度: ${_bpm.round()} BPM', style: const TextStyle(fontSize: 13, color: Colors.white70)),
              Slider(
                value: _bpm,
                min: 72,
                max: 150,
                onChanged: (v) => setState(() => _bpm = v),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _creating
                      ? null
                      : () async {
                          setState(() => _creating = true);
                          final created = await st.composeWithAi(
                            prompt: _promptCtrl.text,
                            mood: _mood,
                            bpm: _bpm.round(),
                          );
                          if (mounted) {
                            setState(() => _creating = false);
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('已生成并切入播放：《${created.title}》')),
                            );
                            widget.onJumpToFeed();
                          }
                        },
                  icon: const Icon(Icons.auto_awesome),
                  label: Text(_creating ? '正在合成多轨波形...' : '立即合成并试听'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAssistantTab(BuildContext context, LunaAppState st) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: st.aiMessages.length,
            itemBuilder: (_, i) {
              final item = st.aiMessages[i];
              return Align(
                alignment: item.isUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(12),
                  constraints: const BoxConstraints(maxWidth: 320),
                  decoration: BoxDecoration(
                    color: item.isUser
                        ? LunaTheme.neonMint.withValues(alpha: 0.22)
                        : LunaTheme.cardBg,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.text),
                      if (item.recommendedTracks.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        ...item.recommendedTracks.map(
                          (trk) => Material(
                            color: Colors.transparent,
                            child: ListTile(
                              contentPadding: EdgeInsets.zero,
                              dense: true,
                              leading: const Icon(Icons.play_circle_outline, color: LunaTheme.neonMint),
                              title: Text(trk.title),
                              subtitle: Text('${trk.artist} · ${trk.moodScene}'),
                              onTap: () async {
                                final idx = st.feedTracks.indexWhere((e) => e.id == trk.id);
                                if (idx >= 0) {
                                  await st.selectTrackIndex(idx, autoPlay: true);
                                  widget.onJumpToFeed();
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatCtrl,
                  decoration: InputDecoration(
                    hintText: '问问 AI：适合夜跑或写代码的歌...',
                    filled: true,
                    fillColor: LunaTheme.cardBg,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: () {
                  final text = _chatCtrl.text;
                  _chatCtrl.clear();
                  st.askAiAssistant(text);
                },
                icon: const Icon(Icons.send_rounded),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
