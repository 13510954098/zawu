import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/state/luna_app_state.dart';
import '../ai/ai_studio_page.dart';
import '../explore/explore_page.dart';
import '../feed/feed_play_page.dart';
import '../guard/protocol_guard_page.dart';
import '../profile/profile_page.dart';

class MainShellPage extends StatefulWidget {
  final LunaAppState state;

  const MainShellPage({super.key, required this.state});

  @override
  State<MainShellPage> createState() => _MainShellPageState();
}

class _MainShellPageState extends State<MainShellPage> {
  int _tabIndex = 0;

  void _openGuardPage() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ListenableBuilder(
          listenable: widget.state,
          builder: (_, __) => ProtocolGuardPage(state: widget.state),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.state,
      builder: (context, _) {
        final st = widget.state;
        final cur = st.currentTrack;
        final activeLine = cur.lyrics.isNotEmpty ? cur.lyrics[st.activeLyricIndex].text : cur.title;

        final pages = [
          FeedPlayPage(state: st, onOpenGuardPage: _openGuardPage),
          ExplorePage(state: st, onJumpToFeed: () => setState(() => _tabIndex = 0)),
          AiStudioPage(state: st, onJumpToFeed: () => setState(() => _tabIndex = 0)),
          ProtocolGuardPage(state: st),
          ProfilePage(
            state: st,
            onOpenGuardPage: () => setState(() => _tabIndex = 3),
            onJumpToFeed: () => setState(() => _tabIndex = 0),
          ),
        ];

        return Scaffold(
          body: Column(
            children: [
              if (st.showFloatingDesktopLyric && _tabIndex != 0)
                SafeArea(
                  bottom: false,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    color: const Color(0xFF10281C),
                    child: Text(
                      '♪ $activeLine',
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: LunaTheme.neonMint, fontSize: 13),
                    ),
                  ),
                ),
              Expanded(child: pages[_tabIndex]),
              if (_tabIndex != 0)
                GestureDetector(
                  onTap: () => setState(() => _tabIndex = 0),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF181D27),
                      border: Border(top: BorderSide(color: Colors.white10)),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: Color(cur.colorPrimary),
                          child: const Icon(Icons.music_note, size: 18, color: Colors.white),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(cur.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                              Text(activeLine, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.white60)),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: st.togglePlay,
                          icon: Icon(
                            st.player.isPlaying ? Icons.pause_circle_filled : Icons.play_circle_fill,
                            color: LunaTheme.neonMint,
                            size: 32,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tabIndex,
            backgroundColor: const Color(0xFF0E1117),
            indicatorColor: LunaTheme.neonMint.withValues(alpha: 0.22),
            onDestinationSelected: (i) => setState(() => _tabIndex = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.album_outlined), selectedIcon: Icon(Icons.album), label: '音乐'),
              NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: '发现'),
              NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'AI创作'),
              NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield), label: '流控'),
              NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: '我的'),
            ],
          ),
        );
      },
    );
  }
}
