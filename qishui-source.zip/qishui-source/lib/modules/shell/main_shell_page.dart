import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/theme/soda_theme.dart';
import '../ai_studio/ai_studio_tab.dart';
import '../explore/explore_tab.dart';
import '../feed/feed_play_tab.dart';
import '../profile/profile_tab.dart';

class MainShellPage extends StatefulWidget {
  const MainShellPage({super.key});

  @override
  State<MainShellPage> createState() => _MainShellPageState();
}

class _MainShellPageState extends State<MainShellPage> {
  final BachPlayerController player = Get.find<BachPlayerController>();
  int _tabIndex = 0;

  final List<Widget> _tabs = const [
    FeedPlayTab(),
    ExploreTab(),
    AiStudioTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          IndexedStack(index: _tabIndex, children: _tabs),
          Obx(() {
            if (!player.showFloatingLyrics.value || _tabIndex == 0) {
              return const SizedBox.shrink();
            }
            final lyrics = player.currentTrack.parsedLyrics;
            final idx = player.currentLyricIndex;
            final line = lyrics.isEmpty
                ? player.currentTrack.title
                : lyrics[idx.clamp(0, lyrics.length - 1)].text;
            return Positioned(
              top: MediaQuery.of(context).padding.top + 6,
              left: 24,
              right: 24,
              child: IgnorePointer(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.72),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: SodaPalette.accent.withValues(alpha: 0.45)),
                  ),
                  child: Text(
                    line,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: SodaPalette.accent,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            );
          }),
          if (_tabIndex != 0)
            Positioned(
              left: 12,
              right: 12,
              bottom: 10,
              child: _MiniDockPlayer(
                player: player,
                onTapExpand: () => setState(() => _tabIndex = 0),
              ),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        height: 64,
        backgroundColor: SodaPalette.bgElevated,
        indicatorColor: SodaPalette.accent.withValues(alpha: 0.2),
        selectedIndex: _tabIndex,
        onDestinationSelected: (idx) => setState(() => _tabIndex = idx),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.bolt_outlined),
            selectedIcon: Icon(Icons.bolt_rounded, color: SodaPalette.accent),
            label: '听歌',
          ),
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore_rounded, color: SodaPalette.accent),
            label: '发现',
          ),
          NavigationDestination(
            icon: Icon(Icons.auto_awesome_outlined),
            selectedIcon: Icon(Icons.auto_awesome_rounded, color: SodaPalette.accent),
            label: 'AI创作',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded, color: SodaPalette.accent),
            label: '我的',
          ),
        ],
      ),
    );
  }
}

class _MiniDockPlayer extends StatelessWidget {
  final BachPlayerController player;
  final VoidCallback onTapExpand;

  const _MiniDockPlayer({
    required this.player,
    required this.onTapExpand,
  });

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final track = player.currentTrack;
      return GestureDetector(
        onTap: onTapExpand,
        child: Container(
          height: 58,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: SodaPalette.bgCard.withValues(alpha: 0.96),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: Colors.white12),
            boxShadow: const [
              BoxShadow(color: Colors.black54, blurRadius: 16, offset: Offset(0, 6)),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [track.primaryColor, track.secondaryColor],
                  ),
                ),
                child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
                    ),
                    Text(
                      track.artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: SodaPalette.textSecondary,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(
                  player.isPlaying.value ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: SodaPalette.accent,
                ),
                onPressed: player.togglePlayPause,
              ),
              IconButton(
                icon: const Icon(Icons.skip_next_rounded, size: 22),
                onPressed: player.nextTrack,
              ),
            ],
          ),
        ),
      );
    });
  }
}
