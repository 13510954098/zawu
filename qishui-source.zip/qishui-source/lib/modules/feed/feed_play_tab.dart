import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import '../../app/routes/app_routes.dart';
import '../../core/models/music_models.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';
import '../../widgets/lyric_stage.dart';
import '../../widgets/player_sheets.dart';
import '../../widgets/vinyl_disc_stage.dart';

class FeedPlayTab extends StatefulWidget {
  const FeedPlayTab({super.key});

  @override
  State<FeedPlayTab> createState() => _FeedPlayTabState();
}

class _FeedPlayTabState extends State<FeedPlayTab> {
  final BachPlayerController player = Get.find<BachPlayerController>();
  final LibraryController library = Get.find<LibraryController>();
  late final PageController _pageController;
  Worker? _indexWorker;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: player.currentIndex.value);
    _indexWorker = ever<int>(player.currentIndex, (idx) {
      if (!_pageController.hasClients) return;
      final currentPage = _pageController.page?.round() ?? 0;
      if (currentPage != idx && idx >= 0 && idx < player.queue.length) {
        _pageController.animateToPage(
          idx,
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  @override
  void dispose() {
    _indexWorker?.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final track = player.currentTrack;
      final queueLen = player.queue.length;
      return AnimatedContainer(
        duration: const Duration(milliseconds: 420),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              track.primaryColor.withValues(alpha: 0.42),
              track.secondaryColor.withValues(alpha: 0.55),
              SodaPalette.bgPrimary,
            ],
            stops: const [0.0, 0.48, 0.96],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              _buildTopChannelBar(context),
              Expanded(
                child: PageView.builder(
                  controller: _pageController,
                  scrollDirection: Axis.vertical,
                  itemCount: queueLen == 0 ? 1 : queueLen,
                  onPageChanged: (idx) {
                    if (idx != player.currentIndex.value) {
                      player.selectIndex(idx, autoPlay: true);
                    }
                  },
                  itemBuilder: (context, idx) {
                    final pageTrack = queueLen == 0 ? track : player.queue[idx];
                    return _buildVerticalTrackPage(context, pageTrack);
                  },
                ),
              ),
              _buildBottomTransport(context, track),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildTopChannelBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 4),
      child: Row(
        children: [
          IconButton(
            tooltip: '车载模式',
            icon: const Icon(Icons.directions_car_filled_rounded, size: 22),
            onPressed: () => Get.toNamed(AppRoutes.carMode),
          ),
          Expanded(
            child: SizedBox(
              height: 36,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: MockCatalog.channels.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (_, idx) {
                  final ch = MockCatalog.channels[idx];
                  return Obx(() {
                    final active = player.activeChannel.value == ch;
                    return GestureDetector(
                      onTap: () => player.loadChannel(ch, autoPlay: true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: active
                              ? Colors.white.withValues(alpha: 0.18)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Center(
                          child: Text(
                            ch,
                            style: TextStyle(
                              color: active ? Colors.white : Colors.white60,
                              fontSize: active ? 15 : 13.5,
                              fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    );
                  });
                },
              ),
            ),
          ),
          IconButton(
            tooltip: '搜索歌曲',
            icon: const Icon(Icons.search_rounded, size: 24),
            onPressed: () => Get.toNamed(AppRoutes.search),
          ),
        ],
      ),
    );
  }

  Widget _buildVerticalTrackPage(BuildContext context, MusicTrack pageTrack) {
    return Obx(() {
      final isCurrent = pageTrack.id == player.currentTrack.id;
      final mode = player.stageMode.value;
      final liked = library.isLiked(pageTrack.id);
      final lyrics = pageTrack.parsedLyrics;
      final activeLine = isCurrent ? player.currentLyricIndex : 0;

      return Stack(
        children: [
          Positioned.fill(
            bottom: 112,
            right: 64,
            child: mode == StageVisualMode.lyrics
                ? LyricStage(
                    lines: lyrics,
                    activeIndex: activeLine,
                    onSeekLine: player.seekTo,
                    onCollapse: player.cycleStageMode,
                  )
                : VinylDiscStage(
                    track: pageTrack,
                    isPlaying: isCurrent && player.isPlaying.value,
                    coverMode: mode == StageVisualMode.cover,
                    onTapStage: player.cycleStageMode,
                  ),
          ),
          Positioned(
            right: 12,
            bottom: 24,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _ActionRailItem(
                  icon: liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  iconColor: liked ? SodaPalette.danger : Colors.white,
                  label: SodaTheme.formatCount(
                    pageTrack.likesCount + (liked ? 1 : 0),
                  ),
                  onTap: () => library.toggleLike(pageTrack),
                ),
                const SizedBox(height: 16),
                _ActionRailItem(
                  icon: Icons.chat_bubble_outline_rounded,
                  label: SodaTheme.formatCount(pageTrack.commentsCount),
                  onTap: () => showTrackCommentsSheet(context, player, library),
                ),
                const SizedBox(height: 16),
                _ActionRailItem(
                  icon: Icons.headphones_rounded,
                  label: '一起听',
                  onTap: () => Get.toNamed(AppRoutes.listenRoom),
                ),
                const SizedBox(height: 16),
                _ActionRailItem(
                  icon: Icons.download_for_offline_outlined,
                  label: '缓存',
                  onTap: () async {
                    await library.cacheTrackOffline(pageTrack);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('已离线缓存《${pageTrack.title}》')),
                      );
                    }
                  },
                ),
                const SizedBox(height: 16),
                _ActionRailItem(
                  icon: Icons.share_outlined,
                  label: SodaTheme.formatCount(pageTrack.sharesCount),
                  onTap: () {
                    Share.share('正在听《${pageTrack.title}》- ${pageTrack.artist}');
                  },
                ),
              ],
            ),
          ),
          Positioned(
            left: 20,
            right: 78,
            bottom: 14,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () => showDspAndQualitySheet(context, player),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: SodaPalette.accent.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: SodaPalette.accent.withValues(alpha: 0.5),
                          ),
                        ),
                        child: Text(
                          player.selectedQuality.value,
                          style: const TextStyle(
                            color: SodaPalette.accent,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => showDspAndQualitySheet(context, player),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '音效 · ${player.activePreset.value.name}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    if (pageTrack.isVip)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: SodaPalette.gold.withValues(alpha: 0.22),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          'VIP 畅听',
                          style: TextStyle(
                            color: SodaPalette.gold,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  pageTrack.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${pageTrack.artist} · ${pageTrack.album}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13.5,
                    color: Colors.white70,
                  ),
                ),
                if (lyrics.isNotEmpty && mode != StageVisualMode.lyrics) ...[
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () => player.stageMode.value = StageVisualMode.lyrics,
                    child: Text(
                      lyrics[activeLine.clamp(0, lyrics.length - 1)].text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: SodaPalette.accent,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      );
    });
  }

  Widget _buildBottomTransport(BuildContext context, MusicTrack track) {
    return Obx(() {
      final posMs = player.position.value.inMilliseconds.toDouble();
      final durMs = player.duration.value.inMilliseconds.toDouble().clamp(1000.0, 3600000.0);
      final modeIcon = switch (player.loopMode.value) {
        LoopPlayMode.sequence => Icons.repeat_rounded,
        LoopPlayMode.single => Icons.repeat_one_rounded,
        LoopPlayMode.shuffle => Icons.shuffle_rounded,
      };

      return Padding(
        padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Text(
                  SodaTheme.formatDuration(player.position.value),
                  style: const TextStyle(fontSize: 11, color: Colors.white60),
                ),
                Expanded(
                  child: Slider(
                    value: posMs.clamp(0.0, durMs),
                    min: 0.0,
                    max: durMs,
                    onChanged: (v) => player.seekTo(Duration(milliseconds: v.round())),
                  ),
                ),
                Text(
                  SodaTheme.formatDuration(player.duration.value),
                  style: const TextStyle(fontSize: 11, color: Colors.white60),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(
                  icon: Icon(modeIcon, color: Colors.white70),
                  onPressed: player.cycleLoopMode,
                ),
                IconButton(
                  icon: const Icon(Icons.skip_previous_rounded, size: 32),
                  onPressed: player.previousTrack,
                ),
                GestureDetector(
                  onTap: player.togglePlayPause,
                  child: Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: SodaPalette.accent,
                      boxShadow: [
                        BoxShadow(
                          color: SodaPalette.accent.withValues(alpha: 0.35),
                          blurRadius: 18,
                        ),
                      ],
                    ),
                    child: Icon(
                      player.isPlaying.value
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      color: Colors.black,
                      size: 34,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.skip_next_rounded, size: 32),
                  onPressed: player.nextTrack,
                ),
                IconButton(
                  icon: const Icon(Icons.queue_music_rounded, color: Colors.white70),
                  onPressed: () => showPlayQueueSheet(context, player, library),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }
}

class _ActionRailItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final VoidCallback onTap;

  const _ActionRailItem({
    required this.icon,
    this.iconColor = Colors.white,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withValues(alpha: 0.28),
            ),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
