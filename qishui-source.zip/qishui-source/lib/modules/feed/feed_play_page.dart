import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/models/luna_models.dart';
import '../../core/state/luna_app_state.dart';

class FeedPlayPage extends StatefulWidget {
  final LunaAppState state;
  final VoidCallback onOpenGuardPage;

  const FeedPlayPage({
    super.key,
    required this.state,
    required this.onOpenGuardPage,
  });

  @override
  State<FeedPlayPage> createState() => _FeedPlayPageState();
}

class _FeedPlayPageState extends State<FeedPlayPage> with SingleTickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _discSpinController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: widget.state.currentIndex);
    _discSpinController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _discSpinController.dispose();
    super.dispose();
  }

  String _fmtMs(int ms) {
    final totalSec = (ms ~/ 1000).clamp(0, 3599);
    final m = (totalSec ~/ 60).toString().padLeft(2, '0');
    final s = (totalSec % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.state;
    final tracks = st.feedTracks;

    return Stack(
      children: [
        PageView.builder(
          controller: _pageController,
          scrollDirection: Axis.vertical,
          itemCount: tracks.length,
          onPageChanged: (idx) {
            st.selectTrackIndex(idx, autoPlay: true);
          },
          itemBuilder: (context, idx) {
            final track = tracks[idx];
            final vipLocked = track.vipOnly && !st.hasVipOrRewardedAccess;
            return Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: track.gradientColors,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildShadowBadgeRow(st, track),
                      const Spacer(),
                      GestureDetector(
                        onTap: st.toggleLyricsMode,
                        child: st.showLyricsOverlay
                            ? _buildFullLyricsCard(st, track)
                            : _buildRotatingVinyl(st, track),
                      ),
                      const Spacer(),
                      if (vipLocked) _buildVipIncentiveBanner(context, st),
                      const SizedBox(height: 10),
                      _buildTrackMetaAndActions(context, st, track),
                      const SizedBox(height: 10),
                      _buildProgressAndTransport(context, st, track),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: DemoCatalogMoodChips.build(st, _pageController),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildShadowBadgeRow(LunaAppState st, LunaTrack track) {
    final shadowId = st.player.shadowPrebufferedTrackId ?? 'none';
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.32),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '${track.moodScene} · ${track.bpm} BPM · 预载:$shadowId',
            style: const TextStyle(fontSize: 11, color: Colors.white70),
          ),
        ),
        const Spacer(),
        InkWell(
          onTap: widget.onOpenGuardPage,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: LunaTheme.neonMint.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: LunaTheme.neonMint.withValues(alpha: 0.5)),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.shield_outlined, size: 13, color: LunaTheme.neonMint),
                SizedBox(width: 4),
                Text('流控页', style: TextStyle(fontSize: 11, color: LunaTheme.neonMint)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRotatingVinyl(LunaAppState st, LunaTrack track) {
    final activeIdx = st.activeLyricIndex;
    final currentLine = track.lyrics.isNotEmpty ? track.lyrics[activeIdx].text : '';

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedBuilder(
          animation: _discSpinController,
          builder: (context, child) {
            final angle = st.player.isPlaying ? _discSpinController.value * 2 * math.pi : 0.0;
            return Transform.rotate(angle: angle, child: child);
          },
          child: Container(
            width: 230,
            height: 230,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [Color(0xFF2B303C), Color(0xFF101218), Color(0xFF050608)],
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(track.colorPrimary).withValues(alpha: 0.36),
                  blurRadius: 36,
                  spreadRadius: 4,
                ),
              ],
              border: Border.all(color: Colors.white24, width: 2),
            ),
            child: Center(
              child: Container(
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(track.colorPrimary), Color(track.colorSecondary)],
                  ),
                ),
                child: const Icon(Icons.music_note_rounded, size: 42, color: Colors.white),
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Text(
          currentLine,
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          '轻触封面切换全屏歌词',
          style: TextStyle(fontSize: 11, color: Colors.white54),
        ),
      ],
    );
  }

  Widget _buildFullLyricsCard(LunaAppState st, LunaTrack track) {
    final activeIdx = st.activeLyricIndex;
    return Container(
      height: 280,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.28),
        borderRadius: BorderRadius.circular(20),
      ),
      child: ListView.builder(
        itemCount: track.lyrics.length,
        itemBuilder: (context, i) {
          final ln = track.lyrics[i];
          final active = i == activeIdx;
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ln.text,
                  style: TextStyle(
                    fontSize: active ? 18 : 14,
                    fontWeight: active ? FontWeight.bold : FontWeight.normal,
                    color: active ? LunaTheme.neonMint : Colors.white60,
                  ),
                ),
                if (ln.translation.isNotEmpty)
                  Text(
                    ln.translation,
                    style: TextStyle(
                      fontSize: 11,
                      color: active ? Colors.white70 : Colors.white38,
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildVipIncentiveBanner(BuildContext context, LunaAppState st) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF261E0F).withValues(alpha: 0.90),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFCA28).withValues(alpha: 0.6)),
      ),
      child: Row(
        children: [
          const Icon(Icons.workspace_premium, size: 18, color: Color(0xFFFFCA28)),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'VIP 臻享曲目 · 完成激励任务领 30 分钟免费畅听',
              style: TextStyle(fontSize: 12, color: Color(0xFFFFECB3)),
            ),
          ),
          TextButton(
            onPressed: () => st.claimRewardedListenMinutes(minutes: 30),
            child: const Text('立即领取', style: TextStyle(color: LunaTheme.neonMint)),
          ),
        ],
      ),
    );
  }

  Widget _buildTrackMetaAndActions(BuildContext context, LunaAppState st, LunaTrack track) {
    final liked = st.isLiked(track.id);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                track.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                '${track.artist} · ${track.album}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, color: Colors.white70),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                children: [
                  _actionChip(
                    icon: Icons.graphic_eq,
                    label: st.effectPreset.label,
                    onTap: () => _showEffectSheet(context, st),
                  ),
                  _actionChip(
                    icon: Icons.high_quality_outlined,
                    label: st.selectedQuality,
                    onTap: () => _showQualitySheet(context, st, track),
                  ),
                  _actionChip(
                    icon: Icons.people_alt_outlined,
                    label: st.togetherRoom == null ? '一起听' : '房间中',
                    onTap: () => _showTogetherSheet(context, st),
                  ),
                ],
              ),
            ],
          ),
        ),
        Column(
          children: [
            IconButton(
              onPressed: () => st.toggleLikeCurrent(track.id),
              icon: Icon(
                liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: liked ? const Color(0xFFFF4081) : Colors.white,
                size: 30,
              ),
            ),
            Text(
              '${track.likeCount + (liked ? 1 : 0)}',
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            ),
            const SizedBox(height: 6),
            IconButton(
              onPressed: () => _showCommentsSheet(context, st, track),
              icon: const Icon(Icons.mode_comment_outlined, color: Colors.white, size: 26),
            ),
            Text(
              '${track.commentCount}',
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            ),
            const SizedBox(height: 6),
            IconButton(
              onPressed: () async {
                await st.cacheTrackOffline(track);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('已缓存《${track.title}》(${st.selectedQuality})')),
                  );
                }
              },
              icon: const Icon(Icons.download_for_offline_outlined, color: Colors.white, size: 26),
            ),
          ],
        ),
      ],
    );
  }

  Widget _actionChip({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.14),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 13, color: LunaTheme.neonMint),
            const SizedBox(width: 4),
            Text(label, style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressAndTransport(BuildContext context, LunaAppState st, LunaTrack track) {
    final pos = st.player.positionMs.clamp(0, track.durationMs);
    final maxDur = math.max(1, track.durationMs);
    IconData loopIcon;
    switch (st.loopMode) {
      case PlayLoopMode.sequence:
        loopIcon = Icons.repeat_rounded;
        break;
      case PlayLoopMode.single:
        loopIcon = Icons.repeat_one_rounded;
        break;
      case PlayLoopMode.shuffle:
        loopIcon = Icons.shuffle_rounded;
        break;
    }

    return Column(
      children: [
        Slider(
          value: pos.toDouble(),
          min: 0,
          max: maxDur.toDouble(),
          onChanged: (v) => st.seekToMs(v.round()),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_fmtMs(pos), style: const TextStyle(fontSize: 11, color: Colors.white60)),
              Text(_fmtMs(maxDur), style: const TextStyle(fontSize: 11, color: Colors.white60)),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            IconButton(
              onPressed: st.cycleLoopMode,
              icon: Icon(loopIcon, color: Colors.white70),
            ),
            IconButton(
              onPressed: () {
                final prev = (st.currentIndex - 1 + st.feedTracks.length) % st.feedTracks.length;
                _pageController.jumpToPage(prev);
                st.selectTrackIndex(prev, autoPlay: true);
              },
              icon: const Icon(Icons.skip_previous_rounded, size: 34),
            ),
            GestureDetector(
              onTap: st.togglePlay,
              child: Container(
                width: 60,
                height: 60,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: LunaTheme.neonMint,
                ),
                child: Icon(
                  st.player.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: const Color(0xFF061B0E),
                  size: 36,
                ),
              ),
            ),
            IconButton(
              onPressed: () {
                final next = (st.currentIndex + 1) % st.feedTracks.length;
                _pageController.jumpToPage(next);
                st.selectTrackIndex(next, autoPlay: true);
              },
              icon: const Icon(Icons.skip_next_rounded, size: 34),
            ),
            IconButton(
              onPressed: st.toggleLyricsMode,
              icon: Icon(
                Icons.lyrics_outlined,
                color: st.showLyricsOverlay ? LunaTheme.neonMint : Colors.white70,
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showEffectSheet(BuildContext context, LunaAppState st) {
    showModalBottomSheet(
      context: context,
      backgroundColor: LunaTheme.cardBg,
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('声学滤镜与空间音效', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: AudioEffectPreset.values.map((preset) {
                  final selected = st.effectPreset == preset;
                  return ChoiceChip(
                    label: Text(preset.label),
                    selected: selected,
                    selectedColor: LunaTheme.neonMint.withValues(alpha: 0.28),
                    onSelected: (_) {
                      st.setAudioEffect(preset);
                      Navigator.pop(ctx);
                    },
                  );
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showQualitySheet(BuildContext context, LunaAppState st, LunaTrack track) {
    showModalBottomSheet(
      context: context,
      backgroundColor: LunaTheme.cardBg,
      builder: (ctx) {
        return Material(
          color: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('音质流策略选择', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...track.qualities.map(
                  (q) => ListTile(
                    title: Text(q),
                    trailing: st.selectedQuality == q
                        ? const Icon(Icons.check_circle, color: LunaTheme.neonMint)
                        : null,
                    onTap: () {
                      st.setQuality(q);
                      Navigator.pop(ctx);
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showCommentsSheet(BuildContext context, LunaAppState st, LunaTrack track) {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: LunaTheme.cardBg,
      builder: (ctx) {
        return Material(
          color: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
            ),
            child: SizedBox(
              height: 360,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('乐评区 (${track.commentCount})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      itemCount: track.comments.length,
                      itemBuilder: (_, i) {
                        final c = track.comments[i];
                        return ListTile(
                          dense: true,
                          title: Text('${c.author} · ${c.timeLabel}', style: const TextStyle(fontSize: 12, color: Colors.white60)),
                          subtitle: Text(c.content, style: const TextStyle(fontSize: 14, color: Colors.white)),
                          trailing: Text('♥ ${c.likes}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
                        );
                      },
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: ctrl,
                          decoration: const InputDecoration(hintText: '留下你的听歌心情...'),
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          st.addCommentToCurrent(ctrl.text);
                          Navigator.pop(ctx);
                        },
                        icon: const Icon(Icons.send_rounded, color: LunaTheme.neonMint),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showTogetherSheet(BuildContext context, LunaAppState st) {
    final msgCtrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: LunaTheme.cardBg,
      builder: (ctx) {
        final room = st.togetherRoom;
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('好友一起听房间', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  FilledButton.tonal(
                    onPressed: () {
                      st.startOrStopListenTogether();
                      Navigator.pop(ctx);
                    },
                    child: Text(room == null ? '创建房间' : '退出房间'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (room == null)
                const Text('开启后可与好友实时同步播放进度、切歌队列与闪聊弹幕。', style: TextStyle(color: Colors.white70))
              else ...[
                Text('房间号: ${room.roomId} · 在线: ${room.members.join("、")}', style: const TextStyle(fontSize: 12, color: LunaTheme.neonMint)),
                const SizedBox(height: 8),
                ...room.messages.take(4).map((m) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: Text(m, style: const TextStyle(fontSize: 13)),
                    )),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: msgCtrl,
                        decoration: const InputDecoration(hintText: '发送房间闪聊消息...'),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        st.sendTogetherFlashMessage(msgCtrl.text);
                        Navigator.pop(ctx);
                      },
                      icon: const Icon(Icons.send, color: LunaTheme.neonMint),
                    ),
                  ],
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}

class DemoCatalogMoodChips {
  static const List<String> _scenes = [
    '全部推荐',
    '抖音热歌',
    '深夜EMO',
    '工作专注',
    '国风新韵',
    '独立民谣',
    '运动燃脂',
  ];

  static List<Widget> build(LunaAppState st, PageController pageController) {
    return _scenes.map((m) {
      final active = st.selectedMood == m;
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(m, style: const TextStyle(fontSize: 12)),
          selected: active,
          selectedColor: LunaTheme.neonMint.withValues(alpha: 0.30),
          onSelected: (_) async {
            await st.changeMood(m);
            if (pageController.hasClients) {
              pageController.jumpToPage(0);
            }
          },
        ),
      );
    }).toList();
  }
}
