import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/security/cleanroom_guard_engine.dart';
import '../../core/state/luna_app_state.dart';

class ProtocolGuardPage extends StatelessWidget {
  final LunaAppState state;

  const ProtocolGuardPage({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final pkt = state.lastEnvelopePacket;
    final hdr = state.lastSignedHeaders;
    final ticket = state.activeTicket;

    return Scaffold(
      appBar: AppBar(
        title: const Text('自托管流加密 · 网关签名 · 权益状态页'),
        actions: [
          IconButton(
            onPressed: state.runLiveEnvelopeCheck,
            icon: const Icon(Icons.refresh_rounded, color: LunaTheme.neonMint),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionCard(
            title: '1. 音频分片 AES-128-CTR 流信封与完整性校验',
            badge: state.lastDecryptionVerified ? 'SHA-256 校验通过' : '待执行',
            children: [
              _kvRow('当前曲目 MediaID', pkt?.mediaId ?? state.currentTrack.id),
              _kvRow(
                '会话密钥 (128-bit)',
                pkt != null ? CleanRoomGuardEngine.hexEncode(pkt.sessionKey) : '-',
              ),
              _kvRow(
                'CTR Nonce (64-bit)',
                pkt != null ? CleanRoomGuardEngine.hexEncode(pkt.nonce) : '-',
              ),
              _kvRow('密文分片长度', '${pkt?.cipherBytes.length ?? 0} Bytes'),
              _kvRow('明文 SHA-256', pkt?.plainSha256 ?? '-'),
              const SizedBox(height: 10),
              FilledButton.tonalIcon(
                onPressed: state.runLiveEnvelopeCheck,
                icon: const Icon(Icons.enhanced_encryption_outlined),
                label: const Text('重新执行本地/服务端流分片封包与解包验签'),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _sectionCard(
            title: '2. 网关请求标准 HMAC-SHA256 签名头',
            badge: hdr != null &&
                    state.guard.verifyGatewayRequest(
                      method: 'GET',
                      path: '/luna/feed',
                      headers: hdr,
                      query: {'mood': state.selectedMood, 'quality': state.selectedQuality},
                    )
                ? '本地验签有效'
                : '动态更新',
            children: [
              _kvRow('X-Clean-Ts', hdr?.timestamp ?? '-'),
              _kvRow('X-Clean-Nonce', hdr?.nonce ?? '-'),
              _kvRow('X-Clean-Did', hdr?.deviceDigest ?? '-'),
              _kvRow('X-Clean-Sig', hdr?.signatureHex ?? '-'),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  hdr?.canonicalString ?? '',
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _sectionCard(
            title: '3. 激励畅听与会员权益凭证状态机 (HMAC Ledger)',
            badge: state.hasVipOrRewardedAccess ? '有效 (${state.remainingFreeMinutes}m)' : '未激活',
            children: [
              _kvRow('权益层级 Tier', ticket?.tier ?? 'FREE_STANDARD'),
              _kvRow('绑定用户 UID', ticket?.userId ?? 'luna_local_user_01'),
              _kvRow('剩余畅听分钟', '${state.remainingFreeMinutes} 分钟'),
              _kvRow('凭证签名摘要', ticket?.hmacHex ?? '-'),
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: () => state.claimRewardedListenMinutes(minutes: 30),
                icon: const Icon(Icons.verified_outlined),
                label: const Text('签发自托管 30 分钟激励畅听凭证'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required String title,
    required String badge,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: LunaTheme.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: LunaTheme.neonMint.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(badge, style: const TextStyle(fontSize: 11, color: LunaTheme.neonMint)),
              ),
            ],
          ),
          const Divider(height: 20, color: Colors.white12),
          ...children,
        ],
      ),
    );
  }

  Widget _kvRow(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 118,
            child: Text(k, style: const TextStyle(fontSize: 12, color: Colors.white60)),
          ),
          Expanded(
            child: SelectableText(
              v,
              style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }
}
