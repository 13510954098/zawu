import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/theme/soda_theme.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 450), () {
      if (mounted) {
        Get.offAllNamed(AppRoutes.shell);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SodaPalette.bgPrimary,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 78,
              height: 78,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [SodaPalette.accent, SodaPalette.accentSecondary],
                ),
                boxShadow: [
                  BoxShadow(
                    color: SodaPalette.accent.withValues(alpha: 0.35),
                    blurRadius: 28,
                  ),
                ],
              ),
              child: const Icon(Icons.music_note_rounded, color: Colors.black, size: 42),
            ),
            const SizedBox(height: 18),
            const Text(
              '汽水音乐',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 1.2),
            ),
            const SizedBox(height: 6),
            const Text(
              '随时随地 · 懂你想听',
              style: TextStyle(color: SodaPalette.textSecondary, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
