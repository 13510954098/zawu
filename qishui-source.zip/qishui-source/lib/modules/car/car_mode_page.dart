import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';

class CarModePage extends StatelessWidget {
  const CarModePage({super.key});

  @override
  Widget build(BuildContext context) {
    final player = Get.find<BachPlayerController>();
    final library = Get.find<LibraryController>();

    return Scaffold(
      backgroundColor: const Color(0xFF07090D),
      appBar: AppBar(
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.directions_car_filled_rounded, color: SodaPalette.accent),
            SizedBox(width: 8),
            Text('汽水车载行车模式', style: TextStyle(fontWeight: FontWeight.w900)),
          ],
        ),
      ),
      body: Obx(() {
        final track = player.currentTrack;
        final liked = library.isLiked(track.id);
        final lyrics = track.parsedLyrics;
        final activeLine = player.currentLyricIndex;
        final currentLyric = lyrics.isEmpty
            ? '专注驾驶，享受旅途音乐'
            : lyrics[activeLine.clamp(0, lyrics.length - 1)].text;

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(26),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(
                    colors: [
                      track.primaryColor.withValues(alpha: 0.35),
                      SodaPalette.bgCard,
                    ],
                  ),
                  border: Border.all(color: Colors.white12, width: 1.5),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${player.activeChannel.value} · ${player.selectedQuality.value}',
                      style: const TextStyle(
                        color: SodaPalette.accent,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      track.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      track.artist,
                      style: const TextStyle(fontSize: 18, color: Colors.white70),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      currentLyric,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 20,
                        color: SodaPalette.accent,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: _GiantCarButton(
                      icon: liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                      iconColor: liked ? SodaPalette.danger : Colors.white,
                      label: '红心收藏',
                      onTap: () => library.toggleLike(track),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _GiantCarButton(
                      icon: Icons.bolt_rounded,
                      iconColor: SodaPalette.accent,
                      label: '随心换台',
                      onTap: () => player.loadChannel('随心听', autoPlay: true),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: _GiantCarButton(
                      icon: Icons.skip_previous_rounded,
                      label: '上一首',
                      onTap: player.previousTrack,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    flex: 2,
                    child: _GiantCarButton(
                      icon: player.isPlaying.value
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      iconColor: Colors.black,
                      bgColor: SodaPalette.accent,
                      label: player.isPlaying.value ? '暂停' : '播放',
                      onTap: player.togglePlayPause,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _GiantCarButton(
                      icon: Icons.skip_next_rounded,
                      label: '下一首',
                      onTap: player.nextTrack,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      }),
    );
  }
}

class _GiantCarButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor;
  final Color? bgColor;
  final VoidCallback onTap;

  const _GiantCarButton({
    required this.icon,
    required this.label,
    this.iconColor = Colors.white,
    this.bgColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 96,
        decoration: BoxDecoration(
          color: bgColor ?? SodaPalette.bgCard,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor, size: 38),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: iconColor,
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
