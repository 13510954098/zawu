import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/state/luna_app_state.dart';

class ProfilePage extends StatelessWidget {
  final LunaAppState state;
  final VoidCallback onOpenGuardPage;
  final VoidCallback onJumpToFeed;

  const ProfilePage({
    super.key,
    required this.state,
    required this.onOpenGuardPage,
    required this.onJumpToFeed,
  });

  @override
  Widget build(BuildContext context) {
    final likedIds = state.store.likedTrackIds;
    final likedTracks = state.feedTracks.where((t) => likedIds.contains(t.id)).toList();
    final history = state.store.history;
    final downloads = state.store.downloads;

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 28,
                backgroundColor: LunaTheme.neonMint,
                child: Icon(Icons.headphones_rounded, color: Color(0xFF061B0E), size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('汽水乐迷 · CleanRoom', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    Text(
                      '多端同步游标 #${state.store.syncCursor} · 音质 ${state.selectedQuality}',
                      style: const TextStyle(fontSize: 12, color: Colors.white60),
                    ),
                  ],
                ),
              ),
              OutlinedButton.icon(
                onPressed: onOpenGuardPage,
                icon: const Icon(Icons.security_rounded, size: 16),
                label: const Text('流控与鉴权页'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF153626), Color(0xFF151922)],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: LunaTheme.neonMint.withValues(alpha: 0.35)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        state.hasVipOrRewardedAccess
                            ? '免费畅听权益生效中 · 剩余 ${state.remainingFreeMinutes} 分钟'
                            : '看激励任务领 30 分钟全曲库畅听',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        '支持无损音质、全景空间音效与离线缓存',
                        style: TextStyle(fontSize: 12, color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                FilledButton(
                  onPressed: () => state.claimRewardedListenMinutes(minutes: 30),
                  child: const Text('领取 30m'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: LunaTheme.cardBg,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Material(
              color: Colors.transparent,
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text('全局桌面悬浮歌词条'),
                    subtitle: const Text('在非播放页顶部常驻显示实时同步歌词'),
                    value: state.showFloatingDesktopLyric,
                    onChanged: (_) => state.toggleFloatingDesktopLyric(),
                  ),
                  ListTile(
                    leading: const Icon(Icons.bedtime_outlined, color: LunaTheme.neonMint),
                    title: const Text('睡眠定时关闭'),
                    trailing: Text(
                      state.sleepTimerMinutes == 0 ? '未开启' : '${state.sleepTimerMinutes} 分钟后',
                      style: const TextStyle(color: Colors.white70),
                    ),
                    onTap: () {
                      final next = state.sleepTimerMinutes == 0 ? 30 : 0;
                      state.setSleepTimer(next);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text('我喜欢的音乐 (${likedTracks.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...likedTracks.map((t) => _trackTile(
                title: t.title,
                subtitle: '${t.artist} · ${t.album}',
                onTap: () async {
                  final idx = state.feedTracks.indexWhere((e) => e.id == t.id);
                  if (idx >= 0) {
                    await state.selectTrackIndex(idx, autoPlay: true);
                    onJumpToFeed();
                  }
                },
              )),
          const SizedBox(height: 16),
          Text('本地离线缓存 (${downloads.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (downloads.isEmpty)
            const Text('暂无离线歌曲，可在播放页点击下载按钮缓存', style: TextStyle(fontSize: 12, color: Colors.white54))
          else
            ...downloads.map((d) => _trackTile(
                  title: d.title,
                  subtitle: '${d.artist} · ${d.quality} · SHA:${d.localHash}',
                  onTap: onJumpToFeed,
                )),
          const SizedBox(height: 16),
          Text('最近播放历史 (${history.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (history.isEmpty)
            const Text('上下滑动切歌后自动记录完播率历史', style: TextStyle(fontSize: 12, color: Colors.white54))
          else
            ...history.take(8).map((h) => _trackTile(
                  title: h.track.title,
                  subtitle: '${h.track.artist} · 完播率 ${(h.completionRate * 100).round()}%',
                  onTap: onJumpToFeed,
                )),
        ],
      ),
    );
  }

  Widget _trackTile({
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: LunaTheme.cardBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Material(
        color: Colors.transparent,
        child: ListTile(
          dense: true,
          leading: const Icon(Icons.library_music_outlined, color: LunaTheme.neonMint),
          title: Text(title),
          subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
          onTap: onTap,
        ),
      ),
    );
  }
}
