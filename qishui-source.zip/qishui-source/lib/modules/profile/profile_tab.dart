import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/models/music_models.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});

  @override
  Widget build(BuildContext context) {
    final library = Get.find<LibraryController>();
    final player = Get.find<BachPlayerController>();

    return SafeArea(
      child: Obx(() {
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 100),
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => Get.toNamed(AppRoutes.auth),
                  child: Container(
                    width: 64,
                    height: 64,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [SodaPalette.accent, SodaPalette.accentSecondary],
                      ),
                    ),
                    child: Center(
                      child: Text(
                        library.nickname.value.characters.first,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: GestureDetector(
                    onTap: () => Get.toNamed(AppRoutes.auth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          library.nickname.value,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          library.signature.value,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: SodaPalette.textSecondary,
                            fontSize: 12.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  tooltip: '系统与音源设置',
                  icon: const Icon(Icons.settings_outlined),
                  onPressed: () => Get.toNamed(AppRoutes.settings),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [
                    SodaPalette.gold.withValues(alpha: 0.22),
                    SodaPalette.bgCard,
                  ],
                ),
                border: Border.all(color: SodaPalette.gold.withValues(alpha: 0.35)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.workspace_premium_rounded, color: SodaPalette.gold, size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '全站无损畅听剩余 ${library.freeListenMinutes.value} 分钟',
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14.5,
                          ),
                        ),
                        const SizedBox(height: 3),
                        const Text(
                          '每日打卡可免费续领 Hi-Res 畅听时长',
                          style: TextStyle(color: SodaPalette.textSecondary, fontSize: 11.5),
                        ),
                      ],
                    ),
                  ),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: SodaPalette.gold,
                      foregroundColor: Colors.black,
                    ),
                    onPressed: () async {
                      await library.claimBonusListenMinutes(30);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已成功领取 +30 分钟畅听权益')),
                        );
                      }
                    },
                    child: const Text('领 30 分钟'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                _StatCard(
                  title: '我喜欢',
                  count: library.likedIds.length,
                  icon: Icons.favorite_rounded,
                  accent: SodaPalette.danger,
                  onTap: () => _openTrackListSheet(
                    context,
                    '我喜欢的音乐',
                    library.likedTrackObjects,
                    player,
                  ),
                ),
                const SizedBox(width: 10),
                _StatCard(
                  title: '最近播放',
                  count: library.historyTracks.length,
                  icon: Icons.history_rounded,
                  accent: SodaPalette.accent,
                  onTap: () => _openTrackListSheet(
                    context,
                    '最近播放记录',
                    library.historyTracks,
                    player,
                  ),
                ),
                const SizedBox(width: 10),
                _StatCard(
                  title: '离线下载',
                  count: library.downloadedTracks.length,
                  icon: Icons.download_done_rounded,
                  accent: SodaPalette.accentSecondary,
                  onTap: () => _openTrackListSheet(
                    context,
                    '本地离线音频',
                    library.downloadedTracks,
                    player,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '自建歌单',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                TextButton.icon(
                  onPressed: () => _showCreatePlaylistDialog(context, library),
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('新建'),
                ),
              ],
            ),
            Material(
              color: Colors.transparent,
              child: Column(
                children: library.userPlaylists.entries.map((entry) {
                  final tracks = entry.value
                      .map(
                        (id) => MockCatalog.tracks.firstWhere(
                          (t) => t.id == id,
                          orElse: () => MockCatalog.tracks.first,
                        ),
                      )
                      .toList();
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: SodaPalette.accent.withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.queue_music_rounded,
                          color: SodaPalette.accent,
                        ),
                      ),
                      title: Text(
                        entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: Text(
                        '${tracks.length} 首单曲',
                        style: const TextStyle(
                          color: SodaPalette.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => _openTrackListSheet(context, entry.key, tracks, player),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              '多端互联与特色体验',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            Material(
              color: Colors.transparent,
              child: Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(
                        Icons.directions_car_filled_rounded,
                        color: SodaPalette.accent,
                      ),
                      title: const Text('车载驾驶大屏模式'),
                      subtitle: const Text(
                        '超大触控热区与极简行车卡片视图',
                        style: TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => Get.toNamed(AppRoutes.carMode),
                    ),
                    const Divider(height: 1, color: Colors.white10),
                    ListTile(
                      leading: const Icon(
                        Icons.people_alt_rounded,
                        color: SodaPalette.accentSecondary,
                      ),
                      title: const Text('好友一起听电台房'),
                      subtitle: const Text(
                        '实时同步播放进度与房间互动留言',
                        style: TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: () => Get.toNamed(AppRoutes.listenRoom),
                    ),
                    const Divider(height: 1, color: Colors.white10),
                    SwitchListTile(
                      secondary: const Icon(Icons.subtitles_rounded, color: SodaPalette.gold),
                      title: const Text('全局桌面悬浮歌词条'),
                      subtitle: const Text(
                        '切到发现或个人页时保留顶部动态双语歌词',
                        style: TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                      ),
                      value: player.showFloatingLyrics.value,
                      onChanged: (v) => player.showFloatingLyrics.value = v,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  void _openTrackListSheet(
    BuildContext context,
    String title,
    List<MusicTrack> tracks,
    BachPlayerController player,
  ) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) {
        return SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '$title (${tracks.length})',
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                    if (tracks.isNotEmpty)
                      FilledButton.tonalIcon(
                        onPressed: () {
                          player.replaceQueueAndPlay(tracks, 0);
                          Navigator.of(ctx).pop();
                        },
                        icon: const Icon(Icons.play_arrow_rounded, size: 18),
                        label: const Text('全部播放'),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: tracks.isEmpty
                    ? const Center(
                        child: Text(
                          '列表暂无歌曲',
                          style: TextStyle(color: SodaPalette.textSecondary),
                        ),
                      )
                    : Material(
                        color: Colors.transparent,
                        child: ListView.builder(
                          itemCount: tracks.length,
                          itemBuilder: (_, idx) {
                            final item = tracks[idx];
                            return ListTile(
                              leading: Icon(Icons.music_note_rounded, color: item.primaryColor),
                              title: Text(item.title),
                              subtitle: Text(
                                '${item.artist} · ${item.album}',
                                style: const TextStyle(
                                  color: SodaPalette.textSecondary,
                                  fontSize: 12,
                                ),
                              ),
                              onTap: () {
                                player.replaceQueueAndPlay(tracks, idx);
                                Navigator.of(ctx).pop();
                              },
                            );
                          },
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showCreatePlaylistDialog(BuildContext context, LibraryController library) {
    final ctrl = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: SodaPalette.bgElevated,
          title: const Text('新建个人歌单'),
          content: TextField(
            controller: ctrl,
            autofocus: true,
            decoration: const InputDecoration(hintText: '输入歌单名称，如：夜跑能量站'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () {
                library.createPlaylist(ctrl.text);
                Navigator.of(ctx).pop();
              },
              child: const Text('创建'),
            ),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title;
  final int count;
  final IconData icon;
  final Color accent;
  final VoidCallback onTap;

  const _StatCard({
    required this.title,
    required this.count,
    required this.icon,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
          decoration: BoxDecoration(
            color: SodaPalette.bgCard,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            children: [
              Icon(icon, color: accent, size: 24),
              const SizedBox(height: 8),
              Text(
                '$count',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 2),
              Text(
                title,
                style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
