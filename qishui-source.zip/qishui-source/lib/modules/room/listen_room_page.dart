import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/music_models.dart';
import '../../core/network/api_service.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';

class ListenRoomPage extends StatefulWidget {
  const ListenRoomPage({super.key});

  @override
  State<ListenRoomPage> createState() => _ListenRoomPageState();
}

class _ListenRoomPageState extends State<ListenRoomPage> {
  final ApiService api = Get.find<ApiService>();
  final BachPlayerController player = Get.find<BachPlayerController>();
  final LibraryController library = Get.find<LibraryController>();
  final TextEditingController _msgCtrl = TextEditingController();

  ListenRoomState? _room;
  final List<ListenRoomMessage> _messages = [];

  @override
  void initState() {
    super.initState();
    _loadRoom();
  }

  Future<void> _loadRoom() async {
    final state = await api.fetchListenRoom(player.currentTrack.id);
    if (mounted) {
      setState(() {
        _room = state;
        _messages
          ..clear()
          ..addAll(state.messages);
      });
    }
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_room?.roomTitle ?? '好友一起听')),
      body: Column(
        children: [
          Obx(() {
            final track = player.currentTrack;
            return Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: LinearGradient(
                  colors: [
                    track.primaryColor.withValues(alpha: 0.3),
                    SodaPalette.bgCard,
                  ],
                ),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: track.primaryColor,
                    child: const Icon(Icons.surround_sound_rounded, color: Colors.white),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '房主 ${_room?.hostName ?? '星河漫游者'} · ${_room?.onlineCount ?? 3} 人在线同步听',
                          style: const TextStyle(color: SodaPalette.accent, fontSize: 12),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${track.title} - ${track.artist}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      player.isPlaying.value ? Icons.pause_circle : Icons.play_circle,
                      color: SodaPalette.accent,
                      size: 36,
                    ),
                    onPressed: player.togglePlayPause,
                  ),
                ],
              ),
            );
          }),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: _messages.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, idx) {
                final m = _messages[idx];
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: SodaPalette.bgCard,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${m.sender}：',
                        style: const TextStyle(
                          color: SodaPalette.accent,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Expanded(child: Text(m.text)),
                      Text(
                        m.timeLabel,
                        style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 11),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _msgCtrl,
                      decoration: InputDecoration(
                        hintText: '和房间里的朋友聊点什么...',
                        filled: true,
                        fillColor: SodaPalette.bgCard,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(999),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: SodaPalette.accent,
                      foregroundColor: Colors.black,
                    ),
                    onPressed: () {
                      final txt = _msgCtrl.text.trim();
                      if (txt.isEmpty) return;
                      _msgCtrl.clear();
                      setState(() {
                        _messages.add(
                          ListenRoomMessage(
                            sender: library.nickname.value,
                            text: txt,
                            timeLabel: '刚刚',
                          ),
                        );
                      });
                    },
                    child: const Text('发送'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
