import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/network/api_service.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/theme/soda_theme.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final ApiService api = Get.find<ApiService>();
  final BachPlayerController player = Get.find<BachPlayerController>();
  late final TextEditingController _urlCtrl;

  @override
  void initState() {
    super.initState();
    _urlCtrl = TextEditingController(text: api.baseUrl.value);
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('音源与播放设置')),
      body: Obx(() {
        return ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: SodaPalette.bgCard,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '自建音频服务端地址',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: (api.serverOnline.value
                                  ? SodaPalette.accent
                                  : SodaPalette.gold)
                              .withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          api.serverOnline.value ? '在线流模式' : '本地合成离线模式',
                          style: TextStyle(
                            color: api.serverOnline.value
                                ? SodaPalette.accent
                                : SodaPalette.gold,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _urlCtrl,
                    decoration: const InputDecoration(
                      hintText: 'http://127.0.0.1:8790',
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: SodaPalette.accent,
                        foregroundColor: Colors.black,
                      ),
                      onPressed: () async {
                        await api.updateBaseUrl(_urlCtrl.text);
                        await player.loadChannel(player.activeChannel.value, autoPlay: false);
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                api.serverOnline.value
                                    ? '已成功连接本地音源服务'
                                    : '未检测到远端服务，已无缝启用内置合成音源',
                              ),
                            ),
                          );
                        }
                      },
                      child: const Text('检测并保存服务端地址'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      }),
    );
  }
}
