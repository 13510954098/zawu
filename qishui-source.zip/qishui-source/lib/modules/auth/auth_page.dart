import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final LibraryController library = Get.find<LibraryController>();
  late final TextEditingController _nickCtrl;
  late final TextEditingController _bioCtrl;

  @override
  void initState() {
    super.initState();
    _nickCtrl = TextEditingController(text: library.nickname.value);
    _bioCtrl = TextEditingController(text: library.signature.value);
  }

  @override
  void dispose() {
    _nickCtrl.dispose();
    _bioCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('个人资料设置')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: _nickCtrl,
            decoration: const InputDecoration(labelText: '听友昵称'),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _bioCtrl,
            decoration: const InputDecoration(labelText: '音乐心情签名'),
          ),
          const SizedBox(height: 28),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: SodaPalette.accent,
              foregroundColor: Colors.black,
              minimumSize: const Size.fromHeight(48),
            ),
            onPressed: () async {
              await library.updateProfile(
                newNick: _nickCtrl.text,
                newBio: _bioCtrl.text,
              );
              Get.back();
            },
            child: const Text('保存资料', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }
}
