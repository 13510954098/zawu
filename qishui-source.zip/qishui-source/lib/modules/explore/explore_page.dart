import 'package:flutter/material.dart';
import '../../app/luna_theme.dart';
import '../../core/models/luna_models.dart';
import '../../core/network/demo_catalog.dart';
import '../../core/state/luna_app_state.dart';

class ExplorePage extends StatefulWidget {
  final LunaAppState state;
  final VoidCallback onJumpToFeed;

  const ExplorePage({
    super.key,
    required this.state,
    required this.onJumpToFeed,
  });

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<LunaTrack> _results = DemoCatalog.initialTracks();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _doSearch(String q) async {
    final res = await widget.state.api.searchTracks(q);
    if (mounted) {
      setState(() {
        _results = res;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('发现电台与热歌榜', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(
            controller: _searchCtrl,
            onChanged: _doSearch,
            decoration: InputDecoration(
              hintText: '搜索歌曲、音乐人、心情电台...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: LunaTheme.cardBg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: DemoCatalog.hotKeywords.map((kw) {
              return ActionChip(
                label: Text(kw, style: const TextStyle(fontSize: 12)),
                onPressed: () {
                  _searchCtrl.text = kw;
                  _doSearch(kw);
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          const Text('全场景情绪电台', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2.3,
            children: DemoCatalog.moodScenes.skip(1).map((scene) {
              return InkWell(
                onTap: () async {
                  await widget.state.changeMood(scene);
                  widget.onJumpToFeed();
                },
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: LunaTheme.cardBg,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.radio_rounded, color: LunaTheme.neonMint),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(scene, style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          Text('曲库精选 (${_results.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          ..._results.map((t) {
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                color: LunaTheme.cardBg,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Material(
                color: Colors.transparent,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Color(t.colorPrimary),
                    child: const Icon(Icons.music_note, color: Colors.white),
                  ),
                  title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${t.artist} · ${t.moodScene} · ${t.bpm} BPM'),
                  trailing: IconButton(
                    icon: const Icon(Icons.play_circle_fill_rounded, color: LunaTheme.neonMint, size: 30),
                    onPressed: () async {
                      await widget.state.changeMood('全部推荐');
                      final idx = widget.state.feedTracks.indexWhere((x) => x.id == t.id);
                      if (idx >= 0) {
                        await widget.state.selectTrackIndex(idx, autoPlay: true);
                      }
                      widget.onJumpToFeed();
                    },
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
