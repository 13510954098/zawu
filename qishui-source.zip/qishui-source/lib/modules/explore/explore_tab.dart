import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../app/routes/app_routes.dart';
import '../../core/models/music_models.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/theme/soda_theme.dart';

class ExploreTab extends StatelessWidget {
  const ExploreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final player = Get.find<BachPlayerController>();
    const moods = [
      ('随心漫游', '一键进入懂你的私人气泡电台', Icons.bolt_rounded, Color(0xFF00F090)),
      ('深夜独处', '低饱和度慢歌与雨声陪伴', Icons.nights_stay_rounded, Color(0xFF7C5CFF)),
      ('公路兜风', '高能合成波与律动电子节拍', Icons.speed_rounded, Color(0xFF00BBF9)),
      ('东方新韵', '笛箫琵琶与现代律动交织', Icons.spa_rounded, Color(0xFFFF6B8B)),
    ];

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 100),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '发现音乐',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
              ),
              IconButton(
                icon: const Icon(Icons.equalizer_rounded, color: SodaPalette.accent),
                onPressed: () => player.loadChannel('随心听', autoPlay: true),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () => Get.toNamed(AppRoutes.search),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              decoration: BoxDecoration(
                color: SodaPalette.bgCard,
                borderRadius: BorderRadius.circular(999),
              ),
              child: const Row(
                children: [
                  Icon(Icons.search_rounded, color: SodaPalette.textSecondary, size: 20),
                  SizedBox(width: 10),
                  Text(
                    '搜索歌曲、音乐人、心情电台...',
                    style: TextStyle(color: SodaPalette.textSecondary, fontSize: 14),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            '场景心情电台',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: moods.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, idx) {
                final m = moods[idx];
                return GestureDetector(
                  onTap: () {
                    final targetChannel = switch (idx) {
                      1 => '深夜治愈',
                      2 => '电音派对',
                      3 => '国风新韵',
                      _ => '随心听',
                    };
                    player.loadChannel(targetChannel, autoPlay: true);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('正在播放「${m.$1}」电台')),
                    );
                  },
                  child: Container(
                    width: 168,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          m.$4.withValues(alpha: 0.32),
                          SodaPalette.bgCard,
                        ],
                      ),
                      border: Border.all(color: m.$4.withValues(alpha: 0.35)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Icon(m.$3, color: m.$4, size: 26),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              m.$1,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              m.$2,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: SodaPalette.textSecondary,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 26),
          const Text(
            '官方风向榜',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 156,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: MockCatalog.charts.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, idx) {
                final chart = MockCatalog.charts[idx];
                return _buildChartCard(chart);
              },
            ),
          ),
          const SizedBox(height: 26),
          const Text(
            '甄选歌单广场',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: MockCatalog.playlists.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.08,
            ),
            itemBuilder: (_, idx) {
              final pl = MockCatalog.playlists[idx];
              return GestureDetector(
                onTap: () => Get.toNamed(AppRoutes.playlistDetail, arguments: pl),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        pl.accentColor.withValues(alpha: 0.28),
                        SodaPalette.bgCard,
                      ],
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: Colors.black26,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              pl.tag,
                              style: TextStyle(
                                color: pl.accentColor,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          Text(
                            '▶ ${SodaTheme.formatCount(pl.playCount)}',
                            style: const TextStyle(color: Colors.white70, fontSize: 11),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            pl.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 15.5,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            pl.subtitle,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: SodaPalette.textSecondary,
                              fontSize: 11.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildChartCard(MusicPlaylist chart) {
    final previewTracks = chart.trackIds
        .take(3)
        .map(
          (id) => MockCatalog.tracks.firstWhere(
            (t) => t.id == id,
            orElse: () => MockCatalog.tracks.first,
          ),
        )
        .toList();

    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.playlistDetail, arguments: chart),
      child: Container(
        width: 236,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: SodaPalette.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: chart.accentColor.withValues(alpha: 0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  chart.title,
                  style: TextStyle(
                    color: chart.accentColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  chart.tag,
                  style: const TextStyle(
                    color: SodaPalette.textSecondary,
                    fontSize: 10.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...List.generate(previewTracks.length, (i) {
              final t = previewTracks[i];
              return Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Text(
                  '${i + 1}. ${t.title} - ${t.artist}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12.5, color: Colors.white),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
