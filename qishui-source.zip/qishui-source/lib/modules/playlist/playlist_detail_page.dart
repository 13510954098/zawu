import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/music_models.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/theme/soda_theme.dart';

class PlaylistDetailPage extends StatelessWidget {
  const PlaylistDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    final player = Get.find<BachPlayerController>();
    final arg = Get.arguments;
    final playlist = arg is MusicPlaylist ? arg : MockCatalog.playlists.first;
    final tracks = playlist.trackIds
        .map(
          (id) => MockCatalog.tracks.firstWhere(
            (t) => t.id == id,
            orElse: () => MockCatalog.tracks.first,
          ),
        )
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(playlist.tag)),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  playlist.accentColor.withValues(alpha: 0.35),
                  SodaPalette.bgCard,
                ],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  playlist.title,
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  playlist.subtitle,
                  style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '共 ${tracks.length} 首 · 播放 ${SodaTheme.formatCount(playlist.playCount)}',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: SodaPalette.accent,
                        foregroundColor: Colors.black,
                      ),
                      onPressed: () {
                        player.replaceQueueAndPlay(tracks, 0);
                        Get.back();
                      },
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('播放全部'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: Material(
              color: Colors.transparent,
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: tracks.length,
                itemBuilder: (_, idx) {
                  final t = tracks[idx];
                  return ListTile(
                    leading: Text(
                      '${idx + 1}'.padLeft(2, '0'),
                      style: const TextStyle(
                        color: SodaPalette.accent,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                      ),
                    ),
                    title: Text(t.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(
                      '${t.artist} · ${t.album}',
                      style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                    ),
                    trailing: Text(
                      t.qualityBadge,
                      style: const TextStyle(color: SodaPalette.accent, fontSize: 11),
                    ),
                    onTap: () {
                      player.replaceQueueAndPlay(tracks, idx);
                      Get.back();
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
