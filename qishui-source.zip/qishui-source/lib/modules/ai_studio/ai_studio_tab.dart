import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/music_models.dart';
import '../../core/network/api_service.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/state/library_controller.dart';
import '../../core/theme/soda_theme.dart';

class AiStudioTab extends StatefulWidget {
  const AiStudioTab({super.key});

  @override
  State<AiStudioTab> createState() => _AiStudioTabState();
}

class _AiStudioTabState extends State<AiStudioTab> {
  final ApiService api = Get.find<ApiService>();
  final BachPlayerController player = Get.find<BachPlayerController>();
  final LibraryController library = Get.find<LibraryController>();

  final TextEditingController _promptCtrl = TextEditingController(
    text: '夏夜海边兜风的薄荷味合成器流行曲',
  );
  final TextEditingController _lyricsCtrl = TextEditingController();
  final TextEditingController _chatCtrl = TextEditingController();

  final List<String> _styles = const [
    '赛博合成波',
    '海风 CityPop',
    '新国风电子',
    '深夜 Lo-Fi',
    '独立摇滚',
  ];
  String _selectedStyle = '海风 CityPop';
  bool _composing = false;
  int _modeIndex = 0;

  final List<({bool fromUser, String text, List<MusicTrack> picks})> _chatHistory = [
    (
      fromUser: false,
      text: '你好！我是汽水灵感助手，告诉我你现在的心情或场景，我为你挑歌或直接生成新曲。',
      picks: const <MusicTrack>[],
    ),
  ];

  @override
  void dispose() {
    _promptCtrl.dispose();
    _lyricsCtrl.dispose();
    _chatCtrl.dispose();
    super.dispose();
  }

  Future<void> _handleCompose() async {
    if (_composing) return;
    setState(() => _composing = true);
    final created = await api.composeAiTrack(
      prompt: _promptCtrl.text,
      style: _selectedStyle,
      customLyrics: _lyricsCtrl.text,
    );
    await library.registerAiTrack(created);
    await player.playSpecificTrack(created);
    if (mounted) {
      setState(() => _composing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已生成并开始播放《${created.title}》')),
      );
    }
  }

  void _handleAskAssistant(String query) {
    final clean = query.trim();
    if (clean.isEmpty) return;
    _chatCtrl.clear();
    List<MusicTrack> matched;
    if (clean.contains('夜') || clean.contains('眠') || clean.contains('雨')) {
      matched = MockCatalog.tracks.where((t) => t.channel == '深夜治愈').toList();
    } else if (clean.contains('国风') || clean.contains('古') || clean.contains('江南')) {
      matched = MockCatalog.tracks.where((t) => t.channel == '国风新韵').toList();
    } else if (clean.contains('车') || clean.contains('电') || clean.contains('嗨')) {
      matched = MockCatalog.tracks.where((t) => t.channel == '电音派对').toList();
    } else {
      matched = MockCatalog.tracks.take(3).toList();
    }
    setState(() {
      _chatHistory.add((fromUser: true, text: clean, picks: const <MusicTrack>[]));
      _chatHistory.add((
        fromUser: false,
        text: '根据「$clean」为你挑选了 ${matched.length} 首契合当下氛围的单曲，轻触即可播放：',
        picks: matched,
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'AI 音乐实验室',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                ),
                SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, label: Text('灵感写歌')),
                    ButtonSegment(value: 1, label: Text('对话找歌')),
                  ],
                  selected: {_modeIndex},
                  onSelectionChanged: (s) => setState(() => _modeIndex = s.first),
                ),
              ],
            ),
          ),
          Expanded(
            child: _modeIndex == 0 ? _buildComposePane() : _buildAssistantPane(),
          ),
        ],
      ),
    );
  }

  Widget _buildComposePane() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(
              colors: [
                SodaPalette.accent.withValues(alpha: 0.2),
                SodaPalette.accentSecondary.withValues(alpha: 0.22),
              ],
            ),
            border: Border.all(color: SodaPalette.accent.withValues(alpha: 0.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '输入一句话画面，实时合成多声部立体声曲目',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _promptCtrl,
                maxLines: 2,
                decoration: InputDecoration(
                  labelText: '灵感主题描述',
                  filled: true,
                  fillColor: SodaPalette.bgPrimary,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                '曲风编曲模型',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _styles.map((st) {
                  final active = st == _selectedStyle;
                  return ChoiceChip(
                    label: Text(st),
                    selected: active,
                    selectedColor: SodaPalette.accent.withValues(alpha: 0.28),
                    onSelected: (_) => setState(() => _selectedStyle = st),
                  );
                }).toList(),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _lyricsCtrl,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: '自定义歌词（留空则自动生成意境歌词）',
                  filled: true,
                  fillColor: SodaPalette.bgPrimary,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: SodaPalette.accent,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: _composing ? null : _handleCompose,
                  icon: _composing
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.auto_awesome_rounded),
                  label: Text(
                    _composing ? '正在合成和弦与音轨...' : '立即生成并试听',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text(
          '我的 AI 原创作品库',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 10),
        Obx(() {
          final items = library.aiCreatedTracks;
          if (items.isEmpty) {
            return Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: SodaPalette.bgCard,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Center(
                child: Text(
                  '点击上方按钮即可生成你的第一首专属单曲',
                  style: TextStyle(color: SodaPalette.textSecondary),
                ),
              ),
            );
          }
          return Material(
            color: Colors.transparent,
            child: Column(
              children: items.map((trk) {
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: trk.primaryColor.withValues(alpha: 0.25),
                      child: Icon(Icons.music_note_rounded, color: trk.primaryColor),
                    ),
                    title: Text(
                      trk.title,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(
                      '${trk.artist} · ${trk.bpm} BPM',
                      style: const TextStyle(
                        color: SodaPalette.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    trailing: const Icon(
                      Icons.play_circle_fill_rounded,
                      color: SodaPalette.accent,
                      size: 30,
                    ),
                    onTap: () => player.playSpecificTrack(trk),
                  ),
                );
              }).toList(),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildAssistantPane() {
    return Column(
      children: [
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 16),
            itemCount: _chatHistory.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (_, idx) {
              final msg = _chatHistory[idx];
              return Align(
                alignment: msg.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 320),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: msg.fromUser
                        ? SodaPalette.accent.withValues(alpha: 0.22)
                        : SodaPalette.bgCard,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(msg.text, style: const TextStyle(fontSize: 14, height: 1.4)),
                      if (msg.picks.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Material(
                          color: Colors.transparent,
                          child: Column(
                            children: msg.picks.map((t) {
                              return ListTile(
                                dense: true,
                                contentPadding: EdgeInsets.zero,
                                leading: Icon(Icons.play_arrow_rounded, color: t.primaryColor),
                                title: Text(t.title),
                                subtitle: Text(
                                  t.artist,
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: SodaPalette.textSecondary,
                                  ),
                                ),
                                onTap: () => player.playSpecificTrack(t),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 94),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _chatCtrl,
                  onSubmitted: _handleAskAssistant,
                  decoration: InputDecoration(
                    hintText: '例如：推荐适合雨夜助眠或开车听的歌...',
                    filled: true,
                    fillColor: SodaPalette.bgCard,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(999),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                style: IconButton.styleFrom(
                  backgroundColor: SodaPalette.accent,
                  foregroundColor: Colors.black,
                ),
                onPressed: () => _handleAskAssistant(_chatCtrl.text),
                icon: const Icon(Icons.send_rounded),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
