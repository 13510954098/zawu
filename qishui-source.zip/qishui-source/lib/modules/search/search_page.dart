import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../core/models/music_models.dart';
import '../../core/network/api_service.dart';
import '../../core/network/mock_catalog.dart';
import '../../core/player/bach_player_controller.dart';
import '../../core/theme/soda_theme.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final ApiService api = Get.find<ApiService>();
  final BachPlayerController player = Get.find<BachPlayerController>();
  final TextEditingController _ctrl = TextEditingController();

  List<MusicTrack> _results = MockCatalog.tracks;
  final List<String> _recentQueries = ['薄荷汽水', '霓虹高架桥'];

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _runSearch(String q) async {
    final clean = q.trim();
    if (clean.isNotEmpty && !_recentQueries.contains(clean)) {
      _recentQueries.insert(0, clean);
    }
    final list = await api.searchTracks(clean);
    if (mounted) {
      setState(() => _results = list);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(right: 16),
          child: TextField(
            controller: _ctrl,
            autofocus: true,
            onChanged: _runSearch,
            onSubmitted: _runSearch,
            decoration: InputDecoration(
              hintText: '搜索歌名、歌手、专辑或流派',
              isDense: true,
              filled: true,
              fillColor: SodaPalette.bgCard,
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(999),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_ctrl.text.trim().isEmpty) ...[
            const Text('热搜趋势', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: MockCatalog.hotKeywords.map((kw) {
                return ActionChip(
                  label: Text(kw),
                  onPressed: () {
                    _ctrl.text = kw;
                    _runSearch(kw);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 18),
            const Text('搜索历史', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _recentQueries.map((rq) {
                return ActionChip(
                  avatar: const Icon(Icons.history_rounded, size: 15),
                  label: Text(rq),
                  onPressed: () {
                    _ctrl.text = rq;
                    _runSearch(rq);
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
          ],
          Text(
            '单曲结果 (${_results.length})',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          ),
          const SizedBox(height: 10),
          Material(
            color: Colors.transparent,
            child: Column(
              children: _results.map((item) {
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: item.primaryColor.withValues(alpha: 0.24),
                      child: Icon(Icons.music_note_rounded, color: item.primaryColor),
                    ),
                    title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(
                      '${item.artist} · ${item.album} · ${item.qualityBadge}',
                      style: const TextStyle(color: SodaPalette.textSecondary, fontSize: 12),
                    ),
                    trailing: const Icon(Icons.play_arrow_rounded, color: SodaPalette.accent),
                    onTap: () {
                      player.playSpecificTrack(item);
                      Get.back();
                    },
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
